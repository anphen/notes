

#import "HDServerSuperviseCategoryItemView.h"
#import <Masonry.h>

extern NSString *const RESETCOLORNOTIFICATION;

@interface HDServerSuperviseCategoryItemView()

@end

@implementation HDServerSuperviseCategoryItemView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.contentLabel];
        
        [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(resetColor:) name:RESETCOLORNOTIFICATION object:@"color"];
    }
    return self;
}

- (UILabel *)contentLabel{
    if (!_contentLabel) {
        _contentLabel = [[UILabel alloc]init];
        _contentLabel.font = [UIFont systemFontOfSize:13];
        _contentLabel.textColor = [UIColor blackColor];
        _contentLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _contentLabel;
}

- (void)resetColor:(NSNotification *)notification
{
    if (self.index == [[notification.userInfo objectForKey:@"index"]integerValue]) {
        return;
    }
    self.contentLabel.textColor = [notification.userInfo objectForKey:@"color"];
    self.contentLabel.font = [notification.userInfo objectForKey:@"font"];
}

- (void)setItemContent:(NSString *)itemContent
{
    _itemContent = itemContent;
    self.contentLabel.text = itemContent;
}
- (void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

@end
