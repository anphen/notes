
#import <UIKit/UIKit.h>

@interface UIView(_reuseIdentifier)

@property (nonatomic, copy) NSString *reuseIdentifier;          //复用标识
@property (nonatomic, copy) NSString *isInScreen;

@end

@class HDServerSupervisePageCollectionView;

@protocol HDPageCollectionViewDelegate <NSObject>

@optional
- (void)HDPageViewDidEndChangeIndex:(HDServerSupervisePageCollectionView *)pageView currentView:(UIView *)view;

- (void)HDPageViewDidScroll:(UIScrollView *)scrollView direction:(NSString *)direction;

- (void)HDPageViewWillBeginDragging:(HDServerSupervisePageCollectionView *)pageView;

@end

@protocol HDPageCollectionViewDataSource <NSObject>

@required
- (NSInteger)numberOfItemsInZXPageCollectionView:(HDServerSupervisePageCollectionView *)HDPageCollectionView;
- (UIView *)HDPageCollectionView:(HDServerSupervisePageCollectionView *)HDPageCollectionView
              viewForItemAtIndex:(NSInteger)index;

@end

@interface HDServerSupervisePageCollectionView : UIView

@property (nonatomic, weak) id<HDPageCollectionViewDelegate> delegate;
@property (nonatomic, weak) id<HDPageCollectionViewDataSource> dataSource;
@property (nonatomic, strong) UIScrollView *mainScrollView;
@property (nonatomic, assign) NSInteger currentIndex;
@property (nonatomic, copy) NSString *noAnimationIndex;
@property (nonatomic, assign) BOOL isAnimation;

- (void)reloadPageView;

- (void)registerClass:(Class)viewClass forViewWithReuseIdentifier:(NSString *)identifier;

- (UIView *)dequeueReuseViewWithReuseIdentifier:(NSString *)identifier forIndex:(NSInteger)index;

- (void)moveToIndex:(NSInteger)index animation:(BOOL)animation;

@end
