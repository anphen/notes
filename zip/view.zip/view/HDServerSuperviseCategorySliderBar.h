
#import <UIKit/UIKit.h>

@interface UIView(ZXExtension)

@property (assign, nonatomic) CGFloat width;
@property (assign, nonatomic) CGFloat height;
@property (assign, nonatomic) CGFloat x;
@property (assign, nonatomic) CGFloat y;

@end


@protocol HDServerSuperviseCategorySliderBarDelegate <NSObject>

- (void)didSelectedIndex:(NSInteger)index;

@end

@interface HDServerSuperviseCategorySliderBar : UIView

@property (nonatomic, strong) NSArray *itemArray;
@property (nonatomic, assign) NSInteger originIndex;
@property (nonatomic, weak) id<HDServerSuperviseCategorySliderBarDelegate> delegate;

@property (nonatomic, assign) BOOL isMoniteScroll;
@property (nonatomic, strong) UIScrollView *moniterScrollView;

@property (nonatomic, assign) CGFloat scrollViewLastContentOffset;

@property (nonatomic, strong) UIColor *textNormalcolor;
@property (nonatomic, strong) UIColor *textSelectcolor;

@property (nonatomic, strong) UIFont *normalFont;
@property (nonatomic, strong) UIFont *selectFont;

@property (nonatomic, strong) UIColor *indicatorColor;

- (void)setSelectIndex:(NSInteger)index;

- (void)adjustIndicateViewX:(UIScrollView *)scrollView direction:(NSString *)direction;

@end
