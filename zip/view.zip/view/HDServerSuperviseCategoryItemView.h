
#import <UIKit/UIKit.h>

@interface HDServerSuperviseCategoryItemView : UICollectionViewCell

@property (nonatomic, copy) NSString *itemContent;
@property (nonatomic, strong) UILabel *contentLabel;
@property (nonatomic, assign) NSInteger index;

@end
