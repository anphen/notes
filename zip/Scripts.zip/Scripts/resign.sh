#!/bin/bash
#### 功能
# 重新签名ipa
# 1.修改ipa的网络环境(prd、pre这些)、bundleid、显示名称
# 2.替换ipa中的framework，frmaework要放在ipa同级目录下
#### 使用方法
# export RESIGN_CERTIFICATE="iPhone Distribution: Suning Commerce Group Co.,Ltd. (76M3JYH4P2)"
# ./resign.sh \                                         shell脚本路径
# /xxx/1567641849203.ipa \                              ipa路径
# -urltype--0 \                                         网络类型，0-prd，1-pre
# -bundleid--SuningEMall \                              bundleid，SuningEMall
# -bundlename--苏宁易购 \                                 app桌面显示名称，苏宁易购,
# -framework                                            是否替换framework,替换的framework要放在ipa同级目录下

set -e

# 基本变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

# 授权证书
# 描述文件
PROVISIONING_PROFILE="6ef5a844-71fe-40fb-b799-c2688cad842b"
PROVISIONING_PROFILE_SPECIFIER="SuningEnterprise"
DEVELOPMENT_TEAM="5E2PGY2377"
# 证书
CODE_SIGN_IDENTITY="011EBD34F82EE293AF72D5AFA739092C0932433A"
CODE_SIGN_IDENTITY_SPECIFIER="iPhone Distribution: Suning Appliance Co., Ltd."

# 兼容C证书
# 描述文件
C_PROVISIONING_PROFILE="ebad1e74-19d9-49a3-b47c-6fa46b6d3efa"
C_PROVISIONING_PROFILE_SPECIFIER="SuningEnterprise"
C_DEVELOPMENT_TEAM="5E2PGY2377"
# 证书
C_CODE_SIGN_IDENTITY="011EBD34F82EE293AF72D5AFA739092C0932433A"
C_CODE_SIGN_IDENTITY_SPECIFIER="iPhone Distribution: Suning Appliance Co., Ltd."
C_CERTIFICATE_C_CHECK_COUNT=0
# 描述文件和证书都要有
if [[ -e ~/Library/MobileDevice/Provisioning\ Profiles/${C_PROVISIONING_PROFILE}.mobileprovision ]]; then
    C_CERTIFICATE_C_CHECK_COUNT=$((${C_CERTIFICATE_C_CHECK_COUNT}+1))
fi
if [[ "$(security find-identity -v -p codesigning | grep "${C_CODE_SIGN_IDENTITY}")" != "" ]]; then
    C_CERTIFICATE_C_CHECK_COUNT=$((${C_CERTIFICATE_C_CHECK_COUNT}+1))
fi
if [[ ${C_CERTIFICATE_C_CHECK_COUNT} -eq 2 ]]; then
    # 描述文件
    PROVISIONING_PROFILE=${C_PROVISIONING_PROFILE}
    PROVISIONING_PROFILE_SPECIFIER=${C_PROVISIONING_PROFILE_SPECIFIER}
    DEVELOPMENT_TEAM=${C_DEVELOPMENT_TEAM}
    # 证书
    CODE_SIGN_IDENTITY=${C_CODE_SIGN_IDENTITY}
    CODE_SIGN_IDENTITY_SPECIFIER=${C_CODE_SIGN_IDENTITY_SPECIFIER}
fi

# 使用指定的证书重新签名
if [[ ! -z ${RESIGN_CERTIFICATE} ]]; then
    # 描述文件
    PROVISIONING_PROFILE=""
    PROVISIONING_PROFILE_SPECIFIER=""
    DEVELOPMENT_TEAM=""
    # 证书
    CODE_SIGN_IDENTITY=${RESIGN_CERTIFICATE}
    CODE_SIGN_IDENTITY_SPECIFIER=${RESIGN_CERTIFICATE}

    echo "using certificate:        ${RESIGN_CERTIFICATE}"
fi

# parameter1 IPA_PATH
IPA_PATH=$1
if [ ! -e ${IPA_PATH} ];then
    echo "not found file ${IPA_PATH}"
    exit 0
fi
if [[ ${IPA_PATH} == "" ]] || [[ ! ${IPA_PATH} =~ ".ipa" ]];then
    echo "${IPA_PATH} is not a ipa file"
    exit 0
fi
if [[ $(dirname ${IPA_PATH}) == "." ]]; then
    IPA_PATH="$(pwd)/${IPA_PATH}"
fi
IPA_NAME=$(basename ${IPA_PATH})

BUILD_DIRECTORY=$(dirname ${IPA_PATH})
cd ${BUILD_DIRECTORY}

IPA_URLCONFIG=""
IPA_BUNDLE_IDENTIFIER=""
IPA_BUNDLE_DISPLAY_NAME=""
IPA_REPLACE_FRAMEWORK=false
for arg in "$@"
do
    if [[ $arg =~ "-urltype--" ]]; then
        IPA_URLCONFIG=${arg:10}
    elif [[ $arg =~ "-bundleid--" ]]; then
        IPA_BUNDLE_IDENTIFIER=${arg:11}
    elif [[ $arg =~ "-bundlename--" ]]; then
        IPA_BUNDLE_DISPLAY_NAME=${arg:13}
    elif [[ $arg == "-framework" ]]; then
        IPA_REPLACE_FRAMEWORK=true
    fi
done

# 参数检查，没有任何参数提示报错
if [[ ${IPA_URLCONFIG} == "" ]] \
    && [[ ${IPA_BUNDLE_IDENTIFIER} == "" ]] \
    && [[ ${IPA_BUNDLE_DISPLAY_NAME} == "" ]] \
    && ! ${IPA_REPLACE_FRAMEWORK}; then
    echo "not found -urltype-- or -bundleid-- or -bundlename-- or -framework"
    exit 0
fi

# IPA_URLCONFIG
if [[ ${IPA_URLCONFIG} != "" ]] \
    && [[ ${IPA_URLCONFIG} != "0" ]] \
    && [[ ${IPA_URLCONFIG} != "1" ]] \
    && [[ ${IPA_URLCONFIG} != "2" ]] \
    && [[ ${IPA_URLCONFIG} != "3" ]] \
    && [[ ${IPA_URLCONFIG} != "4" ]]; then
    echo "urltype should be one of 0,1,2,3,4"
    exit 0
fi

# frameworks
FRAMEWORK_NAME_ARRAY=()
if ${IPA_REPLACE_FRAMEWORK}; then
    for FRAMEWORK_PATH in $(find ${BUILD_DIRECTORY} -maxdepth 1 -name "*.framework")
    do 
        FRAMEWORK_NAME=$(basename ${FRAMEWORK_PATH})
        FRAMEWORK_NAME_ARRAY=(${FRAMEWORK_NAME_ARRAY[@]} ${FRAMEWORK_NAME})
        echo "${FRAMEWORK_NAME}"
    done
    if [[ ${#FRAMEWORK_NAME_ARRAY[@]} -eq 0 ]];then
        echo "no framework found in ${BUILD_DIRECTORY}"
    fi
fi

# echo 
echo "resign directory:         ${BUILD_DIRECTORY}"
echo "resign ipa:               ${IPA_NAME}"
if [[ ${IPA_URLCONFIG} != "" ]]; then
    echo "IPA_URLCONFIG:            ${IPA_URLCONFIG}"
fi
if [[ ${IPA_BUNDLE_IDENTIFIER} != "" ]]; then
    echo "IPA_BUNDLE_IDENTIFIER:    ${IPA_BUNDLE_IDENTIFIER}"
fi
if [[ ${IPA_BUNDLE_DISPLAY_NAME} != "" ]]; then
    echo "IPA_BUNDLE_DISPLAY_NAME:  ${IPA_BUNDLE_DISPLAY_NAME}"
fi
for FRAMEWORK_NAME in ${FRAMEWORK_NAME_ARRAY[@]} 
do
    echo "resign framework:         ${FRAMEWORK_NAME}"
done

# 解压ipa
echo ""
echo "解压ipa..."
BUILD_TMP_DIRECTORY="${BUILD_DIRECTORY}/z_tmp"
mkdir -p ${BUILD_TMP_DIRECTORY}
rm -rf ${BUILD_TMP_DIRECTORY}/*
echo "cmd: unzip -o -d ${BUILD_TMP_DIRECTORY} ${IPA_NAME} >/dev/null 2>&1"
unzip -o -d ${BUILD_TMP_DIRECTORY} ${IPA_NAME} >/dev/null 2>&1
cd ${BUILD_TMP_DIRECTORY}

# app_path
APP_NAME=$(ls ${BUILD_TMP_DIRECTORY}/Payload | head -1)
APP_NAME2=${APP_NAME%.app}   
APP_PATH="${BUILD_TMP_DIRECTORY}/Payload/${APP_NAME}"

# 修改 IPA_URLCONFIG
APP_URLCONFIG_PLIST_PATH="${APP_PATH}/SNUrlDomainManagerUrlType.plist"
if [[ ${IPA_URLCONFIG} != "" ]]; then
    echo ""
    echo "修改SNUrlDomainManagerUrlType.plist环境为:${IPA_URLCONFIG}"
    /usr/libexec/PlistBuddy -c "set URLConfig ${IPA_URLCONFIG}" ${APP_URLCONFIG_PLIST_PATH}
fi

# APP架构
APP_ARCHS=$(lipo -archs ${APP_PATH}/${APP_NAME2})

# 重签名列表
CODE_SIGN_FRAMEWORK_PATH_ARRAY=()
# 修改 IPA_BUNDLE_IDENTIFIER
APP_INFO_PLIST_PATH="${APP_PATH}/Info.plist"
CURRENT_BUNDLE_IDENTIFIER=$(/usr/libexec/PlistBuddy -c "print CFBundleIdentifier" ${APP_INFO_PLIST_PATH})
if [[ ${IPA_BUNDLE_IDENTIFIER} != "" ]] \
    && [[ "${IPA_BUNDLE_IDENTIFIER}" != "${CURRENT_BUNDLE_IDENTIFIER}" ]]; then
    echo ""
    echo "修改bundleid为:${IPA_BUNDLE_IDENTIFIER}"
    ORIGINAL_IPA_BUNDLE_IDENTIFIER=$(/usr/libexec/PlistBuddy -c "print CFBundleIdentifier" ${APP_INFO_PLIST_PATH})
    /usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${IPA_BUNDLE_IDENTIFIER}" ${APP_INFO_PLIST_PATH}

    # 替换plugins
    for PLUGIN_NAME in $(ls ${APP_PATH}/PlugIns)
    do
        PLUGIN_INFO_PLIST_PATH="${APP_PATH}/PlugIns/${PLUGIN_NAME}/Info.plist"
        ORIGINAL_PLUGIN_BUNDLE_IDENTIFIER=$(/usr/libexec/PlistBuddy -c "print CFBundleIdentifier" ${PLUGIN_INFO_PLIST_PATH})
        PLUGIN_BUNDLE_IDENTIFIER=${ORIGINAL_PLUGIN_BUNDLE_IDENTIFIER//${ORIGINAL_IPA_BUNDLE_IDENTIFIER}/${IPA_BUNDLE_IDENTIFIER}}
        /usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${PLUGIN_BUNDLE_IDENTIFIER}" ${PLUGIN_INFO_PLIST_PATH}
        # 加到重签名列表
        CODE_SIGN_FRAMEWORK_PATH_ARRAY=(${CODE_SIGN_FRAMEWORK_PATH_ARRAY[@]} ${APP_PATH}/PlugIns/${PLUGIN_NAME})
    done
fi

# 修改 IPA_BUNDLE_DISPLAY_NAME
APP_INFO_PLIST_STRING_PATH="${APP_PATH}/zh-Hans.lproj/InfoPlist.strings"
if [[ ${IPA_BUNDLE_DISPLAY_NAME} != "" ]]; then
    echo ""
    echo "修改ipa展示名称为:${IPA_BUNDLE_DISPLAY_NAME}"
    /usr/libexec/PlistBuddy -c "set CFBundleDisplayName ${IPA_BUNDLE_DISPLAY_NAME}" ${APP_INFO_PLIST_PATH}
    /usr/libexec/PlistBuddy -c "set CFBundleDisplayName ${IPA_BUNDLE_DISPLAY_NAME}" ${APP_INFO_PLIST_STRING_PATH}
fi

# 替换framework
for FRAMEWORK_NAME in ${FRAMEWORK_NAME_ARRAY[@]} 
do
    FRAMEWORK_NAME2=${FRAMEWORK_NAME%.framework}   

    # app中不存在对应framework，不处理
    if [ ! -e ${APP_PATH}/Frameworks/${FRAMEWORK_NAME} ];then
        echo ""
        echo "skip process ${FRAMEWORK_NAME}..."
        continue
    fi

    # 原framework中的文件
    FRAMEWORK_ORIGINAL_FILES=$(ls ${APP_PATH}/Frameworks/${FRAMEWORK_NAME})

    # 替换framework
    echo ""
    echo "替换${FRAMEWORK_NAME}..."
    echo "cmd: rm -rf ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}"
    rm -rf ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}
    echo "cp -rf ${BUILD_DIRECTORY}/${FRAMEWORK_NAME} ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}"
    cp -rf ${BUILD_DIRECTORY}/${FRAMEWORK_NAME} ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}
    echo "cmd: rm -rf ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}/Headers"
    rm -rf ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}/Headers
    echo "cmd: rm -rf ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}/Modules"
    rm -rf ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}/Modules
    
    # 移除framework多余的架构
    FRAMEWORK_ARCHS=$(lipo -info ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}/${FRAMEWORK_NAME2})
    for FRAMEWORK_ARCH in "armv7" "arm64" "x86_64"
    do
        if [[ ${FRAMEWORK_ARCHS} =~ "${FRAMEWORK_ARCH}" ]] && [[ ! ${APP_ARCHS} =~ "${FRAMEWORK_ARCH}" ]]; then
            echo ""
            echo "移除${FRAMEWORK_NAME} ${FRAMEWORK_ARCH}架构..."
            lipo ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}/${FRAMEWORK_NAME2} \
                -remove ${FRAMEWORK_ARCH} \
                -output ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}/${FRAMEWORK_NAME2}
        fi
    done

    # 覆盖资源
    # 之前framework.framework下没有的文件,全部移入mainBundle
    echo ""
    echo "移动${FRAMEWORK_NAME}中资源文件到mainBundle下..."
    for file in $(ls ${APP_PATH}/Frameworks/${FRAMEWORK_NAME})
    do
        SHOULD_MOVE=""
        # 需要移动的文件
        if [[ ! "${FRAMEWORK_ORIGINAL_FILES}" =~ "${file}" ]];then
            SHOULD_MOVE="1"
        fi
        # 需要文件
        if [[ ${SHOULD_MOVE} == "1" ]];then
            echo "移动${file}..."
            if [[ ${file} =~ "Assets.car" ]]; then
                echo "fail: Assets.car文件不可以覆盖，请检查framework打包配置"
                exit 0
            fi
            echo "cmd: rm -rf ${APP_PATH}/${file}"
            rm -rf ${APP_PATH}/${file}
            echo "cmd: mv ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}/${file} ${APP_PATH}/${file}"
            mv ${APP_PATH}/Frameworks/${FRAMEWORK_NAME}/${file} ${APP_PATH}/${file}
        fi
    done

    # 加到重签名列表
    CODE_SIGN_FRAMEWORK_PATH_ARRAY=(${CODE_SIGN_FRAMEWORK_PATH_ARRAY[@]} ${APP_PATH}/Frameworks/${FRAMEWORK_NAME})
done

# 重新签名
# x86_64架构不需要重新签名
if [[ ! ${APP_ARCHS} =~ "x86_64" ]]; then
    echo ""
    echo "重新签名..."
    echo "生成entitlements.plist..."
    codesign -d --entitlements - ${APP_PATH} > ${BUILD_TMP_DIRECTORY}/entitlements.plist
    for CODE_SIGN_FRAMEWORK_PATH in ${CODE_SIGN_FRAMEWORK_PATH_ARRAY[@]} 
    do
        if [ -e ${CODE_SIGN_FRAMEWORK_PATH} ];then
            echo ""
            echo "codesign $(basename ${CODE_SIGN_FRAMEWORK_PATH})..."
            # 兼容研发云环境，研发云keychain中存在多个有相同名称的证书，这儿只能指定证书的sha-1值
            # codesign -f -s "iPhone Distribution: Suning Appliance Co., Ltd." ${BUILD_TMP_DIRECTORY}/entitlements.plist ${CODE_SIGN_FRAMEWORK_PATH}
            codesign -f -s "${CODE_SIGN_IDENTITY}" ${BUILD_TMP_DIRECTORY}/entitlements.plist ${CODE_SIGN_FRAMEWORK_PATH}
        fi
    done
    echo ""
    echo "codesign $(basename ${APP_PATH})..."
    # 兼容研发云环境，研发云keychain中存在多个有相同名称的证书，这儿只能指定证书的sha-1值
    # codesign -f -s "iPhone Distribution: Suning Appliance Co., Ltd." --entitlements ${BUILD_TMP_DIRECTORY}/entitlements.plist ${APP_PATH}
    codesign -f -s "${CODE_SIGN_IDENTITY}" --entitlements ${BUILD_TMP_DIRECTORY}/entitlements.plist ${APP_PATH}
fi

# 打包ipa
echo ""
echo "打包ipa..."
echo "cmd: zip -r ${APP_NAME2}.ipa Payload >/dev/null 2>&1"
zip -r ${APP_NAME2}.ipa Payload >/dev/null 2>&1
mv ${APP_NAME2}.ipa ../${APP_NAME2}.ipa

# 清理文件
cd ${BUILD_DIRECTORY}
rm -rf ${BUILD_TMP_DIRECTORY}


echo ""
echo "success"

