#!/bin/sh
# xzoscar 2016/03/08
# 功能:更新三种类型库的代码
# 1.git repo仓库
#   1.1 更新代码
#   1.2 svn仓库提示
#   1.3 合并dev分支代码,并push
#   1.4 稀疏检出 sparse checkout
# 2.svn repo仓库
#   2.1 更新代码
# 3.git pod库
#   3.1 更新代码
#   3.2 切换Dev分支到当前版本Dev分支

# 环境
# set -e
export LANG=zh_CN.UTF-8
SCRIPT_DIR="$(cd `dirname $0`; pwd)"


# 变量
PROJECT_DIR=${SCRIPT_DIR}

SVN="svn"

GIT="git"

PODFILE_PATH=${PROJECT_DIR}/Podfile

GIT_BRANCH_VERSION=$(cat ${PODFILE_PATH} | grep 'PROJECT_VERSION.*=')
GIT_BRANCH_VERSION=$(echo ${GIT_BRANCH_VERSION} | cut -d \' -f 2 )
if [[ -z ${GIT_BRANCH_VERSION} ]]; then
    echo "error:PROJECT_VERSION为空"
    echo "请在Podfile中添加:\$PROJECT_VERSION = '9529'"
    exit 1
fi

GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

# 约定pod版本1.8.4
POD="pod"
PROMISE_POD_VERSION="1.8.4"
POD_VERSION=`${POD} _${PROMISE_POD_VERSION}_ --version`
if [ "${POD_VERSION}" != "${PROMISE_POD_VERSION}" ]; then
    echo "请使用cocoapods ${PROMISE_POD_VERSION}版本"
    exit 0
fi

SNEBUY_REPO_BUILD="${HOME}/.cocoapods/repos/SNEBuy_build_rsync"
mkdir -p ${SNEBUY_REPO_BUILD}

RSYNC_JOB_PATH="${SNEBUY_REPO_BUILD}/SuningEBuy-Framework-${GIT_BRANCH_VERSION}"

TMP_LOG_PATH="/tmp/tmp-ebuy.log"

#更新svn资源,还是使用本地的
UPDATE_PAYSDK=false
SKIP_POD=false
ONLY_POD=false
UPDATE_FRAMEWORK=true
CAN_STASH=false
CHECK_BRANCH=false
REVERT_SUB_PROJECT=false
if [[ $# -gt 0 ]]; then
    for arg in "$@"
    do
        if [[ $arg = "-paysdk" ]]; then
            UPDATE_PAYSDK=true
        elif [[ $arg = "-skip--pod" ]]; then
            SKIP_POD=true
        elif [[ $arg = "-pod" ]]; then
            ONLY_POD=true
        elif [[ $arg = "-framework" ]]; then
            echo ""
            echo "\033[34m 温馨提示：执行repo脚本不用再带-framework参数！！！ \033[0m"
            UPDATE_FRAMEWORK=true
        elif [[ $arg = "-stash" ]]; then
            CAN_STASH=true
        elif [[ $arg = "-check--branch" ]]; then
            CHECK_BRANCH=true
        elif [[ $arg = "-revert--subproject" ]]; then
            REVERT_SUB_PROJECT=true
        fi
    done
fi

# 数据格式
# SNLOGIN_PROJECT_INFO_ARRAY=(
#     "REPO_NAME"                  # REPO名称
#     "REPO_URL"                   # REPO地址
#     "REPO_BRANCH_NAME"           # REPO git分支名称
#     "REPO_PATH"                  # REPO clone下来的本地地址
#     "REPO_TYPE"                  # REPO类型，repo仓库还是pod库
# )
REPO_NAME_INDEX=0
REPO_URL_INDEX=1
REPO_BRANCH_NAME_INDEX=2
REPO_PATH_INDEX=3
REPO_TYPE_INDEX=4

PODS_REPO_INFO_ARRAY=(
    "SNEBuy_repos"
    "http://git.cnsuning.com/suningiospods/ipods.git"
    "" # "Dev_Br_repos",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${HOME}/.cocoapods/repos/SNEBuy_repos"
    "repo"
)

BUSS_REPO_INFO_ARRAY=(
    "SNEBuy_buss_repos"
    "http://git.cnsuning.com/suningiosbuss/iosbuss2020.git"
    "" # "Dev_Br_buss_repos",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${HOME}/.cocoapods/repos/SNEBuy_buss_repos"
    "repo"
)

YFBSDK_REPO_INFO_ARRAY=(
    "SNEBuy_YFBSDK"
    "http://b.svndoc.cnsuning.com/svn/SNPiOSPodsRepos/SNPayLibs"
    ""
    "${HOME}/.cocoapods/repos/SNEBuy_YFBSDK/"
    "repo"
)

YFBWallet_REPO_INFO_ARRAY=(
    "SNEBuy_YFBWallet"
    "http://b.svndoc.cnsuning.com/svn/SNPiOSPodsRepos/YFBWalletLibs"
    ""
    "${HOME}/.cocoapods/repos/SNEBuy_YFBWallet/"
    "repo"
)

SNDYNAMICFRAMEWORKS_INFO_ARRAY=(
    "SNDynamicFrameworks"
    "http://git.cnsuning.com/suningebuy/SNDynamicFrameworks.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNProjects/SNDynamicFrameworks"
    "pod"
)

SNDYNAMICFRAMEWORKS_FRAMEWORK_INFO_ARRAY=(
    "SNDynamicFrameworks_Framework"
    "http://opensource.cnsuning.com/suningebuy/sndynamicframeworks_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNDynamicFrameworks_Framework"
    "pod"
)

SNCOMMON_INFO_ARRAY=(
    "SNCommon"
    "http://git.cnsuning.com/suningebuy/SNCommon.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNProjects/SNCommon"
    "pod"
)

SNCOMMON_FRAMEWORK_INFO_ARRAY=(
    "SNCommon_Framework"
    "http://opensource.cnsuning.com/suningebuy/sncommon_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNCommon_Framework"
    "pod"
)

SNSL_FRAMEWORK_INFO_ARRAY=(
    "SNSL_Framework"
    "http://opensource.cnsuning.com/suningebuy/snsl_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNSL_Framework"
    "pod"
    "[git_9518]http://opensource.cnsuning.com/suningebuy/snsl_framework_2021.git"
)

SNSHPRODUCTDETAIL_FRAMEWORK_INFO_ARRAY=(
    "SNSHProductDetail_Framework"
    "http://opensource.cnsuning.com/suningebuy/snproduct_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNSHProductDetail_Framework"
    "pod"
    "[git_9518]http://opensource.cnsuning.com/suningebuy/snproduct_framework_2021.git"
)

SNPM_FRAMEWORK_INFO_ARRAY=(
    "SNPM_Framework"
    "http://opensource.cnsuning.com/suningebuy/snpm_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNPM_Framework"
    "pod"
)

SNLOGIN_FRAMEWORK_INFO_ARRAY=(
    "SNLogin_Framework"
    "http://opensource.cnsuning.com/suningebuy/snlogin_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNLogin_Framework"
    "pod"
)

SNMEMBER_FRAMEWORK_INFO_ARRAY=(
    "SNMember_Framework"
    "http://opensource.cnsuning.com/suningebuy/snmember_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNMember_Framework"
    "pod"
)

SNLIVE_FRAMEWORK_INFO_ARRAY=(
    "SNLive_Framework"
    "http://opensource.cnsuning.com/suningebuy/snlive_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNLive_Framework"
    "pod"
)

SNMK_FRAMEWORK_INFO_ARRAY=(
    "SNMK_Framework"
    "http://opensource.cnsuning.com/suningebuy/snmk_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNMK_Framework"
    "pod"
)

SNPG_FRAMEWORK_INFO_ARRAY=(
    "SNPG_Framework"
    "http://opensource.cnsuning.com/suningebuy/snpg_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNPG_Framework"
    "pod"
)

SNHOMEPAGE_FRAMEWORK_INFO_ARRAY=(
    "SNHomePage_Framework"
    "http://opensource.cnsuning.com/suningebuy/snhomepage_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNHomePage_Framework"
    "pod"
)

SNHWG_FRAMEWORK_INFO_ARRAY=(
    "SNHWG_Framework"
    "http://opensource.cnsuning.com/suningebuy/snhwg_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNHWG_Framework"
    "pod"
)

SNPW_FRAMEWORK_INFO_ARRAY=(
    "SNPW_Framework"
    "http://opensource.cnsuning.com/suningebuy/snpw_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNPW_Framework"
    "pod"
)

SNChannel_FRAMEWORK_INFO_ARRAY=(
    "SNChannel_Framework"
    "http://opensource.cnsuning.com/suningebuy/snchannel_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNChannel_Framework"
    "pod"
)

SNSM_FRAMEWORK_INFO_ARRAY=(
    "SNSM_Framework"
    "http://opensource.cnsuning.com/suningebuy/snsm_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNSM_Framework"
    "pod"
)

SNSHSEARCH_FRAMEWORK_INFO_ARRAY=(
    "SNSHSearch_Framework"
    "http://opensource.cnsuning.com/suningebuy/snshsearch_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNSHSearch_Framework"
    "pod"
)

SNYXCHAT_FRAMEWORK_INFO_ARRAY=(
    "SNYXChat_Framework"
    "http://opensource.cnsuning.com/suningebuy/snyxchat_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNYXChat_Framework"
    "pod"
    "[git_9518]http://opensource.cnsuning.com/suningebuy/snyxchat_framework_2021.git"
)

MSFS_FRAMEWORK_INFO_ARRAY=(
    "MSFS_Framework"
    "http://opensource.cnsuning.com/suningebuy/msfs_framework.git"
    "" # "${GIT_BRANCH_NAME}",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/MSFS_Framework"
    "pod"
    "[git_9518]http://opensource.cnsuning.com/suningebuy/msfs_framework_2021.git"
)

SNIRChatRoomSDK_INFO_ARRAY=(
    "SNIRChatRoomSDK"
    "http://opensource.cnsuning.com/suningebuy/SNIRChatRoomSDK.git"
    "" # "Dev_Br_115",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNIRChatRoomSDK"
    "pod"
)

SNMINIPSDK_INFO_ARRAY=(
    "SNMINIPSDK"
    "http://opensource.cnsuning.com/suningebuy/SNMINIPSDK.git"
    "" # "Dev_Br_136",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNMINIPSDK"
    "pod"
)

PPTVSDK_INFO_ARRAY=(
    "PPTVSDK"
    "http://opensource.cnsuning.com/suningebuy/PPTVSDK.git"
    "" # "Dev_Br_330",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/PPTVSDK"
    "pod"
    "[git_330]http://opensource.cnsuning.com/suningebuy/pptvsdk_2021.git"
)

YFBWALLETLIBS_INFO_ARRAY=(
    "YFBWalletLibs"
    "http://opensource.cnsuning.com/suningebuy/YFBWalletLibs.git"
    "" # "Dev_Br_tags_3.24.0",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/YFBWalletLibs"
    "pod"
)

YFBWALLETSDKDEPENDENCY_INFO_ARRAY=(
    "YFBWalletSDKDependency"
    "http://opensource.cnsuning.com/suningebuy/YFBWalletSDKDependency.git"
    "" # "Dev_Br_tags_3.17.0.0",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/YFBWalletSDKDependency"
    "pod"
)

SNMPAYSDK_INFO_ARRAY=(
    "SNMPaySDK"
    "http://opensource.cnsuning.com/suningebuy/SNMPaySDK.git"
    "" # "Dev_Br_tags_4.2.3.4",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNMPaySDK"
    "pod"
)

SNMPAYDEPENDENCY_INFO_ARRAY=(
    "SNMPayDependency"
    "http://opensource.cnsuning.com/suningebuy/SNMPayDependency.git"
    "" # "Dev_Br_tags_6.3.0.2",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNMPayDependency"
    "pod"
)

SASTATISTICSDK_INFO_ARRAY=(
    "SAStatistic_SDK"
    "http://opensource.cnsuning.com/suningebuy/SAStatistic_SDK.git"
    "" # "Dev_Br_371",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SAStatistic_SDK"
    "pod"
)

CLOUDYTRACESDK_INFO_ARRAY=(
    "CloudyTrace_SDK"
    "http://opensource.cnsuning.com/suningebuy/CloudyTrace_SDK.git"
    "" # "Dev_Br_2662",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/CloudyTrace_SDK"
    "pod"
)

SNXDCCPAGE_INFO_ARRAY=(
    "SNXDCCPage_Framework"
    "http://opensource.cnsuning.com/suningebuy/snxdccpage_framework.git"
    "" # "Dev_Br_9516",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNXDCCPage_Framework"
    "pod"
)

SNUPLOADVIDEO_INFO_ARRAY=(
    "SNUploadVideoFramework"
    "http://opensource.cnsuning.com/suningebuy/snuploadvideoframework.git"
    "" # "Dev_Br_105",改为在Podfile中维护:# ${REPO_NAME}_branch = 'Dev_Br_xxx'
    "${PROJECT_DIR}/SNPods/SNUploadVideoFramework"
    "pod"
)

# ALL_CODE_INFO_ARRAY
ALL_CODE_INFO_ARRAY=(
    PODS_REPO_INFO_ARRAY
    BUSS_REPO_INFO_ARRAY
    SNDYNAMICFRAMEWORKS_INFO_ARRAY
    SNDYNAMICFRAMEWORKS_FRAMEWORK_INFO_ARRAY
    SNCOMMON_INFO_ARRAY
    SNCOMMON_FRAMEWORK_INFO_ARRAY
    SNSL_FRAMEWORK_INFO_ARRAY
    SNSHPRODUCTDETAIL_FRAMEWORK_INFO_ARRAY
    SNPM_FRAMEWORK_INFO_ARRAY
    SNLOGIN_FRAMEWORK_INFO_ARRAY
    SNMEMBER_FRAMEWORK_INFO_ARRAY
    SNLIVE_FRAMEWORK_INFO_ARRAY
    SNMK_FRAMEWORK_INFO_ARRAY
    SNPG_FRAMEWORK_INFO_ARRAY
    SNHOMEPAGE_FRAMEWORK_INFO_ARRAY
    SNChannel_FRAMEWORK_INFO_ARRAY
    SNHWG_FRAMEWORK_INFO_ARRAY
    SNPW_FRAMEWORK_INFO_ARRAY
    SNSM_FRAMEWORK_INFO_ARRAY
    SNSHSEARCH_FRAMEWORK_INFO_ARRAY
    SNYXCHAT_FRAMEWORK_INFO_ARRAY
    MSFS_FRAMEWORK_INFO_ARRAY
    SNIRChatRoomSDK_INFO_ARRAY
    SNMINIPSDK_INFO_ARRAY
    PPTVSDK_INFO_ARRAY
    YFBWALLETLIBS_INFO_ARRAY
    YFBWALLETSDKDEPENDENCY_INFO_ARRAY
    SNMPAYSDK_INFO_ARRAY
    SNMPAYDEPENDENCY_INFO_ARRAY
    SASTATISTICSDK_INFO_ARRAY
    CLOUDYTRACESDK_INFO_ARRAY
    SNXDCCPAGE_INFO_ARRAY
    SNUPLOADVIDEO_INFO_ARRAY
)
if ${UPDATE_PAYSDK}; then
    ALL_CODE_INFO_ARRAY=(${ALL_CODE_INFO_ARRAY[@]} YFBSDK_REPO_INFO_ARRAY)
    ALL_CODE_INFO_ARRAY=(${ALL_CODE_INFO_ARRAY[@]} YFBWallet_REPO_INFO_ARRAY)
fi

# 从Podfile中读取branch
for REPO_INFO_ARRAY in ${ALL_CODE_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
    eval REPO_NAME=\${${REPO_INFO_ARRAY}[${REPO_NAME_INDEX}]}
    eval REPO_URL=\${${REPO_INFO_ARRAY}[${REPO_URL_INDEX}]}
    eval REPO_BRANCH_NAME=\${${REPO_INFO_ARRAY}[${REPO_BRANCH_NAME_INDEX}]}
    # 这儿不维护分支
    if [[ ! -z ${REPO_BRANCH_NAME} ]]; then
        echo "error: 分支改为在Podfile中维护，这儿置空"
        echo "请在Podfile中添加: # ${REPO_NAME}_branch = 'Dev_Br_xxx'"
        exit 1
    fi

    # 从Podfile中读取分支，并设置到REPO_INFO_ARRAY中
    REPO_BRANCH_NAME2=$(cat ${PODFILE_PATH} | grep ${REPO_NAME}_branch.*=)
    REPO_BRANCH_LINE_COUNT=$(echo ${REPO_BRANCH_NAME2} | grep -o ${REPO_NAME}_branch | wc -l)
    REPO_BRANCH_LINE_COUNT=$(echo ${REPO_BRANCH_LINE_COUNT})
    if [[ ${REPO_BRANCH_LINE_COUNT} -gt 1 ]]; then
        echo "error: Podfile中只能有一个# ${REPO_NAME}_branch = 'Dev_Br_xxx'"
        echo "当前存在${REPO_BRANCH_LINE_COUNT}个"
        exit 1
    fi
    REPO_BRANCH_NAME2=$(echo ${REPO_BRANCH_NAME2} | cut -d \' -f 2 )
    REPO_BRANCH_NAME2=${REPO_BRANCH_NAME2//\$\{PROJECT_VERSION\}/${GIT_BRANCH_VERSION}}
    eval ${REPO_INFO_ARRAY}[${REPO_BRANCH_NAME_INDEX}]=${REPO_BRANCH_NAME2}
    # git库必须指定branch
    if [[ -z "${REPO_BRANCH_NAME2}" ]]; then
        if [[ "${REPO_URL}" =~ "git.cnsuning.com" ]] \
            || [[ "${REPO_URL}" =~ "opensource.cnsuning.com" ]]; then
            echo "error: 没有在Podfile中找到${REPO_NAME}分支"
            echo "请在Podfile中添加: # ${REPO_NAME}_branch = 'Dev_Br_xxx'"
            exit 1
        fi
    fi
done

# 更新代码
BRANCH_ERROR_PROJECT_ARRAY=()
GITURL_ERROR_PROJECT_ARRAY=()
for REPO_INFO_ARRAY in ${ALL_CODE_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
    # -pod参数只执行pod install，不更新库
    if ${ONLY_POD}; then
        break
    fi 
    eval REPO_NAME=\${${REPO_INFO_ARRAY}[${REPO_NAME_INDEX}]}
    eval REPO_URL=\${${REPO_INFO_ARRAY}[${REPO_URL_INDEX}]}
    eval REPO_BRANCH_NAME=\${${REPO_INFO_ARRAY}[${REPO_BRANCH_NAME_INDEX}]}
    eval REPO_PATH=\${${REPO_INFO_ARRAY}[${REPO_PATH_INDEX}]}
    eval REPO_TYPE=\${${REPO_INFO_ARRAY}[${REPO_TYPE_INDEX}]}
    BRIEF_REPO_PATH=${REPO_PATH/${PROJECT_DIR}\//}
    BRIEF_REPO_PATH=${BRIEF_REPO_PATH/${HOME}/\~}

    if [[ "${REPO_TYPE}" == "repo" ]]; then
        echo ""
        echo "更新本地仓库\"${BRIEF_REPO_PATH}\" ..."
    else
        echo ""
        echo "更新\"${BRIEF_REPO_PATH}\" ..."
    fi

    # url检查
    {
        # repo信息数组长度
        eval REPO_INFO_ARRAY_LENGTH=\${#${REPO_INFO_ARRAY}[@]}
        # REPO_VERSION
        REPO_VERSION=${REPO_BRANCH_NAME##*_}
        # 9516改为9.5.16
        if [[ ! "${REPO_VERSION}" =~ "." ]]; then
            REPO_VERSION="${REPO_VERSION:0:1}.${REPO_VERSION:1:1}.${REPO_VERSION:2}"
        fi
        # REPO_VERSION_ARRAY
        REPO_VERSION_ARRAY=(${REPO_VERSION//\./ })
        REPO_VERSION_ARRAY_LENGTH=${#REPO_VERSION_ARRAY[@]}

        REPO_URL2=""
        # 从最后一个元素开始查找
        for ((TMP_INDEX=${REPO_INFO_ARRAY_LENGTH}-1; TMP_INDEX>=${REPO_TYPE_INDEX}+1; TMP_INDEX--))
        do
            # TMP_URL [git_9518]http://opensource.cnsuning.com/suningebuy/snsl_framework_2021.git
            eval TMP_URL=\${${REPO_INFO_ARRAY}[${TMP_INDEX}]}
            if [[ "${TMP_URL}" =~ "[git_" ]]; then
                # TMP_VERSION
                TMP_VERSION=${TMP_URL#[git_}
                TMP_VERSION=${TMP_VERSION%]*}
                # 9516改为9.5.16
                if [[ ! "${TMP_VERSION}" =~ "." ]]; then
                    TMP_VERSION="${TMP_VERSION:0:1}.${TMP_VERSION:1:1}.${TMP_VERSION:2}"
                fi
                # TMP_VERSION_ARRAY
                TMP_VERSION_ARRAY=(${TMP_VERSION//./ })
                REPO_VERSION_ARRAY_LENGTH=${#TMP_VERSION_ARRAY[@]}
                # 比较版本
                if [[ "${REPO_VERSION}" = "${TMP_VERSION}" ]]; then
                    # 如果相等，则使用配置到的url
                    REPO_URL2=${TMP_URL#*]}
                else
                    for ((i=0; i<${REPO_VERSION_ARRAY_LENGTH}+1; i++))
                    do
                        if [[ ${REPO_VERSION_ARRAY[i]} -gt ${TMP_VERSION_ARRAY[i]} ]]; then
                            # 如果版本大于配置的版本，则使用匹配到的url
                            REPO_URL2=${TMP_URL#*]}
                            break
                        elif [[ ${REPO_VERSION_ARRAY[i]} -lt ${TMP_VERSION_ARRAY[i]} ]]; then
                            # 小于配置的版本，skip
                            break
                        fi
                    done
                fi
                # 从最后一个元素开始查找，如果找到符合条件的第一个，则不继续查找
                # 所以高版本一定要放到repo信息数组最后
                # 这样做除了符合习惯外，也是为了减少匹配次数，提高效率
                if [[ "${REPO_URL2}" != "" ]]; then
                    break
                fi
            fi
        done
        # 找到了配置的url，进行处理
        if [[ "${REPO_URL2}" != "" ]]; then
            eval ${REPO_NAME}_REPO_URL=${REPO_URL}
            eval ${REPO_NAME}_REPO_URL2=${REPO_URL2}
            REPO_URL=${REPO_URL2}

            # 打包脚本执行repo-update.sh -revert--subproject时，删除${REPO_PATH}
            if ${REVERT_SUB_PROJECT} && [ -d ${REPO_PATH} ]; then
                cd ${REPO_PATH}
                if [[ ! "$(${GIT} remote -v | grep origin | grep fetch)" =~ "${REPO_URL}" ]]; then
                    echo "${REPO_NAME}库升级了url,处理中..."
                    echo "> rm -rf ${REPO_PATH}"
                    cd $(dirname ${REPO_PATH})
                    rm -rf ${REPO_PATH}
                fi
            fi
        fi
    }
    
    if [[ ${REPO_BRANCH_NAME} != "" ]]; then
        # git
        if [ -d ${REPO_PATH} ]; then
            # pod类型,更新代码就好
            if [[ ${REPO_TYPE} = "pod" ]]; then
                cd ${REPO_PATH}

                # revert代码
                if ${REVERT_SUB_PROJECT}; then
                    ${GIT} checkout .
                    echo "${REPO_NAME} reverted"
                    # 当前分支不是${REPO_BRANCH_NAME},切换
                    if [[ ! "$(${GIT} status | head -1)" =~ "${REPO_BRANCH_NAME}" ]]; then
                        ${GIT} checkout ${REPO_BRANCH_NAME}
                    fi
                fi

                # 更新代码
                ${GIT} pull 2>${TMP_LOG_PATH}
                RESULT_STRING=$(cat ${TMP_LOG_PATH})
                if [[ "${RESULT_STRING}" != "" ]]; then
                    echo ${RESULT_STRING}
                fi
                if [[ ${RESULT_STRING} =~ "fatal:" ]] \
                    || [[ ${RESULT_STRING} =~ "error:" ]]; then
                    if ${CAN_STASH} && [[ ${RESULT_STRING} =~ "Your local changes to the following files" ]]; then
                        # 尝试stash解决
                        echo "> git stash..."
                        ${GIT} stash 
                        echo "> git pull..."
                        ${GIT} pull
                        echo "> git stash pop..."
                        ${GIT} stash pop
                    else
                        # git pull失败,异常退出
                        echo "git pull失败,脚本终止,fix it!!!"
                        echo "可以尝试执行\"$0 $* -stash\""
                        exit 1
                    fi
                fi

                # 如果当前是Dev、master分支,和脚本指定的开发分支名称不一致,切换成脚本指定的开发分支
                CURRENT_BRANCH_NAME=$(${GIT} status | head -1)
                CURRENT_BRANCH_NAME=${CURRENT_BRANCH_NAME#*branch }
                if [[ ${CURRENT_BRANCH_NAME} =~ "Dev_" ]] || [[ ${CURRENT_BRANCH_NAME} = "master" ]];then
                    if [[ ${CURRENT_BRANCH_NAME} != ${REPO_BRANCH_NAME} ]];then
                        ${GIT} checkout ${REPO_BRANCH_NAME}
                        # 切换新分支后，pull最新代码
                        ${GIT} pull
                    fi
                fi

                # 检查分支是否切换成功
                if ${CHECK_BRANCH}; then
                    CURRENT_BRANCH_NAME=$(${GIT} status | head -1)
                    CURRENT_BRANCH_NAME=${CURRENT_BRANCH_NAME#*branch }
                    if [[ ${CURRENT_BRANCH_NAME} != ${REPO_BRANCH_NAME} ]];then
                        BRANCH_ERROR_PROJECT_ARRAY=(${BRANCH_ERROR_PROJECT_ARRAY[*]} ${REPO_NAME})
                    fi
                fi

                # 检查git url
                # http://git.cnsuning.com/suningiospods/ipods.git
                # git@git.cnsuning.com:suningiospods/ipods.git
                # 忽略协议
                REPO_URL2=${REPO_URL}
                if [[ "${REPO_URL2}" =~ "http" ]]; then
                    REPO_URL2=${REPO_URL2#*com/}
                fi
                if [[ "${REPO_URL2}" =~ "git@" ]]; then
                    REPO_URL2=${REPO_URL2#*:}
                fi
                if [[ ! "$(${GIT} remote -v | grep origin | grep fetch)" =~ "${REPO_URL2}" ]]; then
                    GITURL_ERROR_PROJECT_ARRAY=(${GITURL_ERROR_PROJECT_ARRAY[*]} ${REPO_NAME})
                fi

                # 处理下一个
                continue
            fi

            # repo类型
            # 判断是否git仓库
            if [ ! -d ${REPO_PATH}/.git ]; then
                echo "${REPO_NAME}不是git仓库"
                echo "你可以选择如下任一操作"
                echo "1.将${REPO_NAME}中的修改备份后,删除该文件夹,然后重新执行本脚本(推荐)"
                echo "2.将${REPO_NAME}改名后,例如改为${REPO_NAME}-svn,然后重新执行本脚本"
                exit 0
            fi

            cd ${REPO_PATH}

            # revert代码
            if ${REVERT_SUB_PROJECT}; then
                ${GIT} checkout .
                echo "${REPO_NAME} reverted"
                # 当前分支不是${REPO_BRANCH_NAME},切换
                if [[ ! "$(${GIT} status | head -1)" =~ "${REPO_BRANCH_NAME}" ]]; then
                    ${GIT} checkout ${REPO_BRANCH_NAME}
                fi
            fi

            # 更新代码
            ${GIT} pull 2>${TMP_LOG_PATH}
            RESULT_STRING=$(cat ${TMP_LOG_PATH})
            if [[ "${RESULT_STRING}" != "" ]]; then
                echo ${RESULT_STRING}
            fi
            if [[ ${RESULT_STRING} =~ "error: Sparse checkout" ]]; then
            	# 兼容稀疏检出配置问题导致的git pull不成功
            	rm -f .git/info/sparse-checkout
            	${GIT} pull 2>${TMP_LOG_PATH}
            	RESULT_STRING=$(cat ${TMP_LOG_PATH})
            fi
            if [[ ${RESULT_STRING} =~ "fatal:" ]] \
                || [[ ${RESULT_STRING} =~ "error:" ]]; then
                if ${CAN_STASH} && [[ ${RESULT_STRING} =~ "Your local changes to the following files" ]]; then
                    # 尝试stash解决
                    echo "> git stash..."
                    ${GIT} stash 
                    echo "> git pull..."
                    ${GIT} pull
                    echo "> git stash pop..."
                    ${GIT} stash pop
                else
                    # git pull失败,异常退出
                    echo "git pull失败,脚本终止,fix it!!!"
                    echo "可以尝试执行\"$0 $* -stash\""
                    exit 1
                fi
            fi

            # 如果当前是Dev、master分支,和脚本指定的开发分支名称不一致,切换成脚本指定的开发分支
            CURRENT_BRANCH_NAME=$(${GIT} status | head -1)
            CURRENT_BRANCH_NAME=${CURRENT_BRANCH_NAME#*branch }
            if [[ ${CURRENT_BRANCH_NAME} =~ "Dev_" ]] || [[ ${CURRENT_BRANCH_NAME} = "master" ]];then
                if [[ ${CURRENT_BRANCH_NAME} != ${REPO_BRANCH_NAME} ]];then
                    ${GIT} checkout ${REPO_BRANCH_NAME}
                    # 切换新分支后，pull最新代码
                    ${GIT} pull
                fi
            fi

            # 合并dev分支代码,并push
            CURRENT_BRANCH_NAME=$(${GIT} status | head -1)
            CURRENT_BRANCH_NAME=${CURRENT_BRANCH_NAME#*branch }
            if [[ ! ${CURRENT_BRANCH_NAME} =~ "Dev_" ]] && [[ ! ${CURRENT_BRANCH_NAME} = "master" ]];then
                echo "merging origin/${REPO_BRANCH_NAME}"
                RESULT_STRING=$(${GIT} merge origin/${REPO_BRANCH_NAME})
                # 命令执行失败,异常退出
                if [[ ! $? -eq 0 ]]; then
                    echo "error:merge失败,请手动处理后再次执行"
                    echo ${RESULT_STRING}
                    exit 1
                fi
                echo ${RESULT_STRING}
                if [ "${RESULT_STRING}" != "Already up to date." ];then
                    echo "pushing ${CURRENT_BRANCH_NAME}"
                    ${GIT} push
                fi
            fi

            # 稀疏检出 sparse checkout
            SNGITCONFIG_PATH=$(find ${REPO_PATH} -name sparse-checkout | head -1)
            if [[ ${SNGITCONFIG_PATH} != "" ]]; then
                # 设置稀疏检出
                SPARSE_CHECKOUT_RESULT=$(${GIT} config core.sparsecheckout)
                if [[ ${SPARSE_CHECKOUT_RESULT} != "true" ]]; then
                    ${GIT} config core.sparsecheckout true
                fi
                # 要设置sparse-checkout文件的md5值
                FILE_SPARSE_CHECKOUT_MD5=$(md5 ${SNGITCONFIG_PATH})
                FILE_SPARSE_CHECKOUT_MD5=${FILE_SPARSE_CHECKOUT_MD5##*= }
                # 当前的sparse-checkout md5值
                CURRENT_SPARSE_CHECKOUT_MD5=""
                if [[ -f .git/info/sparse-checkout ]]; then
                    CURRENT_SPARSE_CHECKOUT_MD5=$(md5 .git/info/sparse-checkout)
                    CURRENT_SPARSE_CHECKOUT_MD5=${CURRENT_SPARSE_CHECKOUT_MD5##*= }
                fi
                # 比对，如果有变动，设置新的
                if [[ ${CURRENT_SPARSE_CHECKOUT_MD5} != ${FILE_SPARSE_CHECKOUT_MD5} ]]; then
                    echo "正在进行稀疏检出，以减少pod仓库的大小,详细查看wiki"
                    echo "  http://wiki.cnsuning.com/pages/viewpage.action?pageId=33631677"
                    echo "请不要中断,稍等片刻..."
                    cp -f ${SNGITCONFIG_PATH} .git/info/sparse-checkout
                    ${GIT} read-tree -mu HEAD
                fi
            fi

            # 检查分支是否切换成功
            if ${CHECK_BRANCH}; then
                CURRENT_BRANCH_NAME=$(${GIT} status | head -1)
                CURRENT_BRANCH_NAME=${CURRENT_BRANCH_NAME#*branch }
                if [[ ${CURRENT_BRANCH_NAME} != ${REPO_BRANCH_NAME} ]];then
                    BRANCH_ERROR_PROJECT_ARRAY=(${BRANCH_ERROR_PROJECT_ARRAY[*]} ${REPO_NAME})
                fi
            fi

            # 检查git url
            # http://git.cnsuning.com/suningiospods/ipods.git
            # git@git.cnsuning.com:suningiospods/ipods.git
            # 忽略协议
            REPO_URL2=${REPO_URL}
            if [[ "${REPO_URL2}" =~ "http" ]]; then
                REPO_URL2=${REPO_URL2#*com/}
            fi
            if [[ "${REPO_URL2}" =~ "git@" ]]; then
                REPO_URL2=${REPO_URL2#*:}
            fi
            if [[ ! "$(${GIT} remote -v | grep origin | grep fetch)" =~ "${REPO_URL2}" ]]; then
                GITURL_ERROR_PROJECT_ARRAY=(${GITURL_ERROR_PROJECT_ARRAY[*]} ${REPO_NAME})
            fi
        else
            if [[ ${REPO_TYPE} = "repo" ]]; then
                echo "本地私有仓库\"${BRIEF_REPO_PATH}\"不存在，正在为你初始化,请耐心等待 ..."
            else
                echo "本地库\"${BRIEF_REPO_PATH}\"不存在，正在为你初始化,请耐心等待 ..."
            fi
            ${GIT} clone ${REPO_URL} ${REPO_PATH}
            cd ${REPO_PATH}
            ${GIT} checkout ${REPO_BRANCH_NAME}

            # 检查分支是否切换成功
            if ${CHECK_BRANCH}; then
                CURRENT_BRANCH_NAME=$(${GIT} status | head -1)
                CURRENT_BRANCH_NAME=${CURRENT_BRANCH_NAME#*branch }
                if [[ ${CURRENT_BRANCH_NAME} != ${REPO_BRANCH_NAME} ]];then
                    BRANCH_ERROR_PROJECT_ARRAY=(${BRANCH_ERROR_PROJECT_ARRAY[*]} ${REPO_NAME})
                fi
            fi
        fi
    else
        # svn
        if [ -d ${REPO_PATH} ]; then
            cd ${REPO_PATH}
            ${SVN} up 2>${TMP_LOG_PATH}
            RESULT_STRING=$(cat ${TMP_LOG_PATH})
            if [[ ${RESULT_STRING} =~ "svn: E" ]]; then
                # svn up失败,异常退出
                echo ${RESULT_STRING}
                echo "svn up失败,脚本终止,fix it!!!"
                exit 1
            fi
        else
            echo "本地私有仓库\"${BRIEF_REPO_PATH}\"不存在，\
            正在为你初始化,请耐心等待 ..."
            ${SVN} co ${REPO_URL} ${REPO_PATH}
        fi
    fi
done

# 列出分支切换失败的project，并报错
if [[ "${BRANCH_ERROR_PROJECT_ARRAY}" != "" ]];then
    echo ""
    echo "error:分支切换失败，请先处理"
    for PROJECT_NAME in ${BRANCH_ERROR_PROJECT_ARRAY[@]};  # ${}里面不能有空格
    do
        echo "    ${PROJECT_NAME}"
    done
    exit 1
fi

# 列出分支切换失败的project，并报错
if [[ "${GITURL_ERROR_PROJECT_ARRAY}" != "" ]];then
    echo ""
    echo "error:git库url和脚本配置的不符，请先处理"
    for PROJECT_NAME in ${GITURL_ERROR_PROJECT_ARRAY[@]};  # ${}里面不能有空格
    do
        echo "    ${PROJECT_NAME}"
        if [[ "${PROJECT_NAME}" = "SNEBuy_repos" ]] \
            || [[ "${PROJECT_NAME}" = "SNEBuy_buss_repos" ]]; then
            if [[ "${PROJECT_NAME}" = "SNEBuy_repos" ]]; then
                echo "        SNEBuy_repos库因为瘦身需要使用新的库、对应新的url"
            elif [[ "${PROJECT_NAME}" = "SNEBuy_buss_repos" ]]; then
                echo "        SNEBuy_buss_repos库因为瘦身需要使用新的库、对应新的url"
            fi
            echo "        请检查本地是否有修改"
            echo "        1.有修改，请拷贝修改的文件到桌面备份，然后删除库，执行repo-update.sh"
            echo "        2.没有修改，直接删除库，执行repo-updatre.sh"
        fi
        if [[ "${PROJECT_NAME}" = "SNSL_Framework" ]] \
            || [[ "${PROJECT_NAME}" = "SNSHProductDetail_Framework" ]] \
            || [[ "${PROJECT_NAME}" = "MSFS_Framework" ]] \
            || [[ "${PROJECT_NAME}" = "SNYXChat_Framework" ]] \
            || [[ "${PROJECT_NAME}" = "PPTVSDK" ]]; then
            eval PROJECT_REPO_URL=\${${PROJECT_NAME}_REPO_URL}
            eval PROJECT_REPO_URL2=\${${PROJECT_NAME}_REPO_URL2}
            echo "        该库更换了git地址"
            echo "        老地址:${PROJECT_REPO_URL}"
            echo "        新地址:${PROJECT_REPO_URL2}"
            echo "        请检查本地没有修改后，手动删除SNPods/${PROJECT_NAME}目录"
            echo "        然后再次执行repo-update.sh"
        fi
    done
    exit 1
fi

if ${UPDATE_FRAMEWORK}; then
    echo ""
    echo "rsync pull..."
    # clean
    for RSYNC_ROOT_PATH in "${HOME}/.rsync/build" "${SNEBUY_REPO_BUILD}"
    do
        if [[ -d ${RSYNC_ROOT_PATH} ]]; then
            for A_DIRECTORY in $(ls ${RSYNC_ROOT_PATH})
            do
                # 不清理项目要使用的目录  SuningEBuy-Framework-875
                if [[ "${A_DIRECTORY}" = "$(basename ${RSYNC_JOB_PATH})" ]]; then
                    continue
                fi
                # 删除7天未使用的文件夹
                SAVE_MAX_DAYS="7"
                MODIFY_FILE_LIST_IN_MAX_DAYS=$(find ${RSYNC_ROOT_PATH}/${A_DIRECTORY} -mtime -${SAVE_MAX_DAYS})
                if [[ ${MODIFY_FILE_LIST_IN_MAX_DAYS} = "" ]]; then
                    echo ""
                    echo "${A_DIRECTORY} ${SAVE_MAX_DAYS}天内没修改，删除..."
                    echo "> rm -rf ${RSYNC_ROOT_PATH}/${A_DIRECTORY}"
                    rm -rf ${RSYNC_ROOT_PATH}/${A_DIRECTORY}
                fi
            done
        fi
    done

    # 移除老方案的文件夹
    if [[ -d ${HOME}/.rsync/build ]]; then
        if [[ "$(ls ${HOME}/.rsync/build)" = "" ]]; then
            rm -rf ${HOME}/.rsync
        fi
    fi

    if [[ ! -d ${RSYNC_JOB_PATH} ]]; then
        echo "第一次拉取framework可能耗时较长，请稍等..."
    fi
    echo "> bash ${PROJECT_DIR}/Scripts/rsync-helper.sh pull ${RSYNC_JOB_PATH}/"
    bash ${PROJECT_DIR}/Scripts/rsync-helper.sh pull ${RSYNC_JOB_PATH}/

    if [[ -d ${RSYNC_JOB_PATH} ]]; then
        # $using_rsync_framework = true
        sed -i '' "s/using_rsync_framework =.*/using_rsync_framework = true/" ${PODFILE_PATH}
    else
        echo "服务端暂时没有SuningEBuy-Framework-${GIT_BRANCH_VERSION}，请联系王彬(14121612)打包生成"
        # $using_rsync_framework = false
        sed -i '' "s/using_rsync_framework =.*/using_rsync_framework = false/" ${PODFILE_PATH}
    fi
elif ${ONLY_POD}; then
    # -pod参数只执行pod install，不更新库
    # : 什么都不做
    :
else
    # $using_rsync_framework = false
    sed -i '' "s/using_rsync_framework =.*/using_rsync_framework = false/" ${PODFILE_PATH}
fi

# 创建pod库软链
cd ${SCRIPT_DIR}
if [ ! -d "${PWD}/SNEBuy_repos" ]; then
    PODS_LOC_PATH="${HOME}/.cocoapods/repos/SNEBuy_repos"
	ln -s ${PODS_LOC_PATH} "${PWD}/SNEBuy_repos"
fi
if [ ! -d "${PWD}/SNEBuy_buss_repos" ]; then
    BUSS_PODS_LOC_PATH="${HOME}/.cocoapods/repos/SNEBuy_buss_repos"
	ln -s ${BUSS_PODS_LOC_PATH} "${PWD}/SNEBuy_buss_repos"
fi

if [ $? = 0 ] && ! ${SKIP_POD}; then
    echo ""
	echo "执行 ${POD} _${POD_VERSION}_ install --no-repo-update"
    rm -f Podfile.lock
	${POD} _${POD_VERSION}_ install --no-repo-update
    # 命令执行失败,异常退出
    if [[ ! $? -eq 0 ]]; then
        exit 1
    fi
fi

exit 0
