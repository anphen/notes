#coding=utf-8
from biplist import *

ebuyPlist = readPlist("../../SuningEBuy/info.plist")

watchPlist = readPlist("../../EBuyWatch/info.plist")

watchExtensionPlist = readPlist("../../EBuyWatch Extension/info.plist")

shortVersion=ebuyPlist["CFBundleShortVersionString"]
buildVersion=ebuyPlist["CFBundleVersion"]
bundleid =ebuyPlist["CFBundleIdentifier"]


watchPlist['CFBundleShortVersionString']=shortVersion
watchPlist['CFBundleVersion']=buildVersion
watchPlist['WKCompanionAppBundleIdentifier']=bundleid
watchPlist['CFBundleIdentifier']=bundleid + '.watchkitapp'

watchExtensionPlist["CFBundleShortVersionString"]=shortVersion
watchExtensionPlist["CFBundleVersion"]=buildVersion
watchExtensionPlist["CFBundleIdentifier"]=bundleid + '.watchkitapp.watchkitextension'
nsextension = watchExtensionPlist["NSExtension"]
nsextensionAttributes = nsextension['NSExtensionAttributes']
nsextensionAttributes['WKAppBundleIdentifier']= bundleid + '.watchkitapp'



writePlist(watchPlist, '../../EBuyWatch/info.plist')
writePlist(watchExtensionPlist, '../../EBuyWatch Extension/info.plist')
