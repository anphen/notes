#coding=utf-8
from biplist import *
from pbxproj import XcodeProject
import string
import os
from os import path

plist = readPlist("../../SuningEBuy/Info.plist")
widgetPlist = readPlist("../../TodayWidget/Info.plist")
pushserviceplist = readPlist("../../PushService/Info.plist")
shortVersion=plist["CFBundleShortVersionString"]

#检查bundleID
print("1.检查主工程的bundleID")
print(plist["CFBundleIdentifier"])
if plist["CFBundleIdentifier"] != "SuningEMall":
    print('error , CFBundleIdentifier is not equal to SuningEMall')
else:
    print('correct , CFBundleIdentifier is equal to SuningEMall')

print("\n1.1检查widget的bundleID")
if widgetPlist["CFBundleIdentifier"] != "SuningEMall.TodayWidget":
    print('error , widget\'s CFBundleIdentifier is not equal to SuningEMall.TodayWidget')
else:
    print('correct , widget\'s  CFBundleIdentifier is equal to SuningEMall.TodayWidget')

print("\n1.2.请确认主工程版本号")
print('主工程版本号是%s' %shortVersion)

print("\n1.3.请确认主工程build版本号")
buildVersion = plist["CFBundleVersion"]
print('主工程版本号是%s' %buildVersion)

print("\n1.4.请确认TodayWidget版本号")
print('TodayWidget 版本号是%s' %widgetPlist["CFBundleShortVersionString"])

print("\n1.5.请确认TodayWidget的build版本号")
buildVersion = widgetPlist["CFBundleVersion"]
print('TodayWidget的build版本号是%s' %buildVersion)

if shortVersion != widgetPlist["CFBundleShortVersionString"]:
    print('\n请注意，主工程版本号与TodayWidget版本号不一致')


print ("\n1.6检查pushservice的bundleid")
if pushserviceplist["CFBundleIdentifier"] != "SuningEMall.PushService":
    print('error , pushservice\'s CFBundleIdentifier is not equal to SuningEMall.PushService')
else:
    print('correct , pushservice\'s  CFBundleIdentifier is equal to SuningEMall.PushService')

#检查苏宁家族schemes
print("\n2.检查苏宁家族schemes")
suningfamilySchemes = plist["LSApplicationQueriesSchemes"]

if 'pptv' in suningfamilySchemes:
    print ("correct, pptv is in suningfamilySchemes")
else :
    print ("error, pptv is not in suningfamilySchemes")

if 'com.suning.reader4iphone' in suningfamilySchemes:
    print ("correct, com.suning.reader4iphone is in suningfamilySchemes")
else :
    print ("error, com.suning.reader4iphone is not in suningfamilySchemes")

if 'com.suning.RedBaby' in suningfamilySchemes:
    print ("correct, com.suning.RedBaby is in suningfamilySchemes")
else :
    print ("error, com.suning.RedBaby is not in suningfamilySchemes")

if 'com.suning.SuningEfubao' in suningfamilySchemes:
    print ("correct, com.suning.SuningEfubao is in suningfamilySchemes")
else :
    print ("error, com.suning.SuningEfubao is not in suningfamilySchemes")



#检查SuningEBuyConfig.h
print('\n3.检查SuningEBuyConfig.h')
netconfigfile = open('../../SNProjects/SNCommon/SNCommon/AppConfig/SuningEBuyConfig.h', 'r')


netconfigContent=netconfigfile.readlines()

index = 0
for line in netconfigContent:
    index += 1
    if '基本网络环境切换' in line:
        break

netconfigContent = netconfigContent[index:]

netconfigContentStrip = []
for line in netconfigContent:
    stripline = line.strip('\n')
    netconfigContentStrip.append(stripline)

for line in netconfigContentStrip:
#    if 'kReleaseH' in line:
#        if '//' in line and line.startswith('//'):
#            print ('error, kReleaseH 被注释')
#        else :
#            print ('correct, kReleaseH 未被注释')
#            if line.endswith('0'):
#                print ('error, kReleashH is not 1\n')
#            else :
#                print ('correct, kReleashH is 1\n')
#
#
#    if 'kReleaseInfoH' in line:
#        if '//' in line and line.startswith('//'):
#            print ('error, kReleaseInfoH 被注释')
#        else :
#            print ('correct, kReleaseInfoH 未被注释')
#            if line.endswith('0'):
#                print ('error, kReleaseInfoH is not 1\n')
#            else :
#                print ('correct, kReleaseInfoH is 1\n')


    if 'kAllowInvalidHttps' in line:
        if '//' in line and line.startswith('//'):
            print ('error, kAllowInvalidHttps 被注释')
        else :
            print ('correct, kAllowInvalidHttps 未被注释')
            if line.endswith('0'):
                print ('correct, kAllowInvalidHttps is 0\n')
            else :
                print ('error, kAllowInvalidHttps is 1\n')


#检查SNUrlDomainManagerUrlType.plist
print('\n4.SNUrlDomainManagerUrlType.plist')
plistUrlConfig = readPlist("../../SuningEBuy/AppConfig/SNUrlDomainManagerUrlType.plist")
if plistUrlConfig['URLConfig'] == '0':
    print("correct, URLConfig is 0")
else :
    print("error, URLConfig 非0")


#检查渠道号
print("\n5.检查渠道号")
dcplist = readPlist("../../SNPods/SNCommon_Framework/Resources/plists/common/DC.plist")
if dcplist['itemIndex'] == 0:
    print("correct,渠道号 dc.plist's itemIndex == 0")
else:
    print ("error,渠道号 dc.plist's itemIndex != 0")

#检查app显示名称
print("\n6.检查app显示名称")
appNameFile  = open("../../SuningEBuy/zh-Hans.lproj/InfoPlist.strings", "r")

for line in appNameFile.readlines():
    if line.startswith("CFBundleDisplayName"):
        if line.endswith("苏宁易购\";\n"):
            print('correct, CFBundleDisplayName is 苏宁易购')
        else:
            print ('error, CFBundleDisplayName is not 苏宁易购')

    if line.startswith("CFBundleName"):
        if line.endswith("SuningEBuy\";\n"):
            print('correct, CFBundleName is SuningEBuy')
        else:
            print ('error, CFBundleName is not SuningEBuy')


#检查所有域名
print("\n7. 检查所有生产域名文件")
def checkplist(plistpath):
    if os.path.exists(plistpath):
        plistContent = readPlist(plistpath)
        errorMsg = ''
        for line in plistContent:
            value = plistContent[line]
            if 'cnsuning.com' in value:
                msg = "error, %s 中 %s 包含cnsuning\n" % (plistpath, line)
                errorMsg = errorMsg + msg

        if errorMsg != '':
            print(errorMsg)
        # else:
        #     print('correct, %s 未发现cnsuning'%os.path.basename(plistpath))
    else:
        print('error, 找不到 %s'%plistpath)




projectDirPath = os.path.realpath(__file__)
print(projectDirPath)
projectDirPath = os.path.dirname(projectDirPath)
print(projectDirPath)
projectDirPath = os.path.dirname(projectDirPath)
print(projectDirPath)
projectDirPath = os.path.dirname(projectDirPath)
print(projectDirPath)
workspaceDirPath = projectDirPath
projectDirPath += '/SuningEBuy'
print(projectDirPath)

# projectDirPath = '/Users/chupeng/Desktop/项目/766mergetoMaster/SuningEBuy'

def findPlist(dir):
    sublist = os.listdir(dir)
    for name in sublist:
        path = os.path.join(dir, name)
        if os.path.isfile(path):
            if '.plist' in name:
                if 'prd' in name or 'release' in name:
                    # print(path)
                    checkplist(path)
        else:
            findPlist(path)

findPlist(workspaceDirPath)


print('\n8.检查bundle中的二进制文件')
binaryFileArr = []
def findBinaryFile(dir):
    sublist = os.listdir(dir)
    for name in sublist:
        path = os.path.join(dir, name)
        if os.path.isfile(path):
            #不带.bundle的说明不在bundle里，不用检查
            if not '.bundle' in path:
                continue
            #扩展名带.的就不检查了，二进制文件一般没有.
            if not '.' in os.path.split(path)[-1]:
                if os.path.split(path)[-1] == 'MegLive_model':
                    continue
                filestate = os.popen('file %s' % path).read()
                isData = filestate.endswith('data\n')
                if isData:
                    binaryFileArr.append(path)
        else:
            findBinaryFile(path)
findBinaryFile(projectDirPath)

if len(binaryFileArr) == 0:
    print('correct，除了已知没问题的MegLive_model以外没有发现可疑的二进制文件')
else:
    print('error，以下是除了已知没问题的MegLive_model以外的可疑二进制文件，请进行检查')

print("\n9.检查App Groups,universal link, KeyChain Sharing, Apple pay")
entitlementsPlist = readPlist("../../SuningEBuy/SuningEBuy.entitlements");

#检查appley pay
if entitlementsPlist.has_key('com.apple.developer.in-app-payments'):
    if entitlementsPlist['com.apple.developer.in-app-payments'] != []:
        merchantIds = entitlementsPlist['com.apple.developer.in-app-payments']
        if (merchantIds[0] == 'merchant.SuningEMall'):
            print('correct, 主工程Apple Pay正确打开，而且merchantID是merchant.SuningEMall\n')
else:
    print('error,主工程apple pay 没有打开\n')

if entitlementsPlist.has_key('com.apple.security.application-groups'):
    if entitlementsPlist['com.apple.security.application-groups'] != []:
        appgroupsArr=entitlementsPlist['com.apple.security.application-groups']
        if (appgroupsArr[0] == 'group.SuningEMall'):
            print('correct,主工程 App Groups 正确打开，而且ID是group.SuningEMall\n')
else:
    print ('error,主工程 App Groups 没有打开\n')


#检查universal link(Associated Domains)
if entitlementsPlist.has_key('com.apple.developer.associated-domains'):
    if entitlementsPlist['com.apple.developer.associated-domains'] != []:
        appgroupsArr=entitlementsPlist['com.apple.developer.associated-domains']
        if ('applinks:*.m.suning.com' in appgroupsArr):
            print('correct,Associated Domains 正确打开，而且包含applinks:*.m.suning.com\n')
        else :
            print('error,Associated Domains 正确打开，但没有包含applinks:*.m.suning.com\n')

        if ('applinks:m.suning.com' in appgroupsArr):
            print('correct,Associated Domains 正确打开，而且包含applinks:m.suning.com\n')
        else :
            print('error,Associated Domains 正确打开，但没有包含applinks:m.suning.com\n')

    else :
        print('error, Associated Domains没有包含applinks:*.m.suning.com和applinks:m.suning.com\n')
else:
    print ('error,主工程 Associated Domains 没有打开\n')


#检查主工程keychain
if entitlementsPlist.has_key('keychain-access-groups'):
    if entitlementsPlist['keychain-access-groups'] != []:
        appgroupsArr=entitlementsPlist['keychain-access-groups']
        if (len(appgroupsArr) < 2):
            print('error, 主工程KeyChain Sharing 正确打开,但应包含SuningEMall,com.suning.SuningEfubao两项\n')
            sys.exit(1)
            # if (appgroupsArr[0] == '$(AppIdentifierPrefix)SuningEMall'):
            #     print('correct,主工程 KeyChain Sharing 正确打开，而且ID包含SuningEMall\n')
            # else:
            #     print ('error, 主工程KeyChain Sharing 正确打开，但没包含SuningEMall')

        elif (len(appgroupsArr) >= 3):
            if ('$(AppIdentifierPrefix)SuningEMall' in appgroupsArr):
                print('correct,主工程 KeyChain Sharing 正确打开，而且包含SuningEMall\n')
            else:
                print ('error, 主工程KeyChain Sharing 正确打开，但不包含SuningEMall\n')
                sys.exit(1)


            if ('$(AppIdentifierPrefix)com.suning.SuningEfubao' in appgroupsArr):
               print('correct,主工程 KeyChain Sharing 正确打开，而且包含com.suning.SuningEfubao\n')
            else:
                print ('error, 主工程KeyChain Sharing 正确打开，但不包含com.suning.SuningEfubao\n')
                sys.exit(1)

            if ('$(AppIdentifierPrefix)com.suning.xiaodian' in appgroupsArr):
               print('correct,主工程 KeyChain Sharing 正确打开，而且包含com.suning.xiaodian\n')
            else:
                print ('error, 主工程KeyChain Sharing 正确打开，但不包含com.suning.xiaodian\n')
                sys.exit(1)

    else:
        print('error, 主工程KeyChain Sharing 正确打开,但应包含SuningEMall,com.suning.SuningEfubao两项\n')
        sys.exit(1)
else:
    print ('error,主工程 KeyChain Sharing 没有打开\n')
    sys.exit(1)

#检查widget keychain
widgetEntitlementsPlist=readPlist("../../TodayWidget/TodayWidget.entitlements")
if widgetEntitlementsPlist.has_key('keychain-access-groups'):
    if widgetEntitlementsPlist['keychain-access-groups'] != []:
        appgroupsArr=widgetEntitlementsPlist['keychain-access-groups']
        if (appgroupsArr[0] == '$(AppIdentifierPrefix)SuningEMall.TodayWidget'):
            print('correct,TodayWidget的 KeyChain Sharing 正确打开，而且ID是$(AppIdentifierPrefix)SuningEMall.TodayWidget\n')
else:
    print ('error,TodayWidget的 KeyChain Sharing 没有打开\n')

#检查widget app groups
if widgetEntitlementsPlist.has_key('com.apple.security.application-groups'):
    if widgetEntitlementsPlist['com.apple.security.application-groups'] != []:
        appgroupsArr=widgetEntitlementsPlist['com.apple.security.application-groups']
        if (appgroupsArr[0] == 'group.SuningEMall'):
            print('correct,TodayWidget的 app groups 正确打开，而且ID是group.SuningEMall\n')
else:
    print ('error,TodayWidget的 app groups 没有打开\n')


#检查push service的keychain
pushserviceEntitlementsPlist=readPlist('../../PushService/PushService.entitlements')
if pushserviceEntitlementsPlist.has_key('keychain-access-groups'):
    if pushserviceEntitlementsPlist['keychain-access-groups'] != []:
        appgroupsArr=pushserviceEntitlementsPlist['keychain-access-groups']
        if (appgroupsArr[0] == '$(AppIdentifierPrefix)SuningEMall.PushService'):
            print('correct,pushservice的 KeyChain Sharing 正确打开，而且ID是$(AppIdentifierPrefix)SuningEMall.PushService\n')
else:
    print ('error,pushservice的 KeyChain Sharing 没有打开\n')




print("\n10.检查推送")
# projectpbxproj = XcodeProject.load("../../SuningEBuy.xcodeproj/project.pbxproj")
# x = projectpbxproj.get()
# print(x)
# projfile = open('../../SuningEBuy.xcodeproj/project.pbxproj','r')
#
# bfindpush = 0
# pushconfig = ''
# projfilestriped = []
# for line in projfile.readlines():
#     if line.find('com.apple.Push') != -1:
#         bfindpush = 1
#         continue
#
#     if bfindpush == 1:
#         pushconfig = line
#         break
#
# if pushconfig.find('enabled = 1') != -1:
#     print ('correct, 推送正常打开')
# elif pushconfig.find('enabled = 0') != -1:
#     print ('error, 推送没有打开')

# print(entitlementsPlist)
if entitlementsPlist.has_key('aps-environment'):
    print('correct, 推送正常打开')
else:
    print('error, 推送没有打开')

print("\n10.1 检查Access WiFi Information")
if entitlementsPlist.has_key('com.apple.developer.networking.wifi-info'):
    print('correct, Access WiFi Information 正常打开')
else:
    print('error, Access WiFi Information 没有打开')

print("\n11.检查Weex性能sdk是否去除")
podfilePath = workspaceDirPath + '/Podfile'
podfile = open(podfilePath, 'r')
for line in podfile.readlines():
    if 'SNWAPM' in line:
        if '#' in line and line.startswith('#'):
            print('\ncorrent, SNWAPM被注释')
        elif "#" in line:
            print('\ncorrent, SNWAPM被注释')
        else:
            print('\nerror, SNWAPM没有被注释')



print("\n11.1检查王彬14121612的性能检测sdk是否去除")
podfilePath = workspaceDirPath + '/Podfile'
podfile = open(podfilePath, 'r')
for line in podfile.readlines():
    if 'IOPTIMISDK' in line:
        if '#' in line and line.startswith('#'):
            print('\ncorrent, IOPTIMISDK被注释')
        elif "#pod" in line:
            print('\ncorrent, IOPTIMISDK被注释')
        else:
            print('\nerror, IOPTIMISDK没有被注释，请马上联系嫌疑人王彬14121612')


print("\n12.检查各工程的分支是否相同版本号\n")
# projectDirPath



def getProjectBranchInfo(projectDirPath):
    os.chdir(projectDirPath)

    branchInfo = os.popen('git branch')
    branchInfoDetail = branchInfo.read()
    branchInfoDetailArr = branchInfoDetail.split('\n')
    currentBranchMain = ''
    for item in branchInfoDetailArr:
        if item.startswith('*'):
            currentBranchMain = item
            break

    return currentBranchMain

mainProjBranch = getProjectBranchInfo(projectDirPath)
print('主工程当前分支 %s\n' % mainProjBranch )

subProjNames = ['SNChannel', 'SNHWG', 'SNLive', 'SNMBLoginRegister', 'SNMBMember', 'SNMK', 'SNHomePage', 'SNPMPinGou', 'SNPM',
                'SNSHProductDetail', 'SNSHSearch', 'SNSL', 'SNSM']


def checkSubProjBranch(subProjName):
    subProjPath = os.path.dirname(projectDirPath) + '/SNProjects/' + subProjName
    subProjPathBranch = getProjectBranchInfo(subProjPath)
    if subProjPathBranch == mainProjBranch:
        print('correct, %s 分支版本为 %s 跟主工程分支版本号相同\n' % (subProjName,subProjPathBranch))
    else:
        print('error, %s 分支版本为 %s 跟主工程分支版本号不同\n' % (subProjName, subProjPathBranch))



def findSubProjResourceLine(subProjName):
    podfilePath = workspaceDirPath + '/Podfile'
    podfile = open(podfilePath, 'r')
    targetStr = subProjName + '_SPEC_PATH'
    targetLine = ''
    for line in podfile.readlines():
        if targetStr in line:
            targetLine = line
            break


    # print(targetLine)
    return targetLine

def checkSubProjResourceVersion(subProjName):
    targetLine = findSubProjResourceLine(subProjName)
    resourceVersion = targetLine[-7:-2]
    resourceVersion = resourceVersion.replace('.', '')
    mainProjVersion = mainProjBranch[-3:]

    if mainProjVersion == resourceVersion:
        print('correct, %s 的资源版本号 %s 和主工程版本号 %s 相同 \n' % (subProjName, resourceVersion, mainProjVersion))
    else:
        print('error, %s 的资源版本号 %s 和主工程版本号 %s 不同 \n' %(subProjName, resourceVersion, mainProjVersion))



for item in subProjNames:
    checkSubProjBranch(item)


print('\n 13.检查子工程资源版本号\n')


subProjNamesNeedCheckResource = ['SNHomePage', 'SNSHSearch', 'SNPMPinGou', 'SNHWG','SNChannel' ,
                'SNSM']
for item in subProjNamesNeedCheckResource:
    checkSubProjResourceVersion(item)


#, snsl,四级页，snpm的代码和资源是在SNPods库，检查方式是看git branch版本号

subProjNamesNeedCheckResource2 = ['SNCommon', 'SNDynamicFrameworks', 'SNLive', 'SNLogin', 'SNMember', 'SNMK', 'SNPM'
    , 'SNSDKs', 'SNSHProductDetail', 'SNSL']
def checkSubProjResourceVersion2(subprojName):
    subProjPath = os.path.dirname(projectDirPath) + '/SNPods/' + subprojName + '_Framework'
    subProjPathBranch = getProjectBranchInfo(subProjPath)
    if subProjPathBranch == mainProjBranch:
        print('correct, %s 分支资源版本号为 %s 跟主工程分支版本号相同\n' % (subprojName,subProjPathBranch))
    else:
        print('error, %s 分支资源版本号为 %s 跟主工程分支版本号不同\n' % (subprojName, subProjPathBranch))


for item in subProjNamesNeedCheckResource2:
    checkSubProjResourceVersion2(item)

print('\n14. 请检查SNAppRegister.m里是否注释了[SNWAPM sharedInstance];和相应的头文件\n')

print("\n基本配置检查完毕，现在请检查打包证书")
