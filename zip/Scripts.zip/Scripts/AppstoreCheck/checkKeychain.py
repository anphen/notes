#coding=utf-8
from biplist import *
from pbxproj import XcodeProject
import string
import os
import sys


entitlementsPlist = readPlist("../../SuningEBuy/SuningEBuy.entitlements");

if entitlementsPlist.has_key('keychain-access-groups'):
    if entitlementsPlist['keychain-access-groups'] != []:
        appgroupsArr=entitlementsPlist['keychain-access-groups']
        if (len(appgroupsArr) < 2):
            print('error, 主工程KeyChain Sharing 正确打开,但应包含SuningEMall,com.suning.SuningEfubao两项\n')
            sys.exit(1)
            # if (appgroupsArr[0] == '$(AppIdentifierPrefix)SuningEMall'):
            #     print('correct,主工程 KeyChain Sharing 正确打开，而且ID包含SuningEMall\n')
            # else:
            #     print ('error, 主工程KeyChain Sharing 正确打开，但没包含SuningEMall')

        elif (len(appgroupsArr) == 2):
            if (appgroupsArr[0] == '$(AppIdentifierPrefix)SuningEMall'):
                print('correct,主工程 KeyChain Sharing 正确打开，而且第一个ID是SuningEMall\n')
            else:
                print ('error, 主工程KeyChain Sharing 正确打开，但第一个ID不是SuningEMall\n')
                sys.exit(1)


            if (appgroupsArr[1] == '$(AppIdentifierPrefix)com.suning.SuningEfubao'):
               print('correct,主工程 KeyChain Sharing 正确打开，而且第二个ID是com.suning.SuningEfubao\n')
            else:
                print ('error, 主工程KeyChain Sharing 正确打开，但第二个ID不是com.suning.SuningEfubao\n')
                sys.exit(1)

    else:
        print('error, 主工程KeyChain Sharing 正确打开,但应包含SuningEMall,com.suning.SuningEfubao两项\n')
        sys.exit(1)
else:
    print ('error,主工程 KeyChain Sharing 没有打开\n')
    sys.exit(1)


