from pbxproj.pbxsections.PBXGenericTarget import *


class PBXAggregatedTarget(PBXGenericTarget):
    pass
