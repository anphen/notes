#!/bin/sh  

#
# 2015/12
# @author:xzoscar
#

echo "过滤结果如下:" > ~/Desktop/unused_all_images.txt 

# 查找这些类型的文件
find $1 -type f  -name '*.xib' -o -name '*.[mh]' -o -name '*.json' -o -name '*.sh'  > ~/Desktop/tmp_all_files.txt 

for png in `find $1 -type f -name '*.png'`
do
    # 不过滤 .bundle下的
    if [[ "$png" =~ ".bundle" ]]; then
	continue
    fi

    name=`basename $png .png`
    empty=""
    if [[ "$name" =~ "@2x" ]] || [[ "$name" =~ "@3x" ]]; then
	name=${name/@2x/$empty} 
    fi
    
    #echo "xzoscar:${name}"

    isfound=0
    while read line
    do
      if grep "${name}" "${line}"; then  
         isfound=1
	 break 
      fi
    done < ~/Desktop/tmp_all_files.txt
  
    if [ $isfound -eq 0 ]; then
       echo "$name is not referenced"  >> ~/Desktop/unused_all_images.txt
    fi    

done 
