#!/bin/sh
# 功能
# 兼容cocoapods1.8.4
# 1.修改FRAMEWORK_SEARCH_PATHS
# 2.修改HEADER_SEARCH_PATHS

# 环境
# set -e
export LANG=zh_CN.UTF-8
SCRIPT_DIR="$(cd `dirname $0`; pwd)"
PROJECT_PATH=$(cd ${SCRIPT_DIR}/../;pwd)
cd ${PROJECT_PATH}

PROJECT_NAME="SuningEBuy"

# ifs设置为换行符
OLD_IFS=${IFS}
IFS='
'

echo "cocoapods-helper.sh兼容cocoapods1.8.4"

# USING_CODE_SNDYNAMICFRAMEWORKS
USING_CODE_SNDYNAMICFRAMEWORKS=true
PODFILE_PATH=${PROJECT_PATH}/Podfile
GREP_STRING=$(cat ${PODFILE_PATH} | grep -v '#' | grep "using_code_sndynamicframeworks.*=.*false")
if [[ "${GREP_STRING}" != "" ]]; then
	USING_CODE_SNDYNAMICFRAMEWORKS=false
fi

#### 1.FRAMEWORK_SEARCH_PATHS
#### 目的
# FRAMEWORK_SEARCH_PATHS中增加所有framework的路径
# 这样#import <AlipaySDK/AlipaySDK.h>可以正常工作
#### 步骤
# 1.获取Pods/Target Support Files下所有xcconfig文件
# 2.解析xcconfig文件FRAMEWORK_SEARCH_PATHS，获取所有framework搜索路径
# 3.设置所有xcconfig文件的FRAMEWORK_SEARCH_PATHS值为所有framework搜索路径
# 获取所有FRAMEWORK_SEARCH_PATHS
ALL_FRAMEWORK_SEARCH_PATHS=""
XCCONFIG_PATH_ARRAY=$(find ${PROJECT_PATH}/Pods/Target\ Support\ Files/ -name *.xcconfig)
for XCCONFIG_PATH in ${XCCONFIG_PATH_ARRAY[*]}
do
	# echo ""
	# echo ${XCCONFIG_PATH}
	FRAMEWORK_SEARCH_PATHS=$(cat "${XCCONFIG_PATH}" | grep "FRAMEWORK_SEARCH_PATHS =")
	# 方法1 太耗性能
	# FRAMEWORK_SEARCH_PATHS=(${FRAMEWORK_SEARCH_PATHS// /${IFS}}) 
	# 方法2 速度快 {
	FRAMEWORK_SEARCH_PATHS=$(
		echo ${FRAMEWORK_SEARCH_PATHS} | sed $"s/ /\\${IFS}/g"
	)
	FRAMEWORK_SEARCH_PATHS=(${FRAMEWORK_SEARCH_PATHS})
	# }
	for FRAMEWORK_SEARCH_PATH in ${FRAMEWORK_SEARCH_PATHS[*]}; do
		# echo "FRAMEWORK_SEARCH_PATH: ${FRAMEWORK_SEARCH_PATH}"
		if [[ "${FRAMEWORK_SEARCH_PATH}" = "FRAMEWORK_SEARCH_PATHS" ]]; then
			continue
		fi
		if [[ "${FRAMEWORK_SEARCH_PATH}" = "=" ]]; then
			continue
		fi
		if [[ "${FRAMEWORK_SEARCH_PATH}" = "\$(inherited)" ]]; then
			continue
		fi
		if [[ ! ${ALL_FRAMEWORK_SEARCH_PATHS} =~ "${FRAMEWORK_SEARCH_PATH}" ]]; then
			# echo "found framework path: ${FRAMEWORK_SEARCH_PATH}"
			ALL_FRAMEWORK_SEARCH_PATHS="${ALL_FRAMEWORK_SEARCH_PATHS} ${FRAMEWORK_SEARCH_PATH}"
		fi
	done
done
ALL_FRAMEWORK_SEARCH_PATHS="FRAMEWORK_SEARCH_PATHS = \$(inherited) ${ALL_FRAMEWORK_SEARCH_PATHS}"
# echo ""
# echo "ALL_FRAMEWORK_SEARCH_PATHS: ${ALL_FRAMEWORK_SEARCH_PATHS}"

#### 兼容framework打包
# 这儿做如下约定
# 1.using_code_sndynamicframeworks = false时
# 	FRAMEWORK_SEARCH_PATHS中
# 		${PODS_ROOT}/../../../../../../.cocoapods/repos
# 	替换为
# 		${HOME}/.cocoapods/repos/
# 	做这个也是因为为了兼容该场景下能正常打包，SNDynamicFrameworks_Framework.podspec做了修改
# 	SNDynamicFrameworks_Framework.podspec增加了
# 	pod18_framework_search_paths = ""
# 	pod18_framework_search_paths += " \"${HOME}/.cocoapods/repos/SNEBuy_repos/SNCJigsawSDK/1.0.8\""
# 	xxx
# 	s.xcconfig = { "FRAMEWORK_SEARCH_PATHS" => pod18_framework_search_paths }
# 	这儿不能使用${PODS_ROOT}/../是因为对于SNDynamicFrameworks_Framework.podspec来说，PODS_ROOT是不固定的
# 	所以为了防止重复，这儿统一使用${HOME}/.cocoapods/repos
# 2.using_code_sndynamicframeworks = true时
# 	FRAMEWORK_SEARCH_PATHS中统一使用${PODS_ROOT}/../../../../../../.cocoapods/repos
# 	不能出现${HOME}/.cocoapods/repos
# 	这个是为了解决如下问题
# 	因为cocoapods在post-install阶段，对Pods/Headers和Pods/Target Support Files的操作有如下现象
# 	1.会修改和新增当次pod涉及的xcconfig和header文件
# 	2.不会删除之前已经存在但当次不应该存在的xcconfig和头文件
# 	3.post-install之后的阶段，才会删除Pods下当次不应该存在的xcconfig和头文件
#	所有在下面场景下
# 	1.using_code_sndynamicframeworks = false,pod install
# 	2.using_code_sndynamicframeworks = true,pod install
# 	即使当前using_code_sndynamicframeworks = true，因为之前有的xcconfig没被删除
# 	xcconfig文件中FRAMEWORK_SEARCH_PATHS仍然留有
# 		${HOME}/.cocoapods/repos/SNEBuy_build_rsync/SuningEBuyES-Framework-120/
# 	被读取设置到ALL_FRAMEWORK_SEARCH_PATHS，所以这儿移除兼容下
# 方法1 太耗性能
# TMP_ARRAY=(${ALL_FRAMEWORK_SEARCH_PATHS// /${IFS}}) 
# 方法2 速度快 {
TMP_ARRAY=$(
	echo ${ALL_FRAMEWORK_SEARCH_PATHS} | sed $"s/ /\\${IFS}/g"
)
TMP_ARRAY=(${TMP_ARRAY})
# }
TMP_ARRAY=(${TMP_ARRAY[*]})
ALL_FRAMEWORK_SEARCH_PATHS=""
for FRAMEWORK_SEARCH_PATH in ${TMP_ARRAY[*]}
do
	if [[ "${USING_CODE_SNDYNAMICFRAMEWORKS}" = "false" ]]; then
		# "${PODS_ROOT}/../../../../../../.cocoapods/repos/SNEBuy_repos/AlipaySDK/15.7.5/AlipaySDK"
		# 替换为${HOME}/.cocoapods/repos/SNEBuy_repos/AlipaySDK/15.7.5/AlipaySD
		if [[ "${FRAMEWORK_SEARCH_PATH}" =~ "/.cocoapods/repos/" ]]; then
			FRAMEWORK_SEARCH_PATH=${FRAMEWORK_SEARCH_PATH#*/.cocoapods/repos/}
			FRAMEWORK_SEARCH_PATH="\"\${HOME}/.cocoapods/repos/${FRAMEWORK_SEARCH_PATH}"
		fi
	else
		# 去除${HOME}/.cocoapods/repos/
		if [[ "${FRAMEWORK_SEARCH_PATH}" =~ "\${HOME}/.cocoapods/repos" ]]; then
			continue
		fi
	fi
	ALL_FRAMEWORK_SEARCH_PATHS="${ALL_FRAMEWORK_SEARCH_PATHS} ${FRAMEWORK_SEARCH_PATH}"
done
# 去掉首个空格
if [[ "${ALL_FRAMEWORK_SEARCH_PATHS: 0: 1}" = " " ]]; then
	ALL_FRAMEWORK_SEARCH_PATHS=${ALL_FRAMEWORK_SEARCH_PATHS: 1}
fi
# echo ""
# echo "ALL_FRAMEWORK_SEARCH_PATHS:${ALL_FRAMEWORK_SEARCH_PATHS}"

#### 2.HEADER_SEARCH_PATHS
# POD_HEADER_PATHS
# 在using_code_sndynamicframeworks = true时为空，不用修改
POD_HEADER_PATHS=""

#### 兼容framework打包
#### 目的
# 在using_code_sndynamicframeworks = false场景下
# HEADER_SEARCH_PATHS中加上"xxx/SNDynamicFrameworks/SNDynamicFrameworks.framework/Headers/**"
# 这样集成到SNDynamicFrameworks中的pod库
# 例如:import "AFNetworking.h"和#import <AFNetworking/AFNetworking.h>
# 可以正常工作
if [[ "${USING_CODE_SNDYNAMICFRAMEWORKS}" = "false" ]]; then
	# 获取POD_PATH值
	# "${HOME}/.cocoapods/repos/SNEBuy_build_rsync/SuningEBuyES-Framework-120/SNDynamicFrameworks"
	POD_PATH=""
	# 方法1 太耗性能
	# TMP_ARRAY=(${ALL_FRAMEWORK_SEARCH_PATHS// /${IFS}}) 
	# 方法2 速度快 {
	TMP_ARRAY=$(
		echo ${ALL_FRAMEWORK_SEARCH_PATHS} | sed $"s/ /\\${IFS}/g"
	)
	TMP_ARRAY=(${TMP_ARRAY})
	# }
	TMP_ARRAY=(${TMP_ARRAY[*]})
	for FRAMEWORK_SEARCH_PATH in ${TMP_ARRAY[*]}
	do
		if [[ "${FRAMEWORK_SEARCH_PATH}" =~ "repos/SNEBuy_build_rsync" ]] \
			&& [[ ${FRAMEWORK_SEARCH_PATH} =~ "SNDynamicFrameworks" ]]; then
			POD_PATH=${FRAMEWORK_SEARCH_PATH}
			# 替换"为空字符串
			POD_PATH=${POD_PATH//\"/}
			break
		fi
	done
	# POD_HEADER_PATHS
	POD_HEADER_PATHS="\"${POD_PATH}/SNDynamicFrameworks.framework/Headers/**\""
fi
# echo ""
# echo "POD_HEADER_PATHS:${POD_HEADER_PATHS}"

#### 3.OTHER_CFLAGS
#### 目的
# 升级cocoapods1.8.4之后发现build完成到启动模拟器那步会卡住
# 最终定位到的原因是编译警告太多，可能是xcode处理编译警告显示在xcode的时候卡住了
# 导致编译警告太多的原因是，之前业务库import pods中的类时，如DefineConstant.h
# DefineConstant.h的编译警告是不会出现在业务库类中的
# 而升级完cocoapods1.8.4之后，因为xcconfig中OTHER_CFLAGS缺少-isystem xxx
# 导致了业务库import DefineConstant.h也会警告
# 而DefineConstant.h是很底层的类，导致所有类都报警告，警告量暴增
# 看了jenkins打包上之前总共的日志大小30M左右，现在300M了
# 不过根本原因还是我们没有解决编译警告，只是Podfile中加上inhibit_all_warnings!忽略了
# 而且升级xcode11之后出现了大量的警告，是需要处理的
# 这儿先兼容下回到cocoapods1.2.0的情况，后面有时间再着手解决编译警告问题
# 完成了之后，就可以去除这儿的兼容了
OTHER_CFLAGS="-isystem \"\${PODS_ROOT}/Headers/Public\""
for POD_NAME in $(ls ${PROJECT_PATH}/Pods/Headers/Public)
do
	OTHER_CFLAGS="${OTHER_CFLAGS} -isystem \"\${PODS_ROOT}/Headers/Public/${POD_NAME}\""
done
# echo ""
# echo "OTHER_CFLAGS:${OTHER_CFLAGS}"

#### 4.最终修改xcconfig文件
# 字符串处理
# 方法1 太耗性能
# ALL_FRAMEWORK_SEARCH_PATHS2=${ALL_FRAMEWORK_SEARCH_PATHS//\$/\\\$}
# ALL_FRAMEWORK_SEARCH_PATHS2=${ALL_FRAMEWORK_SEARCH_PATHS2//\//\\\/}
# ALL_FRAMEWORK_SEARCH_PATHS2=${ALL_FRAMEWORK_SEARCH_PATHS2//\"/\\\"}
# # 不需要用的替换，放着防止后面需要
# # ALL_FRAMEWORK_SEARCH_PATHS2=${ALL_FRAMEWORK_SEARCH_PATHS2//\./\\\.}
# # ALL_FRAMEWORK_SEARCH_PATHS2=${ALL_FRAMEWORK_SEARCH_PATHS2//\ /\\\ }
# # echo ${ALL_FRAMEWORK_SEARCH_PATHS2}
# 方法2 速度快
ALL_FRAMEWORK_SEARCH_PATHS2=$(
	echo ${ALL_FRAMEWORK_SEARCH_PATHS} | sed 's/\$/\\\$/g;s/\//\\\//g;s/\"/\\\"/g'
)
# POD_HEADER_PATHS2
POD_HEADER_PATHS2=$(
	echo ${POD_HEADER_PATHS} | sed 's/\$/\\\$/g;s/\//\\\//g;s/\"/\\\"/g'
)
# OTHER_CFLAGS2
OTHER_CFLAGS2=$(
	echo ${OTHER_CFLAGS} | sed 's/\$/\\\$/g;s/\//\\\//g;s/\"/\\\"/g'
)
for XCCONFIG_PATH in ${XCCONFIG_PATH_ARRAY[*]}
do
	# echo ""
	# echo ${XCCONFIG_PATH}

	# 对xcconfig文件,尽可能执行尽量少的命令
	# 修改2处
	# 1.FRAMEWORK_SEARCH_PATHS
	# 2.HEADER_SEARCH_PATHS，兼容framework打包
	
	# 1.FRAMEWORK_SEARCH_PATHS
	# 目的:FRAMEWORK_SEARCH_PATHS值改为所有framework的路径
	FRAMEWORK_SEARCH_PATHS_FLAG=0
	XCCONFIG_CONTENT=$(cat ${XCCONFIG_PATH})
	if [[ ! "${XCCONFIG_CONTENT}" =~ "FRAMEWORK_SEARCH_PATHS" ]]; then
		# xcconfig不包含FRAMEWORK_SEARCH_PATHS，则新增
		# echo " > echo \${ALL_FRAMEWORK_SEARCH_PATHS} >> \${XCCONFIG_PATH}"
		echo ${ALL_FRAMEWORK_SEARCH_PATHS} >> ${XCCONFIG_PATH}
		FRAMEWORK_SEARCH_PATHS_FLAG=1
	fi

	# 2.HEADER_SEARCH_PATHS
	# 目的:HEADER_SEARCH_PATHS中增加
	# "xxx/SuningEBuyES-Framework-120/SNDynamicFrameworks/Headers/**"
	HEADER_SEARCH_PATHS_FLAG=0
	if [[ "${POD_HEADER_PATHS}" = "" ]]; then
		# using_code_sndynamicframeworks = true，不用兼容
		HEADER_SEARCH_PATHS_FLAG=1
	elif [[ ! "${XCCONFIG_CONTENT}" =~ "HEADER_SEARCH_PATHS" ]]; then
		# 如果xcconfig文件中没有HEADER_SEARCH_PATHS，则新增
		# echo " > echo \"HEADER_SEARCH_PATHS = \\\$(inherited) \${POD_HEADER_PATHS}\" >> \${XCCONFIG_PATH}"
		echo "HEADER_SEARCH_PATHS = \$(inherited) ${POD_HEADER_PATHS}" >> ${XCCONFIG_PATH}
		HEADER_SEARCH_PATHS_FLAG=1
	fi

	# 3.OTHER_CFLAGS
	# 目的:Pods-xxx.release.xcconfig文件OTHER_CFLAGS中增加
	# -isystem "${PODS_ROOT}/Headers/Public" -isystem...
	OTHER_CFLAGS_FLAG=0
	if [[ ! "${XCCONFIG_PATH}" =~ Pods-.*\.xcconfig ]]; then
		# 只处理类似Pods-SNChannel.debug.xcconfig文件
		OTHER_CFLAGS_FLAG=1
	elif [[ ! "${XCCONFIG_CONTENT}" =~ "OTHER_CFLAGS" ]]; then
		# xcconfig不包含OTHER_CFLAGS，则新增
		# echo " > echo \"OTHER_CFLAGS = \$(inherited) ${OTHER_CFLAGS}\" >> ${XCCONFIG_PATH}"
		echo "OTHER_CFLAGS = \$(inherited) ${OTHER_CFLAGS}" >> ${XCCONFIG_PATH}
		OTHER_CFLAGS_FLAG=1
	fi

	# 4.最终操作 sed
	if [[ ${FRAMEWORK_SEARCH_PATHS_FLAG} -eq 0 ]] \
		|| [[ ${HEADER_SEARCH_PATHS_FLAG} -eq 0 ]] \
		|| [[ ${OTHER_CFLAGS_FLAG} -eq 0 ]]; then
		# 拼接命令行 CMD_STRING
		CMD_STRING="sed -i '' \""
		# 1.拼接命令行 替换HEADER_SEARCH_PATHS
		if [[ ${HEADER_SEARCH_PATHS_FLAG} -eq 0 ]]; then
			HEADER_SEARCH_PATHS_STRING=$(cat ${XCCONFIG_PATH} | grep "HEADER_SEARCH_PATHS")
			# 字符串处理
			HEADER_SEARCH_PATHS_STRING=$(
				echo ${HEADER_SEARCH_PATHS_STRING} | sed 's/\$/\\\$/g;s/\//\\\//g;s/\"/\\\"/g'
			)
			HEADER_SEARCH_PATHS_STRING="${HEADER_SEARCH_PATHS_STRING} ${POD_HEADER_PATHS2}"
			# 拼接命令行
			# sed -i '' "s/HEADER_SEARCH_PATHS =.*/${HEADER_SEARCH_PATHS_STRING}/" "${XCCONFIG_PATH}"
			CMD_STRING="${CMD_STRING};s/HEADER_SEARCH_PATHS =.*/${HEADER_SEARCH_PATHS_STRING}/"
		fi
		# 2.拼接命令行 替换OTHER_CFLAGS
		if [[ ${OTHER_CFLAGS_FLAG} -eq 0 ]]; then
			# 拼接命令行
			# 替换OTHER_CFLAGS = $(inherited)实在搞不定，先替换OTHER_CFLAGS =吧，效果一样的
			# OTHER_CFLAGS2=222
			# CMD_STRING="sed -i '' \""
			# CMD_STRING="${CMD_STRING};s/OTHER_CFLAGS =/OTHER_CFLAGS = ${OTHER_CFLAGS2}/"
			# CMD_STRING="${CMD_STRING}\" \"${XCCONFIG_PATH}\""
			# eval ${CMD_STRING}
			CMD_STRING="${CMD_STRING};s/OTHER_CFLAGS =/OTHER_CFLAGS = ${OTHER_CFLAGS2}/"
		fi
		# 3.拼接命令行 替换FRAMEWORK_SEARCH_PATHS
		if [[ ${FRAMEWORK_SEARCH_PATHS_FLAG} -eq 0 ]]; then
			# 拼接命令行
			# sed -i '' "s/FRAMEWORK_SEARCH_PATHS =.*/${ALL_FRAMEWORK_SEARCH_PATHS2}/" "${XCCONFIG_PATH}"
			CMD_STRING="${CMD_STRING};s/FRAMEWORK_SEARCH_PATHS =.*/${ALL_FRAMEWORK_SEARCH_PATHS2}/"
		fi
		CMD_STRING="${CMD_STRING}\" \"${XCCONFIG_PATH}\""
		# 4.执行命令
		# echo " > ${CMD_STRING}"
		eval ${CMD_STRING}
		# 命令执行失败,异常退出
		if [[ ! $? -eq 0 ]]; then
			echo "error:脚本异常报错，请联系王彬(14121612)"
		    exit 1
		fi
	fi
done

#### 检查
# 1.检查FRAMEWORK_SEARCH_PATHS
XCCONFIG_PATH="${PROJECT_PATH}/Pods/Target Support Files/Pods-${PROJECT_NAME}/Pods-${PROJECT_NAME}.debug.xcconfig"
CHECK_STRING=$(cat ${XCCONFIG_PATH} | grep "FRAMEWORK_SEARCH_PATHS")
if [[ "${USING_CODE_SNDYNAMICFRAMEWORKS}" = "false" ]]; then
	# using_code_sndynamicframeworks = false,要有
	# 1.${HOME}/.cocoapods/repos/SNEBuy_build_rsync
	GREP_STRING=$(echo ${CHECK_STRING} | grep "\${HOME}/.cocoapods/repos/SNEBuy_build_rsync")
	if [[ "${GREP_STRING}" = "" ]]; then
		echo "error:脚本异常报错，请联系王彬(14121612)"
	fi
else
	# using_code_sndynamicframeworks = true,不能有
	# 1.${HOME}/.cocoapods/repos/SNEBuy_build_rsync
	GREP_STRING=$(echo ${CHECK_STRING} | grep "\${HOME}/.cocoapods/repos/SNEBuy_build_rsync")
	if [[ "${GREP_STRING}" != "" ]]; then
		echo "error:脚本异常报错，请联系王彬(14121612)"
	fi
fi
# 2.检查HEADER_SEARCH_PATHS
CHECK_STRING=$(cat ${XCCONFIG_PATH} | grep "HEADER_SEARCH_PATHS")
if [[ "${USING_CODE_SNDYNAMICFRAMEWORKS}" = "false" ]]; then
	# using_code_sndynamicframeworks = false
	# 检查HEADER_SEARCH_PATHS的检查逻辑比较简单
	# 1.要有SNDynamicFrameworks.framework/Headers/\*\*
	GREP_STRING=$(echo ${CHECK_STRING} | grep "SNDynamicFrameworks.framework/Headers/\*\*")
	if [[ "${GREP_STRING}" = "" ]]; then
		echo "error:脚本异常报错，请联系王彬(14121612)"
	fi
else
	# 在using_code_sndynamicframeworks = true
	# 检查HEADER_SEARCH_PATHS的检查逻辑比较简单
	# 1.不要有SNDynamicFrameworks.framework/Headers/\*\*
	GREP_STRING=$(echo ${CHECK_STRING} | grep "SNDynamicFrameworks.framework/Headers/\*\*")
	if [[ "${GREP_STRING}" != "" ]]; then
		echo "error:脚本异常报错，请联系王彬(14121612)"
	fi
fi

# ifs设回
IFS=${OLD_IFS}

echo "done"

