#!/bin/bash

###########################################常量设置###########################################

set -e

# 基本变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"
cd ${SCRIPT_DIR}

#cd Scripts
#cd AppstoreCheck
#python checkKeychain.py
#
#
#cd ../..

#测试下载环境上配置的suningEBuy_iphone的配置
appId="2"
versionName="9.5.36"
uploadUrl="http://10.37.64.97/ipa/upload.json"

#bundleIdentifier
bundle_id="SuningEMall"

#appName
app_name="苏宁易购"

#workspace
work_space="SuningEBuy.xcworkspace"

#scheme
scheme="SuningEBuy"

#xocdebuild
XCODE_BUILD="xcodebuild -workspace ${work_space} -scheme ${scheme} -configuration Release"
XCODE_CLEAN="xcodebuild -workspace ${work_space} -scheme ${scheme} -configuration Release clean"
XCODE_ARCHIVE="xcodebuild archive -workspace ${work_space} -scheme ${scheme} -configuration Release"
XCODE_EXPORT="xcodebuild -exportArchive -exportOptionsPlist ./exportOptions.plist"

# 授权证书
# 描述文件
PROVISIONING_PROFILE="6ef5a844-71fe-40fb-b799-c2688cad842b"
PROVISIONING_PROFILE_SPECIFIER="SuningEnterprise"
DEVELOPMENT_TEAM="5E2PGY2377"
# 证书
CODE_SIGN_IDENTITY="011EBD34F82EE293AF72D5AFA739092C0932433A"
CODE_SIGN_IDENTITY_SPECIFIER="iPhone Distribution: Suning Appliance Co., Ltd."

# 兼容C证书
# 描述文件
C_PROVISIONING_PROFILE="ebad1e74-19d9-49a3-b47c-6fa46b6d3efa"
C_PROVISIONING_PROFILE_SPECIFIER="SuningEnterprise"
C_DEVELOPMENT_TEAM="5E2PGY2377"
# 证书
C_CODE_SIGN_IDENTITY="011EBD34F82EE293AF72D5AFA739092C0932433A"
C_CODE_SIGN_IDENTITY_SPECIFIER="iPhone Distribution: Suning Appliance Co., Ltd."
C_CERTIFICATE_C_CHECK_COUNT=0
# 描述文件和证书都要有
if [[ -e ~/Library/MobileDevice/Provisioning\ Profiles/${C_PROVISIONING_PROFILE}.mobileprovision ]]; then
	C_CERTIFICATE_C_CHECK_COUNT=$((${C_CERTIFICATE_C_CHECK_COUNT}+1))
fi
if [[ "$(security find-identity -v -p codesigning | grep "${C_CODE_SIGN_IDENTITY}")" != "" ]]; then
	C_CERTIFICATE_C_CHECK_COUNT=$((${C_CERTIFICATE_C_CHECK_COUNT}+1))
fi
if [[ ${C_CERTIFICATE_C_CHECK_COUNT} -eq 2 ]]; then
	# 描述文件
	PROVISIONING_PROFILE=${C_PROVISIONING_PROFILE}
	PROVISIONING_PROFILE_SPECIFIER=${C_PROVISIONING_PROFILE_SPECIFIER}
	DEVELOPMENT_TEAM=${C_DEVELOPMENT_TEAM}
	# 证书
	CODE_SIGN_IDENTITY=${C_CODE_SIGN_IDENTITY}
	CODE_SIGN_IDENTITY_SPECIFIER=${C_CODE_SIGN_IDENTITY_SPECIFIER}
fi
echo "======证书"
echo "PROVISIONING_PROFILE：${PROVISIONING_PROFILE}"
echo "C_PROVISIONING_PROFILE：${C_PROVISIONING_PROFILE}"

#工程绝对路径
project_path=$(pwd)
echo "======工程路径：${project_path}======"

#创建保存打包结果的目录
result_path=${project_path}/build/build_test_$(date +%Y-%m-%d_%H_%M)
mkdir -p "${result_path}"
echo "======最终打包路径：${result_path}======"

#工程配置文件路径
project_name=$(ls | grep xcodeproj | awk -F.xcodeproj '{print $1}')
echo "======工程文件名称：${project_name}======"

target_name=${project_name}
echo "======target名称：${target_name}======"

project_infoplist_path="${project_path}/${project_name}/Info.plist"
today_widget_infoplist_path="${project_path}/TodayWidget/Info.plist"
push_service_infoplist_path="${project_path}/PushService/Info.plist"
# imessage_infoplist_path="${project_path}/EBuyIMessage/Info.plist"
echo "======Info.plist路径：${project_infoplist_path}======"

infoString=${project_path}/${project_name}/zh-Hans.lproj/InfoPlist.strings

project_pbxproj_path="${project_path}/${project_name}.xcodeproj/project.pbxproj"

#取版本号
bundleShortVersion=$(/usr/libexec/PlistBuddy -c "print CFBundleShortVersionString" ${project_infoplist_path})
#兼容xcode11工程版本号$(MARKETING_VERSION)场景
if [[ "${bundleShortVersion}" = "\$(MARKETING_VERSION)" ]]; then
	bundleShortVersion=$(cat ${project_pbxproj_path} | grep MARKETING_VERSION | head -1)
	bundleShortVersion=$(echo ${bundleShortVersion} | awk -F= '{print $2}')
	bundleShortVersion=${bundleShortVersion%;}
fi
echo "======版本号：${bundleShortVersion}======"

versionShort=$(echo ${bundleShortVersion} | sed "s/\.//g")

#配置文件路径
buildConfig=${project_path}/SNProjects/SNCommon/SNCommon/AppConfig/SuningEBuyConfig.h

#URL配置文件路径
urlTypePlist_Path="${project_path}/${project_name}/AppConfig/SNUrlDomainManagerUrlType.plist"

#编译配置打印到文件中
setting_out=${result_path}/build_setting.txt
${XCODE_BUILD}  -showBuildSettings > ${setting_out}

#编译路径
XCODE_BUILD_DIRECTORY=$(grep " OBJROOT" "${setting_out}" | cut  -d  "="  -f  2 | grep -o "[^ ]\+\( \+[^ ]\+\)*")
XCODE_BUILD_DIRECTORY=$(dirname ${XCODE_BUILD_DIRECTORY})
echo "编译路径：${XCODE_BUILD_DIRECTORY}"

#打包完的程序目录
XCODE_BUILD_RESULT_DIRECTORY="${XCODE_BUILD_DIRECTORY}/Products/Release-iphonesimulator"


###########################################检验参数###########################################
#检查是否含-u参数，包含即上传
needUpload=false
#检查打什么包 -pre -sit -prd 如果三者都没有，默认都打
prd_should=false
pre_should=false
sit_should=false
xgpre_should=false
poc_should=false
force_enterprise=false
debug_should=false
skip_clean_should=false
arch_armv7_should=false
arch_arm64_should=false
arch_x86_64_should=false
pack_name="" 
pack_bundle_id=""
skip_config_export_options=false
jenkins_desc=""
jenkins_url=""
xcpretty_should=false

#只修改配置
just_config=false
#忽略证书检查
ignore_check_codesign=true

if [[ $1 = "config" ]]; then
	config $2 $3
	exit
fi

if [[ $# -gt 0 ]]; then
	for arg in "$@"
	do
		if [[ $arg = "-u" ]]; then
			needUpload=true
		elif [[ $arg = "-pre" ]]; then
			pre_should=true
		elif [[ $arg = "-xgpre" ]]; then
			xgpre_should=true
		elif [[ $arg = "-prd" ]]; then
			prd_should=true
		elif [[ $arg = "-sit" ]]; then
			sit_should=true
		elif [[ $arg = "-poc" ]]; then
			poc_should=true
		elif [[ $arg = "-all" ]]; then
			pre_should=true
			prd_should=true
			sit_should=true
			xgpre_should=true
			poc_should=true
		elif [[ $arg = "-ignore-codesign" ]]; then
			ignore_check_codesign=true
		elif [[ $arg = "-force--enterprise" ]]; then
			force_enterprise=true
		elif [[ $arg = "-debug" ]]; then
			debug_should=true
		elif [[ $arg = "-skip--clean" ]]; then
			skip_clean_should=true
		elif [[ $arg = "-arch--armv7" ]]; then
			arch_armv7_should=true
		elif [[ $arg = "-arch--arm64" ]]; then
			arch_arm64_should=true
		elif [[ $arg = "-arch--x86_64" ]]; then
			arch_x86_64_should=true
		elif [[ ${arg:0:7} = "-name--" ]]; then
			pack_name=${arg:7}
		elif [[ ${arg:0:11} = "-bundleid--" ]]; then
			pack_bundle_id=${arg:11}
		elif [[ $arg = "-skip--configExportOptions" ]]; then
			skip_config_export_options=true
		elif [[ ${arg:0:14} = "-jenkinsDesc--" ]]; then
			jenkins_desc=${arg:14}
		elif [[ ${arg:0:13} = "-jenkinsUrl--" ]]; then
			jenkins_url=${arg:13}
		elif [[ $arg = "-xcpretty" ]]; then
			xcpretty_should=true
		fi
	done
fi

#### 参数兼容
# 如果没有设置，默认都为yes
if ! $prd_should && ! $pre_should && ! $sit_should && ! $xgpre_should && ! $poc_should; then
	pre_should=true
	prd_should=true
	sit_should=true
	xgpre_should=true
	poc_should=true
fi

# 默认打armv7和arm64包
if ! ${arch_armv7_should} && ! ${arch_arm64_should} && ! ${arch_x86_64_should}; then
	arch_armv7_should=true
	arch_arm64_should=true
fi
# 如果设置了armv或者arm64架构，则不打x86_64架构的包，arm优先
if ${arch_armv7_should} || ${arch_arm64_should}; then
	arch_x86_64_should=false
fi

# 模拟器架构打debug包，谁会要release的模拟器包
if ${arch_x86_64_should}; then
	debug_should=true
fi

# 本地如果没有xcpretty,不使用
if ! command -v xcpretty > /dev/null; then
	xcpretty_should=false
fi

if ! $ignore_check_codesign; then
	#检查工程中证书的选择
	echo "======检查是否选择了正确的发布证书======"

	codeSign=$(grep "CODE_SIGN_IDENTITY" "${setting_out}" | cut  -d  "="  -f  2 | grep -o "[^ ]\+\( \+[^ ]\+\)*")
	rightDistributionSign="${CODE_SIGN_IDENTITY_SPECIFIER}"
	if [ "${codeSign}" != "${rightDistributionSign}" ]; then
		echo -e "\033[31m 错误的证书:${codeSign}，请进入xcode选择证书为:${rightDistributionSign} \033[0m"
		exit
	fi
	#检查授权文件
	echo "======检查是否选择了正确的签名文件======"
	provisionProfile=$(grep "PROVISIONING_PROFILE[^_]" "${setting_out}" | cut  -d  "="  -f  2 | grep -o "[^ ]\+\( \+[^ ]\+\)*")
	if [ "${provisionProfile}" != "${PROVISIONING_PROFILE}" ]; then
		echo -e ${provisionProfile}
		echo -e "\033[31m 错误的签名，请进入xcode重新选择授权文件 \033[0m"
		exit
	fi
fi

# 修改证书
if ${force_enterprise}; then
	sed -i '' "s/CODE_SIGN_IDENTITY =.*;/CODE_SIGN_IDENTITY = \"${CODE_SIGN_IDENTITY_SPECIFIER}\";/" ${project_pbxproj_path}
	sed -i '' "s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =.*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${CODE_SIGN_IDENTITY_SPECIFIER}\";/" ${project_pbxproj_path}
	sed -i '' "s/DEVELOPMENT_TEAM =.*;/DEVELOPMENT_TEAM = ${DEVELOPMENT_TEAM};/" ${project_pbxproj_path}
	sed -i '' "s/PROVISIONING_PROFILE = .*;/PROVISIONING_PROFILE = \"${PROVISIONING_PROFILE}\";/" ${project_pbxproj_path}
	sed -i '' "s/PROVISIONING_PROFILE_SPECIFIER =.*;/PROVISIONING_PROFILE_SPECIFIER = ${PROVISIONING_PROFILE_SPECIFIER};/" ${project_pbxproj_path}
fi

if ${debug_should};then
	XCODE_BUILD="${XCODE_BUILD// -configuration Release/ -configuration Debug}"
	XCODE_CLEAN="${XCODE_CLEAN// -configuration Release/ -configuration Debug}"
	XCODE_ARCHIVE="${XCODE_ARCHIVE// -configuration Release/ -configuration Debug}"

	XCODE_BUILD_RESULT_DIRECTORY="${XCODE_BUILD_RESULT_DIRECTORY//Release-iphonesimulator/Debug-iphonesimulator}"

	# 禁用断言，防止DEBUG包有断言引起的崩溃
	# 禁用的工程包括，主工程、SNProjects下子工程以及Pods.xcodeproj
	for TMP_PROJECT_PBXPROJ_PATH in $(find ${project_path} -name project.pbxproj -maxdepth 4); do
		sed -i '' "s/buildSettings = {/buildSettings = {ENABLE_NS_ASSERTIONS = NO;/" ${TMP_PROJECT_PBXPROJ_PATH}
		sed -i '' "s/ENABLE_NS_ASSERTIONS = YES/ENABLE_NS_ASSERTIONS = NO/" ${TMP_PROJECT_PBXPROJ_PATH}
	done
fi

if ${arch_armv7_should}; then
	XCODE_ARCHIVE="${XCODE_ARCHIVE} -arch armv7"
fi

if ${arch_arm64_should}; then
	XCODE_ARCHIVE="${XCODE_ARCHIVE} -arch arm64"
fi


###########################################定义函数###########################################
function config()
{
	#修改环境配置
	#pre
	preConfigLine=$(grep -n "kPreTest" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $preConfigLine ]; then
		if [[ $1 = "-pre" ]] || [[ $1 = "-xgpre" ]] || [[ $1 = "-poc" ]]; then
			sed -i '' -e "${preConfigLine}s/^.*$/#define kPreTest        1/" ${buildConfig}
		else
			sed -i '' -e "${preConfigLine}s/^.*$/\/\/#define kPreTest        1/" ${buildConfig}
		fi
	else
		echo -e "\033[31m 未找到配置： kPreTest \033[0m"
	fi

	#sit
	sitConfigLine=$(grep -n "kSitTest" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $sitConfigLine ]; then
		if [[ $1 = "-sit" ]]; then
			sed -i '' -e "${sitConfigLine}s/^.*$/#define kSitTest        1/" ${buildConfig}
		else
			sed -i '' -e "${sitConfigLine}s/^.*$/\/\/#define kSitTest        1/" ${buildConfig}
		fi
	else
		echo -e "\033[31m 未找到配置： kSitTest \033[0m"
	fi

	#release
	releaseConfigLine=$(grep -n "kReleaseH" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $releaseConfigLine ]; then
		if [[ $1 = "-prd" ]]; then
			sed -i '' -e "${releaseConfigLine}s/^.*$/#define kReleaseH        1/" ${buildConfig}
		else
			sed -i '' -e "${releaseConfigLine}s/^.*$/\/\/#define kReleaseH        1/" ${buildConfig}
		fi
	else
		echo -e "\033[31m 未找到配置： kReleaseH \033[0m"
	fi

	#2.2 检查推送、签到服务器等配置


	#2.3 检查信息搜集服务器


	#如果是发布，再检查下bundleIdentifier 和 国际化名称
	if [[ $2 = "-publish" ]]; then
		#修改bundleIdentifier
		bundleIdNew="${bundle_id}"
		/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}" ${project_infoplist_path}
		/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}.TodayWidget" ${today_widget_infoplist_path}
		/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}.PushService" ${push_service_infoplist_path}
		# /usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}.EBuyIMessage" ${imessage_infoplist_path}

		# 移除EBuyWatch版本号设置
		# cd Scripts
		# cd AppstoreCheck
		# python ModifyWatchBundleID.py
		# cd ../..

		# 修改build settings
		sed -i '' "s/PRODUCT_BUNDLE_IDENTIFIER = [^.]*;/PRODUCT_BUNDLE_IDENTIFIER = ${bundle_id};/" ${project_pbxproj_path}
		sed -i '' "s/PRODUCT_BUNDLE_IDENTIFIER =.*TodayWidget;/PRODUCT_BUNDLE_IDENTIFIER = ${bundle_id}.TodayWidget;/" ${project_pbxproj_path} 
		sed -i '' "s/PRODUCT_BUNDLE_IDENTIFIER =.*PushService;/PRODUCT_BUNDLE_IDENTIFIER = ${bundle_id}.PushService;/" ${project_pbxproj_path}

		#国际化名称
		sed -i '' -e "4s/^.*$/CFBundleDisplayName = \"${app_name}\";/" ${infoString}
		#发布时要打开https证书信任验证
		validatesSecureFile=${project_path}/${project_name}/Common/Http/HttpMsgCtrl.mm
		validatesSecureLine=$(grep -n "request.validatesSecureCertificate" "${validatesSecureFile}" | tail -1 | cut -d ":" -f 1)
		if [ $validatesSecureLine ]; then
			sed -i '' -e "${validatesSecureLine}s/NO/YES/g" ${validatesSecureFile}
		else
			echo -e "\033[31m 未找到：validatesSecureCertificate \033[0m"
		fi
	fi
}

# 修改export配置文件
function configExportOptions()
{
	bundleIdNew=$1

	# export配置文件路径
	exportOptions_path="${project_path}/exportOptions.plist"

	# 修改provisioningProfiles
	# 先删除之前的key值
	/usr/libexec/PlistBuddy -c 'Delete :provisioningProfiles' ${exportOptions_path}
	# 添加key值
	/usr/libexec/PlistBuddy -c 'Add :provisioningProfiles dict' ${exportOptions_path}
	# 添加value值
	# /usr/libexec/PlistBuddy -c "Add :provisioningProfiles:'${bundleIdNew}.EBuyIMessage' string ${PROVISIONING_PROFILE}" ${exportOptions_path}
	/usr/libexec/PlistBuddy -c "Add :provisioningProfiles:'${bundleIdNew}.PushService' string ${PROVISIONING_PROFILE}" ${exportOptions_path}
	/usr/libexec/PlistBuddy -c "Add :provisioningProfiles:'${bundleIdNew}.TodayWidget' string ${PROVISIONING_PROFILE}" ${exportOptions_path}
	/usr/libexec/PlistBuddy -c "Add :provisioningProfiles:'${bundleIdNew}' string ${PROVISIONING_PROFILE}" ${exportOptions_path}

	# 修改signingCertificate
	/usr/libexec/PlistBuddy -c 'Delete :signingCertificate' ${exportOptions_path}
	/usr/libexec/PlistBuddy -c "Add :signingCertificate string ${CODE_SIGN_IDENTITY}" ${exportOptions_path}
}


###########################################打包###########################################
BUILD_ENV_ARRAY=()
if $pre_should; then
	BUILD_ENV_ARRAY=(${BUILD_ENV_ARRAY[@]} pre)
fi
if $xgpre_should; then
	BUILD_ENV_ARRAY=(${BUILD_ENV_ARRAY[@]} xgpre)
fi
if $poc_should; then
	BUILD_ENV_ARRAY=(${BUILD_ENV_ARRAY[@]} poc)
fi
if $prd_should; then
	BUILD_ENV_ARRAY=(${BUILD_ENV_ARRAY[@]} prd)
fi
if $sit_should; then
	BUILD_ENV_ARRAY=(${BUILD_ENV_ARRAY[@]} sit)
fi

# 开始打包
for BUILD_ENV in ${BUILD_ENV_ARRAY[@]};  # ${}里面不能有空格
do 
	# 只打第一个环境的包
	if [[ ${BUILD_ENV} != ${BUILD_ENV_ARRAY[0]} ]]; then
		continue
	fi

	BUILD_ENV_UPPERCASE=$(echo $BUILD_ENV | tr '[a-z]' '[A-Z]') 
	# URL配置
	BUILD_URLConfig="0"
	if [[ ${BUILD_ENV} = "pre" ]];then
		BUILD_URLConfig="1"
	elif [[ ${BUILD_ENV} = "sit" ]]; then
		BUILD_URLConfig="2"
	elif [[ ${BUILD_ENV} = "xgpre" ]]; then
		BUILD_URLConfig="3"
	elif [[ ${BUILD_ENV} = "poc" ]]; then
		BUILD_URLConfig="4"
	fi

	#打PRE环境测试包
	TIP_STRING="======打${BUILD_ENV_UPPERCASE}环境的"
	if ${arch_armv7_should}; then
		TIP_STRING="${TIP_STRING} armv7"
	fi
	if ${arch_arm64_should}; then
		TIP_STRING="${TIP_STRING} arm64"
	fi
	if ${arch_x86_64_should}; then
		TIP_STRING="${TIP_STRING} x86_64"
	fi
	TIP_STRING="${TIP_STRING} 测试包======"
	echo "${TIP_STRING}"
	echo "======修改配置中======"

	# SNUrlDomainManagerUrlType.plist
	/usr/libexec/PlistBuddy -c "set URLConfig ${BUILD_URLConfig}" ${urlTypePlist_Path}

	#修改bundleIdentifier
	if [[ -z ${pack_bundle_id} ]]; then
		bundleIdNew="${bundle_id}${versionShort}${BUILD_ENV}"
	else
		bundleIdNew="${pack_bundle_id}"
	fi
	
	/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundleIdNew}" ${project_infoplist_path}
	/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundleIdNew}.TodayWidget" ${today_widget_infoplist_path}
	/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundleIdNew}.PushService" ${push_service_infoplist_path}
	# /usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundleIdNew}.EBuyIMessage" ${imessage_infoplist_path}

	# 修改export配置
	if ! ${skip_config_export_options}; then
		configExportOptions ${bundleIdNew}
	fi

	# 移除EBuyWatch版本号设置
	# cd Scripts
	# cd AppstoreCheck
	# python ModifyWatchBundleID.py
	# cd ../..

	# 修改build settings
	sed -i '' "s/PRODUCT_BUNDLE_IDENTIFIER = [^.]*;/PRODUCT_BUNDLE_IDENTIFIER = ${bundleIdNew};/" ${project_pbxproj_path}
	sed -i '' "s/PRODUCT_BUNDLE_IDENTIFIER =.*TodayWidget;/PRODUCT_BUNDLE_IDENTIFIER = ${bundleIdNew}.TodayWidget;/" ${project_pbxproj_path}
	sed -i '' "s/PRODUCT_BUNDLE_IDENTIFIER =.*PushService;/PRODUCT_BUNDLE_IDENTIFIER = ${bundleIdNew}.PushService;/" ${project_pbxproj_path}

	#修改环境配置
	config -${BUILD_ENV}

	#国际化名称
	sed -i '' -e "4s/^.*$/CFBundleDisplayName = \"${BUILD_ENV_UPPERCASE}${versionShort}.$(date +%m%d%H)\";/" ${infoString}

	# clean
	${XCODE_CLEAN}

	if ${arch_armv7_should} || ${arch_arm64_should}; then
		# 优先判断打arm架构ipa打包
		#archive
		archive_path=$result_path/${project_name}${BUILD_ENV}.xcarchive
		# ${XCODE_ARCHIVE} -archivePath $archive_path PROVISIONING_PROFILE="${PROVISIONING_PROFILE}"
		if ${xcpretty_should}; then
			${XCODE_ARCHIVE} -archivePath $archive_path | xcpretty
		else
			${XCODE_ARCHIVE} -archivePath $archive_path
		fi

		#export archive
		ipa_path=${result_path}/${bundleIdNew}
		${XCODE_EXPORT} -archivePath $archive_path -exportPath $ipa_path

		#ipa名称
		upload_ipa_name="${ipa_path}/SuningEBuy.ipa"
	else
		# build x86_64架构包
		# xcode11老的模拟器默认只包含iPhone 8
		if ${xcpretty_should}; then
			${XCODE_BUILD} -destination "platform=iOS Simulator,name=iPhone 8" ARCHS="x86_64" VALID_ARCHS="x86_64" | xcpretty
		else
			${XCODE_BUILD} -destination "platform=iOS Simulator,name=iPhone 8" ARCHS="x86_64" VALID_ARCHS="x86_64"
		fi
		# 如果没有打出来SuningEBuy可执行文件，打包报错，兼容xcode build失败返回状态仍为0(命令执行成功)的问题
		if [[ ! -f ${XCODE_BUILD_RESULT_DIRECTORY}/${target_name}.app/${target_name} ]]; then
			exit 1
		fi

		# 生成ipa
		ipa_path=${result_path}/${bundleIdNew}
		mkdir -p ${ipa_path}
		# 模拟ipa目录，创建Payload文件夹
		CURRENT_DIRECTORY=$(pwd)
		cd ${XCODE_BUILD_RESULT_DIRECTORY}
		mkdir -p Payload
		mv ${target_name}.app Payload/${target_name}.app
		# 压缩ipa
		zip -r ${ipa_path}/SuningEBuy-x86_64.ipa Payload >/dev/null 2>&1
		# 放APP文件回原来位置
		mv Payload/${target_name}.app ${target_name}.app
		cd ${CURRENT_DIRECTORY}

		#ipa名称
		upload_ipa_name="${ipa_path}/SuningEBuy-x86_64.ipa"
	fi
	
	if ! ${skip_clean_should};then
		# clean,减少占用磁盘空间
		${XCODE_CLEAN}
	fi

	#上传测试包pre
	upload_pack_name=${pack_name}
	if [ -z "$upload_pack_name" ];then
		upload_pack_name=${bundleIdNew}
	else
		upload_pack_name="${upload_pack_name}${BUILD_ENV}"
	fi
	# 提示,debug包
	if ${debug_should};then
		upload_pack_name="debug模式-${upload_pack_name}"
	fi
	# 提示,只打armv7架构包
	if ${arch_armv7_should} && ! ${arch_arm64_should}; then
		upload_pack_name="armv7架构-${upload_pack_name}"
	fi
	# 提示,只打arm64架构包
	if ${arch_arm64_should} && ! ${arch_armv7_should}; then
		upload_pack_name="arm64架构-${upload_pack_name}"
	fi
	# 提示,只打x86_64架构包
	if ${arch_x86_64_should}; then
		upload_pack_name="模拟器x86_64架构-${upload_pack_name}"
	fi

	if ${needUpload}; then
		dateString=$(date '+%Y-%m-%d %H:%M:%S')
		echo "${dateString}:上传测试包${BUILD_ENV}"
		CMD_STRING="curl ${uploadUrl}"
		CMD_STRING="${CMD_STRING} -F 'appId=${appId}'"
		CMD_STRING="${CMD_STRING} -F 'versionName=${versionName}'"
		CMD_STRING="${CMD_STRING} -F 'bundleId=${bundleIdNew}'"
		CMD_STRING="${CMD_STRING} -F 'ipaDesc=${upload_pack_name}'"
		CMD_STRING="${CMD_STRING} -F 'ipaFile=@${upload_ipa_name}'"
		CMD_STRING="${CMD_STRING} -F 'jenkinsDesc=${jenkins_desc}'"
		CMD_STRING="${CMD_STRING} -F 'jenkinsUrl=${jenkins_url}'"
		echo "${dateString}: ${CMD_STRING}"
		eval ${CMD_STRING}
		echo ""
	fi
done


#############################################还原配置#############################################
#修改URL配置
/usr/libexec/PlistBuddy -c "set URLConfig 0" ${urlTypePlist_Path}

/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}" ${project_infoplist_path}
/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}.TodayWidget" ${today_widget_infoplist_path}
/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}.PushService" ${push_service_infoplist_path}
# /usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}.EBuyIMessage" ${imessage_infoplist_path}
# 修改export配置
if ! ${skip_config_export_options}; then
	configExportOptions ${bundle_id}
fi

# 移除EBuyWatch版本号设置
# cd Scripts
# cd AppstoreCheck
# python ModifyWatchBundleID.py
# cd ../..

# 修改build settings
sed -i '' "s/PRODUCT_BUNDLE_IDENTIFIER = [^.]*;/PRODUCT_BUNDLE_IDENTIFIER = ${bundle_id};/" ${project_pbxproj_path}
sed -i '' "s/PRODUCT_BUNDLE_IDENTIFIER =.*TodayWidget;/PRODUCT_BUNDLE_IDENTIFIER = ${bundle_id}.TodayWidget;/" ${project_pbxproj_path} 
sed -i '' "s/PRODUCT_BUNDLE_IDENTIFIER =.*PushService;/PRODUCT_BUNDLE_IDENTIFIER = ${bundle_id}.PushService;/" ${project_pbxproj_path}

sed -i '' -e "4s/^.*$/CFBundleDisplayName = \"${app_name}\";/" ${infoString}


###########################################重新签名，生成其他环境ipa###########################################
if [[ ${#BUILD_ENV_ARRAY[*]} -le 1 ]]; then
	exit 0
fi
echo ''
echo "======重新签名，生成其他环境ipa======"
BUILD_DIRECTORY=${result_path}
IPA_PATH=$(find ${BUILD_DIRECTORY} -name *.ipa | head -1)
BUILD_DIRECTORY=$(dirname ${IPA_PATH})
IPA_NAME=$(basename ${IPA_PATH})
for BUILD_ENV in ${BUILD_ENV_ARRAY[@]};  # ${}里面不能有空格
do 
	# 生成除第一个环境以外的其他环境包
	if [[ ${BUILD_ENV} = ${BUILD_ENV_ARRAY[0]} ]]; then
		continue
	fi

	echo ""
	echo "生成${BUILD_ENV}环境ipa..."
	# URL配置
	BUILD_URLConfig="0"
	if [[ ${BUILD_ENV} = "pre" ]];then
		BUILD_URLConfig="1"
	elif [[ ${BUILD_ENV} = "sit" ]]; then
		BUILD_URLConfig="2"
	elif [[ ${BUILD_ENV} = "xgpre" ]]; then
		BUILD_URLConfig="3"
	elif [[ ${BUILD_ENV} = "poc" ]]; then
		BUILD_URLConfig="4"
	fi
	
	BUILD_ENV_UPPERCASE=$(echo ${BUILD_ENV} | tr '[a-z]' '[A-Z]') 
	IPA_SHORT_VERSION=${bundleShortVersion}
	IPA_SHORT_VERSION=$(echo ${IPA_SHORT_VERSION} | sed "s/\.//g")
	IPA_BUNDLE_DISPLAY_NAME=${BUILD_ENV_UPPERCASE}${IPA_SHORT_VERSION}.$(date +%m%d%H)

	# 是否指定bundleid为
	if [[ -z ${pack_bundle_id} ]]; then
		IPA_BUNDLE_IDENTIFIER="${bundle_id}${versionShort}${BUILD_ENV}"
	else
		IPA_BUNDLE_IDENTIFIER="${pack_bundle_id}"
	fi

	echo "bash ${project_path}/Scripts/resign.sh \
	     ${BUILD_DIRECTORY}/${IPA_NAME} \
	     -urltype--${BUILD_URLConfig} \
	     -bundleid--${IPA_BUNDLE_IDENTIFIER} \
	     -bundlename--${IPA_BUNDLE_DISPLAY_NAME}"
	bash ${project_path}/Scripts/resign.sh \
	     ${BUILD_DIRECTORY}/${IPA_NAME} \
	     -urltype--${BUILD_URLConfig} \
	     -bundleid--${IPA_BUNDLE_IDENTIFIER} \
	     -bundlename--${IPA_BUNDLE_DISPLAY_NAME}

	#测试下载环境上配置的suningEBuy_iphone的配置
	bundleIdNew=${IPA_BUNDLE_IDENTIFIER}

	upload_pack_name=${pack_name}${BUILD_ENV}
	# 提示,debug包
	if ${debug_should};then
		upload_pack_name="debug模式-${upload_pack_name}"
	fi
	# 提示,只打armv7架构包
	if ${arch_armv7_should} && ! ${arch_arm64_should}; then
		upload_pack_name="armv7架构-${upload_pack_name}"
	fi
	# 提示,只打arm64架构包
	if ${arch_arm64_should} && ! ${arch_armv7_should}; then
		upload_pack_name="arm64架构-${upload_pack_name}"
	fi
	# 提示,只打x86_64架构包
	if ${arch_x86_64_should}; then
		upload_pack_name="x86_64架构-${upload_pack_name}"
	fi

	upload_ipa_name="${BUILD_DIRECTORY}/SuningEBuy.ipa"

	if ${needUpload}; then
		dateString=$(date '+%Y-%m-%d %H:%M:%S')
		echo "${dateString}:上传测试包${BUILD_ENV}"
		CMD_STRING="curl ${uploadUrl}"
		CMD_STRING="${CMD_STRING} -F 'appId=${appId}'"
		CMD_STRING="${CMD_STRING} -F 'versionName=${versionName}'"
		CMD_STRING="${CMD_STRING} -F 'bundleId=${bundleIdNew}'"
		CMD_STRING="${CMD_STRING} -F 'ipaDesc=${upload_pack_name}'"
		CMD_STRING="${CMD_STRING} -F 'ipaFile=@${upload_ipa_name}'"
		CMD_STRING="${CMD_STRING} -F 'jenkinsDesc=${jenkins_desc}'"
		CMD_STRING="${CMD_STRING} -F 'jenkinsUrl=${jenkins_url}'"
		echo "${dateString}: ${CMD_STRING}"
		eval ${CMD_STRING}
		echo ""
	fi
done
