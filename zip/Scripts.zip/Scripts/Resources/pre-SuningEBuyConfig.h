//
//  SuningEBuyConfig.h
//  SuningEBuy
//
//  Created by  on 12-9-21.
//  Copyright (c) 2012年 Suning. All rights reserved.


#ifdef DISTRIBUTION_APPSTORE    //----------------发布到AppStore,勿动

#define kReleaseH            1
#define kReleaseInfoH        1
#define kAllowInvalidHttps   0

//包所属渠道区分(AppStore、其余各市场)1官方 0非官方
#define kChannelOfficial     1

#elif DISTRIBUTION_JAILBROKEN   //----------------越狱渠道发布，勿动

#define kReleaseH            1
#define kReleaseInfoH        1
#define kAllowInvalidHttps   0

//包所属渠道区分(AppStore、其余各市场)1官方 0非官方
//目前越狱市场也强制不可引流到苏宁appstore,直接走苹果appstore升级
#define kChannelOfficial     1

#else //----------------自己配置

//1、基本网络环境切换
#define kPreTest        1
//#define kSitTest        1
//#define kReleaseH        1

//3、信息搜集服务器切换

#define kPreInfoTest        1
//#define kSitInfoTest        1
//#define kReleaseInfoH        1

//4、打印开关控制
//#define DEBUGLOG 1

//5、是否允许不受信任的https证书
#define kAllowInvalidHttps   1


//包所属渠道区分(AppStore、其余各市场)1官方 0非官方
#define kChannelOfficial     1

//(AppStore、其余各市场)1 0苏宁发布管理平台
#define kIsOfficial     1

#endif

//-------------------------------------------

//开启网络加速
#define kNetAccelerate       1
