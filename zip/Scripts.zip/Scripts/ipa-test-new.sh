#!/bin/bash

export LANG=en_US.UTF-8

#path
SCRIPT_DIR=$(cd `dirname $0`; pwd)
cd $SCRIPT_DIR
cd ../

#project
PROJECT_NAME="SuningEBuy"
PROJECT_BUNDLEID="SuningEMall"
PROJECT_WORKSPACE="SuningEBuy.xcworkspace"
PROJECT_PROJ="SuningEBuy.xcodeproj"
PROJECT_SCHEME="SuningEBuy"
PROJECT_TARGET_NAME="SuningEBuy"

#build
ARCHIVE_PROVISION_PROFILE="924700d3-fdc3-4e36-ad24-013ef83cc201"
EXPORTARCHIVE_PROVISION_PROFILE="Suning Enterprise new 2014"

#upload
UPLOAD_URL="http://apptest.cnsuning.com/app/SNUploadPackageAction.php"
UPLOAD_APPID="33"
UPLOAD_VERSIONID="187"


echo "build step 1:set parameters"
prd=false
pre=false
sit=false
upload=false

#bash参数
if [[ $# -gt 0 ]]; then
    for arg in "$@"
    do
        if [[ $arg = "-u" ]]; then
            upload=true
        elif [[ $arg = "-prd" ]]; then
            prd=true
        elif [[ $arg = "-pre" ]]; then
            pre=true
        elif [[ $arg = "-sit" ]]; then
            sit=true
        elif [[ $arg = "-all" ]]; then
            prd=true
            pre=true
            sit=true
        fi
    done
fi
if ! $prd && ! $pre && ! $sit; then
    prd=true
    pre=true
    sit=true
fi


echo "build step 2:make build dir"
if $prd||$pre||$sit; then
    RESULT_DIR=build/build_test_$(date +%Y-%m-%d_%H_%M)
    mkdir -p "${RESULT_DIR}"
fi


PROJECT_INFOPLIST_PATH="${PROJECT_NAME}/Info.plist"
bundleShortVersion=$(/usr/libexec/PlistBuddy -c "print CFBundleShortVersionString" ${PROJECT_INFOPLIST_PATH})
BUNDLE_VERSION_SHORT=$(echo ${bundleShortVersion} | sed "s/\.//g")
XCODE_CLEAN="xcodebuild -workspace ${PROJECT_WORKSPACE} -scheme ${PROJECT_SCHEME} -configuration Release clean"
XCODE_ARCHIVE="xcodebuild archive -workspace ${PROJECT_WORKSPACE} -scheme ${PROJECT_SCHEME} -configuration Release"
XCODE_EXPORT="xcodebuild -exportArchive -exportFormat ipa"

echo "build step 4:prd"
if $prd; then

    #SuningEBuyConfig.h
    cp -f Scripts/Resources/prd-SuningEBuyConfig.h ${PROJECT_NAME}/AppConfig/SuningEBuyConfig.h

    #SNUrlDomainManagerUrlType.plist
    /usr/libexec/PlistBuddy -c "set URLConfig 0" "${PROJECT_NAME}/AppConfig/SNUrlDomainManagerUrlType.plist"

    #bundleId
    bundleIdNew="${PROJECT_BUNDLEID}${BUNDLE_VERSION_SHORT}prd"
    /usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundleIdNew}" ${PROJECT_INFOPLIST_PATH}
    #    echo $bundleIdNew

    #国际化名称
    infoString=${PROJECT_NAME}/zh-Hans.lproj/InfoPlist.strings
    sed -i '' -e "4s/^.*$/CFBundleDisplayName = \"PRD${BUNDLE_VERSION_SHORT}.$(date +%m%d%H)\";/" ${infoString}

    #编译工程
    #clean
    ${XCODE_CLEAN}

    #archive
    archive_path=$RESULT_DIR/${PROJECT_NAME}PRD.xcarchive
    ${XCODE_ARCHIVE} -archivePath $archive_path PROVISIONING_PROFILE="${ARCHIVE_PROVISION_PROFILE}"

    #export archive
    ipa_path=${RESULT_DIR}/${bundleIdNew}.ipa
    ${XCODE_EXPORT} -exportArchive -archivePath $archive_path -exportPath $ipa_path -exportProvisioningProfile "${EXPORTARCHIVE_PROVISION_PROFILE}"

    #上传ipa
    if $upload; then
        echo "上传prd包"
        curl -F "app=${UPLOAD_APPID}" -F "version=${UPLOAD_VERSIONID}" -F "bundleIdentifier=${bundleIdNew}" -F "desc=${bundleIdNew}" -F "file=@${ipa_path}" ${UPLOAD_URL}
    fi

fi


echo "build step 5:pre"
if $pre; then

    #SuningEBuyConfig.h
    cp -f Scripts/Resources/pre-SuningEBuyConfig.h ${PROJECT_NAME}/AppConfig/SuningEBuyConfig.h

    #SNUrlDomainManagerUrlType.plist
    /usr/libexec/PlistBuddy -c "set URLConfig 1" "${PROJECT_NAME}/AppConfig/SNUrlDomainManagerUrlType.plist"

    #bundleId
    bundleIdNew="${PROJECT_BUNDLEID}${BUNDLE_VERSION_SHORT}pre"
    /usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundleIdNew}" ${PROJECT_INFOPLIST_PATH}
    #    echo $bundleIdNew

    #国际化名称
    infoString=${PROJECT_NAME}/zh-Hans.lproj/InfoPlist.strings
    sed -i '' -e "4s/^.*$/CFBundleDisplayName = \"PRE${BUNDLE_VERSION_SHORT}.$(date +%m%d%H)\";/" ${infoString}

    #编译工程
    #clean
    ${XCODE_CLEAN}

    #archive
    archive_path=$RESULT_DIR/${PROJECT_NAME}PRE.xcarchive
    ${XCODE_ARCHIVE} -archivePath $archive_path PROVISIONING_PROFILE="${ARCHIVE_PROVISION_PROFILE}"

    #export archive
    ipa_path=${RESULT_DIR}/${bundleIdNew}.ipa
    ${XCODE_EXPORT} -exportArchive -archivePath $archive_path -exportPath $ipa_path -exportProvisioningProfile "${EXPORTARCHIVE_PROVISION_PROFILE}"

    #上传ipa
    if $upload; then
        echo "上传pre包"
        curl -F "app=${UPLOAD_APPID}" -F "version=${UPLOAD_VERSIONID}" -F "bundleIdentifier=${bundleIdNew}" -F "desc=${bundleIdNew}" -F "file=@${ipa_path}" ${UPLOAD_URL}
    fi

fi


echo "build step 6:sit"
if $sit; then

    #SuningEBuyConfig.h
    cp -f Scripts/Resources/sit-SuningEBuyConfig.h ${PROJECT_NAME}/AppConfig/SuningEBuyConfig.h

    #SNUrlDomainManagerUrlType.plist
    /usr/libexec/PlistBuddy -c "set URLConfig 1" "${PROJECT_NAME}/AppConfig/SNUrlDomainManagerUrlType.plist"

    #bundleId
    bundleIdNew="${PROJECT_BUNDLEID}${BUNDLE_VERSION_SHORT}sit"
    /usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundleIdNew}" ${PROJECT_INFOPLIST_PATH}
    #    echo $bundleIdNew

    #国际化名称
    infoString=${PROJECT_NAME}/zh-Hans.lproj/InfoPlist.strings
    sed -i '' -e "4s/^.*$/CFBundleDisplayName = \"SIT${BUNDLE_VERSION_SHORT}.$(date +%m%d%H)\";/" ${infoString}

    #编译工程
    #clean
    ${XCODE_CLEAN}

    #archive
    archive_path=$RESULT_DIR/${PROJECT_NAME}SIT.xcarchive
    ${XCODE_ARCHIVE} -archivePath $archive_path PROVISIONING_PROFILE="${ARCHIVE_PROVISION_PROFILE}"

    #export archive
    ipa_path=${RESULT_DIR}/${bundleIdNew}.ipa
    ${XCODE_EXPORT} -exportArchive -archivePath $archive_path -exportPath $ipa_path -exportProvisioningProfile "${EXPORTARCHIVE_PROVISION_PROFILE}"

    #上传ipa
    if $upload; then
        echo "上传sit包"
        curl -F "app=${UPLOAD_APPID}" -F "version=${UPLOAD_VERSIONID}" -F "bundleIdentifier=${bundleIdNew}" -F "desc=${bundleIdNew}" -F "file=@${ipa_path}" ${UPLOAD_URL}
    fi

fi

