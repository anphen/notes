#!/bin/bash

############################################常量设置###########################################
set -e

BUNDLEDIR=${CONFIGURATION_BUILD_DIR}/SuningEBuy.app
SEARCHDIR=${CONFIGURATION_BUILD_DIR}/SNSHSearch.framework
SEARCHDIRPOD=${SRCROOT}/Pods/SNSHSearch/SNSHSearch/SNSHSearch.framework

HIBUYDIR=${CONFIGURATION_BUILD_DIR}/SNPMHIBUY.framework
HIBUYDIRPOD=${SRCROOT}/Pods/SNPMHIBUY/SNPMHIBUY/SNPMHIBUY.framework

MSFSDIR=${CONFIGURATION_BUILD_DIR}/MSFS.framework

LOGINDIR=${CONFIGURATION_BUILD_DIR}/SNMBLoginRegister.framework
LOGINDIRPOD=${SRCROOT}/Pods/SNSHSearch/SNSHSearch/SNSHSearch.framework

ProductDetailDIR=${CONFIGURATION_BUILD_DIR}/SNSHProductDetail.framework

OnlindServiceDIR=${CONFIGURATION_BUILD_DIR}/SNYXChat.framework

SNSLDIR=${CONFIGURATION_BUILD_DIR}/SNSL.framework

echo "${BUNDLEDIR}"
echo "${SEARCHDIR}"
echo "${SEARCHDIRPOD}"
echo "${HIBUYDIR}"
echo "${HIBUYDIRPOD}"
echo "${MSFSDIR}"
echo "${ProductDetailDIR}"
echo "${SNSLDIR}"

#if [ -d "${SEARCHDIR}" ]; then
#    if ls ${SEARCHDIR}/*.plist >/dev/null 2>&1;then
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*' ${SEARCHDIR}/SNSHSearchHttpDefine-prd.plist ${BUNDLEDIR}
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*' ${SEARCHDIR}/SNSHSearchHttpDefine-pre.plist ${BUNDLEDIR}
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*' ${SEARCHDIR}/SNSHSearchHttpDefine-sit.plist ${BUNDLEDIR}
#    fi
#
#    if ls ${SEARCHDIR}/*.png >/dev/null 2>&1;then
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SEARCHDIR}/*.png ${BUNDLEDIR}
#    fi
#
#    if ls ${SEARCHDIR}/*.jpg >/dev/null 2>&1;then
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SEARCHDIR}/*.jpg ${BUNDLEDIR}
#    fi
#fi

#if [ -d "${SEARCHDIRPOD}" ]; then
#    if ls ${SEARCHDIRPOD}/*.plist >/dev/null 2>&1;then
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*' ${SEARCHDIRPOD}/SNSHSearchHttpDefine-prd.plist ${BUNDLEDIR}
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*' ${SEARCHDIRPOD}/SNSHSearchHttpDefine-pre.plist ${BUNDLEDIR}
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*' ${SEARCHDIRPOD}/SNSHSearchHttpDefine-sit.plist ${BUNDLEDIR}
#    fi
#
#    if ls ${SEARCHDIRPOD}/*.png >/dev/null 2>&1;then
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SEARCHDIRPOD}/*.png ${BUNDLEDIR}
#    fi
#
#    if ls ${SEARCHDIRPOD}/*.jpg >/dev/null 2>&1;then
#        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SEARCHDIRPOD}/*.jpg ${BUNDLEDIR}
#    fi
#fi


if [ -d "${HIBUYDIR}" ]; then
    if ls ${HIBUYDIR}/*.plist >/dev/null 2>&1;then
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIR}/SNPMHiBuyHttpDefine-prd.plist ${BUNDLEDIR}
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIR}/SNPMHiBuyHttpDefine-pre.plist ${BUNDLEDIR}
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIR}/SNPMHiBuyHttpDefine-sit.plist ${BUNDLEDIR}
    fi

    if ls ${HIBUYDIR}/*.png >/dev/null 2>&1;then
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIR}/*.png ${BUNDLEDIR}
    fi

    if ls ${HIBUYDIR}/*.jpg >/dev/null 2>&1;then
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIR}/*.jpg ${BUNDLEDIR}
    fi
fi


if [ -d "${HIBUYDIRPOD}" ]; then
    if ls ${HIBUYDIRPOD}/*.plist >/dev/null 2>&1;then
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIRPOD}/SNPMHiBuyHttpDefine-prd.plist ${BUNDLEDIR}
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIRPOD}/SNPMHiBuyHttpDefine-pre.plist ${BUNDLEDIR}
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIRPOD}/SNPMHiBuyHttpDefine-sit.plist ${BUNDLEDIR}
    fi

    if ls ${HIBUYDIRPOD}/*.png >/dev/null 2>&1;then
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIRPOD}/*.png ${BUNDLEDIR}
    fi

    if ls ${HIBUYDIRPOD}/*.jpg >/dev/null 2>&1;then
        rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${HIBUYDIRPOD}/*.jpg ${BUNDLEDIR}
    fi
fi


if [ -d "${MSFSDIR}" ]; then
if ls ${MSFSDIR}/*.plist >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${MSFSDIR}/SNMSFSHttpDefine-prd.plist ${BUNDLEDIR}
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${MSFSDIR}/SNMSFSHttpDefine-pre.plist ${BUNDLEDIR}
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${MSFSDIR}/SNMSFSHttpDefine-sit.plist ${BUNDLEDIR}
fi

if ls ${MSFSDIR}/*.png >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${MSFSDIR}/*.png ${BUNDLEDIR}
fi

if ls ${MSFSDIR}/*.jpg >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${MSFSDIR}/*.jpg ${BUNDLEDIR}
fi
fi

if [ -d "${LOGINDIR}" ]; then
if ls ${LOGINDIR}/*.plist >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${LOGINDIR}/SNMBLoginHttpDefine-prd.plist ${BUNDLEDIR}
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${LOGINDIR}/SNMBLoginHttpDefine-pre.plist ${BUNDLEDIR}
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${LOGINDIR}/SNMBLoginHttpDefine-sit.plist ${BUNDLEDIR}
fi
fi

if ls ${LOGINDIR}/*.png >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${LOGINDIR}/*.png ${BUNDLEDIR}
fi

if ls ${LOGINDIR}/*.jpg >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${LOGINDIR}/*.jpg ${BUNDLEDIR}
fi

if ls ${LOGINDIR}/*.nib >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${LOGINDIR}/*.nib ${BUNDLEDIR}
fi


if [ -d "${ProductDetailDIR}" ]; then
if ls ${ProductDetailDIR}/*.plist >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${ProductDetailDIR}/SNProDetailHttpDefine-prd.plist ${BUNDLEDIR}
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${ProductDetailDIR}/SNProDetailHttpDefine-pre.plist ${BUNDLEDIR}
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${ProductDetailDIR}/SNProDetailHttpDefine-sit.plist ${BUNDLEDIR}
fi

if ls ${ProductDetailDIR}/*.png >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${ProductDetailDIR}/*.png ${BUNDLEDIR}
fi

if ls ${ProductDetailDIR}/*.jpg >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${ProductDetailDIR}/*.jpg ${BUNDLEDIR}
fi

if ls ${ProductDetailDIR}/*.html >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${ProductDetailDIR}/*.html ${BUNDLEDIR}
fi
fi


if [ -d "${OnlindServiceDIR}" ]; then
if ls ${OnlindServiceDIR}/SNYX_Emoji.plist >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/SNYX_Emoji.plist ${BUNDLEDIR}
fi

if ls ${OnlindServiceDIR}/SNYXChat.plist >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/SNYXChat.plist ${BUNDLEDIR}
fi

if ls ${OnlindServiceDIR}/SNYXDefine-pre.plist >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/SNYXDefine-pre.plist ${BUNDLEDIR}
fi

if ls ${OnlindServiceDIR}/SNYXDefine-release.plist >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/SNYXDefine-release.plist ${BUNDLEDIR}
fi

if ls ${OnlindServiceDIR}/SNYXDefine-sit.plist >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/SNYXDefine-sit.plist ${BUNDLEDIR}
fi

if ls ${OnlindServiceDIR}/*.png >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/*.png ${BUNDLEDIR}
fi

if ls ${OnlindServiceDIR}/*.jpg >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/*.jpg ${BUNDLEDIR}
fi

if ls ${OnlindServiceDIR}/*.jpeg >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/*.jpeg ${BUNDLEDIR}
fi

if ls ${OnlindServiceDIR}/*.wav >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/*.wav ${BUNDLEDIR}
fi

if ls ${OnlindServiceDIR}/*.nib >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${OnlindServiceDIR}/*.nib ${BUNDLEDIR}
fi
fi



if [ -d "${SNSLDIR}" ]; then
if ls ${SNSLDIR}/*.plist >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SNSLDIR}/SNSLOrderAPIDomain-release.plist ${BUNDLEDIR}
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SNSLDIR}/SNSLOrderAPIDomain-pre.plist ${BUNDLEDIR}
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SNSLDIR}/SNSLOrderAPIDomain-sit.plist ${BUNDLEDIR}
fi

if ls ${SNSLDIR}/*.png >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SNSLDIR}/*.png ${BUNDLEDIR}
fi

if ls ${SNSLDIR}/*.jpg >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SNSLDIR}/*.jpg ${BUNDLEDIR}
fi

if ls ${SNSLDIR}/*.html >/dev/null 2>&1;then
rsync -avr --copy-links --no-relative --exclude '*/.svn/*'  ${SNSLDIR}/*.html ${BUNDLEDIR}
fi
fi

