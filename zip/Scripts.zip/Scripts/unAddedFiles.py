#!/usr/bin/python
# -*- coding: utf-8 -*-
# 检查工程中没有加入工程的文件和重名文件
# 执行前先修改project_directory为工程路径

import os, sys

def getCmdOutput(cmd):
    output = os.popen(cmd)
    return output.read()

project_directory = '/Users/wangbin/Desktop/苏宁易购/code/5.3.0/suningebuy_V5.3.0_build'

projectFiles = []

cmd = 'find ' + project_directory + ' -name \'*.pbxproj\''
output = getCmdOutput(cmd)
array = output.split('\n')
isPBXFileReference = False
for string in array:
    if string != '':
        # print '1:'+string

        # isXML snhibuy是这样的
        # 其他的是'PBXFileReference section'
        isXML = False
        isFileNext = False
        for line in open(string):
            if line.find('<?xml version="') != -1:
                isXML = True

            if isXML:#snhibuy
                if isFileNext:
                    isFileNext = False

                    start = line.find('<string>')
                    end = line.find('</string>')
                    if start != -1 and end != -1:
                        file = line[start+8:end]
                        # pathArray = file.split('/')
                        # file = pathArray[len(pathArray)-1]
                        print 'file:' + file + ':file'
                        projectFiles.append(file)
                else:
                    if line.find('<key>path</key>') != -1:
                        isFileNext = True
            else:
                # print '1:2' + line
                if line.find('PBXFileReference section') != -1:
                    isPBXFileReference = not isPBXFileReference

                if isPBXFileReference:
                    start = line.find('/* ')
                    end = line.find(' */')
                    if start != -1 and end != -1:
                        file = line[start+3:end]
                        # print 'file:' + file + ':file'
                        projectFiles.append(file)

directoryFiles = []
projectFilesDict = {}

multipeFiles = []

for type in ['h', 'm', 'mm', 'pch', 'jpg', 'png', 'bundle', 'json', 'txt', 'html', 'js', 'css', 'cer']:
    cmd = 'find ' + project_directory + ' -name \'*.' + type + '\''
    output = getCmdOutput(cmd)
    array = output.split('\n')
    for string in array:
        # print string

        if string.find('.xcassets/') != -1:
            continue

        if string.find('Local Podspecs/') != -1:
            continue

        if string.find('Pods/') != -1:
            continue

        pathArray = string.split('/')
        file = pathArray[len(pathArray)-1]
        # print file
        if file != '':
            # print 'file:' + file + ':file'

            if file in directoryFiles:
                multipeFiles.append(string)
                multipeFiles.append(projectFilesDict[file])

            directoryFiles.append(file)
            projectFilesDict[file] = string

print 'unAddedFiles:'
for file in directoryFiles:
    if file not in projectFiles:
        print projectFilesDict[file].replace(project_directory, '')

print ''
print ''
print ''
print ''
print 'multipeFiles:'
for file in multipeFiles:
    print file.replace(project_directory+'/', '')
