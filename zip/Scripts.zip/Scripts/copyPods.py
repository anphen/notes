#!/usr/bin/python
# -*- coding: utf-8 -*-
# 将工程依赖的pod库拷贝到工程目录下的repos文件夹下
# 这样修改Podfile 
#   $POD_SPEC_PATH = 'repos/SNEBuy_repos/'
#   $POD_BUSS_SPEC_PATH = 'repos/SNEBuy_buss_repos/'
# 就可以独立跑起工程
# 注意:脚本会将完整pod库拷贝过来，如果全代码集成，可删除对应pod库中的framework文件

import os, sys

def getCmdOutput(cmd):
    output = os.popen(cmd)
    return output.read()

project_directory = os.path.abspath(os.path.join(os.path.dirname(__file__),".."))  
podfile_path = project_directory + '/Podfile'
repo_directory = project_directory + '/repos'

POD_SPEC_PATH = ''
POD_BUSS_SPEC_PATH = ''
POD_EBUY_PUBLIC_RESOURCES = ''

print '1:using pods:'
pod_array = []
for line in open(podfile_path):
    # print line;
    if line.find("POD_SPEC_PATH =") != -1:
        index = line.index("'")
        POD_SPEC_PATH = line[index+1:-2]
        # print POD_SPEC_PATH
    elif line.find("POD_BUSS_SPEC_PATH =") != -1:
        index = line.index("'")
        POD_BUSS_SPEC_PATH = line[index+1:-2]
        # print POD_BUSS_SPEC_PATH
    elif line.find("POD_EBUY_PUBLIC_RESOURCES =") != -1:
        index = line.index("'")
        POD_EBUY_PUBLIC_RESOURCES = line[index+1:-2]
        POD_EBUY_PUBLIC_RESOURCES = POD_SPEC_PATH + POD_EBUY_PUBLIC_RESOURCES
        # print POD_EBUY_PUBLIC_RESOURCES

    elif line.find("#") == -1 and line.find("POD_EBUY_PUBLIC_RESOURCES") == -1 and line.find("pod '") != -1:
        start = line.find('path =>')
        start += 9
        pod_name = line[start:]
        pod_name = pod_name.replace("POD_SPEC_PATH + '", POD_SPEC_PATH)
        pod_name = pod_name.replace("POD_BUSS_SPEC_PATH + '", POD_BUSS_SPEC_PATH)
        pod_name = pod_name.replace("'", '')
        pod_name = pod_name.replace("’", '')
        pod_name = pod_name.replace("\n", '')
        pod_name = pod_name.replace(" ", '')
        # print pod_name

        if pod_name not in pod_array:
            print pod_name
            pod_array.append(pod_name)

print '2:copy pods:'
cmd = 'mkdir -p ' + repo_directory + '/SNEBuy_repos'
output = getCmdOutput(cmd)
cmd = 'mkdir -p ' + repo_directory + '/SNEBuy_buss_repos'
output = getCmdOutput(cmd)

pod_array.append(POD_EBUY_PUBLIC_RESOURCES)
for pod_name in pod_array:
    # print pod_name
    dest_directory = pod_name.replace("~/.cocoapods/repos", repo_directory)
    cmd = 'mkdir -p ' + dest_directory
    print cmd
    output = getCmdOutput(cmd)

    cmd = 'cp -rf ' + pod_name + '/* ' + dest_directory
    print cmd
    output = getCmdOutput(cmd)

