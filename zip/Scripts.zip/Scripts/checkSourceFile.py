#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys,re


# originFilePath = '/Users/chupeng/Desktop/项目/5.7.0/suningebuy_V5.7.0/Scripts/mainProject-changed/16080889/SNDJHPalmRushViewController/SNDJHPalmRushViewController.m'


def analyzeFuncBody(body):
    bodyArray = body.split('\n')
    has = 0
    receivers = []
    ifs = []
    filtedIfs = []
    for line in bodyArray:
        if 'removeObjectAtIndex' in line:
            leftIndex = line.find('[')
            rightIndex = line.find('removeObjectAtIndex')
            receiver = line[leftIndex + 1: rightIndex - 1]
            receivers.append(receiver)

            has = 1

        if 'if (' in line or 'if(' in line:
            ifs.append(line)
    # if (has == 1):
    #     print body

    # if len(receivers) > 0:
        # print (receivers)

    # if len(ifs) > 0 and len(receivers):
    #     print (ifs)

    for receiver in receivers:
        for condition in ifs:
            if receiver in condition:
                filtedIfs.append(condition)

        # if len(filtedIfs) > 0:
            # print (filtedIfs)
        if len(filtedIfs) == 0:
            print('风险，可能没判断%s 的 removeObjectAtIndex是否在数组个数范围内' % receiver)
            return 1

    return 0


def findRemoveObjectAtIndexProblem(filepath):
    cleanlines = []
    f = open(filepath, 'r')
    #不是以-号开头的，并且包含-号，但又没有removeObjectAtIndex的，先删除,避免干扰
    for line in f.readlines():
        if not line.startswith('-') and  '-' in line and not 'removeObjectAtIndex' in line:
            continue
        else:
            cleanlines.append(line)


    allstring = ''.join(cleanlines)
    result = re.split(r'- ?\(', allstring)

    #分析函数里带removeObjectAtIndex的行,拿到对象


    # i = 0
    bNeedPrintFilePath = 0
    for content in result:
        # print (i)
        leftIndex = content.find('{')
        rightIndex = content.rfind('}')
        # print('origin func')
        # print content
        # print('\n')
        funcBody = content[leftIndex:rightIndex+1]
        bNeedPrintFilePath += analyzeFuncBody(funcBody)
        # print (funcBody)
        # i += 1

    f.close()

    if bNeedPrintFilePath > 0:
        print (filepath)
        print ('\n\n')


def listDir(dirPath, allSourceFiles):
    if (os.path.isdir(dirPath)):
        a = [x for x in os.listdir(dirPath) if os.path.isdir(os.path.join(dirPath, x))]
        b = [y for y in os.listdir(dirPath) if not os.path.isdir(os.path.join(dirPath, y))]
        for filename in b :
            if (not filename.startswith('old_') and (filename.endswith(".m") or filename.endswith(".h"))):
                allSourceFiles.append(os.path.join(dirPath, filename))
            # print(os.path.join(dirPath, filename))

        for subdir in a:
            # print(os.path.join(dirPath,subdir))
            listDir(os.path.join(dirPath, subdir), allSourceFiles)

    else:
        return


def findError(folderPath):
    AllProblems = {}
    allSourceFiles = []

    listDir(folderPath, allSourceFiles)
    for file in allSourceFiles:
        fileProblem = {}
        fileProblem["filePath"] = file
        fileProblem["objectAtIndexProblems"] = []
        fileProblem["addObjectProblems"] = []
        fileProblem["DelegateProblems"] = []
        fileProblem["syntaxCandyProblems"] = []
        fileProblem["notificationAndKvoProblems"] = []
        fileProblem["removeObjectAtIndex:0"] = []
        fileProblem["objectForKey"] = []

        lineProblem = {}

        f = open (file, 'r')
        for line in f.readlines():
            if (not line.startswith("//")):
                line = line.replace("\n", "")
                if ("objectAtIndex" in line):
                    fileProblem["objectAtIndexProblems"].append(line)
                if ("addObject" in line):
                    fileProblem["addObjectProblems"].append(line)

                #代理没有用weak
                if "@property" in line and ("id<" in line or "id <" in line) and 'delegate' in line.lower():
                        if not "weak" in line:
                            fileProblem["DelegateProblems"].append(line)

                #语法糖@{},@[]
                if "@{" in line or "@[" in line:
                    fileProblem["syntaxCandyProblems"].append(line)


                #removeObjectAtIndex:0
                if "removeObjectAtIndex:0" in line:
                    fileProblem["removeObjectAtIndex:0"].append(line)

                if "objectForKey" in line:
                    fileProblem["objectForKey"].append(line)

        bFindNotificationCenter = 0
        bRemoveNotificationCenter = 0
        f1 = open(file ,'r')
        for line in f1.readlines():
            if "[NSNotificationCenter defaultCenter]" in line and "addObserver" in line:
                bFindNotificationCenter = 1
                break
        f1.close()

        f2 = open(file,'r')
        if bFindNotificationCenter == 1:
            for line1 in f2.readlines():
                if "[NSNotificationCenter defaultCenter]" in line1 and "removeObserver" in line1:
                    bRemoveNotificationCenter = 1;
                    break

            if bRemoveNotificationCenter == 0:
                fileProblem["notificationAndKvoProblems"].append("true")

        f2.close()

        f3 = open(file,'r')
        findRemoveObjectAtIndexProblem(file)
        f3.close()
        AllProblems[file] = fileProblem



    allobjectAtIndexProblems = []
    alladdObjectProblems = []
    allDelegateProblems = []
    allsyntaxCandyProblems = []
    allnotificationAndKvoProblems = []
    allRemoveObjectAtIndexProblems = []
    allobjectForKeyProblems = []
    for key in AllProblems.keys():
        fileProblem = AllProblems[key]


        if len(fileProblem["objectAtIndexProblems"]) > 0:
            allobjectAtIndexProblems.append(key)

        if len(fileProblem["addObjectProblems"]) > 0:
            alladdObjectProblems.append(key)

        if len(fileProblem["DelegateProblems"]) > 0:
            allDelegateProblems.append(key)

        if len(fileProblem["syntaxCandyProblems"]) > 0:
            allsyntaxCandyProblems.append(key)

        if len(fileProblem["notificationAndKvoProblems"]) > 0:
            allnotificationAndKvoProblems.append(key)

        if len(fileProblem["removeObjectAtIndex:0"]) > 0:
            allRemoveObjectAtIndexProblems.append(key)

        if len(fileProblem["objectForKey"]) > 0:
            allobjectForKeyProblems.append(key)

    print ("使用objectAtIndex,而没用safeObjectAtIndex问题:")

    for key in allobjectAtIndexProblems:
        print (key)

    print ("\n\n\n\n\n")

    print ("使用objectForKey,而没用安全api问题:")

    for key in allobjectForKeyProblems:
        print (key)

    print ("\n\n\n\n\n")

    print ("使用addObject，而没用safeAddObject问题:")

    for key in alladdObjectProblems:
        print(key)

    print ("\n\n\n\n\n")

    print ("removeObjectAtIndex:0")

    for key in allRemoveObjectAtIndexProblems:
        print(key)

    print ("\n\n\n\n\n")

    print ("代理非weak问题:")

    for key in allDelegateProblems:
        print(key)

    print ("\n\n\n\n\n")

    print ("使用语法糖@[],@{}:")

    for key in allsyntaxCandyProblems:
        print(key)

    print ("\n\n\n\n\n")

    print ("通知中心未取消注册：")

    for key in allnotificationAndKvoProblems:
        print(key)

    print ("\n\n\n\n\n")



svnArray = [];

svnInfo = {
    'svnUrl': 'http://a.svncode.cnsuning.com/svn/2012_Terminal_code/Ebuy/iphone/branches/suningebuy_V5.7.0',
    'project': 'SuningEBuy'
};
svnArray.append(svnInfo);

svnInfo = {
    'svnUrl': 'http://d.svncode.cnsuning.com/svn/snlogin/branches/snlogin_V1.0.0/5.7.0',
    'project': 'snlogin'
};
svnArray.append(svnInfo);

svnInfo = {
    'svnUrl': 'http://d.svncode.cnsuning.com/svn/ipdetail/branches/ipdetail_V1.0.0/SNSHProductDetail_V5.7.0',
    'project': 'snproduct'
};
svnArray.append(svnInfo);

svnInfo = {
    'svnUrl': 'http://d.svncode.cnsuning.com/svn/ivirtual/branches/ivirtual_V1.0.0/5.7.0',
    'project': 'snsl'
};
svnArray.append(svnInfo);

svnInfo = {
    'svnUrl': 'http://d.svncode.cnsuning.com/svn/ijigu/branches/ijigu_V1.0.0/SNLive/5.7.0',
    'project': 'snmk'
};
svnArray.append(svnInfo);

svnInfo = {
   'svnUrl': 'http://d.svncode.cnsuning.com/svn/snhibuy/branches/snhibuy_V2.0.0/src/5.7.0',
   'project': 'snmember'
};
svnArray.append(svnInfo);

for svnInfo in svnArray:
    project = svnInfo['project']
    print (project + '\n')
    path = "/Users/chupeng/Desktop/项目/750/" + project
    findError(path)
