#!/bin/sh  
# 现在是将SNHWG.framework类似放到Embed Frameworks中，但是不在Link Binary With Libraies中
# 来实现打包的时候，源代码方式集成的SNHWG跟着编译，但是linking的时候，又不链接它
# 主工程就对SNHWG.framework没有了依赖
# 这就要求编译目录Products/Debug-iphoneos下要存在SNHWG.framework，否则执行Embed Frameworks的时候会报错
# 这就要考虑两种场景了
# 1.源代码方式集成的时候，因为是跟着编译的，没有问题
# 2.framework方式集成的时候，SNHWG.framework在pod仓库中，Products/Debug-iphoneos下不存在，就会报错
# 所以这儿增加这个脚本，在Embed Frameworks之前之后执行
# 1.之前执行，如果Products/Debug-iphoneos目录下没有framework，touch一个framework的空文件
# 2.之后执行，如果存在framework的空文件，说明是我们之前touch的，要删除
# 为什么要删除呢
# 因为cocoapods安装framework脚本Pods-SuningEBuy-frameworks.sh的install_framework方法中
# install_framework的优先级是
# 1.${BUILT_PRODUCTS_DIR}/$1
# 2.${BUILT_PRODUCTS_DIR}/$(basename "$1")
# 3.$1
# 其中$1就是framework的路径
# 我们以framework方式集成时，$1是${PODS_ROOT}/../SNEBuy_buss_repos/BussLibs/SNHWG/SNHWG.framework
# install_framework在2.${BUILT_PRODUCTS_DIR}/$(basename "$1")，是可以找到我们之前创建的framework空文件
# 这时候它就还是拷贝这个空文件到app下面的Frameworks目录下
# 这个是有问题的，我们需要它拷贝的是${PODS_ROOT}/../SNEBuy_buss_repos/BussLibs/SNHWG/SNHWG.framework
# 所以执行Embed Frameworks脚本之后，我们要删除之前touch的framework空文件

echo "sn: sn_embed_frameworks.sh $1"


# 变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

# CONFIGURATION_BUILD_DIR兼容
if [ ! ${CONFIGURATION_BUILD_DIR} ]; then
    CONFIGURATION_BUILD_DIR=${SCRIPT_DIR}
fi

# 确保存在的framework
framework_name_array=("SNHWG.framework" "SNMK.framework" "SNChannel.framework" "SNLive.framework" "SNPMPinGou.framework" "SNLazyLoadFrameworks.framework")



# Embed Frameworks脚本之前，确保Products/Debug-iphoneos下有framework
if [ "$1" = "before" ]; then
  for framework_name in ${framework_name_array[@]};
  do
    if [ ! -e "${CONFIGURATION_BUILD_DIR}/${framework_name}" ]; then
      echo "sn: touch ${CONFIGURATION_BUILD_DIR}/${framework_name}"
      touch ${CONFIGURATION_BUILD_DIR}/${framework_name}
    fi
  done
fi


# Embed Frameworks脚本之后，确保Products/Debug-iphoneos下之前生成的framework文件被删除
if [ "$1" = "after" ]; then
  for framework_name in ${framework_name_array[@]};
  do
    if [ -f "${CONFIGURATION_BUILD_DIR}/${framework_name}" ]; then
      echo "sn: rm -f ${CONFIGURATION_BUILD_DIR}/${framework_name}"
      rm -f ${CONFIGURATION_BUILD_DIR}/${framework_name}
    fi
  done
fi

