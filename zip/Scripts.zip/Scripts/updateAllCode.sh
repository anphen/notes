#!/bin/bash
# 功能:更新全代码

# 环境
export LANG=zh_CN.UTF-8
SCRIPT_DIR=$(cd `dirname $0`; pwd)


# 变量
PROJECT_NAME="SuningEBuy"
GIT_BRANCH_NAME="Dev_Br_9536"

SVN="svn"

GIT="git"

# TMP_LOG_PATH
TMP_LOG_PATH="/tmp/ebuy/tmp-update-all-code.log"
mkdir -p $(dirname ${TMP_LOG_PATH})
rm -f ${TMP_LOG_PATH}

PROJECT_DIR=${SCRIPT_DIR}
cd ${PROJECT_DIR}

REVERT_SUB_PROJECT=false
CAN_STASH=false
if [[ $# -gt 0 ]]; then
    for arg in "$@"
    do
        if [[ $arg = "-revert--subproject" ]]; then
            REVERT_SUB_PROJECT=true
        elif [[ $arg = "-stash" ]]; then
            CAN_STASH=true
        fi
    done
fi

# 数据格式
# SNLOGIN_PROJECT_INFO_ARRAY=(
#     "SUB_PROJECT_NAME"                  # 子工程文件夹名称
#     "SUB_PROJECT_GIT_URL"               # 子工程git库地址
#     "SUB_PROJECT_GIT_BRANCH_NAME"       # 子工程git分支名称
#     "SUB_PROJECT_PATH"                 # 子工程clone本地地址
# )
# 主工程
SNMAIN_PROJECT_INFO_ARRAY=(
    "SNMain"
    "http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}"
)
# 登录
SNMBLOGINREGISTER_PROJECT_INFO_ARRAY=(
    "SNMBLoginRegister"
    "http://git.cnsuning.com/snlogin/snlogin.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNMBLoginRegister"
)
# 会员
SNMBMEMBER_PROJECT_INFO_ARRAY=(
    "SNMBMember"
    "http://git.cnsuning.com/snebuyiosmyebuy/myebuy.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNMBMember"
)
# 搜索
SNSHSEARCH_PROJECT_INFO_ARRAY=(
    "SNSHSearch"
    "http://git.cnsuning.com/snsearch/snsearch.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNSHSearch"
)
# 四级页
SNPRODUCTDETAIL_PROJECT_INFO_ARRAY=(
    "SNSHProductDetail"
    "http://git.cnsuning.com/ipdetail/ipdetail.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNSHProductDetail"
)
# 交易线
SNSL_PROJECT_INFO_ARRAY=(
    "SNSL"
    "http://git.cnsuning.com/ivirtual/snsl.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNSL"
)
# 直播
SNLIVE_PROJECT_INFO_ARRAY=(
    "SNLive"
    "http://git.cnsuning.com/ijigu/snlive.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNLive"
)
# 内容
SNPM_PROJECT_INFO_ARRAY=(
    "SNPM"
    "http://git.cnsuning.com/snhibuy/snpm.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNPM"
)
# 营销
SNMK_PROJECT_INFO_ARRAY=(
    "SNMK"
    "http://git.cnsuning.com/snmk/snmk.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNMK"
)
# 海外购
SNHWG_PROJECT_INFO_ARRAY=(
    "SNHWG"
    "http://git.cnsuning.com/snebuyioshwg/snhwg.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNHWG"
)

# 玩法平台
SNPW_PROJECT_INFO_ARRAY=(
    "SNPW"
    "http://git.cnsuning.com/SNPlayWay/SNPW.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNPW"
)

# 频道
SNCHANNEL_PROJECT_INFO_ARRAY=(
    "SNChannel"
    "http://git.cnsuning.com/suningebuy/snchannel.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNChannel"
)
# 拼购
SNPINGOU_PROJECT_INFO_ARRAY=(
    "SNPMPinGou"
    "http://git.cnsuning.com/snpmpg/snpmpg.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNPMPinGou"
)
# 拼购公共
SNPMPINGOUDYNAMIC_PROJECT_INFO_ARRAY=(
    "SNPMPinGouDynamic"
    "http://git.cnsuning.com/pgbase/pgbase.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNPMPinGouDynamic"
)
# super会员原生支付
SNSM_PROJECT_INFO_ARRAY=(
    "SNSM"
    "http://git.cnsuning.com/suningiospaypage/suningiospaypage.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNSM"
)
#首页
SNHOMEPAGE_PROJECT_INFO_ARRAY=(
    "SNHomePage"
    "http://git.cnsuning.com/snioshomepage/snioshomepage.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNHomePage"
)
# SNCommon
SNCOMMON_PROJECT_INFO_ARRAY=(
    "SNCommon"
    "http://git.cnsuning.com/suningebuy/SNCommon.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_DIR}/SNProjects/SNCommon"
    "-sncommon"
    "YES"
)
# 菜场
SNXDCCPAGE_PROJECT_INFO_ARRAY=(
    "SNXDCCPage"
    "http://git.cnsuning.com/SNXDCCFramework/SNXDCC.git"
    "Dev_Br_9516"
    "${PROJECT_DIR}/SNProjects/SNXDCCPage"
)

# ALL_SUB_PROJECT_INFO_ARRAY
ALL_SUB_PROJECT_INFO_ARRAY=(
    SNMAIN_PROJECT_INFO_ARRAY
    SNMBLOGINREGISTER_PROJECT_INFO_ARRAY
    SNMBMEMBER_PROJECT_INFO_ARRAY
    SNSHSEARCH_PROJECT_INFO_ARRAY
    SNPRODUCTDETAIL_PROJECT_INFO_ARRAY
    SNSL_PROJECT_INFO_ARRAY
    SNLIVE_PROJECT_INFO_ARRAY
    SNPM_PROJECT_INFO_ARRAY
    SNMK_PROJECT_INFO_ARRAY
    SNHWG_PROJECT_INFO_ARRAY
    SNPW_PROJECT_INFO_ARRAY
    SNCHANNEL_PROJECT_INFO_ARRAY
    SNPINGOU_PROJECT_INFO_ARRAY
    SNPMPINGOUDYNAMIC_PROJECT_INFO_ARRAY
    SNSM_PROJECT_INFO_ARRAY
    SNHOMEPAGE_PROJECT_INFO_ARRAY
    SNCOMMON_PROJECT_INFO_ARRAY
    SNXDCCPAGE_PROJECT_INFO_ARRAY
)

# 更新代码
BRANCH_ERROR_PROJECT_ARRAY=()
GITURL_ERROR_PROJECT_ARRAY=()
for SUB_PROJECT_INFO_ARRAY in ${ALL_SUB_PROJECT_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
    eval SUB_PROJECT_NAME=\${${SUB_PROJECT_INFO_ARRAY}[0]}
    eval SUB_PROJECT_GIT_URL=\${${SUB_PROJECT_INFO_ARRAY}[1]}
    eval SUB_PROJECT_GIT_BRANCH_NAME=\${${SUB_PROJECT_INFO_ARRAY}[2]}
    eval SUB_PROJECT_PATH=\${${SUB_PROJECT_INFO_ARRAY}[3]}

    cd ${PROJECT_DIR}
    echo ""
    echo "更新${SUB_PROJECT_NAME}代码..."
    if [ -d ${SUB_PROJECT_PATH} ]; then
        cd ${SUB_PROJECT_PATH}

        # revert代码
        if ${REVERT_SUB_PROJECT}; then
            ${GIT} checkout .
            echo "${SUB_PROJECT_NAME} reverted"
            # 当前分支不是${REPO_BRANCH_NAME},切换
            if [[ ! "$(${GIT} status | head -1)" =~ "${SUB_PROJECT_GIT_BRANCH_NAME}" ]]; then
                ${GIT} checkout ${SUB_PROJECT_GIT_BRANCH_NAME}
            fi
        fi

        # 更新代码
        ${GIT} pull 2>${TMP_LOG_PATH}
        RESULT_STRING=$(cat ${TMP_LOG_PATH})
        if [[ "${RESULT_STRING}" != "" ]]; then
            echo ${RESULT_STRING}
        fi
        if [[ ${RESULT_STRING} =~ "fatal:" ]] \
            || [[ ${RESULT_STRING} =~ "error:" ]]; then
            if ${CAN_STASH} && [[ ${RESULT_STRING} =~ "Your local changes to the following files" ]]; then
                # 尝试stash解决
                echo "> git stash..."
                ${GIT} stash 
                echo "> git pull..."
                ${GIT} pull
                echo "> git stash pop..."
                ${GIT} stash pop
            else
                # git pull失败,异常退出
                echo "git pull失败,脚本终止,fix it!!!"
                if ! ${CAN_STASH}; then
                    echo "可以尝试执行\"$0 $* -stash\""
                fi
                exit 1
            fi
        fi

        # 如果当前是Dev、master分支,和脚本指定的开发分支名称不一致,切换成脚本指定的开发分支
        CURRENT_BRANCH_NAME=$(${GIT} status | head -1)
        CURRENT_BRANCH_NAME=${CURRENT_BRANCH_NAME#*branch }
        if [[ ${CURRENT_BRANCH_NAME} =~ "Dev_" ]] || [[ ${CURRENT_BRANCH_NAME} = "master" ]];then
            if [[ ${CURRENT_BRANCH_NAME} != ${SUB_PROJECT_GIT_BRANCH_NAME} ]];then
                ${GIT} checkout ${SUB_PROJECT_GIT_BRANCH_NAME}
                # 切换新分支后，pull最新代码
                ${GIT} pull
            fi
        fi
    else
        ${GIT} clone ${SUB_PROJECT_GIT_URL} ${SUB_PROJECT_PATH}
        cd ${SUB_PROJECT_PATH}
        ${GIT} checkout ${SUB_PROJECT_GIT_BRANCH_NAME}
    fi
    ${GIT} status | head -2

    # 检查分支是否切换成功
    CURRENT_BRANCH_NAME=$(${GIT} status | head -1)
    CURRENT_BRANCH_NAME=${CURRENT_BRANCH_NAME#*branch }
    if [[ ${CURRENT_BRANCH_NAME} != ${SUB_PROJECT_GIT_BRANCH_NAME} ]];then
        BRANCH_ERROR_PROJECT_ARRAY=(${BRANCH_ERROR_PROJECT_ARRAY[*]} ${SUB_PROJECT_NAME})
    fi

    # 检查git url
    # http://git.cnsuning.com/suningiospods/ipods.git
    # git@git.cnsuning.com:suningiospods/ipods.git
    # 忽略协议
    SUB_PROJECT_GIT_URL2=${SUB_PROJECT_GIT_URL}
    if [[ "${SUB_PROJECT_GIT_URL2}" =~ "http" ]]; then
        SUB_PROJECT_GIT_URL2=${SUB_PROJECT_GIT_URL2#*com/}
    fi
    if [[ "${SUB_PROJECT_GIT_URL2}" =~ "git@" ]]; then
        SUB_PROJECT_GIT_URL2=${SUB_PROJECT_GIT_URL2#*:}
    fi
    if [[ ! "$(git remote -v | grep origin | grep fetch)" =~ "${SUB_PROJECT_GIT_URL2}" ]]; then
        GITURL_ERROR_PROJECT_ARRAY=(${GITURL_ERROR_PROJECT_ARRAY[*]} ${SUB_PROJECT_NAME})
    fi
done

# 列出分支切换失败的project，并报错
if [[ "${BRANCH_ERROR_PROJECT_ARRAY}" != "" ]];then
    echo ""
    echo "error:分支切换失败，请先处理"
    for PROJECT_NAME in ${BRANCH_ERROR_PROJECT_ARRAY[@]};  # ${}里面不能有空格
    do
        echo "    ${PROJECT_NAME}"
    done
    exit 1
fi

# 列出分支切换失败的project，并报错
if [[ "${GITURL_ERROR_PROJECT_ARRAY}" != "" ]];then
    echo ""
    echo "error:git库url和脚本配置的不符，请先处理"
    for PROJECT_NAME in ${GITURL_ERROR_PROJECT_ARRAY[@]};  # ${}里面不能有空格
    do
        echo "    ${PROJECT_NAME}"
    done
    exit 1
fi
