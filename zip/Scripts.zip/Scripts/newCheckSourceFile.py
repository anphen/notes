#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys,re,time, shutil

def listDir(dirPath, allSourceFiles):
    if (os.path.isdir(dirPath)):
        a = [x for x in os.listdir(dirPath) if os.path.isdir(os.path.join(dirPath, x))]
        b = [y for y in os.listdir(dirPath) if not os.path.isdir(os.path.join(dirPath, y))]
        for filename in b :
            if (not filename.startswith('old_') and (filename.endswith(".m") or filename.endswith(".h"))):
                #过滤早期的文件，只检查近期创建的
                file = os.path.join(dirPath, filename)
                file_modify_time = time.strftime('%Y-%m-%d', time.localtime(os.stat(file).st_mtime))
                result = compare_time(file_modify_time, checkTime)
                if result >= 0:
                    allSourceFiles.append(file)

        for subdir in a:
            listDir(os.path.join(dirPath, subdir), allSourceFiles)

    else:
        return

def compare_time(time1,time2):
    s_time = time.mktime(time.strptime(time1,'%Y-%m-%d'))
    e_time = time.mktime(time.strptime(time2,'%Y-%m-%d'))
    return int(s_time) - int(e_time)

def findError(project):
    folderPath = "../SNProjects/" + project
    
    allProblems = {}
    allSourceFiles = []

    listDir(folderPath, allSourceFiles)
    for file in allSourceFiles:

        fileProblem = {}
        fileProblem["objectAtIndexProblems"] = []
        fileProblem["removeObjectAtIndexProblems"] = []
        fileProblem["addObjectProblems"] = []
        fileProblem["objectForKeyProblems"] = []
        fileProblem["delegateProblems"] = []
        fileProblem["caseAndBreakProblems"] = []
        fileProblem["syntaxCandyProblems"] = []
        fileProblem["notificationAndKvoProblems"] = []
        fileProblem["httpsProblems"] = []
        fileProblem["openUDIDProblems"] = []
        fileProblem["forProblems"] = []
        fileProblem["uiwebProblems"] = []
        fileProblem["wkinitProblems"] = []
        fileProblem["pasteboardProblems"] = []
        fileProblem["useOldDeviceTokenProblems"] = []
        fileProblem["useYYYYFormatProblems"] = []

        f = open (file, 'r')
        for index, line in enumerate(f.readlines()):
            if (not line.lstrip().startswith("//") and securityFlag not in line):
                line = line.replace("\n", "")
                lineno = index + 1
                #没使用安全方法safeObjectAtIndex
                if ("objectAtIndex:" in line):
                    #fileProblem["objectAtIndexProblems"].append(line)
                    fileProblem["objectAtIndexProblems"].append(str(lineno))
                
                #没使用安全方法safeRemoveObjectAtIndex
                if ("removeObjectAtIndex:" in line):
                    #fileProblem["removeObjectAtIndexProblems"].append(line)
                    fileProblem["removeObjectAtIndexProblems"].append(str(lineno))
                
                #没使用安全方法safeAddObject
                if ("addObject:" in line):
                    #fileProblem["addObjectProblems"].append(line)
                    fileProblem["addObjectProblems"].append(str(lineno))
                
                #没使用安全方法EncodeXXXFromDic
                if "objectForKey:" in line and "Encode" not in line and "FromDic" not in line:
                    #fileProblem["objectForKeyProblems"].append(line)
                    fileProblem["objectForKeyProblems"].append(str(lineno))

                #代理没有用weak
                if "@property" in line and ("id<" in line or "id <" in line) and 'delegate' in line.lower():
                    if not "weak" in line:
                        #fileProblem["delegateProblems"].append(line)
                        fileProblem["delegateProblems"].append(str(lineno))

                #语法糖@{},@[]
                if "@{" in line or "@[" in line:
                    #fileProblem["syntaxCandyProblems"].append(line)
                    fileProblem["syntaxCandyProblems"].append(str(lineno))
                    
                #使用[OpenUDID value]
                if "[OpenUDID value]" in line:
                    #fileProblem["openUDIDProblems"].append(line)
                    fileProblem["openUDIDProblems"].append(str(lineno))
                    
                #使用UIWebView
                if "UIWebView" in line:
                    #fileProblem["uiwebProblems"].append(line)
                    fileProblem["uiwebProblems"].append(str(lineno))
                    
                #使用WKWebView alloc
                if "[WKWebView alloc]" in line or "[WKWebView new]" in line:
                    #fileProblem["wkinitProblems"].append(line)
                    fileProblem["wkinitProblems"].append(str(lineno))
                    
                #没用使用公共方法获取剪切板
                if "[[UIPasteboard generalPasteboard] string]" in line:
                    #fileProblem["pasteboardProblems"].append(line)
                    fileProblem["pasteboardProblems"].append(str(lineno))
                    
                #禁止使用旧的获取设备指纹方法
                if " getDeviceTokenStr];" in line:
                    fileProblem["useOldDeviceTokenProblems"].append(str(lineno))
                    
                #禁止使用YYYY大写格式来计算时间
                if "YYYY" in line:
                    fileProblem["useYYYYFormatProblems"].append(str(lineno))


        #检测通知是否被移除
        bFindNotificationCenter = 0
        bRemoveNotificationCenter = 0
        f1 = open(file ,'r')
        for index, line1 in enumerate(f1.readlines()):
            line1 = line1.replace("\n", "")
            if not line1.lstrip().startswith("//") and "[NSNotificationCenter defaultCenter]" in line1 and "addObserver" in line1:
                bFindNotificationCenter = 1
                break
        f1.close()

        f2 = open(file,'r')
        if bFindNotificationCenter == 1:
            for index, line2 in enumerate(f2.readlines()):
                line2 = line2.replace("\n", "")
                lineno = index + 1
                line2 = line2 + ':' + str(lineno)
                if not line2.lstrip().startswith("//") and "[NSNotificationCenter defaultCenter]" in line2 and "removeObserver" in line2:
                    bRemoveNotificationCenter = 1;
                    break

            if bRemoveNotificationCenter == 0:
                fileProblem["notificationAndKvoProblems"].append("true")
        f2.close()


        #检测case后边是否跟有break
        iCaseCount = 0
        iBreakCount = 0
        f3 = open(file ,'r')
        for index, line3 in enumerate(f3.readlines()):
            line3 = line3.replace("\n", "")
            if (not line3.lstrip().startswith("//") and securityFlag not in line3):
                if "case " in line3 and ":" in line3:
                    iCaseCount += 1;
            
                if "default:" in line3:
                    iCaseCount += 1;
                
                if "break;" in line3:
                    iBreakCount += 1;
                    
        if iCaseCount > iBreakCount:
            fileProblem["caseAndBreakProblems"].append(line3)
        f3.close()
        
        
        #检测https请求
        f4 = open(file ,'r')
        for index, line4 in enumerate(f4.readlines()):
            line4 = line4.replace("\n", "")
            if not line4.lstrip().startswith("//") and securityFlag not in line4:
                if "loadRequest:" in line4 or "NSURLConnection sendSynchronousRequest:" in line4 or "NSURLConnection connectionWithRequest:" in line4 or "NSURLConnection alloc" in line4 or "dataTaskWithRequest:" in line4 or "NSURLSession alloc" in line4:
                    fileProblem["httpsProblems"].append(line4)
        f4.close()
        
        
        #检测for循环内对源数组是否有增删操作
        iLevelCount = 0
        bStartCount = False
        sHasForLine = ""
        f5 = open(file ,'r')
        for index, line5 in enumerate(f5.readlines()):
            line5 = line5.replace("\n", "")
            lineno = index + 1
            if (not line5.lstrip().startswith("//") and securityFlag not in line5):
                if line5.lstrip().startswith("for") or "enumerateObjectsUsingBlock" in line5 or "enumerateIndexesUsingBlock" in line5:
                    iLevelCount = 0
                    bStartCount = False
                    sHasForLine = line5
            
                if len(sHasForLine) > 0:
                    if "{" in line5:
                        iLevelCount += 1;
                        bStartCount = True
                    
                    if "}" in line5:
                        iLevelCount -= 1;
                        
                    if iLevelCount == 0 and bStartCount:
                        bStartCount = False
                        sHasForLine = "";
                        
                    if "addObject" in line5 or "removeObject" in line5 and iLevelCount > 0:
                        tmpstr = line5[line5.find("[")+1:line5.find("addObject")-1];
                        if len(tmpstr) == 0:
                            tmpstr = line5[line5.find("[")+1:line5.find("removeObject")-1];
                        
                        if len(tmpstr) > 0 and tmpstr.lstrip() in sHasForLine:
                            #fileProblem["forProblems"].append(line5)
                            fileProblem["forProblems"].append(str(lineno))
        f5.close()

        allProblems[file] = fileProblem

    #打开结果存在文件
    path = resultDirPath + '/' + project + ".txt"
    f = open(path, 'w')

    #打印问题
    if len(allProblems) > 0:
        print ('['+project+']\n', file = f)
        
        allobjectAtIndexProblems = []
        allremoveObjectAtIndexProblems = []
        alladdObjectProblems = []
        allobjectForKeyProblems = []
        alldelegateProblems = []
        allcaseAndBreakProblems = []
        allsyntaxCandyProblems = []
        allnotificationAndKvoProblems = []
        allhttpsProblems = []
        allOpenUDIDProblems = []
        allForProblems = []
        allUIWebProblems = []
        allWkInitProblems = []
        allPasteboardProblems = []
        allUseOldDeviceTokenProblems = []
        allUseYYYYFormatProblems = []
        
        for key in allProblems.keys():
            fileProblem = allProblems[key]

            if len(fileProblem["objectAtIndexProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["objectAtIndexProblems"])
                allobjectAtIndexProblems.append(finalline)
            
            if len(fileProblem["removeObjectAtIndexProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["removeObjectAtIndexProblems"])
                allremoveObjectAtIndexProblems.append(finalline)

            if len(fileProblem["addObjectProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["addObjectProblems"])
                alladdObjectProblems.append(finalline)
            
            if len(fileProblem["objectForKeyProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["objectForKeyProblems"])
                allobjectForKeyProblems.append(finalline)

            if len(fileProblem["delegateProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["delegateProblems"])
                alldelegateProblems.append(finalline)
            
            if len(fileProblem["caseAndBreakProblems"]) > 0:
                allcaseAndBreakProblems.append(key)

            if len(fileProblem["syntaxCandyProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["syntaxCandyProblems"])
                allsyntaxCandyProblems.append(finalline)

            if len(fileProblem["notificationAndKvoProblems"]) > 0:
                allnotificationAndKvoProblems.append(key)
                    
            if len(fileProblem["httpsProblems"]) > 0:
                allhttpsProblems.append(key)
                
            if len(fileProblem["openUDIDProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["openUDIDProblems"])
                allOpenUDIDProblems.append(finalline)
                
            if len(fileProblem["forProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["forProblems"])
                allForProblems.append(finalline)
                
            if len(fileProblem["uiwebProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["uiwebProblems"])
                allUIWebProblems.append(finalline)
                
            if len(fileProblem["wkinitProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["wkinitProblems"])
                allWkInitProblems.append(finalline)
                
            if len(fileProblem["pasteboardProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["pasteboardProblems"])
                allPasteboardProblems.append(finalline)
                
            if len(fileProblem["useOldDeviceTokenProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["useOldDeviceTokenProblems"])
                allUseOldDeviceTokenProblems.append(finalline)
                
            if len(fileProblem["useYYYYFormatProblems"]) > 0:
                finalline = key+getLineNos(fileProblem["useYYYYFormatProblems"])
                allUseYYYYFormatProblems.append(finalline)

        if len(allobjectAtIndexProblems) > 0:
            print ("使用objectAtIndex，而没用safeObjectAtIndex:", file = f)
            for key in allobjectAtIndexProblems:
                print (key, file = f)
            print ("\n", file = f)

        if len(allremoveObjectAtIndexProblems) > 0:
            print ("使用removeObjectAtIndex，而没用safeRemoveObjectAtIndex:", file = f)
            for key in allremoveObjectAtIndexProblems:
                print (key, file = f)
            print ("\n", file = f)

        if len(alladdObjectProblems) > 0:
            print ("使用addObject，而没用safeAddObject:", file = f)
            for key in alladdObjectProblems:
                print(key, file = f)
            print ("\n", file = f)

        if len(allobjectForKeyProblems) > 0:
            print ("使用objectForKey，而没用EncodeXXXFromDic:", file = f)
            for key in allobjectForKeyProblems:
                print(key, file = f)
            print ("\n", file = f)

        if len(alldelegateProblems) > 0:
            print ("代理没有用weak:", file = f)
            for key in alldelegateProblems:
                print(key, file = f)
            print ("\n", file = f)

        if len(allcaseAndBreakProblems) > 0:
            print ("case与break不匹配:", file = f)
            for key in allcaseAndBreakProblems:
                print(key, file = f)
            print ("\n", file = f)

        if len(allsyntaxCandyProblems) > 0:
            print ("使用语法糖@[],@{}:", file = f)
            for key in allsyntaxCandyProblems:
                print(key, file = f)
            print ("\n", file = f)

        if len(allnotificationAndKvoProblems) > 0:
            print ("通知中心未取消注册:", file = f)
            for key in allnotificationAndKvoProblems:
                print(key, file = f)
            print ("\n\n\n\n", file = f)

#        if len(allhttpsProblems) > 0:
#            print ("有request请求:", file = f)
#            print ("[使用：loadRequest、sendSynchronousRequest、NSURLConnection、sessionWithConfiguration]", file = f)
#            for key in allhttpsProblems:
#                print(key, file = f)
#            print ("\n\n\n\n", file = f)
            
        if len(allOpenUDIDProblems) > 0:
            print ("没有使用[KCOpenUDID value]:", file = f)
            for key in allOpenUDIDProblems:
                print(key, file = f)
            print ("\n\n\n\n", file = f)
            
        if len(allForProblems) > 0:
            print ("for循环内对源数组有增删操作:", file = f)
            for key in allForProblems:
                print(key, file = f)
            print ("\n\n\n\n", file = f)
            
        if len(allUIWebProblems) > 0:
            print ("苹果不再允许使用UIWebView:", file = f)
            for key in allUIWebProblems:
                print(key, file = f)
            print ("\n\n\n\n", file = f)
            
        if len(allWkInitProblems) > 0:
            print ("WKWebView直接初始化会引起cookie同步问题，请使用SNWKWebView:", file = f)
            for key in allWkInitProblems:
                print(key, file = f)
            print ("\n\n\n\n", file = f)
            
        if len(allPasteboardProblems) > 0:
            print ("请使用公共方法获取剪切板:", file = f)
            for key in allPasteboardProblems:
                print(key, file = f)
            print ("\n\n\n\n", file = f)
            
        if len(allUseOldDeviceTokenProblems) > 0:
            print ("禁止使用获取旧设备指纹方法:", file = f)
            for key in allUseOldDeviceTokenProblems:
                print(key, file = f)
            print ("\n\n\n\n", file = f)
            
        if len(allUseYYYYFormatProblems) > 0:
            print ("禁止使用YYYY大写格式来计算时间:", file = f)
            for key in allUseYYYYFormatProblems:
                print(key, file = f)
            print ("\n\n\n\n", file = f)
            
    f.close()
    
def getLineNos(list):
    nos = ''
    for no in list:
        nos = nos + ':' + no
    return nos


#创建结果存在目录，已存在则清空
resultDirPath = './checkResult'
if not os.path.exists(resultDirPath):
    os.makedirs(resultDirPath)
else:
    shutil.rmtree(resultDirPath)
    os.makedirs(resultDirPath)
    
#代码行后有该注释将不会被检测出来 eg: xxx // snCheckSource:[security]
securityFlag = 'snCheckSource:[security]'

#检测时间，该时间之后修改的文件会被检测
#最近一次检测时间2021-04-24
checkTime = '2021-04-24'

#检测工程，该数组内的工程都会被检测
projectsAry = ['SNCommon', 'SNSHProductDetail', 'SNPMPinGou', 'SNPMPinGouDynamic', 'SNMBLoginRegister', 'SNMBMember', 'SNSL', 'SNMK', 'SNPM', 'SNLive', 'SNHWG', 'SNChannel', 'SNSM', 'SNHomePage', 'SNSHSearch', 'SNPW', 'SNXDCCPage'];
#projectsAry = ['SNSL', 'SNMK', 'SNSHProductDetail', 'SNPMPinGou', 'SNPMPinGouDynamic', 'SNMBLoginRegister', 'SNMBMember', 'SNHWG', 'SNPW'];

for project in projectsAry:
    findError(project)
