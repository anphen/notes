#!/bin/bash
# phoebus-snfinance.sh

# set -e

SCRIPT_DIR="$(cd `dirname $0`; pwd)"

# 兼容研发云打包环境，优先使用/Applications/Xcode11.app打包
# 研发云同时装有多个xcode版本，默认的可能不是xcode11
if [[ -e /Applications/Xcode11.app ]]; then
	export PATH=/Applications/Xcode11.app/Contents/Developer/usr/bin:$PATH
fi

#### 更新主工程代码...
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

#### 设置phoebus打包参数...
export SNFINANCE_BUILD=true
export using_code_sndynamicframeworks=true
# 除了sndynamicframeworks，其他都不使用代码
export using_code_sncommon=false
export using_code_snsearch=false
export using_code_snproduct=false
export using_code_snpingou=false
export using_code_snpm=false
export using_code_snlogin=false
export using_code_snmember=false
export using_code_snsl=false
export using_code_snlive=false
export using_code_snmk=false
export using_code_snmptm=false
export using_code_snhwg=false
export using_code_snchannel=false
export using_code_snsm=false
export using_code_snhome=false

export pre=true
export xgpre=true
export prd=true
export sit=true
export SuningEMall=true
export ARMV7=true
export ARM64=true

export UPLOAD_NAME="研发云-官方金融sdk测试包"

export SNMPaySDK_PATH="libSNMPaySDK/tags/3.8.4.4"
export SNMPayDependency_PATH="SNMPayDependency/branches/5.5.0.1"
export YFBWalletLibs_PATH="YFBWalletSDK/branches/3.14.8.28"
export YFBWalletSDKDependency_PATH="YFBWalletSDKDependency/branches/3.8.8.28"

export JENKINS_TYPE="phoebus"

#### 调用jenkins-project-framework.sh
bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-project-framework.sh

