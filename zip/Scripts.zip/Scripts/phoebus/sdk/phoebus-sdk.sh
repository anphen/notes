#!/bin/bash
# phoebus-sdk.sh

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

#### 更新主工程代码...
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

#### 设置phoebus打包参数...
# 默认值
export SNMPaySDK=false
export SNMPayDependency=false
export YFBWalletLibs=false
export YFBWalletSDKDependency=false
export SNKAHttpDNS=false
export CloudyTrace_SDK=false
export SNSHumanMachine=false
export PPTVSDK=false
export SAStatistic_SDK=false
export SNYXChat_Framework=false
export MSFS_Framework=false
export pre=false
export xgpre=false
export poc=false
export prd=false
export sit=false
export SuningEMall=true
export ARMV7=false
export ARM64=true
export X86_64=false
export UPLOAD_NAME=""
export SPECIAL_BRANCH=""
export BUILDID=""
# 根据入参设置
for arg in "$@"
do
	if [[ $arg = "SNMPaySDK" ]]; then
		export SNMPaySDK=true
	elif [[ $arg = "SNMPayDependency" ]]; then
		export SNMPayDependency=true
	elif [[ $arg = "YFBWalletLibs" ]]; then
		export YFBWalletLibs=true
	elif [[ $arg = "YFBWalletSDKDependency" ]]; then
		export YFBWalletSDKDependency=true
	elif [[ $arg = "SNKAHttpDNS" ]]; then
		export SNKAHttpDNS=true
	elif [[ $arg = "CloudyTrace_SDK" ]]; then
		export CloudyTrace_SDK=true
	elif [[ $arg = "SNSHumanMachine" ]]; then
		export SNSHumanMachine=true
	elif [[ $arg = "PPTVSDK" ]]; then
		export PPTVSDK=true
	elif [[ $arg = "SAStatistic_SDK" ]]; then
		export SAStatistic_SDK=true
	elif [[ $arg = "SNYXChat_Framework" ]]; then
		export SNYXChat_Framework=true
	elif [[ $arg = "MSFS_Framework" ]]; then
		export MSFS_Framework=true
	elif [[ $arg = "pre" ]]; then
		export pre=true
	elif [[ $arg = "xgpre" ]]; then
		export xgpre=true
	elif [[ $arg = "poc" ]]; then
		export poc=true
	elif [[ $arg = "prd" ]]; then
		export prd=true
	elif [[ $arg = "sit" ]]; then
		export sit=true
	elif [[ $arg = "poc" ]]; then
		export poc=true
	elif [[ $arg = "SuningEMall" ]]; then
		export SuningEMall=true
	elif [[ $arg = "ARMV7" ]]; then
		export ARMV7=true
	elif [[ $arg = "ARM64" ]]; then
		export ARM64=true
	elif [[ ${arg:0:14} = "-UPLOAD_NAME--" ]]; then
		export UPLOAD_NAME=${arg:14}
    elif [[ ${arg:0:17} = "-SPECIAL_BRANCH--" ]]; then
        export SPECIAL_BRANCH=${arg:17}
	elif [[ ${arg:0:10} = "-BUILDID--" ]]; then
		export BUILDID=${arg:10}
	fi
done

export JENKINS_TYPE="phoebus"

#### 检查BUILDID 用我们jenkins打包的才执行
BUILD_FILE_PATH="${HOME}/.suning/phoebus/build.txt"
mkdir -p $(dirname ${BUILD_FILE_PATH})
touch ${BUILD_FILE_PATH}
LAST_BUILDID=$(cat ${BUILD_FILE_PATH} | grep ${JOB_NAME})
if [[ "${LAST_BUILDID}" = "${JOB_NAME}=${BUILDID}" ]]; then
	echo "error:请使用http://10.37.64.97/jenkins/进行打包"
	exit 1
fi
sed -i '' "/${JOB_NAME}.*/d" ${BUILD_FILE_PATH}
echo "${JOB_NAME}=${BUILDID}" >> ${BUILD_FILE_PATH}

#### 调用jenkins-sdk.sh
echo ""
echo "> bash ${PROJECT_PATH}/Scripts/jenkins/sdk/jenkins-sdk.sh $*"
bash ${PROJECT_PATH}/Scripts/jenkins/sdk/jenkins-sdk.sh $*

