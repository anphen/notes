#!/bin/bash
# 研发云framework打包

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

#### 更新主工程代码...
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

#### 设置phoebus打包参数...
# 默认值
export using_code_sndynamicframeworks=false
export using_code_sncommon=false
export using_code_snsearch=false
export using_code_snproduct=false
export using_code_snpingou=false
export using_code_snpm=false
export using_code_snlogin=false
export using_code_snmember=false
export using_code_snsl=false
export using_code_snlive=false
export using_code_snmk=false
export using_code_snhwg=false
export using_code_snchannel=false
export using_code_snsm=false
export using_code_snhome=false
export using_code_snxdcc=false
export using_code_snpw=false
export pre=false
export xgpre=false
export poc=false
export prd=false
export sit=false
export SuningEMall=false
export ARMV7=false
export ARM64=false
export X86_64=false
export UPLOAD_NAME=""
export BUILDID=""
# 根据入参设置
for arg in "$@"
do
	if [[ $arg = "using_code_sndynamicframeworks" ]]; then
		export using_code_sndynamicframeworks=true
	elif [[ $arg = "using_code_sncommon" ]]; then
		export using_code_sncommon=true
	elif [[ $arg = "using_code_snsearch" ]]; then
		export using_code_snsearch=true
	elif [[ $arg = "using_code_snproduct" ]]; then
		export using_code_snproduct=true
	elif [[ $arg = "using_code_snpingou" ]]; then
		export using_code_snpingou=true
	elif [[ $arg = "using_code_snpm" ]]; then
		export using_code_snpm=true
	elif [[ $arg = "using_code_snlogin" ]]; then
		export using_code_snlogin=true
	elif [[ $arg = "using_code_snmember" ]]; then
		export using_code_snmember=true
	elif [[ $arg = "using_code_snsl" ]]; then
		export using_code_snsl=true
	elif [[ $arg = "using_code_snlive" ]]; then
		export using_code_snlive=true
	elif [[ $arg = "using_code_snmk" ]]; then
		export using_code_snmk=true
	elif [[ $arg = "using_code_snhwg" ]]; then
		export using_code_snhwg=true
	elif [[ $arg = "using_code_snchannel" ]]; then
		export using_code_snchannel=true
	elif [[ $arg = "using_code_snsm" ]]; then
		export using_code_snsm=true
	elif [[ $arg = "using_code_snhome" ]]; then
		export using_code_snhome=true
    elif [[ $arg = "using_code_snxdcc" ]]; then
        export using_code_snxdcc=true
    elif [[ $arg = "using_code_snpw" ]]; then
        export using_code_snpw=true
	elif [[ $arg = "pre" ]]; then
		export pre=true
	elif [[ $arg = "xgpre" ]]; then
		export xgpre=true
	elif [[ $arg = "poc" ]]; then
		export poc=true
	elif [[ $arg = "prd" ]]; then
		export prd=true
	elif [[ $arg = "sit" ]]; then
		export sit=true
	elif [[ $arg = "SuningEMall" ]]; then
		export SuningEMall=true
	elif [[ $arg = "ARMV7" ]]; then
		export ARMV7=true
	elif [[ $arg = "ARM64" ]]; then
		export ARM64=true
	elif [[ $arg = "X86_64" ]]; then
		export X86_64=true
	elif [[ ${arg:0:14} = "-UPLOAD_NAME--" ]]; then
		export UPLOAD_NAME=${arg:14}
	elif [[ ${arg:0:17} = "-SPECIAL_BRANCH--" ]]; then
		export SPECIAL_BRANCH=${arg:17}
	elif [[ ${arg:0:10} = "-BUILDID--" ]]; then
		export BUILDID=${arg:10}
	fi
done

export JENKINS_TYPE="phoebus"

#### 检查BUILDID 用我们jenkins打包的才执行
BUILD_FILE_PATH="${HOME}/.suning/phoebus/build.txt"
mkdir -p $(dirname ${BUILD_FILE_PATH})
touch ${BUILD_FILE_PATH}
LAST_BUILDID=$(cat ${BUILD_FILE_PATH} | grep ${JOB_NAME})
if [[ "${LAST_BUILDID}" = "${JOB_NAME}=${BUILDID}" ]]; then
	echo "error:请使用http://10.37.64.97/jenkins/进行打包"
	exit 1
fi
sed -i '' "/${JOB_NAME}.*/d" ${BUILD_FILE_PATH}
echo "${JOB_NAME}=${BUILDID}" >> ${BUILD_FILE_PATH}

#### 调用jenkins-project.sh
echo ""
echo "> bash ${PROJECT_PATH}/Scripts/jenkins/project/jenkins-project.sh"
bash ${PROJECT_PATH}/Scripts/jenkins/project/jenkins-project.sh

