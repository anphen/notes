#!/bin/bash
# 研发云appstore打包

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

#### 更新主工程代码...
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

#### 设置phoebus打包参数...
# 默认值
export build=false
export BUILDID=""
# 根据入参设置
for arg in "$@"
do
	if [[ $arg = "build" ]]; then
		export build=true
    elif [[ ${arg:0:10} = "-BUILDID--" ]]; then
        export BUILDID=${arg:10}
	fi
done

export JENKINS_TYPE="phoebus"

#### 检查BUILDID 用我们jenkins打包的才执行
BUILD_FILE_PATH="${HOME}/.suning/phoebus/build.txt"
mkdir -p $(dirname ${BUILD_FILE_PATH})
touch ${BUILD_FILE_PATH}
LAST_BUILDID=$(cat ${BUILD_FILE_PATH} | grep ${JOB_NAME})
if [[ "${LAST_BUILDID}" = "${JOB_NAME}=${BUILDID}" ]]; then
	echo "error:请使用http://10.37.64.97/jenkins/进行打包"
	exit 1
fi
sed -i '' "/${JOB_NAME}.*/d" ${BUILD_FILE_PATH}
echo "${JOB_NAME}=${BUILDID}" >> ${BUILD_FILE_PATH}

#### 调用jenkins-appstore.sh
echo ""
echo "> bash ${PROJECT_PATH}/Scripts/jenkins/appstore/jenkins-appstore.sh"
bash ${PROJECT_PATH}/Scripts/jenkins/appstore/jenkins-appstore.sh

