#!/bin/bash
# phoebus-ioptimi.sh

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

#### 更新主工程代码...
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

#### 设置phoebus打包参数...
# 默认值
export build=false
export analyze=false
export SNMPaySDK_PATH=""
export SNMPayDependency_PATH=""
export YFBWalletLibs_PATH=""
export YFBWalletSDKDependency_PATH=""
export SPECIAL_BRANCH=""
export BUILDID=""
# 根据入参设置
for arg in "$@"
do
	if [[ $arg = "build" ]]; then
		export build=true
	elif [[ $arg = "analyze" ]]; then
		export analyze=true
	elif [[ ${arg:0:14} = "-SNMPaySDK_PATH--" ]]; then
		export SNMPaySDK_PATH=${arg:17}
    elif [[ ${arg:0:17} = "-SNMPayDependency_PATH--" ]]; then
        export SNMPayDependency_PATH=${arg:24}
    elif [[ ${arg:0:14} = "-YFBWalletLibs_PATH--" ]]; then
		export YFBWalletLibs_PATH=${arg:21}
    elif [[ ${arg:0:17} = "-YFBWalletSDKDependency_PATH--" ]]; then
        export YFBWalletSDKDependency_PATH=${arg:30}
    elif [[ ${arg:0:17} = "-SPECIAL_BRANCH--" ]]; then
        export SPECIAL_BRANCH=${arg:17}
	elif [[ ${arg:0:10} = "-BUILDID--" ]]; then
		export BUILDID=${arg:10}
	fi
done

export JENKINS_TYPE="phoebus"

#### 检查BUILDID 用我们jenkins打包的才执行
BUILD_FILE_PATH="${HOME}/.suning/phoebus/build.txt"
mkdir -p $(dirname ${BUILD_FILE_PATH})
touch ${BUILD_FILE_PATH}
LAST_BUILDID=$(cat ${BUILD_FILE_PATH} | grep ${JOB_NAME})
if [[ "${LAST_BUILDID}" = "${JOB_NAME}=${BUILDID}" ]]; then
	echo "error:请使用http://10.37.64.97/jenkins/进行打包"
	exit 1
fi
sed -i '' "/${JOB_NAME}.*/d" ${BUILD_FILE_PATH}
echo "${JOB_NAME}=${BUILDID}" >> ${BUILD_FILE_PATH}

#### 调用jenkins-ioptimi.sh
echo ""
echo "> bash ${PROJECT_PATH}/Scripts/jenkins/ioptimi/jenkins-ioptimi.sh $*"
bash ${PROJECT_PATH}/Scripts/jenkins/ioptimi/jenkins-ioptimi.sh $*

