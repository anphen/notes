#!/bin/bash
# jenkins设置中执行脚本

# set -e

echo "phoebus.sh"

echo ''
echo 'step 1:环境变量...'
export LANG=zh_CN.UTF-8
PATH=${PATH}:/usr/local/bin
if [ -f /etc/bash_profile ];then 
    echo "source /etc/bash_profile"
    source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
    echo "source /etc/bashrc"
    source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
    echo "source ~/.bash_profile"
    source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
    echo "source ~/.bashrc"
    source ~/.bashrc
fi
export LANG=en_US.UTF-8
export LANGUAGE=en_US.UTF-8
export LC_ALL=en_US.UTF-8

# 基本变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

# git
GIT="git"

# pod
POD=pod

# 研发云打包的WORKSPACE是：/Users/suning/jenkins/pre/workspace/SuningEBuyIphone_snjg_785
if [ ! ${WORKSPACE} ]; then
    WORKSPACE=${SCRIPT_DIR}/../
fi
cd ${WORKSPACE}

PROJECT_NAME="SuningEBuy"

GIT_BRANCH_NAME="Dev_Br_820"


echo ''
echo 'step 2:环境检查...'
echo "cmd: whoami"
whoami

echo ""
echo "cmd: pwd"
pwd

echo ""
echo "cmd: df -lh"
df -lh

echo ""
echo "cmd: ${HOME}/.git-credentials"
cat ${HOME}/.git-credentials 

echo ""
echo "cmd: ls"
ls

echo ""
echo "cmd: echo ${WORKSPACE}"
echo ${WORKSPACE}

echo ""
echo "cmd: echo ${WORKSPACE}/SNProjects"
echo ${WORKSPACE}/SNProjects

echo ""
echo "cmd: ls ${WORKSPACE}/../"
ls ${WORKSPACE}/../

echo ""
echo "cmd: ls ${WORKSPACE}/../../"
ls ${WORKSPACE}/../../

echo ""
echo "cmd: ls ${HOME}/.cocoapods/repos"
ls ${HOME}/.cocoapods/repos

echo ""
echo "cmd: pod --version"
${POD} --version

echo ""
echo "cmd: pod _1.2.0_ --version"
${POD} _1.2.0_ --version

echo ""
echo "${GIT} status"
${GIT} status

echo ""
echo "which git"
which git


echo ''
echo 'step 3:clean...'
echo "3-1:主工程${PROJECT_NAME}"
if [ -d ${WORKSPACE} ]; then
    echo "clean ${WORKSPACE}..."
    cd ${WORKSPACE}
    ${GIT} checkout . 
    ${GIT} checkout ${GIT_BRANCH_NAME}
    echo "finish"
fi

echo "3-2:pod repos"
# SNEBuy_buss_repos、SNEBuy_repos
for POD_REPO_PATH in "${HOME}/.cocoapods/repos/SNEBuy_buss_repos" \
  "${HOME}/.cocoapods/repos/SNEBuy_repos"
do
    if [ -d ${POD_REPO_PATH} ]; then
        echo "clean ${POD_REPO_PATH}..."
        cd ${POD_REPO_PATH}
        # 放弃本地修改
        ${GIT} checkout . 
        # 删除Untracked files
        ${GIT} clean -fd
        # 切换分支
        if [[ ${POD_REPO_PATH} =~ "SNEBuy_buss_repos" ]]; then
            ${GIT} checkout Dev_Br_buss_repos
        elif [[ ${POD_REPO_PATH} =~ "SNEBuy_repos" ]]; then
            ${GIT} checkout Dev_Br_repos
        fi
        echo "finish"
    fi
done

# SNEBuy_YFBSDK、SNEBuy_YFBWallet
for POD_REPO_PATH in "${HOME}/.cocoapods/repos/SNEBuy_YFBSDK" \
  "${HOME}/.cocoapods/repos/SNEBuy_YFBWallet"
do
    if [ -d ${POD_REPO_PATH} ]; then
        echo "clean ${POD_REPO_PATH}..."
        cd ${POD_REPO_PATH}
        ${SVN} cleanup
        echo "finish"
    fi
done

echo "3-3:子工程"
for SUB_PROJECT_PATH in "${WORKSPACE}/SNProjects/SNChannel" \
  "${WORKSPACE}/SNProjects/SNDynamicFrameworks" \
  "${WORKSPACE}/SNProjects/SNHomePage" \
  "${WORKSPACE}/SNProjects/SNHWG" \
  "${WORKSPACE}/SNProjects/SNLive" \
  "${WORKSPACE}/SNProjects/SNMBLoginRegister" \
  "${WORKSPACE}/SNProjects/SNMBMember" \
  "${WORKSPACE}/SNProjects/SNMK" \
  "${WORKSPACE}/SNProjects/SNMPTM" \
  "${WORKSPACE}/SNProjects/SNPM" \
  "${WORKSPACE}/SNProjects/SNPMPinGou" \
  "${WORKSPACE}/SNProjects/SNPMPinGouDynamic" \
  "${WORKSPACE}/SNProjects/SNSHProductDetail" \
  "${WORKSPACE}/SNProjects/SNSHSearch" \
  "${WORKSPACE}/SNProjects/SNSL" \
  "${WORKSPACE}/SNProjects/SNSM"
do
    if [ -d ${SUB_PROJECT_PATH} ]; then
        echo "clean ${SUB_PROJECT_PATH}..."
        cd ${SUB_PROJECT_PATH}
        # 放弃本地修改
        ${GIT} checkout . 
        # 删除Untracked files
        ${GIT} clean -fd
        # 切换分支
        ${GIT} checkout ${GIT_BRANCH_NAME}
        echo "finish"
    fi
done


echo 'step 4:pull code...'
echo ''
cd ${WORKSPACE}
${GIT} pull

# ios-ci-1才拉取全代码
if [[ "$(whoami)" = "ios-ci-1" ]]; then
    echo ""
    echo '执行 bash updateAllCode.sh'
    bash updateAllCode.sh -checkupdate
    # 命令执行失败,异常退出
    if [[ ! $? -eq 0 ]]; then
        exit 1
    fi
fi


echo ''
echo 'step 5:pod集成...'
# 清空之前pod生成文件
rm -f ${WORKSPACE}/Podfile.lock
rm -rf ${WORKSPACE}/Pods
rm -rf ${WORKSPACE}/SuningEBuy.xcworkspace
# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
for PBXPROJ_PATH in `find ${WORKSPACE}/SNProjects -name project.pbxproj`
do
    sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
done

# 修改Podfile
PODFILE_PATH=${WORKSPACE}/Podfile
# ios-ci-1才拉取全代码
if [[ "$(whoami)" = "ios-ci-1" ]]; then
    sed -i '' "s/using_code_snsearch = false/using_code_snsearch = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snproduct = false/using_code_snproduct = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snpingou = false/using_code_snpingou = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snpm = false/using_code_snpm = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snlogin = false/using_code_snlogin = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snmember = false/using_code_snmember = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snsl = false/using_code_snsl = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snlive = false/using_code_snlive = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snmk = false/using_code_snmk = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snmptm = false/using_code_snmptm = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snhwg = false/using_code_snhwg = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snchannel = false/using_code_snchannel = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snsm = false/using_code_snsm = true/" ${PODFILE_PATH}
    sed -i '' "s/using_code_snhome = false/using_code_snhome = true/" ${PODFILE_PATH}
fi

bash ${WORKSPACE}/repo-update.sh -checkupdate
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi


echo ''
echo 'step 6:打包...'
echo "6-1:打印Podfile"
cat ${PODFILE_PATH}

echo ""
echo 'bash ipa-test-bundleId.sh -prd -pre -sit -xgpre -u -name--官方定位分享包(研发云) -force--enterprise'
bash ipa-test-bundleId.sh -prd -pre -sit -xgpre -u -name--官方定位分享包\(研发云\) -force--enterprise
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi


echo ''
echo 'step 7:将ipa移到build/下...'
# 将ipa移到build/下
mv build/*/*/*.ipa build/SuningEBuy.ipa

