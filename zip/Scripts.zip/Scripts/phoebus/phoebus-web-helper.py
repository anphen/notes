#!/usr/bin/python
# -*- coding: utf-8 -*-
# 用法
# export CMD_NAME="startjob" # 1-startjob,2-stopjob
# export USER_NAME=14121612
# export PASSWORD=xxx
# export SYSTEM_ID=260
# export TASK_NAME=ebuy_ssa_910
# export BUILD_PARAMS=SAStatistic_SDK
# python Scripts/phoebus/phoebus-web-helper.py

import urllib
import json
import http.cookiejar
import re
import time
import os, sys
import zlib
import socket
import ssl

# python3默认utf-8编码
# # 设置utf-8编码
# reload(sys)
# sys.setdefaultencoding('UTF-8')
# # 请求超时时间设置为60s
# default_timeout = 60
# socket.setdefaulttimeout(default_timeout)

# 全局不验证https证书
# https://www.cnblogs.com/adampei-bobo/p/10073728.html
ssl._create_default_https_context = ssl._create_unverified_context

reportData = [];

#### cookie
def loadCookie():
    global cookie
    global opener

    #### 读取cookie
    # cookie 声明一个MozillaCookieJar对象实例来保存cookie，之后写入文件
    cookie_file_path = os.getenv('HOME') + '/.suning/phoebus/phoebus-web-helper/cookie.txt'
    cookie = http.cookiejar.MozillaCookieJar(cookie_file_path)
    if os.path.exists(cookie_file_path):
        print('load cookie from ' + cookie_file_path)
        cookie.load(cookie_file_path, ignore_discard=True, ignore_expires=True)
    else:
        print('load new cookie ' + cookie_file_path)
        cookie_file_directory = os.path.dirname(cookie_file_path)
        if not os.path.exists(cookie_file_directory):
            os.makedirs(cookie_file_directory)
        cookie.save(ignore_discard=True, ignore_expires=True)
    http_handler = urllib.request.HTTPCookieProcessor(cookie)
    opener = urllib.request.build_opener(http_handler)

#### common
def retryRequest(request_key=None, tip_string=None):
    global request_retry_times_dict

    if request_key in request_retry_times_dict:
        request_retry_times = request_retry_times_dict[request_key]
    else:
        request_retry_times = 0
    request_retry_times += 1
    if request_retry_times < request_retry_times_max:
        request_retry_times_dict[request_key] = request_retry_times
        if tip_string is not None and tip_string != '':
            print(tip_string)
        result_dict = eval(request_key)()
        return result_dict
    else:
        print('error: request retry time beyond ' + str(request_retry_times))
        exit(1)

#### login
def checkLogin(param_dict=None):
    result_dict = {}
    if param_dict is None:
        param_dict = searchByPage()

    result_login = True
    if 'policy' in param_dict['response_json'] \
        and param_dict['response_json']['policy'] == 'RESTRICTED':
        result_login = False
    if not result_login:
        print('login: False')
        login1()
    else:
        print('login: True')

    result_dict['login'] = result_login
    return result_dict
    
def login1():
    print('login1()')
    global last_login_timestamp

    # 5分钟内只能登录一次
    timestamp = time.time()
    # print('time:' + str(timestamp - last_login_timestamp))
    if timestamp - last_login_timestamp < 5*60:
        print('error: 5分钟内连续登录了两次，请检查代码')
        exit(1)
    last_login_timestamp = timestamp

    result_dict = {}

    url = 'https://sso.cnsuning.com/ids/login?loginTheme=upgc&service=http%3A%2F%2Fphoebus.cnsuning.com%2Fphoebus%2Fauth%3FtargetUrl%3Dhttp%253A%252F%252Fphoebus.cnsuning.com%252Fnew%252F%2523%252Fintegration%252FtaskManage%253Ffrom%253DsysManage'
    print('url:' + url)

    headers = {}
    headers['Host'] = 'sso.cnsuning.com'
    headers['Connection'] = 'keep-alive'
    headers['Cache-Control'] = 'max-age=0'
    headers['Upgrade-Insecure-Requests'] = 1
    headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0'
    headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
    headers['Sec-Fetch-Site'] = 'same-origin'
    headers['Sec-Fetch-Mode'] = 'navigate'
    headers['Sec-Fetch-User'] = '?1'
    headers['Sec-Fetch-Dest'] = 'document'
    headers['Accept-Encoding'] = 'gzip, deflate, br'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8'

    try:
        # get请求没有data
        request = urllib.request.Request(url, headers=headers)
        response = opener.open(request)
        response_string = response.read()
        # gzip解压
        if response.headers.get('Content-Encoding') == 'gzip':
            response_string = zlib.decompress(response_string, 16+zlib.MAX_WBITS)
        response_string = response_string.decode("utf-8")
        # print('response_string:' + response_string)
        result_dict['response_string'] = response_string
    except (socket.error, urllib.request.URLError) as e:
        # socket.error socket.timeout: timed out
        # urllib.request.URLError urllib.request.URLError: <urlopen error [Errno 50] Network is down>
        # 1号打包机经常报错urllib.request.URLError异常.立刻再调用接口会报同样的错误，需要延迟再调用
        # 延迟
        print(e)
        time.sleep(sleep_time)
        request_key = 'login1'
        tip_string = 'request timeout, retry...'
        if isinstance(e, urllib.request.URLError):
            tip_string = "Network is down, retry..."
        return retryRequest(request_key, tip_string)

    # 保存cookie
    cookie.save(ignore_discard=True, ignore_expires=True)

    if 'https://sso.cnsuning.com/ids/login' in response.geturl():
        login2(result_dict)
    else:
        # url:http://phoebus.cnsuning.com/new/#/integration/taskManage?from=sysManage
        print('自动登录成功')

def login2(param_dict=None):
    print('login2()')

    response_string = param_dict['response_string']

    uuid_dict = getUUIDFromHtml(response_string)
    uuid_string = uuid_dict['uuid_string']

    service_url = 'http://phoebus.cnsuning.com/phoebus/auth?targetUrl=http%3A%2F%2Fphoebus.cnsuning.com%2Fnew%2F%23%2Fintegration%2FtaskManage%3Ffrom%3DsysManage'
    service_url_urlencoded = urllib.parse.quote(service_url)

    url = 'https://sso.cnsuning.com/ids/login'
    print('url:' + url)

    headers = {}
    headers['Sec-Fetch-Site'] = 'same-origin'
    headers['Sec-Fetch-Mode'] = 'navigate'
    headers['Sec-Fetch-User'] = '?1'
    headers['Sec-Fetch-Dest'] = 'document'
    headers['Referer'] = 'https://sso.cnsuning.com/ids/login?loginTheme=upgc&service='+service_url_urlencoded
    headers['Content-Type'] = 'application/x-www-form-urlencoded'
    headers['Accept-Encoding'] = 'gzip, deflate, br'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8'
    headers['Cache-Control'] = 'max-age=0'
    headers['Upgrade-Insecure-Requests'] = 1
    headers['Origin'] = 'https://sso.cnsuning.com'
    headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0'
    headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
    headers['Connection'] = 'keep-alive'

    values = {}
    values['uuid'] = uuid_string
    values['service'] = service_url
    values['loginTheme'] = 'upgc'
    values['username'] = user_name
    values['password'] = password
    data = urllib.parse.urlencode(values)
    # print('data:' + data)
    data = data.encode(encoding='UTF8')

    try:
        # post请求有data
        request = urllib.request.Request(url, data=data, headers=headers)
        response = opener.open(request)
        response_string = response.read()
        # gzip解压
        if response.headers.get('Content-Encoding') == 'gzip':
            response_string = zlib.decompress(response_string, 16+zlib.MAX_WBITS)
        response_string = response_string.decode("utf-8")
        # print('response_string:' + response_string)
    except (socket.error, urllib.request.URLError) as e:
        # socket.error socket.timeout: timed out
        # urllib.request.URLError urllib.request.URLError: <urlopen error [Errno 50] Network is down>
        # 1号打包机经常报错urllib.request.URLError异常.立刻再调用接口会报同样的错误，需要延迟再调用
        # 延迟
        time.sleep(sleep_time)
        request_key = 'login2'
        tip_string = 'request timeout, retry...'
        if isinstance(e, urllib.request.URLError):
            tip_string = "Network is down, retry..."
        return retryRequest(request_key, tip_string)

    # 保存cookie
    cookie.save(ignore_discard=True, ignore_expires=True)

def getUUIDFromHtml(html):
    result_dict = {}
    url = None
    uuid_string = None
    if html is not None:
        # actionString
        # <input type="hidden" name="service" value="http://phoebus.cnsuning.com:80/phoebus/auth?targetUrl=http%3A%2F%2Fphoebus.cnsuning.com%3A80%2Fphoebus%2FprojectFlow%2FsearchByPage%3FsnapshotId%3D1DF92009716748BDFA805A695FAF6AE3" /> 
        array = re.findall(r'name=\"service\" value=\".*\"', html)
        if len(array) > 0:
            url = array[0]
            url = url.replace('name=\"service\"', '')
            url = url.replace('value=\"', '')
            url = url.replace('\"', '')
            # url = 'http://sso.cloudytrace.com' + url

        # altString
        # <input type="hidden" name="uuid" value="dd3af439-40c9-4945-b0a9-63f4695f6e79" />
        # <input type='hidden' name='uuid' value="4f073b40-fd90-4011-a764-019f1918f8c4" />
        array = re.findall(r'name=[\'\"]+uuid[\'\"]+ value=[\'\"]+.*[\'\"]+', html)
        if len(array) > 0:
            uuid_string = array[0]
            uuid_string = uuid_string.replace('name=\"uuid\" ', '')
            uuid_string = uuid_string.replace('name=\'uuid\' ', '')
            uuid_string = uuid_string.replace('value=\"', '')
            uuid_string = uuid_string.replace('value=\'', '')
            uuid_string = uuid_string.replace('\"', '')
            uuid_string = uuid_string.replace('\'', '')

    if uuid_string is None:
        print("getUUIDFromHtml() not found uuid")
        exit(1)

    result_dict['url'] = url
    result_dict['uuid_string'] = uuid_string
    return result_dict

#### searchByPage
def searchByPage():
    result_dict = {}

    # 检查登录
    # http://phoebus.cnsuning.com/phoebus/projectFlow/searchByPage
    url = 'http://phoebus.cnsuning.com/phoebus/projectFlow/searchByPage'
    url += '?page=1&pageSize=50&type=12'
    url += '&sysId=' + system_id
    print('url:' + url)

    headers = {}
    headers['Accept'] = 'application/json, text/plain, */*'
    headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0'
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Referer'] = 'http://phoebus.cnsuning.com/new/'
    headers['Accept-Encoding'] = 'gzip, deflate'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8'
    headers['Connection'] = 'keep-alive'

    try:
        # get请求没有data
        request = urllib.request.Request(url, headers=headers)
        response = opener.open(request)
        response_string = response.read()
        # gzip解压
        if response.headers.get('Content-Encoding') == 'gzip':
            response_string = zlib.decompress(response_string, 16+zlib.MAX_WBITS)
        response_string = response_string.decode("utf-8")
        result_dict['response_string'] = response_string

        if print_debug_info:
            print('response_string:' + response_string)

        # 请求成功
        response_json = json.loads(response_string)
        result_dict['response_json'] = response_json
    except ValueError as e:
        print('error: searchByPage() parse json fail')
        exit(1)
    except (socket.error, urllib.request.URLError) as e:
        # socket.error socket.timeout: timed out
        # urllib.request.URLError urllib.request.URLError: <urlopen error [Errno 50] Network is down>
        # 1号打包机经常报错urllib.request.URLError异常.立刻再调用接口会报同样的错误，需要延迟再调用
        # 延迟
        time.sleep(sleep_time)
        request_key = 'searchByPage'
        tip_string = 'request timeout, retry...'
        if isinstance(e, urllib.request.URLError):
            tip_string = "Network is down, retry..."
        return retryRequest(request_key, tip_string)
    else:
        pass
    finally:
        pass

    # 检查登录状态,登录状态可能随时失效
    login_dict = checkLogin(result_dict)
    # 之前没有登录，则再次请求数据
    if not login_dict['login']:
        result_dict = searchByPage()

    # 保存cookie
    cookie.save(ignore_discard=True, ignore_expires=True)

    return result_dict

#### getBranchQuality
def getBranchQuality():
    result_dict = {}

    # 检查登录
    # http:///phoebus/projectFlow/getBranchQuality/198642/SIT
    env_type = 'SIT'
    if config_environment == 2:
        env_type = 'SIT'
    elif config_environment == 4:
        env_type = 'PRD'
    url = 'http://phoebus.cnsuning.com/phoebus/projectFlow/getBranchQuality'
    url += '/'+branch_id
    url += '/'+env_type
    print('url:' + url)

    headers = {}
    headers['Host'] = 'phoebus.cnsuning.com'
    headers['Accept'] = 'application/json, text/plain, */*'
    headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0'
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Referer'] = 'http://phoebus.cnsuning.com/new/'
    headers['Accept-Encoding'] = 'gzip, deflate'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8'
    headers['Connection'] = 'keep-alive'

    try:
        # get请求没有data
        request = urllib.request.Request(url, headers=headers)
        response = opener.open(request)
        response_string = response.read()
        # gzip解压
        if response.headers.get('Content-Encoding') == 'gzip':
            response_string = zlib.decompress(response_string, 16+zlib.MAX_WBITS)
        response_string = response_string.decode("utf-8")
        result_dict['response_string'] = response_string

        if print_debug_info:
            print('response_string:' + response_string)

        # 请求成功
        response_json = json.loads(response_string)
        result_dict['response_json'] = response_json
    except ValueError as e:
        print('error: getBranchQuality() parse json fail')
        exit(1)
    except (socket.error, urllib.request.URLError) as e:
        # socket.error socket.timeout: timed out
        # urllib.request.URLError urllib.request.URLError: <urlopen error [Errno 50] Network is down>
        # 1号打包机经常报错urllib.request.URLError异常.立刻再调用接口会报同样的错误，需要延迟再调用
        # 延迟
        time.sleep(sleep_time)
        request_key = 'getBranchQuality'
        tip_string = 'request timeout, retry...'
        if isinstance(e, urllib.request.URLError):
            tip_string = "Network is down, retry..."
        return retryRequest(request_key, tip_string)
    else:
        pass
    finally:
        pass

    # 检查登录状态,登录状态可能随时失效
    login_dict = checkLogin(result_dict)
    # 之前没有登录，则再次请求数据
    if not login_dict['login']:
        result_dict = getBranchQuality()

    # 保存cookie
    cookie.save(ignore_discard=True, ignore_expires=True)

    return result_dict

#### isModule
def isModule():
    result_dict = {}

    # 检查登录
    # http://phoebus.cnsuning.com/phoebus/projectFlow/isModule/260
    url = 'http://phoebus.cnsuning.com/phoebus/projectFlow/isModule'
    url += '/'+system_id
    print('url:' + url)

    headers = {}
    headers['Host'] = 'phoebus.cnsuning.com'
    headers['Accept'] = 'application/json, text/plain, */*'
    headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0'
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Referer'] = 'http://phoebus.cnsuning.com/new/'
    headers['Accept-Encoding'] = 'gzip, deflate'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8'
    headers['Connection'] = 'keep-alive'

    try:
        # get请求没有data
        request = urllib.request.Request(url, headers=headers)
        response = opener.open(request)
        response_string = response.read()
        # gzip解压
        if response.headers.get('Content-Encoding') == 'gzip':
            response_string = zlib.decompress(response_string, 16 + zlib.MAX_WBITS)
        response_string = response_string.decode("utf-8")
        result_dict['response_string'] = response_string

        if print_debug_info:
            print('response_string:' + response_string)

        # 请求成功
        response_json = json.loads(response_string)
        result_dict['response_json'] = response_json
    except ValueError as e:
        print('error: isModule() parse json fail')
        exit(1)
    except (socket.error, urllib.request.URLError) as e:
        # socket.error socket.timeout: timed out
        # urllib.request.URLError urllib.request.URLError: <urlopen error [Errno 50] Network is down>
        # 1号打包机经常报错urllib.request.URLError异常.立刻再调用接口会报同样的错误，需要延迟再调用
        # 延迟
        time.sleep(sleep_time)
        request_key = 'isModule'
        tip_string = 'request timeout, retry...'
        if isinstance(e, urllib.request.URLError):
            tip_string = "Network is down, retry..."
        return retryRequest(request_key, tip_string)
    else:
        pass
    finally:
        pass

    # 检查登录状态,登录状态可能随时失效
    login_dict = checkLogin(result_dict)
    # 之前没有登录，则再次请求数据
    if not login_dict['login']:
        result_dict = isModule()

    # 保存cookie
    cookie.save(ignore_discard=True, ignore_expires=True)

    return result_dict

#### executeJob
def executeJob():
    result_dict = {}

    # 检查登录
    # http://phoebus.cnsuning.com//phoebus/projectFlow/executeJob/
    url = 'http://phoebus.cnsuning.com/phoebus/projectFlow/executeJob/'
    print('url:' + url)

    headers = {}
    headers['Host'] = 'phoebus.cnsuning.com'
    headers['Accept'] = 'application/json, text/plain, */*'
    headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0'
    headers['Content-Type'] = 'application/json'
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Origin'] = 'http://phoebus.cnsuning.com'
    headers['Referer'] = 'http://phoebus.cnsuning.com/new/'
    headers['Accept-Encoding'] = 'gzip, deflate'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8'
    headers['Connection'] = 'keep-alive'

    env_type='SIT'
    if config_environment == 2:
        env_type='SIT'
    elif config_environment == 4:
        env_type='PRD'

    values = {}
    values['buildConfigId'] = int(build_config_id)
    values['buildConfigName'] = build_config_name
    values['buildOrder'] = build_order
    values['buildParams'] = build_params
    values['buildTaskId'] = int(task_id)
    values['callSource'] = 'phoebus'
    values['configEnvironment'] = config_environment
    values['envType'] = env_type
    values['isModule'] = False
    values['releaseNoteContent'] = ''
    values['stcsTaskId'] = None
    values['systemId'] = int(system_id)
    values['taskName'] = task_name
    values['reason'] = ''
    quality_string = json.dumps({'result': True})
    values['quality'] = quality_string
    data = json.dumps(values)
    # print('data:' + data)
    data = data.encode(encoding='UTF8')

    try:
        # post请求有data
        request = urllib.request.Request(url, data=data, headers=headers)
        response = opener.open(request)
        response_string = response.read()
        # gzip解压
        if response.headers.get('Content-Encoding') == 'gzip':
            response_string = zlib.decompress(response_string, 16 + zlib.MAX_WBITS)
        response_string = response_string.decode("utf-8")
        result_dict['response_string'] = response_string

        if print_debug_info:
            print('response_string:' + response_string)

        # 请求成功
        response_json = json.loads(response_string)
        result_dict['response_json'] = response_json

        # 执行job请求失败3次，则退出
        if response_json['resultCode'] != '0':
            # 延迟
            time.sleep(sleep_time)
            request_key = 'executeJob'
            tip_string = 'response error, retry...'
            return retryRequest(request_key)
    except ValueError as e:
        print('error: executeJob() parse json fail')
        exit(1)
    except (socket.error, urllib.request.URLError) as e:
        # socket.error socket.timeout: timed out
        # urllib.request.URLError urllib.request.URLError: <urlopen error [Errno 50] Network is down>
        # 1号打包机经常报错urllib.request.URLError异常.立刻再调用接口会报同样的错误，需要延迟再调用
        # 延迟
        time.sleep(sleep_time)
        request_key = 'executeJob'
        tip_string = 'request timeout, retry...'
        if isinstance(e, urllib.request.URLError):
            tip_string = "Network is down, retry..."
        return retryRequest(request_key, tip_string)
    else:
        pass
    finally:
        pass

    # 检查登录状态,登录状态可能随时失效
    login_dict = checkLogin(result_dict)
    # 之前没有登录，则再次请求数据
    if not login_dict['login']:
        result_dict = executeJob()

    # 保存cookie
    cookie.save(ignore_discard=True, ignore_expires=True)

    return result_dict

#### searchBuildRecord
def searchBuildRecord():
    result_dict = {}

    # 检查登录
    # http://phoebus.cnsuning.com/phoebus/projectFlow/searchBuildRecord
    url = 'http://phoebus.cnsuning.com/phoebus/projectFlow/searchBuildRecord'
    print('url:' + url)

    headers = {}
    headers['Host'] = 'phoebus.cnsuning.com'
    headers['Accept'] = 'application/json, text/plain, */*'
    headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0'
    headers['Content-Type'] = 'application/json'
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Origin'] = 'http://phoebus.cnsuning.com'
    headers['Referer'] = 'http://phoebus.cnsuning.com/new/'
    headers['Accept-Encoding'] = 'gzip, deflate'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8'
    headers['Connection'] = 'keep-alive'

    values = {}
    values['buildTaskId'] = task_id
    values['createName'] = ''
    values['endDate'] = ''
    values['page'] = 1
    values['pageSize'] = 10
    values['startDate'] = ''
    data = json.dumps(values)
    # print('data:' + data)
    data = data.encode(encoding='UTF8')

    try:
        # post请求有data
        request = urllib.request.Request(url, data=data, headers=headers)
        response = opener.open(request)
        response_string = response.read()
        # gzip解压
        if response.headers.get('Content-Encoding') == 'gzip':
            response_string = zlib.decompress(response_string, 16+zlib.MAX_WBITS)
        response_string = response_string.decode("utf-8")
        result_dict['response_string'] = response_string

        if print_debug_info:
            print('response_string:' + response_string + '222')

        # 请求成功
        response_json = json.loads(response_string)
        result_dict['response_json'] = response_json
    except ValueError as e:
        print('error: searchBuildRecord() parse json fail')
        exit(1)
    except (socket.error, urllib.request.URLError) as e:
        # socket.error socket.timeout: timed out
        # urllib.request.URLError urllib.request.URLError: <urlopen error [Errno 50] Network is down>
        # 1号打包机经常报错urllib.request.URLError异常.立刻再调用接口会报同样的错误，需要延迟再调用
        # 延迟
        time.sleep(sleep_time)
        request_key = 'searchBuildRecord'
        tip_string = 'request timeout, retry...'
        if isinstance(e, urllib.request.URLError):
            tip_string = "Network is down, retry..."
        return retryRequest(request_key, tip_string)
    else:
        pass
    finally:
        pass

    # 检查登录状态,登录状态可能随时失效
    login_dict = checkLogin(result_dict)
    # 之前没有登录，则再次请求数据
    if not login_dict['login']:
        result_dict = searchBuildRecord()

    # 保存cookie
    cookie.save(ignore_discard=True, ignore_expires=True)

    return result_dict

#### stopJob
def stopJob():
    result_dict = {}

    # 检查登录
    # http://phoebus.cnsuning.com/phoebus/projectFlow/stopBuildTask/
    url = 'http://phoebus.cnsuning.com/phoebus/projectFlow/stopBuildTask/'
    print('url:' + url)

    headers = {}
    headers['Host'] = 'phoebus.cnsuning.com'
    headers['Accept'] = 'application/json, text/plain, */*'
    headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0'
    headers['Content-Type'] = 'application/json'
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['Origin'] = 'http://phoebus.cnsuning.com'
    headers['Referer'] = 'http://phoebus.cnsuning.com/new/'
    headers['Accept-Encoding'] = 'gzip, deflate'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8'
    headers['Connection'] = 'keep-alive'

    values = {}
    values['buildRecordId'] = int(build_record_id)
    values['buildSource'] = build_source
    values['buildTaskId'] = task_id
    values['taskStatus'] = 3
    data = json.dumps(values)
    # print('data:' + data)
    data = data.encode(encoding='UTF8')

    try:
        # post请求有data
        request = urllib.request.Request(url, data=data, headers=headers)
        response = opener.open(request)
        response_string = response.read()
        # gzip解压
        if response.headers.get('Content-Encoding') == 'gzip':
            response_string = zlib.decompress(response_string, 16 + zlib.MAX_WBITS)
        response_string = response_string.decode("utf-8")
        result_dict['response_string'] = response_string

        if print_debug_info:
            print('response_string:' + response_string)

        # 请求成功
        response_json = json.loads(response_string)
        result_dict['response_json'] = response_json
    except ValueError as e:
        print('error: stopJob() parse json fail')
        exit(1)
    except (socket.error, urllib.request.URLError) as e:
        # socket.error socket.timeout: timed out
        # urllib.request.URLError urllib.request.URLError: <urlopen error [Errno 50] Network is down>
        # 1号打包机经常报错urllib.request.URLError异常.立刻再调用接口会报同样的错误，需要延迟再调用
        # 延迟
        time.sleep(sleep_time)
        request_key = 'stopJob'
        tip_string = 'request timeout, retry...'
        if isinstance(e, urllib.request.URLError):
            tip_string = "Network is down, retry..."
        return retryRequest(request_key, tip_string)
    else:
        pass
    finally:
        pass

    # 检查登录状态,登录状态可能随时失效
    login_dict = checkLogin(result_dict)
    # 之前没有登录，则再次请求数据
    if not login_dict['login']:
        result_dict = stopJob()

    # 保存cookie
    cookie.save(ignore_discard=True, ignore_expires=True)

    return result_dict

#### jenkinsLog
def jenkinsLog():
    global jenkins_log_start
    global jenkins_log_start_last
    global jenkins_console_annotator
    global jenkins_more_data
    global jenkins_build_url
    global request_retry_times_dict

    result_dict = {}

    # http://10.37.87.240:80/job/ebuy_ssa_910/14/logText/progressiveHtml
    # jenkins_build_url http://10.37.87.240:80/job/ebuy_ssa_910/14/
    url = jenkins_build_url+'logText/progressiveHtml'
    # print('url:' + url)

    url_parsed = urllib.parse.urlparse(url)
    url_scheme = url_parsed.scheme
    url_host = url_parsed.netloc

    headers = {}
    headers['Accept'] = 'text/javascript, text/html, application/xml, text/xml, */*'
    headers['X-Prototype-Version'] = '1.7'
    headers['X-Requested-With'] = 'XMLHttpRequest'
    headers['User-Agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0'
    headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
    headers['Host'] = url_host
    headers['Origin'] = url_scheme+'://'+url_host
    headers['Referer'] = jenkins_build_url+'console'
    headers['Accept-Encoding'] = 'gzip, deflate'
    headers['Accept-Language'] = 'zh-CN,zh;q=0.9,en;q=0.8'
    # headers['Connection'] = 'keep-alive'
    if jenkins_console_annotator != '':
        headers['X-ConsoleAnnotator'] = jenkins_console_annotator

    values = {}
    values['start'] = jenkins_log_start
    data = urllib.parse.urlencode(values)
    # print('data:' + data)
    data = data.encode(encoding='UTF8')

    try:
        # post请求有data
        request = urllib.request.Request(url, data=data, headers=headers)
        response = opener.open(request)
        response_string = response.read()
        # gzip解压
        if response.headers.get('Content-Encoding') == 'gzip':
            response_string = zlib.decompress(response_string, 16+zlib.MAX_WBITS)
        response_string = response_string.decode("utf-8")
        # 字符串替换
        # git pull &lt;remote> &lt;branch>
        # git pull <remote> <branch>
        response_string = response_string.replace("&lt;", "<");
        # pod 'SNHomePage/resources', :path =&gt; '/Users/ios-ci-1/.cocoapods/repos/SNEBuy_build_rsync/SuningEBuy-Framework-910/SNHomePage'
        # pod 'SNHomePage/resources', :path => '/Users/ios-ci-1/.cocoapods/repos/SNEBuy_build_rsync/SuningEBuy-Framework-910/SNHomePage'
        response_string = response_string.replace("&gt;", ">");
        # GIT_URL:          					<a href='http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git'>http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git</a>
        # GIT_URL:          					http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git
        response_string = re.sub(r"<a.*?>", "", response_string)
        response_string = response_string.replace("</a>", "");
        # check url: http://10.37.64.97/ipa/build.json?identifier=ebuy_920&amp;duration=0
        response_string = response_string.replace("&amp;", "&");
        # https://www.cnblogs.com/asdyzh/p/9747201.html
        response_string = response_string.replace("&nbsp;", " ");
        response_string = response_string.replace("&quot;", "\"");
        response_string = response_string.replace("&apos;", "'");
        response_string = response_string.replace("&times;", "x");
        response_string = response_string.replace("&divide;", "÷");
        result_dict['response_string'] = response_string

        # if print_debug_info:
        #     print('response_string:' + response_string + '222')

        jenkins_log_start = response.headers.get('X-Text-Size')
        jenkins_console_annotator = response.headers.get('X-ConsoleAnnotator')
        jenkins_more_data = response.headers.get('X-More-Data')

        if response_string is not None and response_string != '' and len(response_string) > 0 and not response_string.isspace():
            print(response_string)

        # 重置jenkins_log_request_count,这儿接口会调用n多次，每次调用都有3次重试机会
        request_key = 'jenkinsLog'
        request_retry_times_dict[request_key] = 0
    except (socket.error, urllib.request.URLError) as e:
        # socket.error socket.timeout: timed out
        # urllib.request.URLError urllib.request.URLError: <urlopen error [Errno 50] Network is down>
        # 1号打包机经常报错urllib.request.URLError异常.立刻再调用接口会报同样的错误，需要延迟再调用
        # 延迟
        time.sleep(sleep_time)
        request_key = 'jenkinsLog'
        tip_string = 'request timeout, retry...'
        if isinstance(e, urllib.request.URLError):
            tip_string = "Network is down, retry..."
        return retryRequest(request_key, tip_string)

    # 保存cookie
    cookie.save(ignore_discard=True, ignore_expires=True)

    return result_dict

#### command_startJob
def command_startJob():
    print('execute command startJob')

    global task_id
    global branch_id
    global config_environment
    global build_config_id
    global build_config_name
    global build_order
    global build_params
    global build_record_id
    global jenkins_build_url
    global jenkins_log_start
    global jenkins_console_annotator
    global jenkins_more_data

    # 读取cookie
    print('')
    print('loadCookie...')
    loadCookie()

    # 查询构建任务
    print('')
    print('searchByPage...')
    project_dict = searchByPage()

    if 'data' not in project_dict['response_json'] \
        or 'data' not in project_dict['response_json']['data']:
        print('error: fail')
        exit(1)
    for task_dict in project_dict['response_json']['data']['data']:
        if task_dict['taskName'] == task_name:
            task_id=str(task_dict['taskId'])
            branch_id=str(task_dict['branchId'])
            config_environment=str(task_dict['configEnvironment'])
            build_config_id = str(task_dict['buildConfigId'])
            build_config_name = task_dict['buildConfigName']
            build_order = task_dict['buildOrder']
            # build_params如果外部没指定，则使用job的
            if build_params == '':
                build_params = task_dict['buildParams']
    # 2021.6.9 打包报错，定位原因是buildParams中包含&,这儿兼容下
    # buildParams: using_code_snpm pre xgpre prd sit SuningEMall ARM64 X86_64 -UPLOAD_NAME--替换图片接口&笔记创作bug -SPECIAL_BRANCH-- -BUILDID--8
    # 测试了所有特殊字符+ % # & = ? /，没有问题
    if build_params is not None and '&' in build_params:
        print('build_params中包含&会导致研发云报错，这儿统一替换为AND')
        build_params = build_params.replace('&', 'AND')
    print('taskName:' + task_name)
    print('taskId:' + task_id)
    print('branchId:' + branch_id)
    print('configEnvironment:' + config_environment)
    print('systemId:' + system_id)
    print('buildConfigId:' + build_config_id)
    print('buildConfigName:' + build_config_name)
    print('buildOrder:' + build_order)
    print('buildParams:' + build_params)

    # 参数检查
    char_length = len(build_params)
    char_length_max = 255
    if (char_length > char_length_max):
        print('error: 研发云后台buildParams参数允许最大长度'+str(char_length_max)+'，当前'+str(char_length)+'>'+str(char_length_max)+',请减少打包参数')
        exit(1)

    if task_id == '':
        print('error: 没有找到任务' + task_name + ',请确认是否已经创建')
        exit(1)

    # 获取质量，好像没啥用
    print('')
    print('getBranchQuality...')
    # 延迟
    time.sleep(sleep_time)
    getBranchQuality()

    # isModule，好像没啥用
    print('')
    print('isModule...')
    # 延迟
    time.sleep(sleep_time)
    isModule()

    # 执行job
    print('')
    print('executeJob...')
    # 延迟
    time.sleep(sleep_time)
    execute_dict = executeJob()
    build_record_id = execute_dict['response_json']['data']['buildRecordId']
    print('build_record_id：' + str(build_record_id))
    if build_record_id is None:
        # 研发云在当前job有任务正在执行的时候，executeJob返回的buildRecordId值为null
        # 解决方法是不勾选jenkins上job配置中的Execute concurrent builds if necessary，
        # 以前多个打包机这么配置没问题，不过现在只有研发云一台打包机器了
        print('error: ' + task_name + '当前有任务正在执行，请等待结束后再执行新的任务')
        print('研发云暂不支持job并发执行多个任务')
        print('message: ' + execute_dict['response_json']['message'])
        exit(1)

    # 获取执行状态
    print('')
    print('searchBuildRecord...')
    # task_status,1-成功，2-失败，3-构建中，4-排队中，5-终止
    task_status = 4
    current_build_dict = {}
    while task_status == 4:
        # 延迟
        time.sleep(sleep_time)
        all_build_dict = searchBuildRecord()

        # 默认终止状态
        # 研发云终止排队中的任务后，接口不会再返回对应记录，这儿默认终止状态，兼容这种场景
        task_status = 5;
        for a_build_dict in all_build_dict['response_json']['data']['data']:
            if a_build_dict['buildRecordId'] == build_record_id:
                task_status = a_build_dict['taskStatus']
                current_build_dict = a_build_dict
                break
        if task_status == 4:
            print('排队中...')

    # # test
    # task_status = 3
    # current_build_dict = {}
    # current_build_dict['buildSource'] = 'http://10.37.87.240/job/ebuy_sdk_910/17/'

    # 打印执行log
    if task_status == 3:
        print('')
        print('执行中...')
        print('读取log...')
        print(current_build_dict['buildSource'])
        # buildSource http://10.37.87.240/job/ebuy_ssa_910/7/
        jenkins_build_url = current_build_dict['buildSource']
        jenkins_log_start = 0
        jenkins_console_annotator = ''
        jenkins_more_data = True

        while jenkins_more_data:
            # 延迟
            time.sleep(sleep_time)
            # 获取jenkins日志
            jenkinsLog()

    #### 查询执行结果
    print('')
    print('查询执行结果...')
    # 延迟
    time.sleep(sleep_time)
    build_dict = searchBuildRecord()
    task_status = 0
    for a_build_dict in build_dict['response_json']['data']['data']:
        if a_build_dict['buildRecordId'] == build_record_id:
            task_status = a_build_dict['taskStatus']
            break
    if task_status == 1:
        print("执行成功")
    elif task_status == 2:
        print("执行失败")
        exit(1)
    elif task_status == 3:
        # ebuy_appstore_930任务执行结束，接口taskStatus还是返回3，表示任务状态:执行中
        # while循环获取接口最新taskStatus多次后，还会返回10
        # 可能研发云后台对appstore打包的处理有延迟，这儿兼容下，认为打包成功
        print("执行成功")
    elif task_status == 4:
        print('排队中')
        print('这个状态码按理不该出现，不可能已经执行完了还排队中...')
        exit(1)
    elif task_status == 5:
        print('执行终止')
        exit(1)
    elif task_status == 10:
        print('查询失败，该状态暂且当作执行成功')
        exit(0)
    else:
        print('查询失败')
        print('build_record_id:' + str(build_record_id))
        print('response_string:')
        print(build_dict['response_string'])
        exit(1)

#### command_stopJob
def command_stopJob():
    print('execute command stopJob')
    global task_id
    global branch_id
    global config_environment
    global build_config_id
    global build_config_name
    global build_order
    global build_params
    global task_status
    global build_record_id
    global build_source

    # 读取cookie
    print('')
    print('loadCookie...')
    loadCookie()

    # 查询构建任务
    print('')
    print('searchByPage...')
    project_dict = searchByPage()
    if 'data' not in project_dict['response_json'] \
            or 'data' not in project_dict['response_json']['data']:
        print('error: fail')
        exit(1)
    for task_dict in project_dict['response_json']['data']['data']:
        if task_dict['taskName'] == task_name:
            task_id = str(task_dict['taskId'])
            branch_id = str(task_dict['branchId'])
            config_environment = str(task_dict['configEnvironment'])
            build_config_id = str(task_dict['buildConfigId'])
            build_config_name = task_dict['buildConfigName']
            build_order = task_dict['buildOrder']
            # build_params如果外部没指定，则使用job的
            if build_params == '':
                build_params = task_dict['buildParams']
    # 2021.6.9 打包报错，定位原因是buildParams中包含&,这儿兼容下
    # buildParams: using_code_snpm pre xgpre prd sit SuningEMall ARM64 X86_64 -UPLOAD_NAME--替换图片接口&笔记创作bug -SPECIAL_BRANCH-- -BUILDID--8
    # 测试了所有特殊字符+ % # & = ? /，没有问题
    if build_params is not None and '&' in build_params:
        print('build_params中包含&会导致研发云报错，这儿统一替换为AND')
        build_params = build_params.replace('&', 'AND')
    print('taskName:' + task_name)
    print('taskId:' + task_id)
    print('branchId:' + branch_id)
    print('configEnvironment:' + config_environment)
    print('systemId:' + system_id)
    print('buildConfigId:' + build_config_id)
    print('buildConfigName:' + build_config_name)
    print('buildOrder:' + build_order)
    print('buildParams:' + build_params)

    # 获取执行状态
    print('')
    print('searchBuildRecord...')
    # task_status,1-成功，2-失败，3-构建中，4-排队中，5-终止
    task_status = 1
    build_record_id = 0
    build_source = ''
    # 延迟
    time.sleep(sleep_time)
    all_build_dict = searchBuildRecord()
    build_array = all_build_dict['response_json']['data']['data']
    if len(build_array) >= 1:
        task_status = build_array[0]['taskStatus']
        build_record_id = build_array[0]['buildRecordId']
        build_source = build_array[0]['buildSource']
    if task_status == 3:
        # 停止job
        print('')
        print('stopJob...')
        # 延迟
        time.sleep(sleep_time)
        stop_dict = stopJob()
        if stop_dict['response_json']['data'] != 'SUCCESS':
            print('error: stopJob failed')
            exit(1)
    else:
        print('')
        print('没有构建中的任务')

#### 参数
# cmd_name
cmd_name = os.getenv('CMD_NAME')
if cmd_name is None:
    cmd_name = 'startjob'

# user_name
user_name = os.getenv('USER_NAME')
if user_name is None:
    print('error: not found USER_NAME')
    exit(1)

# password
password = os.getenv('PASSWORD')
if password is None:
    print('error: not found PASSWORD')
    exit(1)

system_id = os.getenv('SYSTEM_ID')
if system_id is None:
    system_id = '260'

task_name = os.getenv('TASK_NAME')
if task_name is None:
    print('error: not found TASK_NAME')
    exit(1)

build_params = os.getenv('BUILD_PARAMS')
if build_params is None:
    build_params = ''

# 休息时间
sleep_time = 2

# request请求重试
request_retry_times_max = 3
request_retry_times_dict = {}

# cookie
cookie = None
opener = None

# 上次登录时间戳，5分钟内只能登录一次
last_login_timestamp = 0

# 打印debug信息
print_debug_info = False

# 研发云执行job相关参数
task_id = ''
branch_id = ''
config_environment = ''
build_config_id = ''
build_config_name = ''
build_order = ''
build_record_id = 0
build_source = ''

# jenkins
jenkins_build_url = ''
jenkins_log_start = 0
jenkins_console_annotator = ''
jenkins_more_data = True

#### 执行command
if cmd_name == 'startjob':
    command_startJob()
elif cmd_name == 'stopjob':
    command_stopJob()
else:
    print('no command named --- ' + cmd_name)

