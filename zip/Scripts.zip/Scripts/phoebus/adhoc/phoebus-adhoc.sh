#!/bin/bash
# 研发云adhoc打包

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

#### 更新主工程代码...
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

#### 设置phoebus打包参数...
# using_code_xxx 默认true，不需要设置
export pre=true
export xgpre=true
export prd=true
export sit=true
export SuningEMall=true
export ARMV7=true
export ARM64=true
export UPLOAD_NAME="研发云-adhoc官方定位分享包"

export JENKINS_TYPE="phoebus"

#### 调用jenkins-adhoc.sh
echo ""
echo "> bash ${PROJECT_PATH}/Scripts/jenkins/adhoc/jenkins-adhoc.sh"
bash ${PROJECT_PATH}/Scripts/jenkins/adhoc/jenkins-adhoc.sh

