#!/bin/bash

# 基本变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"
cd ${SCRIPT_DIR}

bash ./ipa-test.sh $* -bundleid--SuningEMall
