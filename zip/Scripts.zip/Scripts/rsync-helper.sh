#!/bin/bash
# rsync-helper.sh
#### 功能
# rsync上传下载
# 1.pull
# 2.push
#### 使用方法
# 1.pull
#   拉取文件夹
#       ./rsync-helper.sh.sh pull ${HOME}/.cocoapods/repos/SNEBuy_build_rsync/SuningEBuy-Framework-820/
#   拉取文件
#       ./rsync-helper.sh.sh pull ${HOME}/.cocoapods/repos/SNEBuy_build_rsync/1.txt
# 2.push
#   推送文件夹
#       ./rsync-helper.sh.sh push ${HOME}/.cocoapods/repos/SNEBuy_build_rsync/SuningEBuy-Framework-820/
#   推送文件
#       ./rsync-helper.sh.sh push ${HOME}/.cocoapods/repos/SNEBuy_build_rsync/1.txt
# 3.pushsdk
#   推送sdk
#       ./rsync-helper.sh pushsdk 910 PPTVSDK
#### 注意
# 文件夹路径以/结尾，文件不需要

# set -e

# 基本变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

RSYNC_SERVER_URL="10.37.64.97"
RSYNC_USER_STRING="suning"
RSYNC_PASSWD_STRING="suning123"

RSYNC_LOCAL_ROOT_PATH="${HOME}/.cocoapods/repos/SNEBuy_build_rsync"
RSYNC_PASSWD_FILE_PATH="${RSYNC_LOCAL_ROOT_PATH}/rsync.password"

LOG_PATH="/tmp/rsync-helper.txt"

# rsync密码
mkdir -p $(dirname ${RSYNC_PASSWD_FILE_PATH})
if [[ ! -e ${RSYNC_PASSWD_FILE_PATH} ]] \
    || [[ $(cat ${RSYNC_PASSWD_FILE_PATH}) != ${RSYNC_PASSWD_STRING} ]]; then
    echo "${RSYNC_PASSWD_STRING}" > ${RSYNC_PASSWD_FILE_PATH}
    chmod 600 ${RSYNC_PASSWD_FILE_PATH}
fi

function pull {
    # echo "pull $*"
    # LOCAL_PATH="${HOME}/.cocoapods/repos/SNEBuy_build_rsync/Dev_Br_820/"
    LOCAL_PATH=$2
    # echo ${LOCAL_PATH}

    if [[ ! "${LOCAL_PATH}" =~ "${RSYNC_LOCAL_ROOT_PATH}" ]]; then
        echo "只处理~/.cocoapods/repos/SNEBuy_build_rsync目录文件"
        exit 1
    fi

    SERVER_PATH=${LOCAL_PATH#*${RSYNC_LOCAL_ROOT_PATH}/}
    SERVER_PATH="build/${SERVER_PATH}"
    SERVER_PATH="${RSYNC_USER_STRING}@${RSYNC_SERVER_URL}::${SERVER_PATH}"

    echo "LOCAL_PATH:           ${LOCAL_PATH}"
    echo "SERVER_PATH:          ${SERVER_PATH}"
    echo "cmd: rsync -avz --delete --password-file=${RSYNC_PASSWD_FILE_PATH} ${SERVER_PATH} ${LOCAL_PATH}"
    echo ""
    mkdir -p $(dirname ${LOCAL_PATH})
    rsync -avz --delete \
        --password-file=${RSYNC_PASSWD_FILE_PATH} \
        ${SERVER_PATH} \
        ${LOCAL_PATH} \
        2>${LOG_PATH}
    
    # 输出报错信息
    if [[ "$(cat ${LOG_PATH})" != "" ]]; then
        cat /tmp/rsync-helper.txt
    fi
    # 删除本地文件
    if [[ "$(cat ${LOG_PATH} | grep 'No such file or directory')" != "" ]]; then
        if [[ -e ${LOCAL_PATH} ]]; then
            echo ""
            echo "${SERVER_PATH}不存在,删除本地对应文件..."
            echo "cmd: rm -rf ${LOCAL_PATH}"
            rm -rf ${LOCAL_PATH}
        else
            echo ""
            echo "同步失败,${SERVER_PATH}不存在..."
        fi
    fi
}

function push {
    # echo "push $*"
    # LOCAL_PATH="${HOME}/.cocoapods/repos/SNEBuy_build_rsync/suningebuypro-820/"
    LOCAL_PATH=$2
    # echo ${LOCAL_PATH}

    if [[ ! "${LOCAL_PATH}" =~ "${RSYNC_LOCAL_ROOT_PATH}" ]]; then
        echo "只处理~/.cocoapods/repos/SNEBuy_build_rsync目录文件"
        exit 1
    fi

    SERVER_PATH=${LOCAL_PATH#*${RSYNC_LOCAL_ROOT_PATH}/}
    SERVER_PATH="build/${SERVER_PATH}"
    SERVER_PATH="${RSYNC_USER_STRING}@${RSYNC_SERVER_URL}::${SERVER_PATH}"

    echo "LOCAL_PATH:           ${LOCAL_PATH}"
    echo "SERVER_PATH:          ${SERVER_PATH}"
    echo "cmd: rsync -avz --delete --password-file=${RSYNC_PASSWD_FILE_PATH} ${LOCAL_PATH} ${SERVER_PATH}"
    echo ""
    rsync -avz --delete \
        --password-file=${RSYNC_PASSWD_FILE_PATH} \
        ${LOCAL_PATH} \
        ${SERVER_PATH}
}

KNOWN_SDK_ARRAY=(
    "SNMPaySDK"
    "SNMPayDependency"
    "YFBWalletLibs"
    "YFBWalletSDKDependency"
    "SNKAHttpDNS"
    "CloudyTrace_SDK"
    "SNSHumanMachine"
    "PPTVSDK"
    "SAStatistic_SDK"
    "Cronet_Framework"
    "SNYXChat_Framework"
    "MSFS_Framework"
)

function pushsdk {
    PROJECT_VERSION=$2

    # 判断PROJECT_VERSION是否为数字
    if [ ! -z $(echo ${PROJECT_VERSION} | sed 's/[0-9]//g') ]; then
        echo "error: pushsdk后面应该跟着版本号"
        exit 1
    fi

    # 同步服务端数据
    RSYNC_PROJECT_PATH=${RSYNC_LOCAL_ROOT_PATH}/SuningEBuy-Framework-${PROJECT_VERSION}
    bash ${SCRIPT_DIR}/rsync-helper.sh pull ${RSYNC_PROJECT_PATH}/
    if [[ ! -e ${RSYNC_PROJECT_PATH} ]]; then
        echo "error:not found SuningEBuy-Framework-${PROJECT_VERSION} in server"
        exit 1
    fi

    # 删除${HOME}/.cocoapods/repos/SNEBuy_build_rsync目录7天未使用的文件夹
    echo ""
    echo "clean ${RSYNC_LOCAL_ROOT_PATH}..."
    # 删除7天未使用的文件夹
    for A_DIRECTORY in $(ls ${RSYNC_LOCAL_ROOT_PATH})
    do
        SAVE_MAX_DAYS="7"
        MODIFY_FILE_LIST_IN_MAX_DAYS=$(find ${RSYNC_LOCAL_ROOT_PATH}/${A_DIRECTORY} -mtime -${SAVE_MAX_DAYS})
        if [[ ${MODIFY_FILE_LIST_IN_MAX_DAYS} = "" ]]; then
            # 不处理本次操作的目录
            if [[ "${A_DIRECTORY}" = "$(basename ${RSYNC_PROJECT_PATH})" ]]; then
                continue
            fi
            echo "BUILD ${A_DIRECTORY} ${SAVE_MAX_DAYS}天内没修改，删除..."
            echo "cmd: rm -rf ${RSYNC_LOCAL_ROOT_PATH}/${A_DIRECTORY}"
            rm -rf ${RSYNC_LOCAL_ROOT_PATH}/${A_DIRECTORY}
        fi
    done

    PROJECT_PATH=${SCRIPT_DIR}/SuningEBuy-Framework-${PROJECT_VERSION}
    mkdir -p ${PROJECT_PATH}

    SDK_NAME_ARRAY=()
    for SDK_NAME in "$@"
    do
        KNOWN_SDK_NAME=""
        for TMP_SDK_NAME in ${KNOWN_SDK_ARRAY[*]}; do
            if [[ "${SDK_NAME}" = "${TMP_SDK_NAME}" ]]; then
                KNOWN_SDK_NAME=${SDK_NAME}
                break
            fi
        done
        if [[ "${KNOWN_SDK_NAME}" = "" ]]; then
            continue
        fi
        # 添加SDK_NAME
        SDK_NAME_ARRAY=(${SDK_NAME_ARRAY[*]} ${SDK_NAME})

        # 创建文件夹
        SDK_PATH=${PROJECT_PATH}/${SDK_NAME}
        mkdir -p ${SDK_PATH}
    done

    ERROR_COUNT=0
    for SDK_NAME in ${SDK_NAME_ARRAY[*]}; do
        echo ""
        echo "替换sdk:  ${SDK_NAME}"

        # 判断内容是否为空
        SDK_PATH=${PROJECT_PATH}/${SDK_NAME}
        if [[ "$(ls ${SDK_PATH})" = "" ]]; then
            echo "error:目录为空"
            if [[ -d ${RSYNC_PROJECT_PATH}/${SDK_NAME} ]]; then
                echo "正在为你拷贝打包sdk历史版本数据..."
                cp -rf ${RSYNC_PROJECT_PATH}/${SDK_NAME}/* ${SDK_PATH}/
            fi
            echo "请拷贝最新版本的打包sdk到${SDK_PATH}"
            # 失败次数+1
            ERROR_COUNT=$((${ERROR_COUNT}+1))
            # 处理下一个
            continue
        fi

        RSYNC_SDK_PATH=${RSYNC_PROJECT_PATH}/${SDK_NAME}
        mkdir -p ${RSYNC_SDK_PATH}
        echo "> rm -rf ${RSYNC_SDK_PATH}/*"
        rm -rf ${RSYNC_SDK_PATH}/*
        echo "> cp -rf ${SDK_PATH}/* ${RSYNC_SDK_PATH}/"
        cp -rf ${SDK_PATH}/* ${RSYNC_SDK_PATH}/
    done
    if [[ ${ERROR_COUNT} -gt 0 ]]; then
        exit 1
    fi
    echo "done"

    # 推送数据到服务端
    bash ${SCRIPT_DIR}/rsync-helper.sh push ${RSYNC_PROJECT_PATH}/

    # 检查
    echo ""
    echo "sdk检查"
    checksdk $*

    echo ""
    echo "确认sdk时间"
    for SDK_NAME in ${SDK_NAME_ARRAY[*]}; do
        RSYNC_SDK_PATH=${RSYNC_PROJECT_PATH}/${SDK_NAME}

        echo ""
        echo "> ls -l ${RSYNC_SDK_PATH}"
        ls -l ${RSYNC_SDK_PATH}
    done
}

# 检查测试sdk文件，防止文件位置错误或者忘记提交
function checksdk {
    PROJECT_VERSION=$2

    # 同步服务端数据
    RSYNC_PROJECT_PATH=${RSYNC_LOCAL_ROOT_PATH}/SuningEBuy-Framework-${PROJECT_VERSION}
    if [[ ! -e ${RSYNC_PROJECT_PATH} ]]; then
       echo "error: ${RSYNC_PROJECT_PATH} does not exist"
       exit 1
    fi

    SDK_NAME_ARRAY=()
    for SDK_NAME in "$@"
    do
        KNOWN_SDK_NAME=""
        for TMP_SDK_NAME in ${KNOWN_SDK_ARRAY[*]}; do
            if [[ "${SDK_NAME}" = "${TMP_SDK_NAME}" ]]; then
                KNOWN_SDK_NAME=${SDK_NAME}
                break
            fi
        done
        if [[ "${KNOWN_SDK_NAME}" = "" ]]; then
            continue
        fi
        # 添加SDK_NAME
        SDK_NAME_ARRAY=(${SDK_NAME_ARRAY[*]} ${SDK_NAME})
    done

    ERROR_COUNT=0
    for SDK_NAME in ${SDK_NAME_ARRAY[*]}; do
        echo ""
        echo "检查sdk:  ${SDK_NAME}"

        SDK_ERROR_COUNT=0

        CHECK_PATH_ARRAY=()
        if [[ "${SDK_NAME}" = "SNMPaySDK" ]]; then
            CHECK_PATH_ARRAY=(
                libSNMPaySDK.podspec
                libSNMPaySDK.a
            )
        elif [[ "${SDK_NAME}" = "SNMPayDependency" ]]; then
            CHECK_PATH_ARRAY=(
                SNMPayDependency.podspec
                IFAAFingerprintSDK/IFAAAuthenticator.framework
                SNFCFCA/SCAP/SCAP.framework
                SNFOssSDK/Release-universal/SNFOssSDK.framework 
                SNFSymmetricEncryptionSDK/Release-universal/SNFSymmetricEncryptionSDK.framework 
            )
        elif [[ "${SDK_NAME}" = "YFBWalletLibs" ]]; then
            CHECK_PATH_ARRAY=(
                YFBWalletLibs.podspec
                YFBWalletSDK.framework
            )
        elif [[ "${SDK_NAME}" = "YFBWalletSDKDependency" ]]; then
            CHECK_PATH_ARRAY=(
                YFBWalletSDKDependency.podspec
                SNFAdvancedRealNameSDK/Release-universal/SNFAdvancedRealNameSDK.framework
                SNFRNMiniPSDK/Release-universal/SNFRNMiniPSDK.framework 
                SNFWalletMainSDK/Release-universal/SNFWalletMainSDK.framework
            )
        elif [[ "${SDK_NAME}" = "SNKAHttpDNS" ]]; then
            CHECK_PATH_ARRAY=(
                SNKAHttpDNS.podspec
                SNKAHttpDNS.framework
            )
        elif [[ "${SDK_NAME}" = "CloudyTrace_SDK" ]]; then
            CHECK_PATH_ARRAY=(
                CloudyTrace_SDK.podspec
                CloudyTrace_SDK/CloudyTrace_IOS.framework
                CloudyTrace_SDK/KSCrash.framework 
                CloudyTrace_SDK/SNSMEncryptionSDK.framework 
            )
        elif [[ "${SDK_NAME}" = "SNSHumanMachine" ]]; then
            CHECK_PATH_ARRAY=(
                SNSHumanMachine.podspec
                SNSHumanMachineSDK.framework
            )
        elif [[ "${SDK_NAME}" = "PPTVSDK" ]]; then
            CHECK_PATH_ARRAY=(
                PPTVSDK.podspec
                PPTVSDK/PPTVSdk/MediaPlayerFramework.framework 
                PPTVSDK/PPTVSdk/MediaStationFramework.framework 
                PPTVSDK/PPTVSdk/PPTVSdk/SNOnePlayer.framework
                PPTVSDK/PPTVSdk/PPTVSdk/SNOPFeedbackSDK.framework
                PPTVSDK/PPYun/MediaStreamerFramework.framework 
                PPTVSDK/PPYun/PPTVFileUpload.framework
                PPTVSDK/PPYun/PPVideoSDK.framework
                PPTVSDK/PPYun/PPYCommonSDK.framework
            )
        elif [[ "${SDK_NAME}" = "SAStatistic_SDK" ]]; then
            CHECK_PATH_ARRAY=(
                SAStatistic_SDK.podspec
                SAStatistic_SDK/SSA_IOS.framework
            )
        elif [[ "${SDK_NAME}" = "Cronet_Framework" ]]; then
            CHECK_PATH_ARRAY=(
                Cronet_Framework.podspec
                Cronet.framework
            )
        elif [[ "${SDK_NAME}" = "SNYXChat_Framework" ]]; then
            CHECK_PATH_ARRAY=(
                SNYXChat_Framework.podspec
                SNYXChat.framework
                Resources
            )
        elif [[ "${SDK_NAME}" = "MSFS_Framework" ]]; then
            CHECK_PATH_ARRAY=(
                MSFS.podspec
                MSFS.framework
                Resources
            )
        fi
        for CHECK_PATH in ${CHECK_PATH_ARRAY[*]}; do
            if [[ ! -e ${RSYNC_PROJECT_PATH}/${SDK_NAME}/${CHECK_PATH} ]]; then
                echo "error: not found ${RSYNC_PROJECT_PATH}/${SDK_NAME}/${CHECK_PATH}"
                echo "请检查是否需要这个文件，不需要的话，请联系王彬(14121612)修改脚本"
                # 错误次数+1
                ERROR_COUNT=$((${ERROR_COUNT}+1))
                SDK_ERROR_COUNT=$((${SDK_ERROR_COUNT}+1))
            fi
        done
        if [[ ${#CHECK_PATH_ARRAY[*]} -eq 0 ]]; then
            echo "error: not found CHECK_PATH_ARRAY for ${SDK_NAME}"
            echo "请联系王彬(14121612)修改脚本"
            # 错误次数+1
            ERROR_COUNT=$((${ERROR_COUNT}+1))
            SDK_ERROR_COUNT=$((${SDK_ERROR_COUNT}+1))
        fi
        if [[ ${SDK_ERROR_COUNT} -eq 0 ]]; then
            echo "pass"
        fi
    done
    if [[ ${ERROR_COUNT} -gt 0 ]]; then
        echo ""
        echo "total: fail"
        exit 1
    else
        echo ""
        echo "total: pass"
    fi
}

if [[ "$1" = "pull" ]]; then
    pull $*
elif [[ "$1" = "push" ]]; then
    push $*
elif [[ "$1" = "pushsdk" ]]; then
    pushsdk $*
elif [[ "$1" = "checksdk" ]]; then
    checksdk $*
else
    echo "nothing to do"
fi
