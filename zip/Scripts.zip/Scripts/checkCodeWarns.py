#!/usr/bin/python
# -*- coding: utf-8 -*-
import os,sys,re,shutil

# 打印警告
def printWarns():
    # 创建存放目录
    warnpath = './warn'
    if os.path.exists(warnpath):
        shutil.rmtree(warnpath)
    os.makedirs(warnpath)
    for p in warnsdata.keys():
        path = warnpath + '/' + p + ".txt"
        f = open(path, 'w')
        for w in warnsdata[p].keys():
            print ('\n\n', file = f)
            if w == warnkey1:
                print ('Warning：方法注释格式有误', file = f)
            if w == warnkey2:
                print ('Warning：定义变量没有使用', file = f)
            if w == warnkey3:
                print ('Warning：声明函数/block不规范', file = f)
                
            for str in warnsdata[p][w]:
                print (str, file = f)
        f.close()


# 插入数据
def appendWarns(project, warnkey, str):
    p = warnsdata.get(project, {})
    w = p.get(warnkey, [])
    if str not in w:
        w.append(str)
        p[warnkey] = w
        warnsdata[project] = p


def main():
    buildfile = sys.argv[1]
    if not os.path.exists(buildfile):
        print ('No compiled file found!')
        sys.exit()
    
    f = open(buildfile, 'r')
    for line in f.readlines():
        matchObj = re.match('Build target (.*) of project (.*) with configuration Debug', line)
        if matchObj:
            project = matchObj.group(2)
        if ': warning: ' in line and project:
            str = line[:line.index(': warning: ')]
            # 注释不规范
            if 'not found in the function declaration' in line or 'command used in a comment' in line or 'Empty paragraph passed to' in line or 'is already documented' in line:
                appendWarns(project, warnkey1, str)
            # 变量未使用
            if 'unused variable' in line:
                appendWarns(project, warnkey2, str)
            # 声明不规范
            if 'declaration is not a prototype' in line:
                appendWarns(project, warnkey3, str)
                    
    f.close()
    
    printWarns()
    
    print('Executed successful!')
      

warnkey1 = 'commentWarn'    # 注释不规范
warnkey2 = 'unusedVWarn'    # 变量未使用
warnkey3 = 'missVoidWarn'   # 声明不规范

# 警告数据
warnsdata = {}
    
if __name__ == '__main__':
    main()
