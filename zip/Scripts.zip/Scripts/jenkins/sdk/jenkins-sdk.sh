#!/bin/bash
# jenkins-sdk-framework.sh
# sdk打包脚本
# 这个是sdk打包最终执行脚本，其他只是外衣，设置参数环境什么的
# jenkins job
# 1.SuningEBuy-SDK-910

#### 用法，同时也是jenkins build参数
#### SuningEBuy-SDK-910
# export JOB_NAME="SuningEBuy-SDK-910"
# export SNMPaySDK=false # 支付sdk
# export SNMPayDependency=false # 支付sdk依赖
# export YFBWalletLibs=false # 钱包sdk
# export YFBWalletSDKDependency=false # 钱包sdk依赖
# export SNKAHttpDNS=false # httpdns
# export CloudyTrace_SDK=false # 云迹sdk
# export SNSHumanMachine=false # 人机sdk
# export PPTVSDK=false # pptvsdk
# export SAStatistic_SDK=false # 大数据sdk
# export SNYXChat_Framework=false # 云信sdk
# export MSFS_Framework=false # 店铺sdk
# export pre=true
# export xgpre=false
# export poc=false
# export prd=true
# export sit=false
# export SuningEMall=true # 选中-官方定位分享包，不选中-官方测试包
# export ARMV7=false # 打armv7架构测试包，兼容iPhone4s、5设备
# export ARM64=true # 打arm64架构测试包，目前大部分iPhone都是arm64架构
# export UPLOAD_NAME="" # 可不配置,描述会按照SuningEMall的选择来
# # SNLive=Ft_Br_910,SNLive_Framework=Ft_Br_910 子工程可以单独指定使用哪个分支打包
# export SPECIAL_BRANCH="" 
# # 开始打包
# bash jenkins-sdk.sh

# 模拟jenkins参数检查
if [[ -z ${JOB_NAME} ]]; then
	echo "error: JOB_NAME not found"
	exit 1
fi

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi
export LANG=zh_CN.UTF-8
export PATH=/usr/local/bin:${PATH}

# 兼容研发云打包环境，优先使用/Applications/Xcode12.3.app打包
# 研发云同时装有多个xcode版本，默认的可能不是Xcode12.3
if [[ -e /Applications/Xcode12.3.app ]]; then
    export PATH=/Applications/Xcode12.3.app/Contents/Developer/usr/bin:$PATH
fi
# 检查Xcode版本号
RESULT_STRING=$(xcodebuild -version | head -1)
echo ""
echo "using xcode: ${RESULT_STRING}"
if [[ "${RESULT_STRING}" != "Xcode 12.3" ]]; then
    echo "error: 请使用指定的Xcode版本进行打包"
    exit 1
fi

#### 变量
echo ""
echo "step 1:更新主工程代码..."
# WORKSPACE默认值
# PROJECT_PATH,最终打包目录
if [ -z ${WORKSPACE} ]; then
	# JOB_NAME
	cd ${SCRIPT_DIR}/../../../../
	WORKSPACE=$(pwd)/${JOB_NAME}
	mkdir -p ${WORKSPACE}
	PROJECT_PATH="${WORKSPACE}"
else
	# 兼容研发云Delete workspace when build is done
	PROJECT_PATH=${HOME}/.suning/build/${JOB_NAME}
	mkdir -p ${PROJECT_PATH}
fi
cd ${PROJECT_PATH}

PROJECT_NAME="SuningEBuy"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_VERSION="830"
# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
	# jenkins打包 SuningEBuy-840
	GIT_BRANCH_VERSION=${JOB_NAME##*-}
elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
	# 研发云打包 ebuy_840
	GIT_BRANCH_VERSION=${JOB_NAME##*_}
fi
GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

# 拉取代码
cd ${PROJECT_PATH}
if [ ! -d ${PROJECT_PATH}/.git ]; then
	${GIT} init
	${GIT} remote add origin ${GIT_URL}
	${GIT} fetch
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
if [[ "$(${GIT} status)" =~ "unmerged" ]]; then
	${GIT} reset --hard HEAD
fi
${GIT} checkout . 
# 删除Untracked files
${GIT} clean -fd
# 拉取代码
${GIT} pull
# 切换分支
${GIT} checkout ${GIT_BRANCH_NAME}
# 拉取代码
${GIT} pull

# 可以使用我们jenkins控制研发云打包，不用流水线功能了，不兼容了
# # 兼容研发云流水线打包场景，每次都会生成新的job-name
# # 将子工程放到 ~/.jenkins-slave/workspace/ebuy-sdk-sub 下
# echo ""
# echo "兼容研发云流水线场景，使用~/.jenkins-slave/workspace/ebuy-sdk-sub下子工程..."
# SUB_PROJECT_PATH_ARRAY=(
# 	"SNPods/CloudyTrace_SDK"
# 	"SNPods/MSFS_Framework"
# 	"SNPods/PPTVSDK"
# 	"SNPods/SAStatistic_SDK"
# 	"SNPods/SNChannel_Framework"
# 	"SNPods/SNCommon_Framework"
# 	"SNPods/SNDynamicFrameworks_Framework"
# 	"SNPods/SNHomePage_Framework"
# 	"SNPods/SNHWG_Framework"
# 	"SNPods/SNIRChatRoomSDK"
# 	"SNPods/SNLive_Framework"
# 	"SNPods/SNLogin_Framework"
# 	"SNPods/SNMember_Framework"
# 	"SNPods/SNMINIPSDK"
# 	"SNPods/SNMK_Framework"
# 	"SNPods/SNMPayDependency"
# 	"SNPods/SNMPaySDK"
# 	"SNPods/SNPG_Framework"
# 	"SNPods/SNPM_Framework"
# 	"SNPods/SNSHSearch_Framework"
# 	"SNPods/SNSHProductDetail_Framework"
# 	"SNPods/SNSL_Framework"
# 	"SNPods/SNSM_Framework"
# 	"SNPods/SNYXChat_Framework"
# 	"SNPods/YFBWalletLibs"
# 	"SNPods/YFBWalletSDKDependency"
# 	"SNProjects/SNChannel"
# 	"SNProjects/SNCommon"
# 	"SNProjects/SNDynamicFrameworks"
# 	"SNProjects/SNHomePage"
# 	"SNProjects/SNHWG"
# 	"SNProjects/SNLive"
# 	"SNProjects/SNMBLoginRegister"
# 	"SNProjects/SNMBMember"
# 	"SNProjects/SNMK"
# 	"SNProjects/SNPM"
# 	"SNProjects/SNPMPinGou"
# 	"SNProjects/SNPMPinGouDynamic"
# 	"SNProjects/SNSHProductDetail"
# 	"SNProjects/SNSHSearch"
# 	"SNProjects/SNSL"
# 	"SNProjects/SNSM"
# )
# JOB_EBUY_SUB_PATH=$(dirname ${WORKSPACE})/ebuy-sdk-sub-${GIT_BRANCH_VERSION}
# for SUB_PROJECT_PATH in ${SUB_PROJECT_PATH_ARRAY[*]}; do
# 	# 删除之前的软连接
# 	if [[ -L ${PROJECT_PATH}/${SUB_PROJECT_PATH} ]]; then
# 		rm -f ${PROJECT_PATH}/${SUB_PROJECT_PATH}
# 	fi
# 	# 创建新的软连接
# 	if [[ -d ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ]]; then
# 		rm -f ${PROJECT_PATH}/${SUB_PROJECT_PATH}
# 		echo "ln -fs ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ${PROJECT_PATH}/${SUB_PROJECT_PATH}"
# 		ln -fs ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ${PROJECT_PATH}/${SUB_PROJECT_PATH}
# 	fi
# done

#### 打包前处理
echo ""
echo "step 2:打包前处理..."

# 同步缓存
echo ""
echo "1) 同步构建缓存..."
RSYNC_BUILD_PATH="${HOME}/.suning/build/SuningEBuy"
if [[ ! -d ${PROJECT_PATH}/SNProjects/SNCommon ]] && [[ -d ${RSYNC_BUILD_PATH} ]]; then
    rsync -raP ${RSYNC_BUILD_PATH}/ ${PROJECT_PATH}/ >/dev/null 2>&1
fi

# 清理归档文件...
echo ""
echo "2) clean..."
bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-clean-helper.sh

echo ""
echo "开始打包🚀 🚀 🚀"

#### 参数
echo ""
echo "step 3:参数..."
#### 输入参数检查
BUILD_PARAMETER=""
if [[ "${pre}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -pre"
fi
if [[ "${xgpre}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -xgpre"
fi
if [[ "${poc}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -poc"
fi
if [[ "${prd}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -prd"
fi
if [[ "${sit}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -sit"
fi
# 去除左右空格
BUILD_PARAMETER=$(echo ${BUILD_PARAMETER})
if [ "${BUILD_PARAMETER}" = "" ]; then
	echo "请选择打包环境"
	exit 1
fi

BUILD_SDK_ARRAY=()
if [[ "${SNMPaySDK}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} SNMPaySDK"
fi
if [[ "${SNMPayDependency}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} SNMPayDependency"
fi
if [[ "${YFBWalletLibs}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} YFBWalletLibs"
fi
if [[ "${YFBWalletSDKDependency}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} YFBWalletSDKDependency"
fi
if [[ "${SNKAHttpDNS}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} SNKAHttpDNS"
fi
if [[ "${CloudyTrace_SDK}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} CloudyTrace_SDK"
fi
if [[ "${SNSHumanMachine}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} SNSHumanMachine"
fi
if [[ "${PPTVSDK}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} PPTVSDK"
fi
if [[ "${SAStatistic_SDK}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} SAStatistic_SDK"
fi
if [[ "${SNYXChat_Framework}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} SNYXChat_Framework"
fi
if [[ "${MSFS_Framework}" = "true" ]]; then
	BUILD_SDK_ARRAY="${BUILD_SDK_ARRAY[*]} MSFS_Framework"
fi
# 研发云每晚会清理workspace,导致第一次打包clone代码非常耗时
# 兼容方案是,jenkins配置定时5点执行job、clone代码
# if [[ ${#BUILD_SDK_ARRAY[*]} -eq 0 ]]; then
# 	echo "请选择打包的sdk"
# 	exit 1
# fi

if [[ -z ${JENKINS_TYPE} ]]; then
	JENKINS_TYPE="jenkins"
fi

# 金融sdk勾选1个，则勾选对应的另外1个
if [[ "${SNMPaySDK}" = "true" ]] \
	|| [[ "${SNMPayDependency}" = "true" ]]; then
	SNMPaySDK=true
	SNMPayDependency=true
fi
if [[ "${YFBWalletLibs}" = "true" ]] \
	|| [[ "${YFBWalletSDKDependency}" = "true" ]]; then
	YFBWalletLibs=true
	YFBWalletSDKDependency=true
fi

# httpdns要和云迹sdk一起打包
if [[ "${SNKAHttpDNS}" = "true" ]]; then
	CloudyTrace_SDK=true
fi

# 默认打armv7和arm64包
if [[ "${ARMV7}" != "true" ]] && [[ "${ARM64}" != "true" ]]; then
	ARMV7=true
	ARM64=true
fi

BUILD_ARCHS=""
if [[ "${ARMV7}" = "true" ]];then
	BUILD_ARCHS="${BUILD_ARCHS} armv7"
fi
if [[ "${ARM64}" = "true" ]];then
	BUILD_ARCHS="${BUILD_ARCHS} arm64"
fi
if [[ "${X86_64}" = "true" ]];then
	BUILD_ARCHS="${BUILD_ARCHS} x86_64"
fi
# 去除左右空格
BUILD_ARCHS=$(echo ${BUILD_ARCHS})

if [[ -z ${UPLOAD_NAME} ]]; then
	if [[ "${SNMPaySDK}" = "true" ]]; then
		UPLOAD_NAME="官方金融sdk测试包"
	elif [[ "${PPTVSDK}" = "true" ]]; then
		UPLOAD_NAME="官方pptvsdk测试包"
	elif [[ "${SNKAHttpDNS}" = "true" ]]; then
		UPLOAD_NAME="官方httpdns测试包"
	elif [[ "${CloudyTrace_SDK}" = "true" ]]; then
		UPLOAD_NAME="官方云迹sdk测试包"
	elif [[ "${SAStatistic_SDK}" = "true" ]]; then
		UPLOAD_NAME="官方大数据sdk测试包"
	elif [[ "${SNSHumanMachine}" = "true" ]]; then
		UPLOAD_NAME="官方人机sdk测试包"
	elif [[ "${SNYXChat_Framework}" = "true" ]]; then
		UPLOAD_NAME="云信sdk测试包"
	elif [[ "${MSFS_Framework}" = "true" ]]; then
		UPLOAD_NAME="店铺sdk测试包"
	else
		UPLOAD_NAME="官方sdk测试包"
	fi
fi
# if [[ "${JENKINS_TYPE}" = "phoebus" ]]; then
# 	UPLOAD_NAME="研发云-${UPLOAD_NAME}"
# fi

echo "JENKINS_TYPE:      	${JENKINS_TYPE}"
echo "WORKSPACE:      	${WORKSPACE}"
echo "PROJECT_PATH: 		${PROJECT_PATH}"
echo "JOB_NAME:         	${JOB_NAME}"
echo "GIT_URL:          	${GIT_URL}"
echo "PROJECT_NAME:     	${PROJECT_NAME}"
echo "GIT_BRANCH_NAME:  	${GIT_BRANCH_NAME}"

echo ""
echo "buld参数"
echo "BUILD_PARAMETER:          ${BUILD_PARAMETER}"
echo "UPLOAD_NAME:      	${UPLOAD_NAME}"
echo "BUILD_ARCHS:      	${BUILD_ARCHS}"
echo "SuningEMall:      	${SuningEMall}"
echo "SNMPaySDK:      	${SNMPaySDK}"
echo "SNMPayDependency:      	${SNMPayDependency}"
echo "YFBWalletLibs:      	${YFBWalletLibs}"
echo "YFBWalletSDKDependency: ${YFBWalletSDKDependency}"
echo "SNKAHttpDNS:      	${SNKAHttpDNS}"
echo "CloudyTrace_SDK:      	${CloudyTrace_SDK}"
echo "SNSHumanMachine:      	${SNSHumanMachine}"
echo "PPTVSDK:      		${PPTVSDK}"
echo "SAStatistic_SDK:      	${SAStatistic_SDK}"
echo "SNYXChat_Framework:     ${SNYXChat_Framework}"
echo "MSFS_Framework:      	${MSFS_Framework}"

#### pull代码
echo ""
echo "step 4:pull code..."
# sdk打包不需要updateAllCode.sh
# # updateAllCode
# cd ${PROJECT_PATH}/
# echo "cmd: bash ${PROJECT_PATH}/updateAllCode.sh -revert--subproject"
# bash ${PROJECT_PATH}/updateAllCode.sh -revert--subproject
# # 命令执行失败,异常退出
# if [[ ! $? -eq 0 ]]; then
#     exit 1
# fi

# 处理SPECIAL_BRANCH中主分支，确保打包用的脚本用的是指定分支的
if [[ ! -z ${SPECIAL_BRANCH} ]]; then
    echo ""
    echo "处理SPECIAL_BRANCH，寻找指定的主工程分支..."
    BRANCH_INFO_ARRAY=(${SPECIAL_BRANCH//,/ })
    for BRANCH_INFO in ${BRANCH_INFO_ARRAY[*]}
    do
        PROJECT_NAME=${BRANCH_INFO%=*}
        BRANCH_NAME=${BRANCH_INFO#*=}

        # 切换主分支
        if [[ "${PROJECT_NAME}" = "SuningEBuy" ]]; then
            echo "BRANCH_INFO:${BRANCH_INFO}"
            echo "PROJECT_NAME:${PROJECT_NAME}"
            echo "BRANCH_NAME:${BRANCH_NAME}"
            
            cd ${PROJECT_PATH}
            # 放弃本地修改
            ${GIT} checkout .
            # 切换分支
            ${GIT} checkout ${BRANCH_NAME}
			# 命令执行失败,异常退出
			if [[ ! $? -eq 0 ]]; then
			    exit 1
			fi
            # 拉取代码
            ${GIT} pull
            # 跳出
            break
        fi
    done
fi

# repo-update
echo "cmd: repo-update.sh -skip--pod..."
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/repo-update.sh -checkupdate -skip--pod -revert--subproject
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# # 兼容研发云流水线打包场景，每次都会生成新的job-name
# # 将子工程放到 ~/.jenkins-slave/workspace/ebuy-sdk-sub 下
# echo ""
# echo "兼容研发云流水线场景，移动子工程到~/.jenkins-slave/workspace/ebuy-sdk-sub..."
# for SUB_PROJECT_PATH in ${SUB_PROJECT_PATH_ARRAY[*]}; do
# 	if [[ ! -L ${PROJECT_PATH}/${SUB_PROJECT_PATH} ]]; then
# 		echo "    移动子工程${SUB_PROJECT_PATH}..."
# 		mkdir -p $(dirname ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH})
# 		rm -rf ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH}
# 		mv ${PROJECT_PATH}/${SUB_PROJECT_PATH} ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} 
# 		echo "ln -fs ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ${PROJECT_PATH}/${SUB_PROJECT_PATH}"
# 		ln -fs ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ${PROJECT_PATH}/${SUB_PROJECT_PATH}
# 	fi
# done
# echo "done"

# # 检查SNPods、SNProjects下不是软链接的文件夹，报错并提示，需要放入SUB_PROJECT_PATH_ARRAY
# echo ""
# echo "检查SNPods、SNProjects下不是软链接的文件夹..."
# for SNPODS_PATH_NAME in "SNPods" "SNProjects"; do 
# 	for SUB_PROJECT_NAME in $(ls ${PROJECT_PATH}/${SNPODS_PATH_NAME}); do
# 		# 忽略SNSDKs_Framework、SNLazyLoadFrameworks_Framework，是放到主工程的
# 		if [[ ${SUB_PROJECT_NAME} = "SNSDKs_Framework" ]] \
# 			|| [[ ${SUB_PROJECT_NAME} = "SNLazyLoadFrameworks_Framework" ]]; then
# 			continue
# 		fi
# 		if [[ ! -L ${PROJECT_PATH}/${SNPODS_PATH_NAME}/${SUB_PROJECT_NAME} ]] \
# 			&& [[ -d ${PROJECT_PATH}/${SNPODS_PATH_NAME}/${SUB_PROJECT_NAME} ]]; then
# 			echo "wb error: ${SNPODS_PATH_NAME}/${SUB_PROJECT_NAME} 需要放入 SUB_PROJECT_PATH_ARRAY"
# 		fi
# 	done
# done

# 处理SPECIAL_BRANCH
if [[ ! -z ${SPECIAL_BRANCH} ]]; then
    echo ""
    echo "处理SPECIAL_BRANCH..."
    BRANCH_INFO_ARRAY=(${SPECIAL_BRANCH//,/ })
    for BRANCH_INFO in ${BRANCH_INFO_ARRAY[*]}
    do
        echo ""
        echo "BRANCH_INFO:${BRANCH_INFO}"
        PROJECT_NAME=${BRANCH_INFO%=*}
        BRANCH_NAME=${BRANCH_INFO#*=}
        echo "PROJECT_NAME:${PROJECT_NAME}"
        echo "BRANCH_NAME:${BRANCH_NAME}"
        # 切换主分支
        if [[ "${PROJECT_NAME}" = "SuningEBuy" ]]; then
            cd ${PROJECT_PATH}
        fi
        # 切换SNEBuy_buss_repos、SNEBuy_repos分支
        if [[ "${PROJECT_NAME}" = "SNEBuy_buss_repos" ]] \
        	|| [[ "${PROJECT_NAME}" = "SNEBuy_repos" ]]; then
            cd "${HOME}/.cocoapods/repos/${PROJECT_NAME}"
        fi
        # 如果存在
        if [[ -e ${PROJECT_PATH}/SNProjects/${PROJECT_NAME} ]]; then
            cd ${PROJECT_PATH}/SNProjects/${PROJECT_NAME}
        fi
        if [[ -e ${PROJECT_PATH}/SNPods/${PROJECT_NAME} ]]; then
            cd ${PROJECT_PATH}/SNPods/${PROJECT_NAME}
        fi
        CURRENT_DIRECTORY=$(pwd)
        CURRENT_DIRECTORY=$(basename ${CURRENT_DIRECTORY})
        # 兼容主工程目录ebuy_9520 -> SuningEBuy
		if [[ ${CURRENT_DIRECTORY} =~ "ebuy_" ]]; then
			CURRENT_DIRECTORY="SuningEBuy"
		fi
        if [[ "${CURRENT_DIRECTORY}" = ${PROJECT_NAME} ]]; then
            # 放弃本地修改
            ${GIT} checkout .
            # 切换分支
            ${GIT} checkout ${BRANCH_NAME}
			# 命令执行失败,异常退出
			if [[ ! $? -eq 0 ]]; then
			    exit 1
			fi
            # 拉取代码
            ${GIT} pull
        fi
    done
fi

# 检查测试sdk文件
echo ""
echo "检查测试sdk文件，防止文件位置错误或者忘记提交..."
echo "cmd: bash ${PROJECT_PATH}/Scripts/rsync-helper.sh checksdk ${GIT_BRANCH_VERSION} ${BUILD_SDK_ARRAY[*]}"
bash ${PROJECT_PATH}/Scripts/rsync-helper.sh checksdk ${GIT_BRANCH_VERSION} ${BUILD_SDK_ARRAY[*]}
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### pod集成
echo ''
echo 'step 5:pod集成...'
# 清空之前pod生成文件
cd ${PROJECT_PATH}/
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
for PBXPROJ_PATH in `find ${PROJECT_PATH}/SNProjects -name project.pbxproj`
do
    sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
done

echo "修改Podfile..."
PODFILE_PATH=${PROJECT_PATH}/Podfile
# using_code_sncommon
echo "修改using_code_sncommon"
sed -i '' "s/using_code_sncommon =.*/using_code_sncommon = false/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_sncommon ="
for SDK_NAME in ${BUILD_SDK_ARRAY[*]}; do
	echo ""
	echo "修改${SDK_NAME}"
	if [[ "${SDK_NAME}" = "SNMPaySDK" ]] \
		|| [[ "${SDK_NAME}" = "SNMPayDependency" ]] \
		|| [[ "${SDK_NAME}" = "YFBWalletLibs" ]] \
		|| [[ "${SDK_NAME}" = "YFBWalletSDKDependency" ]] \
		|| [[ "${SDK_NAME}" = "PPTVSDK" ]] \
		|| [[ "${SDK_NAME}" = "SAStatistic_SDK" ]] \
		|| [[ "${SDK_NAME}" = "SNYXChat_Framework" ]] \
		|| [[ "${SDK_NAME}" = "MSFS_Framework" ]]; then
		# pod 'libSNMPaySDK', :path => 'SNPods/SNMPaySDK'
		# pod 'libSNMPaySDK/Bundle', :path => 'SNPods/SNMPaySDK'
		# pod 'SNMPayDependency/FrameWorkWithoutOpenSSL', :path => 'SNPods/SNMPayDependency'
		# pod 'SNMPayDependency/OpenSSL', :path => 'SNPods/SNMPayDependency'
		# pod 'SNMPayDependency/Bundle', :path => 'SNPods/SNMPayDependency'
		# pod 'YFBWalletLibs', :path => 'SNPods/YFBWalletLibs'
		# pod 'YFBWalletLibs/Bundle', :path => 'SNPods/YFBWalletLibs'
		# pod 'YFBWalletSDKDependency/Bundle', :path => 'SNPods/YFBWalletSDKDependency'
		# pod 'YFBWalletSDKDependency', :path => 'SNPods/YFBWalletSDKDependency'
		# pod 'PPTVSDK/PPTVSdk', :path => 'SNPods/PPTVSDK'
		# pod 'PPTVSDK/PPYLiveKit-dynamic', :path => 'SNPods/PPTVSDK'
		# pod 'PPTVSDK/PPYCommonSDK-dynamic', :path => 'SNPods/PPTVSDK'
		# pod 'PPTVSDK/PPTVFileUpload', :path => 'SNPods/PPTVSDK' 
		# pod 'PPTVSDK/MediaPlayerFramework', :path => 'SNPods/PPTVSDK'
		# pod 'PPTVSDK/MediaStreamerFramework-dynamic', :path => 'SNPods/PPTVSDK'
		# pod 'SAStatistic_SDK', :path => 'SNPods/SAStatistic_SDK'
		# pod 'SNYXChat_Framework/SNYXChatlib', :path => 'SNPods/SNYXChat_Framework'
		# pod 'MSFS/MSFSlib', :path => 'SNPods/MSFS_Framework'
		sed -i '' "s/'SNPods\/${SDK_NAME}'/\$POD_RSYNC_SPEC_PATH + '${SDK_NAME}'/" ${PODFILE_PATH}
	elif [[ "${SDK_NAME}" = "SNKAHttpDNS" ]] \
		|| [[ "${SDK_NAME}" = "CloudyTrace_SDK" ]] \
		|| [[ "${SDK_NAME}" = "SNSHumanMachine" ]]; then
		# pod 'SNKAHttpDNS', :path => $POD_SPEC_PATH + 'SNKAHttpDNS/1.5.3'
		# pod 'CloudyTrace_SDK', :path => 'SNPods/CloudyTrace_SDK'
		# pod 'SNSHumanMachine', :path => $POD_SPEC_PATH + 'SNSHumanMachine/2.6.2'
		sed -i '' "s/pod.*${SDK_NAME}.*/pod '${SDK_NAME}', :path => \$POD_RSYNC_SPEC_PATH + '${SDK_NAME}'/" ${PODFILE_PATH}
	fi
	cat ${PODFILE_PATH} | grep ${SDK_NAME}
done

# repo-update
echo ""
echo "cmd: bash repo-update.sh -pod"
cd ${PROJECT_PATH}/
bash repo-update.sh -pod

#### 打包
echo ''
echo 'step 6:打包...'
echo "6-1:打印Podfile"
cat ${PODFILE_PATH}

# 处理SPECIAL_BRANCH
if [[ ! -z ${SPECIAL_BRANCH} ]]; then
	echo ""
	echo "处理SPECIAL_BRANCH，检查切换操作是否完成..."
	BRANCH_INFO_ARRAY=(${SPECIAL_BRANCH//,/ })  
	for BRANCH_INFO in ${BRANCH_INFO_ARRAY[*]}
	do
		echo ""
		echo "BRANCH_INFO:${BRANCH_INFO}"
		PROJECT_NAME=${BRANCH_INFO%=*}
		BRANCH_NAME=${BRANCH_INFO#*=}
		echo "PROJECT_NAME:${PROJECT_NAME}"
		echo "BRANCH_NAME:${BRANCH_NAME}"
        # 切换主分支
        if [[ "${PROJECT_NAME}" = "SuningEBuy" ]]; then
            cd ${PROJECT_PATH}
        fi
        # 切换SNEBuy_buss_repos、SNEBuy_repos分支
        if [[ "${PROJECT_NAME}" = "SNEBuy_buss_repos" ]] \
        	|| [[ "${PROJECT_NAME}" = "SNEBuy_repos" ]]; then
            cd "${HOME}/.cocoapods/repos/${PROJECT_NAME}"
        fi
		# 如果存在
		if [[ -e ${PROJECT_PATH}/SNProjects/${PROJECT_NAME} ]]; then
			cd ${PROJECT_PATH}/SNProjects/${PROJECT_NAME}
		fi
		if [[ -e ${PROJECT_PATH}/SNPods/${PROJECT_NAME} ]]; then
			cd ${PROJECT_PATH}/SNPods/${PROJECT_NAME}
		fi
		CURRENT_DIRECTORY=$(pwd)
		CURRENT_DIRECTORY=$(basename ${CURRENT_DIRECTORY})
		# 兼容主工程目录ebuy_9520 -> SuningEBuy
		if [[ ${CURRENT_DIRECTORY} =~ "ebuy_" ]]; then
			CURRENT_DIRECTORY="SuningEBuy"
		fi
		if [[ "${CURRENT_DIRECTORY}" = ${PROJECT_NAME} ]]; then
			if [[ -z "$(${GIT} status | grep ${BRANCH_NAME})" ]]; then
				echo "error: 没有找到该分支,请检查"
				exit 1
			else
				${GIT} status | head -2
			fi
		else
			echo "error: 没有找到该库,请检查"
			exit 1
		fi
	done
fi

echo "6-2:Archive"
BUILD_PARAMETER="${BUILD_PARAMETER} -u -name--${UPLOAD_NAME} -force--enterprise -xcpretty"
# jenkins描述 http://10.37.64.97/jenkins/job/SuningEBuy-Framework-850/107/
BUILD_PARAMETER="${BUILD_PARAMETER} -jenkinsDesc--#${BUILD_NUMBER}"
if [[ "${JENKINS_TYPE}" = "jenkins" ]]; then
	# http://10.37.64.97/jenkins/job/SuningEBuy-Framework-850/107/
	JENKINS_URL="http://10.37.64.97/jenkins/job/${JOB_NAME}/${BUILD_NUMBER}/"
elif [[ "${JENKINS_TYPE}" = "phoebus" ]]; then
	# http://10.37.64.97/ftp-ios/Dev_Br_842/suningebuy__researchCloud_pipeline_1578897649221_1/
	JENKINS_URL="http://10.37.64.97/ftp-ios/${GIT_BRANCH_NAME}/${JOB_NAME}_${BUILD_NUMBER}/"
fi
BUILD_PARAMETER="${BUILD_PARAMETER} -jenkinsUrl--${JENKINS_URL}"
# armv7
if [[ "${ARMV7}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--armv7"
fi
# arm64
if [[ "${ARM64}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--arm64"
fi

if [[ "${SuningEMall}" = "true" ]]; then
	echo ""
	echo "6-2:打包命令:${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}"
	echo "building..."
	bash ${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}
else
	echo ""	
	echo "6-2:打包命令:${PROJECT_PATH}/ipa-test.sh ${BUILD_PARAMETER}"
	echo "building..."
	bash ${PROJECT_PATH}/ipa-test.sh ${BUILD_PARAMETER}
fi
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# CURRENT_BUILD_DIRECTORY
CURRENT_BUILD_DIRECTORY=$(ls -rt ${PROJECT_PATH}/build | tail -1)
CURRENT_BUILD_DIRECTORY="${PROJECT_PATH}/build/${CURRENT_BUILD_DIRECTORY}"
cd ${CURRENT_BUILD_DIRECTORY}

#### 生成归档文件，jenkins Copy Artifact Plugin
echo ""
echo "step 8:生成归档文件..."
# 列出build结果
echo "cmd: ls ${CURRENT_BUILD_DIRECTORY}"
ls ${CURRENT_BUILD_DIRECTORY}
# 拷贝dsynm文件到build-artifacts
BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
for XCARCHIVE_FILE_PATH in $(find ${CURRENT_BUILD_DIRECTORY} -name *.xcarchive -maxdepth 1)
do
	cd ${XCARCHIVE_FILE_PATH}/dSYMs
	for DSYM_FILE_NAME in $(ls)
	do
		if [[ ${DSYM_FILE_NAME} =~ ".dSYM" ]]; then
			echo ""
			echo "cmd: zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1"
			zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1
		fi
	done
done
# 兼容研发云Delete workspace when build is done
if [[ -d ${WORKSPACE}/build-artifacts ]] && [[ ! -L ${WORKSPACE}/build-artifacts ]]; then
    rm -rf ${WORKSPACE}/build-artifacts
fi
ln -fs ${BUILD_ARTIFACTS_PATH} ${WORKSPACE}/

#### 打印sdk信息
echo ""
echo "step 9:打印sdk信息..."
RSYNC_PROJECT_PATH=${HOME}/.cocoapods/repos/SNEBuy_build_rsync/SuningEBuy-Framework-${GIT_BRANCH_VERSION}
for SDK_NAME in ${BUILD_SDK_ARRAY[*]}; do
    RSYNC_SDK_PATH=${RSYNC_PROJECT_PATH}/${SDK_NAME}

    echo ""
    echo "> ls -l ${RSYNC_SDK_PATH}"
    ls -l ${RSYNC_SDK_PATH}
done

