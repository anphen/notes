#!/bin/bash
# jenkins设置中执行脚本

# set -e

# #### 模拟参数
# IPA_PLIST_URL="https://10.37.64.97/ipa/manifest/2/648/41123/.plist"
# SDK_URL="http://10.200.21.114:8070/job/SNOPWrapperFramework/168/artifact/SNOPWrapperFramework/PPTVSDK_static_1.1.5-rc.21.zip"
# UPLOAD_NAME="PPTV测试包 官方包"
# BUNDLE_IDENTIFIER="SuningEMall"
# VERSION_NAME="8.1.0"

#### 环境变量
echo ''
echo 'step 1:环境变量...'
export LANG=zh_CN.UTF-8
PATH=${PATH}:/usr/local/bin
if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi

# 基本变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

# WORKSPACE默认值
if [ ! ${WORKSPACE} ]; then
	WORKSPACE=${SCRIPT_DIR}
fi
cd ${WORKSPACE}

PROJECT_NAME="SuningEBuy"

PROJECT_PATH="${WORKSPACE}/${PROJECT_NAME}"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_NAME="Dev_Br_800"
VERSION_NAME2=${VERSION_NAME//./}
GIT_BRANCH_NAME="Dev_Br_${VERSION_NAME2}"

# svn
SVN="svn"
# jenkins svn变量兼容
if [ ${JENKINS_SVN} ]; then
	SVN=${JENKINS_SVN}
	echo "using svn:        ${SVN}"
fi

echo "JOB_NAME:         	${JOB_NAME}"
echo "GIT_URL:          	${GIT_URL}"
echo "PROJECT_NAME:     	${PROJECT_NAME}"
echo "GIT_BRANCH_NAME:  	${GIT_BRANCH_NAME}"

#### 输入参数检查
echo ''
echo 'step 2:参数检查...'
SHOULD_EXIT=""
if [ "${IPA_PLIST_URL}" = "" ]; then
	echo "不能为空:    		IPA_PLIST_URL"
	SHOULD_EXIT="1"
fi
if [ "${SDK_URL}" = "" ]; then
	echo "不能为空:    		SDK_URL"
	SHOULD_EXIT="1"
fi
if [ "${VERSION_NAME}" = "" ]; then
	echo "不能为空:    		VERSION_NAME"
	SHOULD_EXIT="1"
fi
if [ "${SHOULD_EXIT}" = "1" ]; then
	exit 0
fi

if [ "${UPLOAD_NAME}" = "" ]; then
	UPLOAD_NAME="PPTV测试包"
fi
if [ "${BUNDLE_IDENTIFIER}" = "" ]; then
	BUNDLE_IDENTIFIER="SuningEMall"
fi
echo "UPLOAD_NAME:          ${UPLOAD_NAME}"
echo "BUNDLE_IDENTIFIER:    ${BUNDLE_IDENTIFIER}"

#### clean
echo ''
echo 'step 3:clean...'
echo "3-1:主工程${PROJECT_NAME}"
if [ -d ${PROJECT_PATH} ]; then
	echo "clean ${PROJECT_PATH}..."
	cd ${PROJECT_PATH}
	# 放弃本地修改
	${GIT} checkout . 
	# 删除Untracked files
	${GIT} clean -fd
	# 切换分支
	${GIT} checkout ${GIT_BRANCH_NAME}
	echo "finish"
fi

echo "3-2:pod repos"
# SNEBuy_buss_repos、SNEBuy_repos
for POD_REPO_PATH in "${HOME}/.cocoapods/repos/SNEBuy_buss_repos" \
  "${HOME}/.cocoapods/repos/SNEBuy_repos"
do
	if [ -d ${POD_REPO_PATH} ]; then
		echo "clean ${POD_REPO_PATH}..."
		cd ${POD_REPO_PATH}
		# 放弃本地修改
		${GIT} checkout . 
		# 删除Untracked files
		${GIT} clean -fd
		# 切换分支
		if [[ ${POD_REPO_PATH} =~ "SNEBuy_buss_repos" ]]; then
			${GIT} checkout Dev_Br_buss_repos
		elif [[ ${POD_REPO_PATH} =~ "SNEBuy_repos" ]]; then
			${GIT} checkout Dev_Br_repos
		fi
		echo "finish"
	fi
done

# SNEBuy_YFBSDK、SNEBuy_YFBWallet
for POD_REPO_PATH in "${HOME}/.cocoapods/repos/SNEBuy_YFBSDK" \
  "${HOME}/.cocoapods/repos/SNEBuy_YFBWallet"
do
	if [ -d ${POD_REPO_PATH} ]; then
		echo "clean ${POD_REPO_PATH}..."
		cd ${POD_REPO_PATH}
		${SVN} cleanup
		${SVN} revert . -R
		echo "finish"
	fi
done

echo "3-3:子工程"
for SUB_PROJECT_PATH in "${PROJECT_PATH}/SNProjects/SNChannel" \
  "${PROJECT_PATH}/SNProjects/SNDynamicFrameworks" \
  "${PROJECT_PATH}/SNProjects/SNHomePage" \
  "${PROJECT_PATH}/SNProjects/SNHWG" \
  "${PROJECT_PATH}/SNProjects/SNLive" \
  "${PROJECT_PATH}/SNProjects/SNMBLoginRegister" \
  "${PROJECT_PATH}/SNProjects/SNMBMember" \
  "${PROJECT_PATH}/SNProjects/SNMK" \
  "${PROJECT_PATH}/SNProjects/SNMPTM" \
  "${PROJECT_PATH}/SNProjects/SNPM" \
  "${PROJECT_PATH}/SNProjects/SNPMPinGou" \
  "${PROJECT_PATH}/SNProjects/SNPMPinGouDynamic" \
  "${PROJECT_PATH}/SNProjects/SNSHProductDetail" \
  "${PROJECT_PATH}/SNProjects/SNSHSearch" \
  "${PROJECT_PATH}/SNProjects/SNSL" \
  "${PROJECT_PATH}/SNProjects/SNSM"
do
	if [ -d ${SUB_PROJECT_PATH} ]; then
		echo "clean ${SUB_PROJECT_PATH}..."
		cd ${SUB_PROJECT_PATH}
		# 放弃本地修改
		${GIT} checkout . 
		# 删除Untracked files
		${GIT} clean -fd
		# 切换分支
		${GIT} checkout ${GIT_BRANCH_NAME}
		echo "finish"
	fi
done

echo "3-4:build目录"
# 删除工程打包build目录1天前文件夹
BUILD_DIRECTORY="${PROJECT_PATH}/SNProjects/SNDynamicFrameworks/SNSDKsBuild"
if [ -e ${BUILD_DIRECTORY} ];then 
	echo "cmd: rm -rf ${BUILD_DIRECTORY}/*"
	rm -rf ${BUILD_DIRECTORY}/*
fi

echo "3-5:.jenkins-slave/workspace"
# 删除.jenkins-slave下7天没使用的workspace
JENKINS_WORKSPACE_DIRECTORY="${HOME}/.jenkins-slave/workspace"
for JOB_WORKSPACE_NAME in $(ls ${JENKINS_WORKSPACE_DIRECTORY}); do
	JOB_SAVE_MAX_DAYS="7"
	JOB_MODIFY_FILE_LIST_IN_MAX_DAYS=$(find ${JENKINS_WORKSPACE_DIRECTORY}/${JOB_WORKSPACE_NAME} -mtime -${JOB_SAVE_MAX_DAYS})
    if [[ ${JOB_MODIFY_FILE_LIST_IN_MAX_DAYS} = "" ]]; then
		echo "JOB ${JOB_WORKSPACE_NAME} ${JOB_SAVE_MAX_DAYS}天内没修改，删除..."
		echo "cmd: rm -rf ${JENKINS_WORKSPACE_DIRECTORY}/${JOB_WORKSPACE_NAME}"
		rm -rf ${JENKINS_WORKSPACE_DIRECTORY}/${JOB_WORKSPACE_NAME}
    fi
done

#### pull代码
echo ''
cd ${WORKSPACE}
echo 'step 4:pull code...'
echo 'step 4-1:SNDynamicFrameworks'
if [ -d ${PROJECT_NAME} ]; then
	cd ${PROJECT_NAME}
	${GIT} pull
	${GIT} checkout ${GIT_BRANCH_NAME}
else
	${GIT} clone ${GIT_URL} ${PROJECT_NAME}
	cd ${PROJECT_NAME}
	${GIT} checkout ${GIT_BRANCH_NAME}
fi

echo ""
echo 'step 4-2:sdk'
# 拷贝SNEBuy_buss_repos目录下的PPTVSDK
cd ${WORKSPACE}/${PROJECT_NAME}/
PROJECT_PPTVSDK_PATH=$(cat Podfile | grep BussLibs/PPTVSDK/ | head -1)
PROJECT_PPTVSDK_PATH=${PROJECT_PPTVSDK_PATH%\'*}
PROJECT_PPTVSDK_PATH=${PROJECT_PPTVSDK_PATH##*\'}
PROJECT_PPTVSDK_PATH=${HOME}/.cocoapods/repos/SNEBuy_buss_repos/${PROJECT_PPTVSDK_PATH}
echo "当前PPTVSDK: ${PROJECT_PPTVSDK_PATH}"

echo "cmd: cp -rf ${PROJECT_PPTVSDK_PATH} SNPods/PPTVSDK"
mkdir -p SNPods/PPTVSDK
cp -rf ${PROJECT_PPTVSDK_PATH} SNPods/PPTVSDK

# 下载新打包的PPTVSDK
cd SNPods/PPTVSDK/*/PPTVSDK/PPTVSdk 
mkdir -p z_tmp
cd z_tmp
SDK_NAME=$(basename ${SDK_URL})
echo ""
echo "cmd: curl -k $SDK_URL -o ${SDK_NAME}"
curl -k $SDK_URL -o ${SDK_NAME}
echo ""
echo "cmd: unzip -o -d ./ ${SDK_NAME}"
unzip -o -d ./ ${SDK_NAME}

# 替换PPTVSDK
echo ""
echo "替换PPTVSDK..."
rm -rf ../MediaPlayerFramework.framework
rm -rf ../PPTVSdk/*
mv *.framework ../PPTVSdk/

cd ../
rm -rf z_tmp

#### pod集成
echo ''
echo 'step 5:pod集成...'
# 清空之前pod生成文件
cd ${PROJECT_PATH}/
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
for PBXPROJ_PATH in `find ${PROJECT_PATH}/SNProjects -name project.pbxproj`
do
    sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
done

echo "修改Podfile..."
PodfilePath=${PROJECT_PATH}/Podfile
sed -i '' "s/\$POD_BUSS_SPEC_PATH + \'BussLibs\/PPTVSDK/\'SNPods\/PPTVSDK/" ${PodfilePath}
cat ${PodfilePath} | grep "pod 'PPTVSDK"

# repo-update
echo ""
echo "cmd: repo-update.sh..."
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/repo-update.sh -checkupdate
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### 打包
echo ''
echo 'step 6:打包...'
echo "6-1:打印Podfile"
cat $PodfilePath

echo "6-2:Archive"
cd ${PROJECT_PATH}/SNProjects/SNDynamicFrameworks
echo "打包命令: bash ArchiveSNSDKs.sh -skip--x86"
bash ArchiveSNSDKs.sh -skip--x86
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# CURRENT_BUILD_DIRECTORY
CURRENT_BUILD_DIRECTORY=$(ls -rt ${BUILD_DIRECTORY} | tail -1)
CURRENT_BUILD_DIRECTORY="${BUILD_DIRECTORY}/${CURRENT_BUILD_DIRECTORY}"
cd ${CURRENT_BUILD_DIRECTORY}

#### 下载ipa
echo ''
echo 'step 7:下载ipa...'
if [[ "${IPA_PLIST_URL##*.}" == "plist" ]]; then
	echo "获取IPA_DOWNLOAD_URL..."
  	IPA_DOWNLOAD_URL=$(curl -k ${IPA_PLIST_URL} | grep -o -e "[^>]*\.ipa")
  	echo "IPA_DOWNLOAD_URL:		${IPA_DOWNLOAD_URL}"
else
  	IPA_DOWNLOAD_URL=${IPA_PLIST_URL}
fi
IPA_NAME=$(basename ${IPA_DOWNLOAD_URL})
if [ ! -f ${IPA_NAME} ]; then
	echo ""
	echo "cmd: curl -k ${IPA_DOWNLOAD_URL} -o ${IPA_NAME}"
  	curl -k ${IPA_DOWNLOAD_URL} -o ${IPA_NAME}
fi

#### 替换SNSDKs、重新生成ipa
echo ''
echo 'step 8:替换SNSDKs、重新生成ipa...'
echo "cmd :resign.sh ${CURRENT_BUILD_DIRECTORY}/${IPA_NAME} -framework -bundleid--${BUNDLE_IDENTIFIER}"
bash ${PROJECT_PATH}/Scripts/resign.sh ${CURRENT_BUILD_DIRECTORY}/${IPA_NAME} -framework -bundleid--${BUNDLE_IDENTIFIER}

#### 上传ipa
echo ''
echo 'step 9:上传ipa...'
#测试下载环境上配置的suningEBuy_iphone的配置
appId="2"
versionName="${VERSION_NAME}"
uploadUrl="http://10.37.64.97/ipa/upload.json"

#bundleIdentifier
bundleIdNew=${BUNDLE_IDENTIFIER}

pack_name=${UPLOAD_NAME}

ipa_name=${CURRENT_BUILD_DIRECTORY}/SuningEBuy.ipa

dateString=`date '+%Y-%m-%d %H:%M:%S'`
echo "${dateString}:上传测试包"
echo "${dateString}:curl -F 'appId=${appId}' -F 'versionName=${versionName}' -F 'bundleId=${bundleIdNew}'' -F 'ipaDesc=${pack_name}' -F 'ipaFile=@${ipa_name}' ${uploadUrl}"
curl -F "appId=${appId}" -F "versionName=${versionName}" -F "bundleId=${bundleIdNew}" -F "ipaDesc=${pack_name}" -F "ipaFile=@${ipa_name}" ${uploadUrl}

#### 生成归档文件，jenkins Copy Artifact Plugin
echo ''
echo ''
echo 'step 10:生成归档文件...'
BUILD_ARTIFACTS_PATH="${WORKSPACE}/build-artifacts"
mkdir -p ${BUILD_ARTIFACTS_PATH}
rm -rf ${BUILD_ARTIFACTS_PATH}/*
# 拷贝文件
cd ${CURRENT_BUILD_DIRECTORY}
echo "cmd: ls ${CURRENT_BUILD_DIRECTORY}"
ls ${CURRENT_BUILD_DIRECTORY}
for DSYM_FILE_NAME in $(ls)
do
	if [[ ${DSYM_FILE_NAME} =~ ".dSYM" ]]; then
		echo ""
		echo "cmd: zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1"
		zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1
	fi
done

