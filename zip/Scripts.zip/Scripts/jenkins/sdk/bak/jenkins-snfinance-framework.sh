#!/bin/bash
# 金融framework打包
# 使用，同时也是jenkins build参数
# export JOB_NAME="SNFinance-Framework-904"
# export using_code_snsl=false
# export pre=true
# export xgpre=true
# export prd=true
# export sit=true
# export poc=false
# # 选中-官方定位分享包，不选中-官方测试包
# export SuningEMall=true 
# # 打armv7架构测试包，兼容iPhone4s、5设备
# export ARMV7=false 
# # 打arm64架构测试包，目前大部分iPhone都是arm64架构
# export ARM64=true 
# # 可不配置,描述会按照SuningEMall的选择来
# export UPLOAD_NAME=融合钱包840 
# # 钱包打包配置项，默认空，libSNMPaySDK/branches/2.9.0.1
# export SNMPaySDK_PATH=libSNMPaySDK/branches/ 
# # 钱包打包配置项，默认空，SNMPayDependency/branches/3.1.0.1
# export SNMPayDependency_PATH=SNMPayDependency/branches/ 
# # 钱包打包配置项，默认空，YFBWalletSDK/branches/2.9.4.7
# export YFBWalletLibs_PATH=YFBWalletSDK/branches/ 
# # 钱包打包配置项，默认空，YFBWalletSDKDependency/branches/1.7.7.3
# export YFBWalletSDKDependency_PATH=YFBWalletSDKDependency/branches/ 
# 开始打包
# bash jenkins-snfinance-framework.sh

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

export LANG=zh_CN.UTF-8
export PATH=/usr/local/bin:${PATH}

#### 更新主工程代码...
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_VERSION="830"
# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
if [ ${JOB_NAME} ] && [[ ${JOB_NAME} =~ "-" ]];then
	GIT_BRANCH_VERSION=${JOB_NAME##*-}
fi
GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

cd ${WORKSPACE}
if [ ! -d ${WORKSPACE}/.git ]; then
	echo "> ${GIT} init"
	${GIT} init
	echo "> ${GIT} remote add origin ${GIT_URL}"
	${GIT} remote add origin ${GIT_URL}
	echo "> ${GIT} fetch"
	${GIT} fetch
	echo "> ${GIT} checkout ${GIT_BRANCH_NAME}"
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
echo "> ${GIT} checkout . "
${GIT} checkout . 
# 删除Untracked files
echo "> ${GIT} clean -fd"
${GIT} clean -fd
# 拉取代码
echo "> ${GIT} pull"
${GIT} pull
# 切换分支
echo "> ${GIT} checkout ${GIT_BRANCH_NAME}"
${GIT} checkout ${GIT_BRANCH_NAME}
echo "> build"

#### 设置金融打包参数...
export SNFINANCE_BUILD=true
export using_code_sndynamicframeworks=true
# 除了sndynamicframeworks、snsl，其他都不使用代码
export using_code_sncommon=false
export using_code_snsearch=false
export using_code_snproduct=false
export using_code_snpingou=false
export using_code_snpm=false
export using_code_snlogin=false
export using_code_snmember=false
export using_code_snlive=false
export using_code_snmk=false
export using_code_snmptm=false
export using_code_snhwg=false
export using_code_snchannel=false
export using_code_snsm=false
export using_code_snhome=false


#### 调用jenkins-project-framework.sh
bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-project-framework.sh

