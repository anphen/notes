#!/bin/bash
# jenkins设置中执行脚本
# 使用，同时也是jenkins build参数
# export JOB_NAME="SNHUMANMACHINE-Framework-904"
# export pre=false
# export xgpre=false
# export prd=false
# export sit=false
# # 选中-官方定位分享包，不选中-官方测试包
# export SuningEMall=true 
# # 打armv7架构测试包，兼容iPhone4s、5设备
# export ARMV7=false 
# # 打arm64架构测试包，目前大部分iPhone都是arm64架构
# export ARM64=true 
# # 可不配置,描述会按照SuningEMall的选择来
# export UPLOAD_NAME="人机SDK测试包" 
# # 人机sdk的下载地址	
# export SDK_URL="ftp://10.104.249.195/mmds/prd/ios_sdk/SNSHumanMachineSDK-1.1.8.zip" 
# 执行脚本
# bash jenkins-snhumanmachine-framework.sh

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

export LANG=zh_CN.UTF-8
PATH=${PATH}:/usr/local/bin
if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi

#### 变量
echo ""
echo "step 1:更新主工程代码..."
# 基本变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

# WORKSPACE默认值
if [ ! ${WORKSPACE} ]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

PROJECT_NAME="SuningEBuy"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_VERSION="830"
# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
	# jenkins打包 SuningEBuy-840
	GIT_BRANCH_VERSION=${JOB_NAME##*-}
elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
	# 研发云打包 ebuy_840
	GIT_BRANCH_VERSION=${JOB_NAME##*_}
fi
GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

# 拉取代码
cd ${WORKSPACE}
if [ ! -d ${WORKSPACE}/.git ]; then
	${GIT} init
	${GIT} remote add origin ${GIT_URL}
	${GIT} fetch
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
${GIT} checkout . 
# 删除Untracked files
${GIT} clean -fd
# 拉取代码
${GIT} pull
# 切换分支
${GIT} checkout ${GIT_BRANCH_NAME}

#### 打包前处理
echo ""
echo "step 2:打包前处理..."
# 清理归档文件...
echo "1) clean..."
bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-clean-helper.sh

echo ""
echo "开始打包🚀 🚀 🚀"

#### 参数
echo ""
echo "step 3:参数..."
#### 输入参数检查
BUILD_PARAMETER=""
if [[ "${pre}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -pre"
fi
if [[ "${xgpre}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -xgpre"
fi
if [[ "${poc}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -poc"
fi
if [[ "${prd}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -prd"
fi
if [[ "${sit}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -sit"
fi
# 去除左右空格
BUILD_PARAMETER=$(echo ${BUILD_PARAMETER})
if [ "${BUILD_PARAMETER}" = "" ]; then
	echo "请选择打包环境"
	exit 0
fi

SHOULD_EXIT=""
if [ "${SDK_URL}" = "" ]; then
	echo "不能为空:    		SDK_URL"
	SHOULD_EXIT="1"
fi
if [ "${SHOULD_EXIT}" = "1" ]; then
	exit 0
fi

echo "JOB_NAME:         	${JOB_NAME}"
echo "GIT_URL:          	${GIT_URL}"
echo "PROJECT_NAME:     	${PROJECT_NAME}"
echo "GIT_BRANCH_NAME:  	${GIT_BRANCH_NAME}"

if [ "${UPLOAD_NAME}" = "" ]; then
	UPLOAD_NAME="人机SDK测试包"
fi
echo "UPLOAD_NAME:          	${UPLOAD_NAME}"

#### pull代码
echo ""
echo "step 4:repo-update.sh..."
# repo-update
echo "cmd: repo-update.sh..."
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/repo-update.sh -framework -checkupdate -skip--pod
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### pull代码
echo ""
echo "step 5:pull sdk code..."
# 拷贝SNEBuy_buss_repos目录下的PPTVSDK
cd ${PROJECT_PATH}
POD_PATH=$(cat Podfile | grep -v '#' | grep "SNSHumanMachine" | head -1)
POD_PATH=${POD_PATH#*=>}
# 替换空格为空字符串
POD_PATH=${POD_PATH// /}
# 替换+为空字符串
POD_PATH=${POD_PATH//+/}
# 替换'为空字符串
POD_PATH=${POD_PATH//\'/}
# 替换POD_BUSS_SPEC_PATH为${HOME}/.cocoapods/repos/SNEBuy_buss_repos
POD_PATH=${POD_PATH//\$POD_BUSS_SPEC_PATH/${HOME}\/.cocoapods\/repos\/SNEBuy_buss_repos\/}
# 替换POD_BUSS_SPEC_PATH为${HOME}/.cocoapods/repos/SNEBuy_repos
POD_PATH=${POD_PATH//\$POD_SPEC_PATH/${HOME}\/.cocoapods\/repos\/SNEBuy_repos\/}
echo "当前人机SDK: ${POD_PATH}"

echo "cmd: cp -rf ${POD_PATH} SNPods/SNSHumanMachine"
mkdir -p SNPods/SNSHumanMachine-jenkins
rm -rf SNPods/SNSHumanMachine-jenkins/*
cp -rf ${POD_PATH} SNPods/SNSHumanMachine-jenkins

# 下载新打包的PPTVSDK
cd ${PROJECT_PATH}/SNPods/SNSHumanMachine-jenkins/*/
mkdir -p z_tmp
cd z_tmp
SDK_NAME="SNSHumanMachineSDK.zip"
echo ""
echo "cmd: curl ${SDK_URL} -u \"xxx:xxx\" -o ${SDK_NAME}"
curl ${SDK_URL} -u "dfprsquest:dfprsquest" -o ${SDK_NAME}
echo ""
echo "cmd: unzip -o -d ./ ${SDK_NAME}"
unzip -o -d ./ ${SDK_NAME}

# 替换PPTVSDK
echo ""
echo "替换人机SDK..."
# 删除之前的framework  find搜索framework，确保删除
for FRAMEWORK_PATH in $(find ../ -name "*.framework"); do
	if [[ ! "${FRAMEWORK_PATH}" =~ "z_tmp/" ]]; then
		rm -rf ${FRAMEWORK_PATH}
	fi
done
# 拷贝framework
# 创建验证文件test.txt
touch SNSHumanMachineSDK.framework/test.txt
# 移动framework
mv SNSHumanMachineSDK.framework ../SNSHumanMachineSDK.framework
# 删除z_tmp
cd ../
rm -rf z_tmp
echo "done"

echo ""
echo "检查是否最新人机SDK..."
# 检查是否新的framework
if [[ -f SNSHumanMachineSDK.framework/test.txt ]]; then
	rm -f SNSHumanMachineSDK.framework/test.txt
	echo "success"
else
	echo "fail,联系14121612"
	exit 1
fi

#### pod集成
echo ''
echo 'step 5:pod集成...'
# 清空之前pod生成文件
cd ${PROJECT_PATH}/
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
for PBXPROJ_PATH in `find ${PROJECT_PATH}/SNProjects -name project.pbxproj`
do
    sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
done

echo "修改Podfile..."
PODFILE_PATH=${PROJECT_PATH}/Podfile
# using_code_sndynamicframeworks
# SNSHumanMachineSDK是集成到主工程的，所以动态库也可以用framework集成
echo "using_code_sndynamicframeworks"
sed -i '' "s/using_code_sndynamicframeworks =.*/using_code_sndynamicframeworks = false/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_sndynamicframeworks ="
# using_code_sncommon
echo ""
echo "修改using_code_sncommon"
sed -i '' "s/using_code_sncommon =.*/using_code_sncommon = false/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_sncommon ="
# SNSHumanMachine
echo ""
echo "修改人机SDK"
sed -i '' "s/\$POD_SPEC_PATH + \'SNSHumanMachine/\'SNPods\/SNSHumanMachine-jenkins/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "pod 'SNSHumanMachine"

# repo-update
echo ""
echo "cmd: pod _1.2.0_ install --no-repo-update"
cd ${PROJECT_PATH}/
pod _1.2.0_ install --no-repo-update

#### 打包
echo ''
echo 'step 6:打包...'
echo "6-1:打印Podfile"
cat ${PODFILE_PATH}

echo "6-2:Archive"
BUILD_PARAMETER="${BUILD_PARAMETER} -u -name--${UPLOAD_NAME} -force--enterprise -xcpretty"
# jenkins描述 http://10.243.139.123/job/SuningEBuy-Framework-850/107/
BUILD_PARAMETER="${BUILD_PARAMETER} -jenkinsDesc--#${BUILD_NUMBER}"
JENKINS_URL="http://10.243.139.123/job/${JOB_NAME}/${BUILD_NUMBER}/"
BUILD_PARAMETER="${BUILD_PARAMETER} -jenkinsUrl--${JENKINS_URL}"
# armv7
if [[ "${ARMV7}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--armv7"
fi
# arm64
if [[ "${ARM64}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--arm64"
fi

if [[ "${SuningEMall}" = "true" ]]; then
	echo "6-2:打包命令:${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}"
	echo ""
	echo "building..."
	bash ${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}
else
	echo "6-2:打包命令:${PROJECT_PATH}/ipa-test.sh ${BUILD_PARAMETER}"
	echo ""	
	echo "building..."
	bash ${PROJECT_PATH}/ipa-test.sh ${BUILD_PARAMETER}
fi
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# CURRENT_BUILD_DIRECTORY
CURRENT_BUILD_DIRECTORY=$(ls -rt ${PROJECT_PATH}/build | tail -1)
CURRENT_BUILD_DIRECTORY="${PROJECT_PATH}/build/${CURRENT_BUILD_DIRECTORY}"
cd ${CURRENT_BUILD_DIRECTORY}

#### 生成归档文件，jenkins Copy Artifact Plugin
echo ""
echo "step 8:生成归档文件..."
# 列出build结果
echo "cmd: ls ${CURRENT_BUILD_DIRECTORY}"
ls ${CURRENT_BUILD_DIRECTORY}
# 拷贝dsynm文件到build-artifacts
BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
for XCARCHIVE_FILE_PATH in $(find ${CURRENT_BUILD_DIRECTORY} -name *.xcarchive -maxdepth 1)
do
	cd ${XCARCHIVE_FILE_PATH}/dSYMs
	for DSYM_FILE_NAME in $(ls)
	do
		if [[ ${DSYM_FILE_NAME} =~ ".dSYM" ]]; then
			echo ""
			echo "cmd: zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1"
			zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1
		fi
	done
done

