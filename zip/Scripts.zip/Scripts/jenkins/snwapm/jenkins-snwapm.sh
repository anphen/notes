#!/bin/bash
# jenkins-snwapm.sh

#### 用法，同时也是jenkins build参数
#### SuningEBuy-SNWAPM-930
# export JOB_NAME="SuningEBuy-SNWAPM-930"
# export build=true
# # 开始打包
# bash Scripts/jenkins/snwapm/jenkins-snwapm.sh

# 模拟jenkins参数检查
if [[ -z ${JOB_NAME} ]]; then
	echo "error: JOB_NAME not found"
	exit 1
fi

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi
export LANG=zh_CN.UTF-8
export PATH=/usr/local/bin:${PATH}

# 兼容研发云打包环境，优先使用/Applications/Xcode12.3.app打包
# 研发云同时装有多个xcode版本，默认的可能不是Xcode12.3
if [[ -e /Applications/Xcode12.3.app ]]; then
    export PATH=/Applications/Xcode12.3.app/Contents/Developer/usr/bin:$PATH
fi
# 检查Xcode版本号
RESULT_STRING=$(xcodebuild -version | head -1)
echo ""
echo "using xcode: ${RESULT_STRING}"
if [[ "${RESULT_STRING}" != "Xcode 12.3" ]]; then
    echo "error: 请使用指定的Xcode版本进行打包"
    exit 1
fi

#### 变量
echo ""
echo "step 1:更新主工程代码..."
# WORKSPACE默认值
# PROJECT_PATH,最终打包目录
if [ -z ${WORKSPACE} ]; then
	# JOB_NAME
	cd ${SCRIPT_DIR}/../../../../
	WORKSPACE=$(pwd)/${JOB_NAME}
	mkdir -p ${WORKSPACE}
	PROJECT_PATH="${WORKSPACE}"
else
	# 兼容研发云Delete workspace when build is done
	PROJECT_PATH=${HOME}/.suning/build/${JOB_NAME}
	mkdir -p ${PROJECT_PATH}
fi
cd ${PROJECT_PATH}

PROJECT_NAME="SuningEBuy"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_VERSION="830"
# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
	# jenkins打包 SuningEBuy-840
	GIT_BRANCH_VERSION=${JOB_NAME##*-}
elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
	# 研发云打包 ebuy_840
	GIT_BRANCH_VERSION=${JOB_NAME##*_}
fi
# 研发云流水线 origin/Dev_Br_850
if [[ "${GIT_BRANCH}" =~ "origin/" ]]; then
	GIT_BRANCH_VERSION=${GIT_BRANCH##*_}
fi
GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

SNWAPM_BRANCH_NAME="Ft_Br_SNWAPM_${GIT_BRANCH_VERSION}"

# 拉取代码
cd ${PROJECT_PATH}
if [ ! -d ${PROJECT_PATH}/.git ]; then
	${GIT} init
	${GIT} remote add origin ${GIT_URL}
	${GIT} fetch
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
if [[ "$(${GIT} status)" =~ "unmerged" ]]; then
	${GIT} reset --hard HEAD
fi
${GIT} checkout . 
# 删除Untracked files
${GIT} clean -fd
# 切换分支
${GIT} checkout ${GIT_BRANCH_NAME}
# 拉取代码
${GIT} pull

#### 打包前处理
echo ""
echo "step 2:打包前处理..."
# 清理归档文件...
echo "1) clean..."
bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-clean-helper.sh

#### 输入参数检查
echo ""
echo "step 3:参数..."
BUILD_PARAMETER=""
UPLOAD_NAME="官方自动化测试打包"

echo ""
echo "JENKINS_TYPE:      					${JENKINS_TYPE}"
echo "WORKSPACE:      					${WORKSPACE}"
echo "PROJECT_PATH: 						${PROJECT_PATH}"
echo "JOB_NAME:         					${JOB_NAME}"
echo "GIT_URL:          					${GIT_URL}"
echo "PROJECT_NAME:     					${PROJECT_NAME}"
echo "GIT_BRANCH_NAME:  					${GIT_BRANCH_NAME}"
echo "SNWAPM_BRANCH_NAME:  					${SNWAPM_BRANCH_NAME}"

echo ""
echo "buld参数"
echo "BUILD_PARAMETER:          				${BUILD_PARAMETER}"
echo "UPLOAD_NAME:      					${UPLOAD_NAME}"

# 数据格式
# SNLOGIN_PROJECT_INFO_ARRAY=(
#     "SUB_PROJECT_NAME"                  # 子工程文件夹名称
#     "SUB_PROJECT_GIT_URL"               # 子工程git库地址
#     "SUB_PROJECT_GIT_BRANCH_NAME"       # 子工程git分支名称
#     "SUB_PROJECT_PATH"                  # 子工程clone本地地址
#     "SUB_PROJECT_SNWAPM_BRANCH_NAME"    # SNWAPM分支名称
# )
# 主工程
SNMAIN_PROJECT_INFO_ARRAY=(
    "SNMain"
    "http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_PATH}"
    "${SNWAPM_BRANCH_NAME}"
)
# SNCommon
SNCOMMON_PROJECT_INFO_ARRAY=(
    "SNCommon"
    "http://git.cnsuning.com/suningebuy/SNCommon.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_PATH}/SNProjects/SNCommon"
    "${SNWAPM_BRANCH_NAME}"
)
#首页
SNHOMEPAGE_PROJECT_INFO_ARRAY=(
    "SNHomePage"
    "http://git.cnsuning.com/snioshomepage/snioshomepage.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_PATH}/SNProjects/SNHomePage"
    "${SNWAPM_BRANCH_NAME}"
)

# ALL_SUB_PROJECT_INFO_ARRAY
ALL_SUB_PROJECT_INFO_ARRAY=(
    SNMAIN_PROJECT_INFO_ARRAY
    SNCOMMON_PROJECT_INFO_ARRAY
    SNHOMEPAGE_PROJECT_INFO_ARRAY
)

#### pull代码
echo ""
echo "step 4:pull code..."
# updateAllCode
echo ""
echo "4-1:updateAllCode.sh..."
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/updateAllCode.sh -checkupdate -revert--subproject
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# repo-update.sh
echo ""
echo "4-2:repo-update.sh..."
bash ${PROJECT_PATH}/repo-update.sh -checkupdate -skip--pod -check--branch -revert--subproject
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# 切换SNWAPM相关分支
echo ""
echo "4-3:切换SNWAPM相关分支,并合并dev代码..."
for SUB_PROJECT_INFO_ARRAY in ${ALL_SUB_PROJECT_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
    eval SUB_PROJECT_NAME=\${${SUB_PROJECT_INFO_ARRAY}[0]}
    eval SUB_PROJECT_GIT_URL=\${${SUB_PROJECT_INFO_ARRAY}[1]}
    eval SUB_PROJECT_GIT_BRANCH_NAME=\${${SUB_PROJECT_INFO_ARRAY}[2]}
    eval SUB_PROJECT_PATH=\${${SUB_PROJECT_INFO_ARRAY}[3]}
    eval SUB_PROJECT_SNWAPM_BRANCH_NAME=\${${SUB_PROJECT_INFO_ARRAY}[4]}

    echo ""
    echo "${SUB_PROJECT_NAME}..."
    # pull
    cd ${SUB_PROJECT_PATH}
    echo "cmd: ${GIT} checkout ${SUB_PROJECT_SNWAPM_BRANCH_NAME}"
    ${GIT} checkout ${SUB_PROJECT_SNWAPM_BRANCH_NAME}
    # 命令执行失败,异常退出
	if [[ ! $? -eq 0 ]]; then
		echo "error:切换SNWAPM分支失败，请先创建${SUB_PROJECT_SNWAPM_BRANCH_NAME}分支"
		echo ${RESULT_STRING}
	    exit 1
	fi
    echo "cmd: ${GIT} pull"
    ${GIT} pull
    # 合并dev分支代码,并push
    echo "cmd: ${GIT} merge origin/${SUB_PROJECT_GIT_BRANCH_NAME}"
    RESULT_STRING=$(${GIT} merge origin/${SUB_PROJECT_GIT_BRANCH_NAME})
    # 命令执行失败,异常退出
	if [[ ! $? -eq 0 ]]; then
		echo "error:merge失败,请手动处理后再次执行"
		echo "主工程、SNCommon、SNHomePage这3个工程需要merge,方便起见,一起先手动合并下吧"
		echo ${RESULT_STRING}
	    exit 1
	fi
    if [ "${RESULT_STRING}" != "Already up to date." ];then
        echo "cmd: ${GIT} push"
        ${GIT} push
    fi
done

# SNWAPM
echo ""
echo "4-4:更新SNPods/SNWAPM代码..."
if [[ -d ${PROJECT_PATH}/SNPods/SNWAPM ]]; then
	cd ${PROJECT_PATH}/SNPods/SNWAPM
	git checkout dev
	git pull
else
	cd ${PROJECT_PATH}/SNPods
	git clone http://opensource.cnsuning.com/suningebuy/snwapm.git SNWAPM
	cd SNWAPM
	git checkout dev
fi

#### pod集成
echo ''
echo 'step 5:pod集成...'
# 修改Podfile
echo "5-1:修改Podfile..."
PODFILE_PATH=${PROJECT_PATH}/Podfile
# 清空之前pod生成文件
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace


echo ''
echo '5-2:repo-update.sh...'
# repo-update
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/repo-update.sh -pod
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### 修改打包配置
# ENABLE_NS_ASSERTIONS
echo ''
echo 'step 6:修改打包配置...'
echo "6-1:ENABLE_NS_ASSERTIONS..."
cd ${PROJECT_PATH}
for PROJECT_PBXPROJ_PATH in $(find ${PROJECT_PATH} -name project.pbxproj -maxdepth 5); 
do
	echo ""
	echo "${PROJECT_PBXPROJ_PATH}"
	sed -i '' $"/buildSettings = {/a\\
	ENABLE_NS_ASSERTIONS = NO;
	" ${PROJECT_PBXPROJ_PATH}
	sed -i '' "s/ENABLE_NS_ASSERTIONS =.*/ENABLE_NS_ASSERTIONS = NO;/" ${PROJECT_PBXPROJ_PATH}
	# 打印
	cat ${PROJECT_PBXPROJ_PATH} | grep "ENABLE_NS_ASSERTIONS"
done

# dwarf-with-dsym
echo ""
echo "6-2:dwarf-with-dsym..."
cd ${PROJECT_PATH}
for PROJECT_PBXPROJ_PATH in $(find ${PROJECT_PATH} -name project.pbxproj -maxdepth 5); do
	sed -i '' $"/buildSettings = {/a\\
	DEBUG_INFORMATION_FORMAT = \"dwarf-with-dsym\";
	" ${PROJECT_PBXPROJ_PATH}
	sed -i '' "s/DEBUG_INFORMATION_FORMAT =.*/DEBUG_INFORMATION_FORMAT = \"dwarf-with-dsym\";/" ${PROJECT_PBXPROJ_PATH}
	# 打印
	cat ${PROJECT_PBXPROJ_PATH} | grep "DEBUG_INFORMATION_FORMAT"
done

# # Archive改为debug
# XCSCHEME_FILE_PATH="${PROJECT_PATH}/SuningEBuy.xcodeproj/xcshareddata/xcschemes/SuningEBuy.xcscheme"
# sed -i '' "s/buildConfiguration = \"Release\"/buildConfiguration = \"Debug\"/" ${XCSCHEME_FILE_PATH}
# SNCommonToast.m 

echo ""
echo "6-3:修改SNCommonToast.m..."
POD_PATH=$(cat ${PODFILE_PATH} | grep -v '#' | grep "SNFOUNDATION_PATH =" | head -1)
POD_PATH=${POD_PATH#*=}
POD_PATH=${POD_PATH// /}
POD_PATH=${POD_PATH//+/}
POD_PATH=${POD_PATH//\'/}
POD_PATH=${POD_PATH//\$POD_SPEC_PATH/${HOME}\/.cocoapods\/repos\/SNEBuy_repos\/}
TOAST_CLASS_PATH="${POD_PATH}/SNFoundation/SNCommonCtrls/SNCommonToast/SNCommonToast.m"
TOAST_CLASS_MD5="655acd87a4d108acb12b67c28f10af85"
if [[ "$(md5 ${TOAST_CLASS_PATH})" =~ "${TOAST_CLASS_MD5}" ]]; then
	sed -i '' "10a\\
	#import <SNWAPM/SNWAPMWdaTool.h> \\
	" ${TOAST_CLASS_PATH}
	sed -i '' "104a\\
	\\
	\ \ \ \ // 放到方法最后 \\
	\ \ \ \ // 自动化测试toast \\
	\ \ \ \ [[SNWAPMWdaTool sharedInstance] sendToastMessageWithText:self.toastView.toastLabel.text andTag:nil]; \\
	" ${TOAST_CLASS_PATH}
	# 打印
	cat ${TOAST_CLASS_PATH} | grep "SNWAPM"
else
	echo ""
	echo "error: SNCommonToast.m file changed"
	md5 ${TOAST_CLASS_PATH}
	exit 1
fi

#### 检查修改
echo ''
echo 'step 7:检查snwapm打包所有修改...'
export GIT_BRANCH_NAME="${GIT_BRANCH_NAME}"
export SNWAPM_BRANCH_NAME="${SNWAPM_BRANCH_NAME}"
bash ${PROJECT_PATH}/Scripts/jenkins/snwapm/jenkins-snwapm-helper.sh
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### 打包
echo ''
echo 'step 8:打包...'
echo "8-1:打印Podfile"
cat ${PODFILE_PATH}

echo "8-2:build..."
XCODE_WORKSPACE="SuningEBuy.xcworkspace"
PROJECT_SCHEME="SuningEBuy"
XCODE_BUILD="xcodebuild -workspace ${XCODE_WORKSPACE} -scheme ${PROJECT_SCHEME} -configuration Debug"
XCODE_EXPORT="xcodebuild -exportArchive -exportOptionsPlist ./exportOptions.plist"

# clean
cd ${PROJECT_PATH}/
echo "clean..."
${XCODE_BUILD} clean

# build目录
mkdir -p build
rm -rf build/*

# archive
echo ""
echo "archive..."
if command -v xcpretty > /dev/null; then
	${XCODE_BUILD} archive -archivePath build/${PROJECT_SCHEME}.xcarchive | xcpretty
else
	${XCODE_BUILD} archive -archivePath build/${PROJECT_SCHEME}.xcarchive
fi

# export
echo ""
echo "export..."
${XCODE_EXPORT} -archivePath build/${PROJECT_SCHEME}.xcarchive -exportPath build/

# clean，解决DerivedData文件夹一直占用空间的问题
echo ""
echo "clean..."
${XCODE_BUILD} clean

# CURRENT_BUILD_DIRECTORY
CURRENT_BUILD_DIRECTORY=${PROJECT_PATH}/build
cd ${CURRENT_BUILD_DIRECTORY}

#### 生成归档文件，jenkins Copy Artifact Plugin
echo ''
echo 'step 9:生成归档文件...'
# 列出build结果
echo "cmd: ls ${CURRENT_BUILD_DIRECTORY}"
ls ${CURRENT_BUILD_DIRECTORY}
# 归档文件到build-artifacts
BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
# ipa
echo ""
echo "cmd: mv ${CURRENT_BUILD_DIRECTORY}/*.ipa ${BUILD_ARTIFACTS_PATH}/"
mv ${CURRENT_BUILD_DIRECTORY}/*.ipa ${BUILD_ARTIFACTS_PATH}/
# dsym
for XCARCHIVE_FILE_PATH in $(find ${CURRENT_BUILD_DIRECTORY} -name *.xcarchive -maxdepth 1); do
	cd ${XCARCHIVE_FILE_PATH}/dSYMs
	for DSYM_FILE_NAME in $(ls)
	do
		if [[ ${DSYM_FILE_NAME} =~ ".dSYM" ]]; then
			echo ""
			echo "cmd: zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1"
			zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1
		fi
	done
done
# 兼容研发云Delete workspace when build is done
if [[ -d ${WORKSPACE}/build-artifacts ]] && [[ ! -L ${WORKSPACE}/build-artifacts ]]; then
    rm -rf ${WORKSPACE}/build-artifacts
fi
ln -fs ${BUILD_ARTIFACTS_PATH} ${WORKSPACE}/

