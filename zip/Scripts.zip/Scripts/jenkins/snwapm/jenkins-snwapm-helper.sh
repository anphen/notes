# #!/bin/bash
# jenkins-snwapm-helper.sh

# 使用
# export GIT_BRANCH_NAME="Dev_Br_930"
# export SNWAPM_BRANCH_NAME="Ft_Br_SNWAPM_930"
# bash Scripts/jenkins/snwapm/jenkins-snwapm-helper.sh

# 使用参数检查
if [[ -z ${GIT_BRANCH_NAME} ]]; then
	echo "error: GIT_BRANCH_NAME not found"
	exit 1
fi
if [[ -z ${SNWAPM_BRANCH_NAME} ]]; then
	echo "error: SNWAPM_BRANCH_NAME not found"
	exit 1
fi

# 基本变量
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"
PROJECT_PATH="$(cd ${SCRIPT_DIR}/../../../;pwd)"
cd ${PROJECT_PATH}

GIT="git"

if [[ -z ${GIT_BRANCH_NAME} ]]; then
	echo "need environment variables GIT_BRANCH_NAME、SNWAPM_BRANCH_NAME"
	exit 1
fi
# 主工程
SNMAIN_PROJECT_INFO_ARRAY=(
    "SNMain"
    "http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_PATH}"
    "${SNWAPM_BRANCH_NAME}"
)
# 主工程
SNCOMMON_PROJECT_INFO_ARRAY=(
    "SNCommon"
    "http://git.cnsuning.com/suningebuy/SNCommon.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_PATH}/SNProjects/SNCommon"
    "${SNWAPM_BRANCH_NAME}"
)
#首页
SNHOMEPAGE_PROJECT_INFO_ARRAY=(
    "SNHomePage"
    "http://git.cnsuning.com/snioshomepage/snioshomepage.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_PATH}/SNProjects/SNHomePage"
    "${SNWAPM_BRANCH_NAME}"
)

# ALL_CHECK_PROJECT_INFO_ARRAY
ALL_CHECK_PROJECT_INFO_ARRAY=(
    SNMAIN_PROJECT_INFO_ARRAY
    SNCOMMON_PROJECT_INFO_ARRAY
    SNHOMEPAGE_PROJECT_INFO_ARRAY
)

ERROR_COUNT=0
PROJECT_ERROR_COUNT=0
FILE_ERROR_COUNT=0
LINE_ERROR_COUNT=0
PODFILE_ERROR_COUNT=0

OLD_IFS=${IFS}
IFS='
'

#### 方法
#### 通用
function print_LINE_KNOWN_CHANGED_ARRAY() {
	# LINE_KNOWN_CHANGED_ARRAY=(
	# 	"-\$using_code_snsearch = false"
	# )
	echo "LINE_KNOWN_CHANGED_ARRAY=("
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		if [[ "${CHANGED_LINE}" =~ "_VERSION =" ]]; then
			# 版本号经常修改，只要修改版本号合并代码就报冲突，需要手动处理
			# 修改1个或者2个版本号的时候，区分版本号就比较麻烦
			# 而且发布的时候版本号也好测试，这儿就不比较版本号了
			continue
		fi

		# $替换为\$
		CHANGED_LINE=${CHANGED_LINE//\$/\\\$}
		# "替换为\"
		CHANGED_LINE=${CHANGED_LINE//\"/\\\"}
		# 打印
		echo "	\"${CHANGED_LINE}\""
	done
	echo ")"
}

#### 检查工程
#### f_check_project
# 有修改的工程
# 1.SNEBuy_repos
function f_check_project_SNEBuy_repos() {
	GIT_PATH=$1
	# echo "function:f_check_project_SNCommon"
	# echo "GIT_PATH:${GIT_PATH}"

	# 检查修改
	# 检查需要的文件修改操作
	# SNEBuy_repos修改了SNCommonToast.m文件
	cd ${GIT_PATH}
	if [[ "$(${GIT} status | grep "modified" | grep "SNFoundation/SNCommonCtrls/SNCommonToast/SNCommonToast.m")" = "" ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: SNCommonToast.m没修改"
	fi
	# 检查不需要的文件修改操作
	for MODIFIED_FILE in $(${GIT} status | grep "modified")
	do
		if [[ "${MODIFIED_FILE}" =~ "SNCommonToast.m" ]]; then
			continue
		fi
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 不需要的文件修改操作 ${MODIFIED_FILE}"
	done
	# 检查不需要的文件新增操作
	for NEW_FILE in $(${GIT} status | grep "new file")
	do
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 不需要的文件新增操作 ${NEW_FILE}"
	done
	# 检查不需要的文件删除操作
	for DELETED_FILE in $(${GIT} status | grep "deleted")
	do
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 不需要的文件删除操作 ${DELETED_FILE}"
	done
	# 检查Untracked files
	if [[ "$(${GIT} status | grep "Untracked files")" != "" ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 存在不需要的Untracked files文件"
		echo "详细"
		${GIT} status
	fi
}

# 检查其他工程
function f_check_project_other() {
	GIT_PATH=$1
	# echo "function:f_check_project_other"
	# echo "GIT_PATH:${GIT_PATH}"

	# 检查修改
	cd ${GIT_PATH}
	# 检查不需要的文件修改操作
	for MODIFIED_FILE in $(${GIT} status | grep "modified")
	do
		# 忽略project.pbxproj修改，后面再次检查
		# 1.ENABLE_NS_ASSERTIONS
		# 2.dwarf-with-dsym
		if [[ "${MODIFIED_FILE}" =~ "project.pbxproj" ]]; then
			continue
		fi
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 不需要的文件修改操作 ${MODIFIED_FILE}"
	done
	# 检查不需要的文件新增操作
	for NEW_FILE in $(${GIT} status | grep "new file")
	do
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 不需要的文件新增操作 ${NEW_FILE}"
	done
	# 检查不需要的文件删除操作
	for DELETED_FILE in $(${GIT} status | grep "deleted")
	do
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 不需要的文件删除操作 ${DELETED_FILE}"
	done
	# 检查Untracked files
	if [[ "$(${GIT} status | grep "Untracked files")" != "" ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 存在不需要的Untracked files文件"
		echo "详细"
		${GIT} status
	fi
}

#### 检查工程下文件
#### f_check_files_SNMain
# Podfile
function f_check_files_SNMain_Podfile() {
	CHANGED_LINE_ARRAY=$1
	# echo "function:f_check_files_SNMain_Podfile"
	# echo "CHANGED_LINE_ARRAY:${CHANGED_LINE_ARRAY}"

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-\$using_code_snsearch = false"
		"-\$using_code_snproduct = false"
		"-\$using_code_snpingou = false"
		"-\$using_code_snpm = false"
		"-\$using_code_snlogin = false"
		"-\$using_code_snmember = false"
		"-\$using_code_snsl = false"
		"-\$using_code_snlive = false"
		"-\$using_code_snmk = false"
		"-#\$using_code_snmptm = false"
		"-\$using_code_snhwg = false"
		"-\$using_code_snchannel = false"
		"-\$using_code_snsm = false"
		"-\$using_code_snhome = false"
		"-\$using_code_snxdcc = false"
		"-\$using_code_snpw = false"
		"+\$using_code_snsearch = true"
		"+\$using_code_snproduct = true"
		"+\$using_code_snpingou = true"
		"+\$using_code_snpm = true"
		"+\$using_code_snlogin = true"
		"+\$using_code_snmember = true"
		"+\$using_code_snsl = true"
		"+\$using_code_snlive = true"
		"+\$using_code_snmk = true"
		"+#\$using_code_snmptm = true"
		"+\$using_code_snhwg = true"
		"+\$using_code_snchannel = true"
		"+\$using_code_snsm = true"
		"+\$using_code_snhome = true"
		"+\$using_code_snxdcc = true"
		"+\$using_code_snpw = true"
		"+        pod 'SNWAPM',                           :path => 'SNPods/SNWAPM'"
		"+        "
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# PushService.entitlements
function f_check_files_SNMain_PushService_Info_plist() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-    <string>SuningEMall.PushService</string>"
		"+    <string>\$(PRODUCT_BUNDLE_IDENTIFIER)</string>"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SuningEBuy.xcodeproj/project.pbxproj
function f_check_files_SNMain_SuningEBuy_xcodeproj() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-                        DevelopmentTeam = 76M3JYH4P2;"
		"+                        DevelopmentTeam = J7F2VA5FRW;"
		"-                        DevelopmentTeam = 76M3JYH4P2;"
		"+                        DevelopmentTeam = J7F2VA5FRW;"
		"-                        DevelopmentTeam = 76M3JYH4P2;"
		"+                        DevelopmentTeam = J7F2VA5FRW;"
		"-                DEVELOPMENT_TEAM = 76M3JYH4P2;"
		"+                DEVELOPMENT_TEAM = J7F2VA5FRW;"
		"-                PRODUCT_BUNDLE_IDENTIFIER = SuningEMall;"
		"+                PRODUCT_BUNDLE_IDENTIFIER = com.suning.SuningEMall;"
		"-                PROVISIONING_PROFILE_SPECIFIER = DevProfile;"
		"+                PROVISIONING_PROFILE_SPECIFIER = testwa20210318;"
		"-                CODE_SIGN_IDENTITY = \"iPhone Distribution\";"
		"-                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Distribution\";"
		"+                CODE_SIGN_IDENTITY = \"iPhone Developer\";"
		"+                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Developer\";"
		"-                DEVELOPMENT_TEAM = 5E2PGY2377;"
		"+                DEVELOPMENT_TEAM = J7F2VA5FRW;"
		"-                PRODUCT_BUNDLE_IDENTIFIER = SuningEMall;"
		"+                PRODUCT_BUNDLE_IDENTIFIER = com.suning.SuningEMall;"
		"-                PROVISIONING_PROFILE_SPECIFIER = SuningEnterprise;"
		"+                PROVISIONING_PROFILE_SPECIFIER = testwa20210318;"
		"-                DEVELOPMENT_TEAM = 76M3JYH4P2;"
		"+                DEVELOPMENT_TEAM = J7F2VA5FRW;"
		"-                PRODUCT_BUNDLE_IDENTIFIER = SuningEMall.TodayWidget;"
		"+                PRODUCT_BUNDLE_IDENTIFIER = com.suning.SuningEMall.TodayWidget;"
		"-                PROVISIONING_PROFILE_SPECIFIER = DevProfile;"
		"+                PROVISIONING_PROFILE_SPECIFIER = testwa20210318;"
		"-                CODE_SIGN_IDENTITY = \"iPhone Distribution\";"
		"-                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Distribution\";"
		"+                CODE_SIGN_IDENTITY = \"iPhone Developer\";"
		"+                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Developer\";"
		"-                DEVELOPMENT_TEAM = 5E2PGY2377;"
		"+                DEVELOPMENT_TEAM = J7F2VA5FRW;"
		"-                PRODUCT_BUNDLE_IDENTIFIER = SuningEMall.TodayWidget;"
		"+                PRODUCT_BUNDLE_IDENTIFIER = com.suning.SuningEMall.TodayWidget;"
		"-                PROVISIONING_PROFILE_SPECIFIER = SuningEnterprise;"
		"+                PROVISIONING_PROFILE_SPECIFIER = testwa20210318;"
		"-                DEVELOPMENT_TEAM = 76M3JYH4P2;"
		"+                DEVELOPMENT_TEAM = J7F2VA5FRW;"
		"-                PRODUCT_BUNDLE_IDENTIFIER = SuningEMall.PushService;"
		"+                PRODUCT_BUNDLE_IDENTIFIER = com.suning.SuningEMall.PushService;"
		"-                PROVISIONING_PROFILE_SPECIFIER = DevProfile;"
		"+                PROVISIONING_PROFILE_SPECIFIER = testwa20210318;"
		"-                CODE_SIGN_IDENTITY = \"iPhone Distribution\";"
		"-                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Distribution\";"
		"+                CODE_SIGN_IDENTITY = \"iPhone Developer\";"
		"+                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Developer\";"
		"-                DEVELOPMENT_TEAM = 5E2PGY2377;"
		"+                DEVELOPMENT_TEAM = J7F2VA5FRW;"
		"-                PRODUCT_BUNDLE_IDENTIFIER = SuningEMall.PushService;"
		"+                PRODUCT_BUNDLE_IDENTIFIER = com.suning.SuningEMall.PushService;"
		"-                PROVISIONING_PROFILE_SPECIFIER = SuningEnterprise;"
		"+                PROVISIONING_PROFILE_SPECIFIER = testwa20210318;"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}"
		CHANGED_LINE_RESULT=0
		if [[ "${CHANGED_LINE}" =~ "_VERSION =" ]]; then
			# 版本号经常修改，只要修改版本号合并代码就报冲突，需要手动处理
			# 修改1个或者2个版本号的时候，区分版本号就比较麻烦
			# 而且发布的时候版本号也好测试，这儿就不比较版本号了
			continue

			# # appstore分支会修改自己的版本号，所以版本号修改不比对版本号变化
			# # 操作是将KNOWN_LINE中的版本号替换为CHANGED_LINE中的版本号

			# # CHANGED_LINE
			# # 替换空格为空字符串
			# CHANGED_LINE2=${CHANGED_LINE// /}
			# # CHANGED_LINE_VERSION
			# CHANGED_LINE_VERSION=${CHANGED_LINE2#*=}
			# CHANGED_LINE_VERSION=${CHANGED_LINE_VERSION%;*}

			# # KNOWN_LINE
			# KNOWN_LINE=${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}
			# KNOWN_LINE=${KNOWN_LINE%=*}
			# KNOWN_LINE="${KNOWN_LINE} = ${CHANGED_LINE_VERSION};"
			# # 替换空格为空字符串
			# KNOWN_LINE=${KNOWN_LINE// /}

			# if [[ "${CHANGED_LINE2}" = "${KNOWN_LINE}" ]]; then
			# 	CHANGED_LINE_RESULT=1
			# fi
		elif [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			CHANGED_LINE_RESULT=1
		fi
		if [[ ${CHANGED_LINE_RESULT} -eq 1 ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SuningEBuy/AppDelegate/AppDelegate.m
function f_check_files_SNMain_AppDelegate_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+#import <SNWAPM/SNWAPMDataManager.h>"
		"+"
		"+    // 启动sdk"
		"+    [[SNWAPMDataManager sharedInstance] startSNWAPMMonitor];"
		"+    "
        "+    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@\"agreePrivacyStatement\"];"
        "+    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@\"hasShowPermissionSetting\"];"
        "+    "
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SuningEBuy/Info.plist
function f_check_files_SNMain_SuningEBuy_Info_plist() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-    <string>SuningEMall</string>"
		"+    <string>\$(PRODUCT_BUNDLE_IDENTIFIER)</string>"
		"-    <key>NSLocationAlwaysUsageDescription</key>"
		"-    <string>苏宁易购需要获取您的 “位置” 权限，查看周边服务、获取最新的商品库存信息、推送本地专属商品和优惠信息。</string>"
		"-    <key>NSLocationUsageDescription</key>"
		"-    <string>苏宁易购需要获取您的 “位置” 权限，查看周边服务、获取最新的商品库存信息、推送本地专属商品和优惠信息。</string>"
		"-    <key>NSLocationWhenInUseUsageDescription</key>"
		"-    <string>苏宁易购需要获取您的 “位置” 权限，查看周边服务、获取最新的商品库存信息、推送本地专属商品和优惠信息。</string>"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# TodayWidget/Info.plist
function f_check_files_SNMain_TodayWidget_Info_plist() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-    <string>SuningEMall.TodayWidget</string>"
		"+    <string>\$(PRODUCT_BUNDLE_IDENTIFIER)</string>"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# exportOptions.plist
function f_check_files_SNMain_exportOptions_plist() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-    <string>enterprise</string>"
		"+    <string>development</string>"
		"-        <key>SuningEMall</key>"
		"-        <string>ebad1e74-19d9-49a3-b47c-6fa46b6d3efa</string>"
		"-        <key>SuningEMall.PushService</key>"
		"-        <string>ebad1e74-19d9-49a3-b47c-6fa46b6d3efa</string>"
		"-        <key>SuningEMall.TodayWidget</key>"
		"-        <string>ebad1e74-19d9-49a3-b47c-6fa46b6d3efa</string>"
		"+        <key>com.suning.SuningEMall</key>"
		"+        <string>testwa20210318</string>"
		"+        <key>com.suning.SuningEMall.PushService</key>"
		"+        <string>testwa20210318</string>"
		"+        <key>com.suning.SuningEMall.TodayWidget</key>"
		"+        <string>testwa20210318</string>"
		"-    <string>011EBD34F82EE293AF72D5AFA739092C0932433A</string>"
		"+    <string>iPhone Developer</string>"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

function f_check_files_SNMain() {
	SUB_PROJECT_GIT_BRANCH_NAME=$1
	SUB_PROJECT_SNWAPM_BRANCH_NAME=$2
	# echo "function:f_check_files_SNMain"
	# echo "SUB_PROJECT_GIT_BRANCH_NAME:${SUB_PROJECT_GIT_BRANCH_NAME}"
	# echo "SUB_PROJECT_SNWAPM_BRANCH_NAME:${SUB_PROJECT_SNWAPM_BRANCH_NAME}"

	FILE_ERROR_COUNT=0
	for CHANGED_FILE in $(${GIT} diff origin/${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME} --name-only)
	do
		echo ""
		# check file:   Podfile
		echo "#### check file:  ${CHANGED_FILE}..."
		KNOWN_CHANGED_FILE=""
		if [[ "${CHANGED_FILE}" =~ "Podfile" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "PushService/Info.plist" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SuningEBuy.xcodeproj/project.pbxproj" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SuningEBuy/AppDelegate/AppDelegate.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SuningEBuy/Info.plist" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "TodayWidget/Info.plist" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "exportOptions.plist" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		# 其他文件修改
		if [[ "${KNOWN_CHANGED_FILE}" = "" ]]; then
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			FILE_ERROR_COUNT=$((${FILE_ERROR_COUNT}+1))
			# 打印错误
			echo "error ${ERROR_COUNT}: 不需要的文件修改操作 ${KNOWN_CHANGED_FILE}"
		else
			CHANGED_LINE_ARRAY=$(${GIT} diff origin/${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME} ${KNOWN_CHANGED_FILE})
			CHANGED_LINE_ARRAY2=()
			for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
			do
				# --- a/Podfile
				if [[ "${CHANGED_LINE}" =~ "--- a" ]]; then
					continue
				fi
				# +++ b/Podfile
				if [[ "${CHANGED_LINE}" =~ "+++ b" ]]; then
					continue
				fi
				LINE_FIRST_CHARACTER=${CHANGED_LINE:0:1}
				if [[ "${LINE_FIRST_CHARACTER}" != "-" && "${LINE_FIRST_CHARACTER}" != "+" ]]; then
					continue
				fi
				# 终端上输出tab，拷贝到sublime是tab，拷贝到xcode里是4个空格
				# 这儿统一将tab替换为4个空格，兼容sublime和xcode
				CHANGED_LINE=${CHANGED_LINE//	/    }
				CHANGED_LINE_ARRAY2=(${CHANGED_LINE_ARRAY2[*]} "${CHANGED_LINE}")
			done
			CHANGED_LINE_ARRAY="${CHANGED_LINE_ARRAY2[*]}"

			LINE_ERROR_COUNT=0
			if [[ "${KNOWN_CHANGED_FILE}" = "Podfile" ]]; then
				f_check_files_SNMain_Podfile "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" = "PushService/Info.plist" ]]; then
				f_check_files_SNMain_PushService_Info_plist "${CHANGED_LINE_ARRAY[*]}"	
			fi
			if [[ "${KNOWN_CHANGED_FILE}" = "SuningEBuy.xcodeproj/project.pbxproj" ]]; then
				f_check_files_SNMain_SuningEBuy_xcodeproj  "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" = "SuningEBuy/AppDelegate/AppDelegate.m" ]]; then
				f_check_files_SNMain_AppDelegate_m  "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" = "SuningEBuy/Info.plist" ]]; then
				f_check_files_SNMain_SuningEBuy_Info_plist  "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" = "TodayWidget/Info.plist" ]]; then
				f_check_files_SNMain_TodayWidget_Info_plist  "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" = "exportOptions.plist" ]]; then
				f_check_files_SNMain_exportOptions_plist  "${CHANGED_LINE_ARRAY[*]}"
			fi
			# 打印单个project结果
			if [[ ${LINE_ERROR_COUNT} -eq 0 ]]; then
				echo "total: pass"
			else
				echo "total: fail"
				echo "changed:"
				print_LINE_KNOWN_CHANGED_ARRAY "${CHANGED_LINE_ARRAY[*]}"
			fi
		fi
	done
}

#### f_check_files_SNCommon
# SNBSPrivacyStatementManager.m
function f_check_files_SNCommon_SNBSPrivacyStatementManager_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+    // snwapm打包 不显示隐私声明页面"
		"+    return NO;"
		"+    "
		"+    // snwapm打包 不显示隐私声明页面"
		"+    return YES;"
		"+    "
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"	
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SNBSHomeManager.m
function f_check_files_SNCommon_SNBSHomeManager_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+#import <SSA_IOS/SSAIOSSNDataCollection.h>"
		"+"
		"-    "
		"+    return;"
		"-        if (snSwitch && [snSwitch isHttpDnsOpen]) {"
		"-            [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:YES];"
		"-        }"
		"-        else{"
		"-            [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:NO];"
		"-        }"
		"+//        if (snSwitch && [snSwitch isHttpDnsOpen]) {"
		"+//            [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:YES];"
		"+//        }"
		"+//        else{"
		"+//            [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:NO];"
		"+//        }"
		"+        [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:YES];"
		"+                        [SSAIOSSNDataCollection setHttpsSwitch:kSwitchHttp];"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SNAppLauncher.m
function f_check_files_SNCommon_SNAppLauncher_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+    "
		"+    // 写在方法底部"
		"+    // 小程序冷热启动"
		"+//    NSString *tmpString = @\"http://m.suning.com?adTypeCode=100013&adId=http%3a%2f%2fsnmpsprexg.cnsuning.com%2fsnmps-web%2fprogram%2fget_ecf460c427b94274a41d803bced0c851_%7bcurrVersion%7d_0_%7bclientVersion%7d.htm\";"
		"+//    NSMutableDictionary *dictionary = [NSMutableDictionary dictionary];"
		"+//    [dictionary setValue:[NSURL URLWithString:tmpString] forKey:UIApplicationLaunchOptionsURLKey];"
		"+//    launchOptions = dictionary;"
		"+ "
		"+    NSURL *url = [launchOptions objectForKey:UIApplicationLaunchOptionsURLKey];"
		"+    NSDictionary *queryDict = [[url query] queryDictionaryUsingEncoding:NSUTF8StringEncoding];"
		"+    if ([[queryDict objectForKey:@\"adTypeCode\"] isEqualToString:@\"100013\"]) {"
		"+//        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@\"snminip-title\" message:@\"100013\" delegate:nil cancelButtonTitle:@\"确定\" otherButtonTitles:nil];"
		"+//        [alertView show];"
		"+        [[NSUserDefaults standardUserDefaults] setValue:@\"cold\" forKey:@\"routeToSNMINIPPage\"];"
		"+    } else {"
		"+        [[NSUserDefaults standardUserDefaults] setValue:nil forKey:@\"routeToSNMINIPPage\"];"
		"+    }"
		"+     "
		"+    [[NSUserDefaults standardUserDefaults] synchronize];"
		"+    return;"
		"+    "
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"		
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SNBaseServiceManager.m
function f_check_files_SNCommon_SNBaseServiceManager_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-        if (snSwitch && [snSwitch isHttpDnsOpen]) {"
		"-            [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:YES];"
		"-        } else{"
		"-            [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:NO];"
		"-        }"
		"+//        if (snSwitch && [snSwitch isHttpDnsOpen]) {"
		"+//            [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:YES];"
		"+//        } else{"
		"+//            [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:NO];"
		"+//        }"
		"+        [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:YES];"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"	
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SNMINIPSDKApi.m
function f_check_files_SNCommon_SNMINIPSDKApi_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+#import <SNWAPM/SNWAPMDataManager.h>"
		"+#import <React/RCTRootView.h>"
		"+"
		"+- (id)init {"
		"+    if (self = [super init]) {"
		"+        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(rctContentDidAppear) name:RCTContentDidAppearNotification object:nil];"
		"+    }"
		"+    return self;"
		"+}"
		"+ "
		"+- (void)rctContentDidAppear {"
		"+    NSString *string = [[NSUserDefaults standardUserDefaults] valueForKey:@\"routeToSNMINIPPage\"];"
		"+    if ([string isEqualToString:@\"cold\"]) {"
		"+        [[SNWAPMDataManager sharedInstance] setMiniInitEndPoint];"
		"+        //        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@\"snminip-title\" message:@\"cold end\" delegate:nil cancelButtonTitle:@\"确定\" otherButtonTitles:nil];"
		"+        //        [alertView show];"
		"+    } else {"
		"+        [[SNWAPMDataManager sharedInstance] setMiniWarmEndPoint];"
		"+        //        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@\"snminip-title\" message:@\"warm end\" delegate:nil cancelButtonTitle:@\"确定\" otherButtonTitles:nil];"
		"+        //        [alertView show];"
		"+    }"
		"+ "
		"+    [[NSUserDefaults standardUserDefaults] setValue:nil forKey:@\"routeToSNMINIPPage\"];"
		"+    [[NSUserDefaults standardUserDefaults] synchronize];"
		"+ "
		"+    // 打印小程序完成日志"
		"+    NSLog([NSString stringWithFormat:@\"MiniProgramEndTime：%.0f\", [[NSDate date] timeIntervalSince1970]*1000], nil);"
		"+}"
		"+"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SNInfomationClick.m
function f_check_files_SNCommon_SNInfomationClick_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+    [SSAIOSSNDataCollection setHttpsSwitch:kSwitchHttp];"
		"-            [CTIOSSNDataCollection SetAppKey:@\"e220c7a823e54f6aada37d97465475d3\"];"
		"+            [CTIOSSNDataCollection SetAppKey:@\"360d0a504d394290b2a39149384972b4\"];"
		"-            [CTIOSSNDataCollection SetAppKey:@\"dd7138d352d04f67848e5cf2aada6c44\"];"
		"+            [CTIOSSNDataCollection SetAppKey:@\"360d0a504d394290b2a39149384972b4\"];"
		"-            [CTIOSSNDataCollection SetAppKey:@\"e220c7a823e54f6aada37d97465475d3\"];"
		"+            [CTIOSSNDataCollection SetAppKey:@\"360d0a504d394290b2a39149384972b4\"];"
		"-    [WBDNSCache setAppkey:@\"fb43843a2d4d49ac89fa87bd859ec06b\"]; //Appkey找祖兆研(15072198)"
		"+    [WBDNSCache setAppkey:@\"800b5ce5d7b243ff9a9161cb85a8c415\"]; //Appkey找祖兆研(15072198)"
		"-    if (switchName && [switchName isHttpDnsOpen]) {"
		"-        [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:YES];"
		"-    } else{"
		"-        [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:NO];"
		"-    }"
		"+//    if (switchName && [switchName isHttpDnsOpen]) {"
		"+//        [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:YES];"
		"+//    } else{"
		"+//        [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:NO];"
		"+//    }"
		"+    [[WBDNSCache sharedInstance] setAllowHttpDNSToStart:YES];"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SNRoutes+SNCommon.m
function f_check_files_SNCommon_SNRoutes+SNCommon_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+#import <SNWAPM/SNWAPMDataManager.h>"
		"+"
		"+        // 小程序冷热启动"
		"+       NSString *string = [[NSUserDefaults standardUserDefaults] valueForKey:@\"routeToSNMINIPPage\"];"
		"+       if ([string isEqualToString:@\"cold\"]) {"
		"+           [[SNWAPMDataManager sharedInstance] setMiniInitStartPoint];"
		"+           //            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@\"snminip-title\" message:@\"cold start\" delegate:nil     cancelButtonTitle:@\"确定\" otherButtonTitles:nil];"
		"+           //            [alertView show];"
		"+       } else {"
		"+           [[SNWAPMDataManager sharedInstance] setMiniWarmStartPoint];"
		"+           //            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@\"snminip-title\" message:@\"warm start\" delegate:nil cancelButtonTitle:@\"确定\" otherButtonTitles:nil];"
		"+           //            [alertView show];"
		"+       }"
		"+    "
		"+       // 打印小程序启动日志"
		"+       NSLog([NSString stringWithFormat:@\"MiniProgramStartTime：%.0f\", [[NSDate date] timeIntervalSince1970]*1000], nil);"
		"+        "
		"+        "
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SNSwitch+SNCommon_Config.m
function f_check_files_SNCommon_SNSwitch+SNCommon_Config_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+    complent(YES, NO, nil);"
		"+    return;"
		"+    complent(NO, nil);"
		"+    return;"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SNUrlDomainManager.m
function f_check_files_SNCommon_SNUrlDomainManager_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+{"
		"+    NSString *result = [self getDomainForKey2:key];"
		"+    result = [result stringByReplacingOccurrencesOfString:@\"https://\" withString:@\"http://\"];"
		"+    return result;"
		"+}"
		"+- (NSString *)getDomainForKey2:(NSString *)key"
		"+{"
		"+    NSString *result = [self getHttpsDomainForKey2:key];"
		"+    result = [result stringByReplacingOccurrencesOfString:@\"https://\" withString:@\"http://\"];"
		"+    return result;"
		"+}"
		"+- (NSString *)getHttpsDomainForKey2:(NSString *)key"
		"+{"
		"+    NSString *result = [self getHttp2DomainForKey2:key];"
		"+    result = [result stringByReplacingOccurrencesOfString:@\"https://\" withString:@\"http://\"];"
		"+    return result;"
		"+}"
		"+- (NSString *)getHttp2DomainForKey2:(NSString *)key"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

function f_check_files_SNCommon() {
	SUB_PROJECT_GIT_BRANCH_NAME=$1
	SUB_PROJECT_SNWAPM_BRANCH_NAME=$2
	# echo "function:f_check_files_SNCommon"
	# echo "SUB_PROJECT_GIT_BRANCH_NAME:${SUB_PROJECT_GIT_BRANCH_NAME}"
	# echo "SUB_PROJECT_SNWAPM_BRANCH_NAME:${SUB_PROJECT_SNWAPM_BRANCH_NAME}"

	FILE_ERROR_COUNT=0
	for CHANGED_FILE in $(${GIT} diff origin/${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME} --name-only)
	do
		echo ""
		# check file:   Podfile                              | 28 ++++++++++++++--------------...
		echo "#### check file:  ${CHANGED_FILE}..."
		KNOWN_CHANGED_FILE=""
		if [[ "${CHANGED_FILE}" =~ "SNBSPrivacyStatementManager.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SNBSHomeManager.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SNAppLauncher.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SNBaseServiceManager.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SNMINIPSDKApi.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SNInfomationClick.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SNRoutes+SNCommon.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SNSwitch+SNCommon_Config.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SNUrlDomainManager.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		# 其他文件修改
		if [[ "${KNOWN_CHANGED_FILE}" = "" ]]; then
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			FILE_ERROR_COUNT=$((${FILE_ERROR_COUNT}+1))
			# 打印错误
			echo "error ${ERROR_COUNT}: 不需要的文件修改操作 ${KNOWN_CHANGED_FILE}"
		else
			CHANGED_LINE_ARRAY=$(${GIT} diff origin/${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME} ${KNOWN_CHANGED_FILE})
			CHANGED_LINE_ARRAY2=()
			for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
			do
				# --- a/Podfile
				if [[ "${CHANGED_LINE}" =~ "--- a" ]]; then
					continue
				fi
				# +++ b/Podfile
				if [[ "${CHANGED_LINE}" =~ "+++ b" ]]; then
					continue
				fi
				LINE_FIRST_CHARACTER=${CHANGED_LINE:0:1}
				if [[ "${LINE_FIRST_CHARACTER}" != "-" && "${LINE_FIRST_CHARACTER}" != "+" ]]; then
					continue
				fi
				# 终端上输出tab，拷贝到sublime是tab，拷贝到xcode里是4个空格
				# 这儿统一将tab替换为4个空格，兼容sublime和xcode
				CHANGED_LINE=${CHANGED_LINE//	/    }
				CHANGED_LINE_ARRAY2=(${CHANGED_LINE_ARRAY2[*]} "${CHANGED_LINE}")
			done
			CHANGED_LINE_ARRAY="${CHANGED_LINE_ARRAY2[*]}"

			LINE_ERROR_COUNT=0
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNBSPrivacyStatementManager.m" ]]; then
				f_check_files_SNCommon_SNBSPrivacyStatementManager_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNBSHomeManager.m" ]]; then
				f_check_files_SNCommon_SNBSHomeManager_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNAppLauncher.m" ]]; then
				f_check_files_SNCommon_SNAppLauncher_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNBaseServiceManager.m" ]]; then
				f_check_files_SNCommon_SNBaseServiceManager_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNMINIPSDKApi.m" ]]; then
				f_check_files_SNCommon_SNMINIPSDKApi_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNInfomationClick.m" ]]; then
				f_check_files_SNCommon_SNInfomationClick_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNRoutes+SNCommon.m" ]]; then
				f_check_files_SNCommon_SNRoutes+SNCommon_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNSwitch+SNCommon_Config.m" ]]; then
				f_check_files_SNCommon_SNSwitch+SNCommon_Config_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNUrlDomainManager.m" ]]; then
				f_check_files_SNCommon_SNUrlDomainManager_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			# 打印单个project结果
			if [[ ${LINE_ERROR_COUNT} -eq 0 ]]; then
				echo "total: pass"
			else
				echo "total: fail"
				echo "changed:"
				print_LINE_KNOWN_CHANGED_ARRAY "${CHANGED_LINE_ARRAY[*]}"
			fi
		fi
	done
}

#### f_check_files_SNHomePage
# SNSHHomePageViewController.m
function f_check_files_SNHomePage_SNSHHomePageViewController_m() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"+#import <SNWAPM/SNWAPMDataManager.h>"
		"+"
		"+    // 冷启动结束打点,放在业务代码最后"
		"+    [[SNWAPMDataManager sharedInstance] setInitEndPoint];"
		"+    // 红孩子线上环境"
		"+    [self handleTargetType:@\"4\" targetURLString:@\"http://m.suning.com/index?adTypeCode=100013&adId=http%3A%2F%2Fsnmps.suning.com%2Fsnmps-web%2Fprogram%2Fget_740f38e2718fbba846b3c9ee616c0951_%7BcurrVersion%7D_0_%7BclientVersion%7D.htm&webUrl=https%3a%2f%2fc.m.suning.com%2fmuying2018.html\"];"
		"+    return;"
		"+    "
		"+        "
		"+        // 首页元素加载完成后调用,测量app启动流量"
		"+        [[SNWAPMDataManager sharedInstance] homePageLoaded];"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}222"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

function f_check_files_SNHomePage() {
	SUB_PROJECT_GIT_BRANCH_NAME=$1
	SUB_PROJECT_SNWAPM_BRANCH_NAME=$2
	# echo "function:f_check_files_SNHomePage"
	# echo "SUB_PROJECT_GIT_BRANCH_NAME:${SUB_PROJECT_GIT_BRANCH_NAME}"
	# echo "SUB_PROJECT_SNWAPM_BRANCH_NAME:${SUB_PROJECT_SNWAPM_BRANCH_NAME}"

	FILE_ERROR_COUNT=0
	for CHANGED_FILE in $(${GIT} diff origin/${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME} --name-only)
	do
		echo ""
		# check file:   Podfile
		echo "#### check file:  ${CHANGED_FILE}..."
		KNOWN_CHANGED_FILE=""
		if [[ "${CHANGED_FILE}" =~ "SNSHHomePageViewController.m" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		# 其他文件修改
		if [[ "${KNOWN_CHANGED_FILE}" = "" ]]; then
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			FILE_ERROR_COUNT=$((${FILE_ERROR_COUNT}+1))
			# 打印错误
			echo "error ${ERROR_COUNT}: 不需要的文件修改操作 ${KNOWN_CHANGED_FILE}"
		else
			CHANGED_LINE_ARRAY=$(${GIT} diff origin/${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME} ${KNOWN_CHANGED_FILE})
			CHANGED_LINE_ARRAY2=()
			for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
			do
				# --- a/Podfile
				if [[ "${CHANGED_LINE}" =~ "--- a" ]]; then
					continue
				fi
				# +++ b/Podfile
				if [[ "${CHANGED_LINE}" =~ "+++ b" ]]; then
					continue
				fi
				LINE_FIRST_CHARACTER=${CHANGED_LINE:0:1}
				if [[ "${LINE_FIRST_CHARACTER}" != "-" && "${LINE_FIRST_CHARACTER}" != "+" ]]; then
					continue
				fi
				# 终端上输出tab，拷贝到sublime是tab，拷贝到xcode里是4个空格
				# 这儿统一将tab替换为4个空格，兼容sublime和xcode
				CHANGED_LINE=${CHANGED_LINE//	/    }
				CHANGED_LINE_ARRAY2=(${CHANGED_LINE_ARRAY2[*]} "${CHANGED_LINE}")
			done
			CHANGED_LINE_ARRAY="${CHANGED_LINE_ARRAY2[*]}"
			
			LINE_ERROR_COUNT=0
			if [[ "${KNOWN_CHANGED_FILE}" =~ "SNSHHomePageViewController.m" ]]; then
				f_check_files_SNHomePage_SNSHHomePageViewController_m "${CHANGED_LINE_ARRAY[*]}"
			fi
			# 打印单个project结果
			if [[ ${LINE_ERROR_COUNT} -eq 0 ]]; then
				echo "total: pass"
			else
				echo "total: fail"
				echo "changed:"
				print_LINE_KNOWN_CHANGED_ARRAY "${CHANGED_LINE_ARRAY[*]}"
			fi
		fi
	done
}

# 检查工程
echo ""
echo "检查项1:检查工程修改..."
cd ${PROJECT_PATH}
CHECK_GIT_ARRAY=(${PROJECT_PATH})
CHECK_GIT_ARRAY=(${CHECK_GIT_ARRAY[*]} ${HOME}/.cocoapods/repos/SNEBuy_buss_repos)
CHECK_GIT_ARRAY=(${CHECK_GIT_ARRAY[*]} ${HOME}/.cocoapods/repos/SNEBuy_repos)
for GIT_PROJECT_NAME in $(ls ${PROJECT_PATH}/SNProjects)
do
	GIT_PATH=${PROJECT_PATH}/SNProjects/${GIT_PROJECT_NAME}
	if [[ -e ${GIT_PATH}/.git ]]; then
		CHECK_GIT_ARRAY=(${CHECK_GIT_ARRAY[*]} ${GIT_PATH})
	fi
done 
for GIT_PROJECT_NAME in $(ls ${PROJECT_PATH}/SNPods)
do
	GIT_PATH=${PROJECT_PATH}/SNPods/${GIT_PROJECT_NAME}
	if [[ -e ${GIT_PATH}/.git ]]; then
		CHECK_GIT_ARRAY=(${CHECK_GIT_ARRAY[*]} ${GIT_PATH})
	fi
done 
for GIT_PATH in ${CHECK_GIT_ARRAY[*]}
do
	echo ""
	echo "check project $(basename ${GIT_PATH})..."
	cd ${GIT_PATH}
	PROJECT_ERROR_COUNT=0
	if [[ "$(basename ${GIT_PATH})" = "SNEBuy_repos" ]]; then
		# SNEBuy_repos单独检查
		f_check_project_SNEBuy_repos ${GIT_PATH}
	else
		f_check_project_other ${GIT_PATH}
	fi

	# 打印单个project结果
	if [[ ${PROJECT_ERROR_COUNT} -eq 0 ]]; then
	    echo "pass"
	else
		echo "fail"
	fi
done

# 检查文件
echo ""
echo "检查项2:检查工程下文件修改..."
cd ${PROJECT_PATH}
for SUB_PROJECT_INFO_ARRAY in ${ALL_CHECK_PROJECT_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
	eval SUB_PROJECT_NAME=\${${SUB_PROJECT_INFO_ARRAY}[0]}
	eval SUB_PROJECT_GIT_URL=\${${SUB_PROJECT_INFO_ARRAY}[1]}
	eval SUB_PROJECT_GIT_BRANCH_NAME=\${${SUB_PROJECT_INFO_ARRAY}[2]}
	eval SUB_PROJECT_PATH=\${${SUB_PROJECT_INFO_ARRAY}[3]}
	eval SUB_PROJECT_SNWAPM_BRANCH_NAME=\${${SUB_PROJECT_INFO_ARRAY}[4]}

	echo ""
	echo "check project ${SUB_PROJECT_NAME}下文件修改..."
	cd ${SUB_PROJECT_PATH}
	if [[ "${SUB_PROJECT_NAME}" = "SNMain" ]]; then
		f_check_files_SNMain ${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME}
	fi
	if [[ "${SUB_PROJECT_NAME}" = "SNCommon" ]]; then
		f_check_files_SNCommon ${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME}
	fi
	if [[ "${SUB_PROJECT_NAME}" = "SNHomePage" ]]; then
		f_check_files_SNHomePage ${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME}
	fi
done

echo ""
echo "检查项3:检查Podfile..."
PODFILE_PATH=${PROJECT_PATH}/Podfile
for PODFILE_USING_CODE_FALSE in $(cat ${PODFILE_PATH} | grep using_code_.*=.*false); do
	if [[ ! "${PODFILE_USING_CODE_FALSE}" =~ "using_code_show3dsdk" ]] \
		&& [[ ! "${PODFILE_USING_CODE_FALSE}" =~ "using_code_snarplatform" ]] \
		&& [[ ! "${PODFILE_USING_CODE_FALSE}" =~ "using_code_snarhomedesign" ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PODFILE_ERROR_COUNT=$((${PODFILE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}:未知的using_code_xxx = false ---- ${PODFILE_USING_CODE_FALSE} "
	fi
done
# 打印单个project结果
if [[ ${PODFILE_ERROR_COUNT} -eq 0 ]]; then
    echo "pass"
else
	echo "fail"
fi

echo ""
if [[ ${ERROR_COUNT} -gt 0 ]]; then
	echo "检查出不符合预期的修改:${ERROR_COUNT}处"
	echo "最终检查结果:  不通过"
	exit 1
else
	echo "最终检查结果:  pass"
fi

# 设回IFS
IFS=${OLD_IFS}

