#!/bin/bash
# jenkins-adhoc.sh
# adhoc打包脚本
# 这个是adhoc打包最终执行脚本，其他只是外衣，设置参数环境什么的
# jenkins job
# 1.SuningEBuy-AdHoc-920

#### 用法，同时也是jenkins build参数
#### SuningEBuy-AdHoc-920
# export JOB_NAME="SuningEBuy-AdHoc-920"
# export CHECK_LAST_BUILD_TIME=true # 检查上次build时间，勾选则15分钟内只打一次包
# export pre=true
# export xgpre=false
# export poc=false
# export prd=true
# export sit=true
# export DEBUG=false # 选中-debug模式测试包,不选中-正常Release模式测试包
# export ARMV7=true # 打armv7架构测试包，兼容iPhone4s、5设备
# export ARM64=true # 打arm64架构测试包，目前大部分iPhone都是arm64架构
# export X86_64=false # 打X86_64架构测试包，模拟器使用
# export UPLOAD_NAME="AdHoc官方定位分享包" # 可不配置,描述会按照SuningEMall的选择来
# # 开始打包
# bash Scripts/jenkins/adhoc/jenkins-adhoc.sh

# 模拟jenkins参数检查
if [[ -z ${JOB_NAME} ]]; then
	echo "error: JOB_NAME not found"
	exit 1
fi

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi
export LANG=zh_CN.UTF-8
export PATH=/usr/local/bin:${PATH}

# 兼容研发云打包环境，优先使用/Applications/Xcode12.3.app打包
# 研发云同时装有多个xcode版本，默认的可能不是Xcode12.3
if [[ -e /Applications/Xcode12.3.app ]]; then
    export PATH=/Applications/Xcode12.3.app/Contents/Developer/usr/bin:$PATH
fi
# 检查Xcode版本号
RESULT_STRING=$(xcodebuild -version | head -1)
echo ""
echo "using xcode: ${RESULT_STRING}"
if [[ "${RESULT_STRING}" != "Xcode 12.3" ]]; then
    echo "error: 请使用指定的Xcode版本进行打包"
    exit 1
fi

#### 变量
echo ""
echo "step 1:更新主工程代码..."
# WORKSPACE默认值
# PROJECT_PATH,最终打包目录
if [ -z ${WORKSPACE} ]; then
    # JOB_NAME
    cd ${SCRIPT_DIR}/../../../../
    WORKSPACE=$(pwd)/${JOB_NAME}
    mkdir -p ${WORKSPACE}
    PROJECT_PATH="${WORKSPACE}"
else
    # 兼容研发云Delete workspace when build is done
    PROJECT_PATH=${HOME}/.suning/build/${JOB_NAME}
    mkdir -p ${PROJECT_PATH}
fi
cd ${PROJECT_PATH}

PROJECT_NAME="SuningEBuy"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_VERSION="850"
# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
	# jenkins打包 SuningEBuy-840
	GIT_BRANCH_VERSION=${JOB_NAME##*-}
elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
	# 研发云打包 ebuy_840
	GIT_BRANCH_VERSION=${JOB_NAME##*_}
fi
GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

# 拉取代码
cd ${PROJECT_PATH}
if [ ! -d ${PROJECT_PATH}/.git ]; then
	${GIT} init
	${GIT} remote add origin ${GIT_URL}
	${GIT} fetch
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
${GIT} checkout . 
# 删除Untracked files
${GIT} clean -fd
# 拉取代码
${GIT} pull
# 切换分支
${GIT} checkout ${GIT_BRANCH_NAME}

#### 打包前处理
echo ''
echo 'step 2:打包前处理...'
# 清理归档文件...
echo "2-1:clean..."
bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-clean-helper.sh

# 打包间隔检查
echo ""
echo "2-2:打包间隔检查..."
BUILD_IDENTIFIER="${JOB_NAME}"
BUILD_DURATION="0"
if [[ "${CHECK_LAST_BUILD_TIME}" = "true" ]]; then
	BUILD_DURATION="15"
fi
BUILD_CHECK_URL="http://10.37.64.97/ipa/build.json?identifier=${BUILD_IDENTIFIER}&duration=${BUILD_DURATION}"
BUILD_CHECK_RESULT=$(curl -m 10 -s ${BUILD_CHECK_URL})
echo "check url: ${BUILD_CHECK_URL}"
echo "check result: ${BUILD_CHECK_RESULT}"
if [[ ! ${BUILD_CHECK_RESULT} =~ "\"code\":\"0\"" ]]; then
	BUILD_CHECK_RESULT_MSG=$(echo ${BUILD_CHECK_RESULT} | cut -d "\"" -f 4)
	echo "error: 不打包, ${BUILD_CHECK_RESULT_MSG}"
	echo ""
	echo "如果想强制打包，打包的时候，不要勾选CHECK_LAST_BUILD_TIME即可😢 😢 😢"
	echo ""
	exit 1
else
	echo ""
	echo "开始打包🚀 🚀 🚀"
	echo ""
fi

echo ""
echo "WORKSPACE:      	${WORKSPACE}"
echo "PROJECT_PATH: 	${PROJECT_PATH}"
echo "JOB_NAME:         ${JOB_NAME}"
echo "GIT_URL:          ${GIT_URL}"
echo "PROJECT_NAME:     ${PROJECT_NAME}"
echo "GIT_BRANCH_NAME:  ${GIT_BRANCH_NAME}"

#### 输入参数检查
echo ''
echo 'step 3:参数检查...'
BUILD_PARAMETER=""
BUILD_ENV_COUNT=0
if ${pre}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -pre"
	BUILD_ENV_COUNT=$((${BUILD_ENV_COUNT}+1))
fi
if ${xgpre}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -xgpre"
	BUILD_ENV_COUNT=$((${BUILD_ENV_COUNT}+1))
fi
if ${poc}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -poc"
	BUILD_ENV_COUNT=$((${BUILD_ENV_COUNT}+1))
fi
if ${prd}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -prd"
	BUILD_ENV_COUNT=$((${BUILD_ENV_COUNT}+1))
fi
if ${sit}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -sit"
	BUILD_ENV_COUNT=$((${BUILD_ENV_COUNT}+1))
fi
if [ "${BUILD_PARAMETER}" = "" ]; then
	echo "请选择打包环境"
	exit 0
fi
# if [[ ${BUILD_ENV_COUNT} -gt 1 ]]; then
# 	echo "只能选择1个打包环境 ${BUILD_PARAMETER}"
# 	exit 0
# fi

if [ "${UPLOAD_NAME}" = "" ]; then
	UPLOAD_NAME="AdHoc官方定位分享包"
fi

echo "buld参数:          ${BUILD_PARAMETER}"
echo "UPLOAD_NAME:      ${UPLOAD_NAME}"

#### pull代码
echo ''
cd ${WORKSPACE}
echo 'step 4:pull code...'
# updateAllCode
echo "4-1:updateAllCode.sh..."
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/updateAllCode.sh -checkupdate
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# repo-update.sh
echo ""
echo "4-2:repo-update.sh..."
bash ${PROJECT_PATH}/repo-update.sh -checkupdate -skip--pod -check--branch -revert--subproject
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### pod集成
echo ''
echo 'step 5:pod集成...'
echo "5-1:修改Podfile..."
# 清空之前pod生成文件
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
for PBXPROJ_PATH in `find ${PROJECT_PATH}/SNProjects -name project.pbxproj`
do
    sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
done

# 修改Podfile
PODFILE_PATH=${PROJECT_PATH}/Podfile
sed -i '' "s/using_code_snsearch = false/using_code_snsearch = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snproduct = false/using_code_snproduct = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snpingou = false/using_code_snpingou = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snpm = false/using_code_snpm = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snlogin = false/using_code_snlogin = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snmember = false/using_code_snmember = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snsl = false/using_code_snsl = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snlive = false/using_code_snlive = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snmk = false/using_code_snmk = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snhwg = false/using_code_snhwg = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snchannel = false/using_code_snchannel = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snsm = false/using_code_snsm = true/" ${PODFILE_PATH}
sed -i '' "s/using_code_snhome = false/using_code_snhome = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep using_code_.*=

echo ''
echo '5-2:repo-update.sh -pod...'
# repo-update
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/repo-update.sh -pod
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### 修改打包配置
echo ''
echo 'step 6:修改打包配置...'
echo ""
echo "6-1:修改证书..."
# DEVELOPMENT_TEAM
PROJECT_PBXPROJ_PATH="${PROJECT_PATH}/SuningEBuy.xcodeproj/project.pbxproj"
PROJECT_DEVELOPMENT_TEAM="76M3JYH4P2"
sed -i '' "s/DEVELOPMENT_TEAM =.*;/DEVELOPMENT_TEAM = ${PROJECT_DEVELOPMENT_TEAM};/" ${PROJECT_PBXPROJ_PATH}

# 修改project证书
PROJECT_PROVISIONING_PROFILE_SPECIFIER="SuningEMallHocDistribution"
PROJECT_CODE_SIGN_IDENTITY="iPhone Distribution"
# CODE_SIGN_IDENTITY
set +H
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/1" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/2" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/1" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/2" ${PROJECT_PBXPROJ_PATH}

# 修改第一个target也就是SuningEBuy证书
# PROVISIONING_PROFILE_SPECIFIER
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${PROJECT_PROVISIONING_PROFILE_SPECIFIER};/1" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${PROJECT_PROVISIONING_PROFILE_SPECIFIER};/2" ${PROJECT_PBXPROJ_PATH}
# CODE_SIGN_IDENTITY
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/3" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/4" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/3" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/4" ${PROJECT_PBXPROJ_PATH}

# 修改第2个target也就是TodayWidget证书
# PROVISIONING_PROFILE_SPECIFIER
TODAY_WIDGET_PROVISIONING_PROFILE_SPECIFIER="SuningEMallTodayWidgeHocDistribution"
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${TODAY_WIDGET_PROVISIONING_PROFILE_SPECIFIER};/3" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${TODAY_WIDGET_PROVISIONING_PROFILE_SPECIFIER};/4" ${PROJECT_PBXPROJ_PATH}
# CODE_SIGN_IDENTITY
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/5" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/6" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/5" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/6" ${PROJECT_PBXPROJ_PATH}

# 修改第3个target也就是PushService证书
# PROVISIONING_PROFILE_SPECIFIER
PUSH_SERVICE_PROVISIONING_PROFILE_SPECIFIER="SuningEMallPushServiceHocDistrbution"
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${PUSH_SERVICE_PROVISIONING_PROFILE_SPECIFIER};/5" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${PUSH_SERVICE_PROVISIONING_PROFILE_SPECIFIER};/6" ${PROJECT_PBXPROJ_PATH}
# CODE_SIGN_IDENTITY
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/7" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/8" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/7" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/8" ${PROJECT_PBXPROJ_PATH}

# 打印验证
cat ${PROJECT_PBXPROJ_PATH} | grep "PROVISIONING_PROFILE"
cat ${PROJECT_PBXPROJ_PATH} | grep "CODE_SIGN_IDENTITY"
cat ${PROJECT_PBXPROJ_PATH} | grep "DEVELOPMENT_TEAM"

#### SuningEBuy Capabilities
echo ""
echo "6-2:修改Capabilities..."
# SuningEBuy.entitlements
echo "SuningEBuy.entitlements..."
PROJECT_ENTITLEMENTS_PATH="${PROJECT_PATH}/SuningEBuy/SuningEBuy.entitlements"

# 推送 aps-environment
PLIST_KEY="aps-environment"
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} string 'development'" ${PROJECT_ENTITLEMENTS_PATH}

# 苹果登录 com.apple.developer.applesignin
PLIST_KEY="com.apple.developer.applesignin"
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string 'Default'" ${PROJECT_ENTITLEMENTS_PATH}

# App Groups
# 在工程中开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.ApplicationGroups.iOS = {[^}]*};/com.apple.ApplicationGroups.iOS = {enabled = 1;};/1" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy.entitlements
PLIST_KEY="com.apple.security.application-groups"
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string 'group.SuningEMall'" ${PROJECT_ENTITLEMENTS_PATH}

# Access Wifi Infomation com.apple.developer.networking.wifi-info
PLIST_KEY="com.apple.developer.networking.wifi-info"
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} bool true" ${PROJECT_ENTITLEMENTS_PATH}

# 打印验证
cat ${PROJECT_ENTITLEMENTS_PATH}

#### TodayWidget Capabilities 
echo ""
echo "TodayWidget.entitlements..."
TODAY_WIDGET_ENTITLEMENTS_PATH="${PROJECT_PATH}/TodayWidget/TodayWidget.entitlements"

# App Groups
# 在工程中开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.ApplicationGroups.iOS = {[^}]*};/com.apple.ApplicationGroups.iOS = {enabled = 1;};/2" ${PROJECT_PBXPROJ_PATH}
# TodayWidget.entitlements
PLIST_KEY="com.apple.security.application-groups"
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${TODAY_WIDGET_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string 'group.SuningEMall'" ${TODAY_WIDGET_ENTITLEMENTS_PATH}

# 打印验证
cat ${TODAY_WIDGET_ENTITLEMENTS_PATH}

# exportOptions.plist
echo ""
echo "6-3:修改exportOptions.plist..."
PROJECT_EXPORTT_OPTIONS_PATH="${PROJECT_PATH}/exportOptions.plist"
/usr/libexec/PlistBuddy -c 'Delete :method' ${PROJECT_EXPORTT_OPTIONS_PATH}
/usr/libexec/PlistBuddy -c "Add :method string ad-hoc" ${PROJECT_EXPORTT_OPTIONS_PATH}
# provisioningProfiles
/usr/libexec/PlistBuddy -c 'Delete :provisioningProfiles' ${PROJECT_EXPORTT_OPTIONS_PATH}
/usr/libexec/PlistBuddy -c 'Add :provisioningProfiles dict' ${PROJECT_EXPORTT_OPTIONS_PATH}
/usr/libexec/PlistBuddy -c "Add :provisioningProfiles:'SuningEMall.PushService' string SuningEMallPushServiceHocDistrbution" ${PROJECT_EXPORTT_OPTIONS_PATH}
/usr/libexec/PlistBuddy -c "Add :provisioningProfiles:'SuningEMall.TodayWidget' string SuningEMallTodayWidgeHocDistribution" ${PROJECT_EXPORTT_OPTIONS_PATH}
/usr/libexec/PlistBuddy -c "Add :provisioningProfiles:'SuningEMall' string SuningEMallHocDistribution" ${PROJECT_EXPORTT_OPTIONS_PATH}
# 修改signingCertificate
/usr/libexec/PlistBuddy -c 'Delete :signingCertificate' ${PROJECT_EXPORTT_OPTIONS_PATH}
/usr/libexec/PlistBuddy -c "Add :signingCertificate string ${PROJECT_CODE_SIGN_IDENTITY}" ${PROJECT_EXPORTT_OPTIONS_PATH}
# 打印验证
cat ${PROJECT_EXPORTT_OPTIONS_PATH}

#### 打包
echo ''
echo 'step 7:打包...'
echo "7-1:打印Podfile"
cat ${PODFILE_PATH}

# BUILD_PARAMETER
BUILD_PARAMETER="${BUILD_PARAMETER} -u -name--${UPLOAD_NAME} -skip--configExportOptions -xcpretty"
# jenkins描述 http://10.243.139.123/job/SuningEBuy-Framework-850/107/
BUILD_PARAMETER="${BUILD_PARAMETER} -jenkinsDesc--#${BUILD_NUMBER}"
JENKINS_URL="http://10.37.64.97/jenkins/job/${JOB_NAME}/${BUILD_NUMBER}/"
BUILD_PARAMETER="${BUILD_PARAMETER} -jenkinsUrl--${JENKINS_URL}"
# debug
if ${DEBUG}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -debug"
fi
# armv7
if ${ARMV7}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--armv7"
fi
# arm64
if ${ARM64}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--arm64"
fi
# x86_64
if ${X86_64}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--x86_64"
fi

# ipa-test
cd ${PROJECT_PATH}/
echo "7-2:打包命令:${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}"
echo ''
echo "building..."
export RESIGN_CERTIFICATE="iPhone Distribution: Suning Commerce Group Co.,Ltd. (76M3JYH4P2)"
bash ${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}

# CURRENT_BUILD_DIRECTORY
BUILD_DIRECTORY="${PROJECT_PATH}/build"
CURRENT_BUILD_DIRECTORY=$(ls -rt ${BUILD_DIRECTORY} | tail -1)
CURRENT_BUILD_DIRECTORY="${BUILD_DIRECTORY}/${CURRENT_BUILD_DIRECTORY}"
cd ${CURRENT_BUILD_DIRECTORY}

#### 生成归档文件，jenkins Copy Artifact Plugin
echo ""
echo "step 8:生成归档文件..."
# 列出build结果
echo "cmd: ls ${CURRENT_BUILD_DIRECTORY}"
ls ${CURRENT_BUILD_DIRECTORY}
# 拷贝dsynm文件到build-artifacts
BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
for XCARCHIVE_FILE_PATH in $(find ${CURRENT_BUILD_DIRECTORY} -name *.xcarchive -maxdepth 1)
do
	cd ${XCARCHIVE_FILE_PATH}/dSYMs
	for DSYM_FILE_NAME in $(ls)
	do
		if [[ ${DSYM_FILE_NAME} =~ ".dSYM" ]]; then
			echo ""
			echo "cmd: zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1"
			zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1
		fi
	done
done
# debug模式ipa没dsym文件，这儿占个位，不然会提示任务错误
if [[ "${DEBUG}" = "true" ]]; then
	echo "cmd: touch ${BUILD_ARTIFACTS_PATH}/debug-ipa-no-dsym.zip"
	touch ${BUILD_ARTIFACTS_PATH}/debug-ipa-no-dsym.zip
fi
# x86_64架构ipa没dsym文件，这儿占个位，不然会提示任务错误
if [[ "${X86_64}" = "true" ]]; then
	echo "cmd: touch ${BUILD_ARTIFACTS_PATH}/x86_64-ipa-no-dsym.zip"
	touch ${BUILD_ARTIFACTS_PATH}/x86_64-ipa-no-dsym.zip
fi
# 兼容研发云Delete workspace when build is done
if [[ -d ${WORKSPACE}/build-artifacts ]] && [[ ! -L ${WORKSPACE}/build-artifacts ]]; then
    rm -rf ${WORKSPACE}/build-artifacts
fi
ln -fs ${BUILD_ARTIFACTS_PATH} ${WORKSPACE}/

