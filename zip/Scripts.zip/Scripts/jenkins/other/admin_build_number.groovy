#!/usr/bin/env groovy
// admin_build_number
// 使我们jenkins的build number和研发云的build nunmber保持一致
// 根据研发云日志设置job的下次build number

import jenkins.model.Jenkins
import hudson.model.Job

// job_path_file_list
def jobs_path_string="/root/.jenkins/jobs"
def jobs_path_file = new File(jobs_path_string)
def job_path_file_list = []
jobs_path_file.eachDir{build_path_file->
	job_path_file_list << build_path_file
}
for ( job_path_file in job_path_file_list ) {
	println ""
    println job_path_file.getAbsolutePath()

    // latest_build_number
    def latest_build_number=0
    def builds_path_string="${job_path_file.getAbsolutePath()}/builds"
    println "builds_path_string:${builds_path_string}"
    def builds_path_file = new File(builds_path_string)
    builds_path_file.eachDir{build_path->
    	// println "build_path:${build_path.name}"
    	tmp_build_number = build_path.name.toInteger()
    	if (tmp_build_number > latest_build_number) {
    		log_path_string="${builds_path_string}/${tmp_build_number}/log"
			log_path_file = new File(log_path_string)
			if (log_path_file.exists()) {
				latest_build_number = tmp_build_number
			}
    	}
    }
    println "latest_build_number:${latest_build_number}"
    // 只处理有log的job
    if (latest_build_number <= 0) {
    	println "latest_build_number为0,skip..."
    	continue
    }

    // jenkins_url
	def jenkins_url = ""
	def last_line_is_read_log_tip = false
	log_path_string="${builds_path_string}/${latest_build_number}/log"
	log_path_file = new File(log_path_string)
	log_path_file.eachLine {line ->
		// 读取log...
		// http://10.37.87.240/job/ebuy_920/118/
		if (line.contains("读取log...")) {
			last_line_is_read_log_tip = true
		} else {
			if (last_line_is_read_log_tip && line.contains("http://10.37.87.240/job/")) {
				jenkins_url = line
			}
			// 只判断读取log...下一行
			last_line_is_read_log_tip = false
		}
	}
	println "jenkins_url:${jenkins_url}"
	// jenkins_url为空，skip
	if (jenkins_url == "") {
		println "jenkins_url为空，skip..."
		continue
	}

	// build_number_new
	def tmp_array = jenkins_url.tokenize("/")
	def build_number_new = tmp_array[4]
	build_number_new = build_number_new.toInteger()
	build_number_new += 1
	println "build_number_new:${build_number_new}"

	// 开始设置NextBuildNumber
	item = Jenkins.instance.getItemByFullName(job_path_file.name)
	// 停止build
	stop_count = 0
	item.builds.each() { build ->
		if (build.number >= build_number_new) {
			build.doStop()
			stop_count += 1
		}
	}
	// 延迟15s删除build，防止任务还在执行
	if (stop_count > 0) {
		sleep(15*1000)
	}
	// 删除之前的build记录
	item.builds.each() { build ->
		if (build.number >= build_number_new) {
			println "delete build ${build.number}"
			build.delete()
		}
	}
	// 删除log日志,上面的删除有时候不彻底，导致jenkins上点击了build但是没效果
	builds_path_file.eachDir{build_path->
    	if (build_path.name.toInteger() >= build_number_new) {
    		if (build_path.exists()) {
				build_path.deleteDir()
			}
    	}
    }
	// 设置NextBuildNumber
	println "updateNextBuildNumber ${build_number_new}"
	item.updateNextBuildNumber(build_number_new)
	println "done"
}

