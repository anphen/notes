#!/bin/bash
# jenkins设置中执行脚本

# set -e

#### 系统环境
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

export LANG=zh_CN.UTF-8
PATH=${PATH}:/usr/local/bin
if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi

#### 变量
echo ""
echo "step 1:更新主工程代码..."
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

PROJECT_NAME="SuningEBuy"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_NAME="master"

# 拉取代码
cd ${WORKSPACE}
if [ ! -d ${WORKSPACE}/.git ]; then
	${GIT} init
	${GIT} remote add origin ${GIT_URL}
	${GIT} fetch
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
${GIT} checkout . 
# 删除Untracked files
${GIT} clean -fd
# 切换分支
${GIT} checkout ${GIT_BRANCH_NAME}
# 拉取代码
${GIT} pull

#### pod集成
echo ''
echo 'step 2:pod集成...'
# 清空之前pod生成文件
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
for PBXPROJ_PATH in `find ${PROJECT_PATH}/SNProjects -name project.pbxproj`
do
    sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
done

bash ${PROJECT_PATH}/repo-update.sh -checkupdate
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

MACHO_FILE_PATH_ARRAY=()
for MACHO_FILE_PATH in $(find /Users/wangbin/.cocoapods/repos/SNEBuy_repos/ -name *.framework)
do
	MACHO_FILE_NAME=$(basename ${MACHO_FILE_PATH})
	MACHO_FILE_NAME=${MACHO_FILE_NAME%.*}
	MACHO_FILE_PATH="${MACHO_FILE_PATH}/${MACHO_FILE_NAME}"
	MACHO_FILE_PATH_ARRAY=(${MACHO_FILE_PATH_ARRAY[*]} ${MACHO_FILE_PATH})
done
for MACHO_FILE_PATH in $(find /Users/wangbin/.cocoapods/repos/SNEBuy_repos/ -name *.a)
do
	MACHO_FILE_PATH_ARRAY=(${MACHO_FILE_PATH_ARRAY[*]} ${MACHO_FILE_PATH})
done

cd ${PROJECT_PATH}
mkdir -p tmp
for MACHO_FILE_PATH in ${MACHO_FILE_PATH_ARRAY[*]}
do
	# 文件不存在，跳过
	if [[ ! -e ${MACHO_FILE_PATH} ]]; then
		continue
	fi
	
	# FILE_TYPE
	MACHO_FILE_TYPE="0"
	RESULT_STRING=$(file ${MACHO_FILE_PATH})
	if [[ "${RESULT_STRING}" =~ "current ar archive" ]]; then
		# 静态库
		MACHO_FILE_TYPE="1"
	fi
	if [[ "${RESULT_STRING}" =~ "Mach-O object" ]]; then
		# 静态库
		MACHO_FILE_TYPE="1"
	fi
	if [[ "${RESULT_STRING}" =~ "dynamically" ]]; then
		# 动态库
		MACHO_FILE_TYPE="2"
	fi
	if [[ "${MACHO_FILE_TYPE}" == "0" ]]; then
		echo "unknown type,check it."
		echo "${RESULT_STRING}"
		exit 0
	fi

	# 检查静态库
	if [[ "${MACHO_FILE_TYPE}" == "1" ]]; then
		# 结果好像不准确...
		rm -f tmp/tmp-arm64
		lipo -thin arm64 ${MACHO_FILE_PATH} -output tmp/tmp-arm64
		if [[ "$(objdump -h tmp/tmp-arm64 | grep "__debug_")" != "" ]]; then
			echo ""
			echo "${MACHO_FILE_PATH} found debug,check it"
		fi
	else
		# echo "dynamic framework,to be supported..."
		echo "" >> /dev/null
	fi
done

