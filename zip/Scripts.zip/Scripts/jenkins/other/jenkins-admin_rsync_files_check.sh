#!/bin/bash
# admin_rsync_files_check
# 检查rsync中文件sha1值，防止被改动
# 文件sha1值维护在/data/rsync-data/private/sha1-files.txt
# 示例
# files/Xcode_12.4.xip	85d77f3876bd3a955b4422e10d2e9acd9a11f104
# 其中
# shasum files/Xcode_12.4.xip计算出85d77f3876bd3a955b4422e10d2e9acd9a11f104

# 环境
SCRIPT_DIR="$(cd `dirname $0`; pwd)"
cd ${SCRIPT_DIR}

set -e

# 不设置代理
http_proxy=
https_proxy=

#### 变量
RSYNC_DIRECTORY="/data/rsync-data"

SHA1_FILE_PATH="${RSYNC_DIRECTORY}/private/sha1-files.txt"
if [[ -e ${SCRIPT_DIR}/sha1-files.txt ]]; then
	SHA1_FILE_PATH="${SCRIPT_DIR}/sha1-files.txt"
fi
echo "SHA1_FILE_PATH:${SHA1_FILE_PATH}"

ERROR_FILE_COUNT=0

# ifs
OLD_IFS=${IFS}
NEW_IFS='
'

#### 检查1 xcode是否有维护sha1
echo ""
echo "检查1 xcode是否有维护sha1"
RESULT_STRING=$(cat ${SHA1_FILE_PATH})
for FILE_PATH in $(find ${RSYNC_DIRECTORY} -name Xcode*)
do
	echo ""
	FILE_PATH=${FILE_PATH/${RSYNC_DIRECTORY}\//} 
	echo "check ${FILE_PATH}"
	if [[ "${RESULT_STRING}" =~ "${FILE_PATH}" ]]; then
		echo "result: found this file"
	else
		echo "result: error,not found this file"
		# 失败次数+1
		ERROR_FILE_COUNT=$((${ERROR_FILE_COUNT}+1))
	fi
done

#### 检查2 sha1值检验
echo ""
echo "检查2 sha1值检验"

# ifs设置为换行符
IFS=${NEW_IFS}

for FILE_LINE in $(cat ${SHA1_FILE_PATH})
do
	if [[ "${FILE_LINE}" =~ "#" ]]; then
		continue
	fi

	echo ""
	echo "check line:${FILE_LINE}"
	TMP_ARRAY=(${FILE_LINE//	/${IFS}}) 
	FILE_PATH=${TMP_ARRAY[0]}
	FILE_SHA1=${TMP_ARRAY[1]}
	# 兼容FILE_PATH
	if [[ -e ${RSYNC_DIRECTORY}/${FILE_PATH} ]]; then
		FILE_PATH=${RSYNC_DIRECTORY}/${FILE_PATH}
	fi
	# 去除左右空格
	# 设置ifs回原来值
	IFS=${OLD_IFS}
	FILE_PATH=$(echo ${FILE_PATH})
	FILE_SHA1=$(echo ${FILE_SHA1})
	# ifs设置为换行符
	IFS=${NEW_IFS}
	# 打印
	echo "    FILE_PATH:${FILE_PATH} ----"
	echo "    FILE_SHA1:${FILE_SHA1} ----"

	if [[ -e ${FILE_PATH} ]]; then
		# 计算sha1值
		if [[ "$(uname -a)" =~ "Darwin" ]]; then
			SHA1_STRING=$(shasum ${FILE_PATH})
			SHA1_STRING=${SHA1_STRING% *}
		else
			SHA1_STRING=$(sha1sum ${FILE_PATH})
			SHA1_STRING=${SHA1_STRING% *}
		fi
		# 去除左右空格
		# 设置ifs回原来值
		IFS=${OLD_IFS}
		SHA1_STRING=$(echo ${SHA1_STRING})
		# ifs设置为换行符
		IFS=${NEW_IFS}
		# 打印
		echo "    SHA1_STRING:${SHA1_STRING} ----"

		# 判断是否和保存的值相同
		if [[ "${SHA1_STRING}" != "${FILE_SHA1}" ]]; then
			echo "result: not matches"
			# 失败次数+1
			ERROR_FILE_COUNT=$((${ERROR_FILE_COUNT}+1))
		else
			echo "result: matches"
		fi
	else
		echo "result: ${FILE_PATH} not exist"
	fi
done

# 设置ifs回原来值
IFS=${OLD_IFS}

echo ""
if [[ ${ERROR_FILE_COUNT} -eq 0 ]]; then
	echo "total: pass"
else 
	echo "total: fail"

	echo ""
	echo "发送邮件..."
	# 获取时间戳
	NOTIFY_TOKEN=$(date "+%Y-%m-%d %H:%M:%S")
	NOTIFY_TOKEN=$(echo -n "${NOTIFY_TOKEN}" | openssl enc -aes-128-cbc -e -a -pass pass:mail-send-key -nosalt)

	NOTIFY_URL="http://10.37.64.97/mail/send.json"
	curl \
	-F "receiver=14121612@suning.com" \
	-F "subject=${JOB_NAME}" \
	-F "content=admin_rsync_files_check error!!!<br>http://10.37.64.97/jenkins/job/${JOB_NAME}/${BUILD_NUMBER}/console" \
	-F "token=${NOTIFY_TOKEN}" \
	${NOTIFY_URL}
fi
