#!/bin/sh

set -e #-v -x

export LANG=zh_CN.UTF-8

#脚本所在位置
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

PROJECT_NAME="SuningEBuy"

POD_BUSS_SPEC_PATH=${HOME}'/.cocoapods/repos/SNEBuy_buss_repos'

if [ ! ${WORKSPACE} ]; then
WORKSPACE=${SCRIPT_DIR}
cd ${WORKSPACE}
echo "using WORKSPACE:${WORKSPACE}"
fi

PodfilePath="${WORKSPACE}/${PROJECT_NAME}/Podfile"
DerivedDataPath="${WORKSPACE}/${PROJECT_NAME}/DerivedData/"

SVN=svn

echo '1:check parameters and set upload name'

#设置打包名称
setUploadName() {
	if [ "${UPLOAD_NAME}" != "" ]; then
			echo "已经设置打包名称${UPLOAD_NAME}"
			return
	fi

	TestUploadName="功能测试包"
	if ${using_code_snsearch}; then 
			TestUploadName="${TestUploadName}A"
	fi
	
	if ${using_code_snproduct}; then 
			TestUploadName="${TestUploadName}B"
	fi
	
	if ${using_code_snpingou}; then 
			TestUploadName="${TestUploadName}C"
	fi
	
	if ${using_code_snpm}; then 
			TestUploadName="${TestUploadName}D"
	fi
	
	if ${using_code_snlogin}; then 
			TestUploadName="${TestUploadName}E"
	fi
	
	if ${using_code_snsl}; then 
			TestUploadName="${TestUploadName}F"
	fi
	
	if ${using_code_snlive}; then 
			TestUploadName="${TestUploadName}G"
	fi
	
	if ${using_code_snmk}; then 
			TestUploadName="${TestUploadName}H"
	fi

  if ${using_code_snhwg}; then
          TestUploadName="${TestUploadName}J"
  fi

    if ${using_code_snmember}; then
    TestUploadName="${TestUploadName}K"
    fi

    if ${using_code_snchannel}; then
    TestUploadName="${TestUploadName}L"
    fi
    
		
	if [ "${TestUploadName}" = "功能测试包ABCDEFGHIJKL" ]; then
			echo "编译全代码包"
			TestUploadName=""			
	fi
	
	if [ "${TestUploadName}" = "" ]; then
			if [ "${UPLOAD_NAME}" = "" ]; then
			
				if ${SuningEMall}; then
					UPLOAD_NAME="官方定位分享包2"
				else
					UPLOAD_NAME="官方测试包2"
				fi
			fi
	else
		UPLOAD_NAME=${TestUploadName}
	fi
	
	echo "final upload name is ${UPLOAD_NAME}"
}

# 输入参数检查
checkBuildParameter() {
	BUILD_PARAMETER=""
	if ${pre}; then
		BUILD_PARAMETER="${BUILD_PARAMETER} -pre"
	fi
	if ${xgpre}; then
		BUILD_PARAMETER="${BUILD_PARAMETER} -xgpre"
	fi
	if ${prd}; then
		BUILD_PARAMETER="${BUILD_PARAMETER} -prd"
	fi
	if ${sit}; then
		BUILD_PARAMETER="${BUILD_PARAMETER} -sit"
	fi
	if [ "${BUILD_PARAMETER}" = "" ]; then
		echo "请选择打包环境"
		exit 0
	fi
	
	echo "BUILD_PARAMETER = ${BUILD_PARAMETER} and pre=${pre} xgpre=${xgpre} prd=${prd} sit=${sit}"

}

#设置打包名称
setUploadName

#检查打包环境及命名
checkBuildParameter




echo '2:check svn code'

if [ -d ${PROJECT_NAME} ]; then
	echo "已经存在主工程文件夹"
else
	git clone http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git ${PROJECT_NAME}
fi

cd ${WORKSPACE}/${PROJECT_NAME}
git checkout .
git checkout "Dev_Br_${MainVersion}"
git pull



# updateAllCode
# clean
# "/Users/ebuy/.cocoapods/repos/SNEBuy_buss_repos" 
# "/Users/ebuy/.cocoapods/repos/SNEBuy_repos"
USER=`whoami`
for directory in "/Users/${USER}/.cocoapods/repos/SNEBuy_buss_repos" \
  "/Users/${USER}/.cocoapods/repos/SNEBuy_repos" \
  "/Users/${USER}/.cocoapods/repos/SNEBuy_YFBSDK" \
  "/Users/${USER}/.cocoapods/repos/SNEBuy_YFBWallet"
do
	echo "clean ${directory}..."
	if [ -d ${directory} ]; then
		cd ${directory}
		${SVN} cleanup
		echo "finish"
	fi
done

for directory in "${WORKSPACE}/${PROJECT_NAME}/SNDynamicFrameworks/${VersionNum}" \
  "${WORKSPACE}/${PROJECT_NAME}/snpm/" \
  "${WORKSPACE}/${PROJECT_NAME}/snlive/" \
  "${WORKSPACE}/${PROJECT_NAME}/snlogin/" \
  "${WORKSPACE}/${PROJECT_NAME}/snproduct/" \
  "${WORKSPACE}/${PROJECT_NAME}/snpingou/" \
  "${WORKSPACE}/${PROJECT_NAME}/snsearch/" \
  "${WORKSPACE}/${PROJECT_NAME}/snsl/" \
  "${WORKSPACE}/${PROJECT_NAME}/snmk/" \
  "${WORKSPACE}/${PROJECT_NAME}/snhwg/"
do
	echo "clean ${directory}..."
	if [ -d ${directory} ]; then
		cd ${directory}
#		svn revert -R .
		echo "finish"
	fi
done

# 删除build目录2天前文件夹
for number in "2" \
	  "3" \
	  "4" \
	  "5" \
	  "6" \
	  "7" \
	  "8"
do
	day=`date -v-${number}d +"%Y-%m-%d"`
	directory="${WORKSPACE}/${PROJECT_NAME}/build/build_test_${day}"
	echo "rm -rf ${directory}*"
	rm -rf "${directory}"*
done

# update
cd ${WORKSPACE}/${PROJECT_NAME}/

rm -rf 	snhwg snlive snlogin snmember snmk snpgbase snpingou snpm snproduct snsearch snsl
bash ${WORKSPACE}/${PROJECT_NAME}/updateAllCode.sh


echo '3：根据配置选项修改podfile'

#修改Podfile并使用pod install生成工程
for flag in "using_code_snsearch" "using_code_snproduct" "using_code_snpm" "using_code_snlogin" "using_code_snsl" "using_code_snlive" "using_code_snmk" "using_code_snpingou" "using_code_snhwg" "using_code_snmember" "using_code_snchannel"
do
	flagValue=$(echo `eval echo '$'"${flag}"`)
	echo ${flagValue}
	echo "flag is ${flag}: ${flagValue}"
	echo "currentDir = $(pwd)"
	if ${flagValue};then
		
		echo "=========="
		sed -i '' "s/${flag} = false/${flag} = true/" ${PodfilePath}
	else
		echo "##########"
		sed -i '' "s/${flag} = true/${flag} = false/" ${PodfilePath}
	fi
done


echo '4:pod集成'

repo_update() {
    #将原先替换的Framework恢复回来，否则会存在svn update conflict可能
    ${SVN} revert -R ~/.cocoapods/repos/SNEBuy_buss_repos/BussLibs/
	# 清空之前pod生成文件
	rm -rf ${WORKSPACE}/${PROJECT_NAME}/Podfile.lock Pods SuningEBuy.xcworkspace
	#生成新的pod文件
	bash ${WORKSPACE}/${PROJECT_NAME}/repo-update.sh
}

repo_update

echo '5:根据选项打包framework'
#生成保存打包framework用的文件夹
if [ -d "${WORKSPACE}/${PROJECT_NAME}/ArchiveFrameworks" ]; then
 	echo "ArchiveFrameworks文件夹已经存在"
else
	echo "创建ArchiveFrameworks文件夹"
	mkdir ${WORKSPACE}/${PROJECT_NAME}/ArchiveFrameworks
fi

for scheme in "SNLive" "SNPM" "SNMBLoginRegister" "SNSHProductDetail" "SNSHSearch" "SNSL" "SNMK" "SNPMPinGou" "SNHWG" "SNMBMember" "SNChannel"
do
if  [ ${scheme} = "SNLive" ] && ${using_code_snlive}
then
 		BuildProjectFoldName="snlive"
 		ChildProjectRootFoldName=${scheme}
 		
elif [ ${scheme} = "SNPM" ] && $using_code_snpm 
then
		BuildProjectFoldName="snpm"
		ChildProjectRootFoldName=${scheme}
		
elif [ ${scheme} = "SNMBLoginRegister" ] && $using_code_snlogin 
then
		BuildProjectFoldName="snlogin"
		ChildProjectRootFoldName=${scheme}
		
elif [ ${scheme} = "SNPMPinGou" ] && $using_code_snpingou 
then
		BuildProjectFoldName="snpingou"
		ChildProjectRootFoldName="SNPMHIBUY"
		
elif [ ${scheme} = "SNSHProductDetail" ] && $using_code_snproduct
then
		BuildProjectFoldName="snproduct"
		ChildProjectRootFoldName=${scheme}
		
elif [ ${scheme} = "SNSHSearch" ] && $using_code_snsearch
then
		BuildProjectFoldName="snsearch"
		ChildProjectRootFoldName=${scheme}
		
elif [ ${scheme} = "SNSL" ] && $using_code_snsl
then
		BuildProjectFoldName="snsl"
		ChildProjectRootFoldName=${scheme}
		
elif [ ${scheme} = "SNMK" ] && $using_code_snmk
then
		BuildProjectFoldName="snmk"
		ChildProjectRootFoldName=${scheme}
elif [ ${scheme} = "SNHWG" ] && $using_code_snhwg
then
        BuildProjectFoldName="snhwg"
        ChildProjectRootFoldName="snhwg"
elif [ ${scheme} = "SNMBMember" ] && $using_code_snmember
then
        BuildProjectFoldName="snmember"
        ChildProjectRootFoldName=${scheme}
elif [ ${scheme} = "SNChannel" ] && $using_code_snchannel
then
        BuildProjectFoldName="snchannel"
        ChildProjectRootFoldName=${scheme}
else
	continue
fi

ReleaseFrameworkPath="${DerivedDataPath}Build/Products/Release-iphoneos/${scheme}.framework"
DebugSimulatorFrameworkPath="${DerivedDataPath}Build/Products/Debug-iphonesimulator/${scheme}.framework"
#修改子工程的build号为当前打包日期，方便版本跟踪
INFOPLIST_FILE="${WORKSPACE}/${PROJECT_NAME}/${BuildProjectFoldName}/${ChildProjectRootFoldName}/Info.plist"

cd ${WORKSPACE}/${PROJECT_NAME}/${BuildProjectFoldName}

#重置原先的Info.plist文件，并且确保版本及代码最新的
git checkout ${INFOPLIST_FILE}
git checkout "Dev_Br_${MainVersion}"
git pull

SchemeVersionNum=$(git log --pretty=format:"%h" -1)  #$(svn info --show-item revision ${WORKSPACE}/${PROJECT_NAME}/${BuildProjectFoldName}/${VersionNum}/)
cd ${WORKSPACE}/${PROJECT_NAME}

echo "${scheme} git commit 版本号是：${SchemeVersionNum}"
echo "${scheme} git branch 分支是：$(git branch -l)"

#framework打包完成的文件路径
BuildFrameworkPath="${WORKSPACE}/${PROJECT_NAME}/ArchiveFrameworks/${scheme}_${SchemeVersionNum}.framework"
#检查文件夹路径
FrameworkReplaceFoldPath="${POD_BUSS_SPEC_PATH}/BussLibs/${scheme}/${VersionNum}"
#framework放到podfile里的路径
FrameworkReplacePodPath="${POD_BUSS_SPEC_PATH}/BussLibs/${scheme}/${VersionNum}/${scheme}.framework"

#检查缓存的对应svn版本号framework是否存在
echo "framework文件备份路径path = ${BuildFrameworkPath}"
if [ -e $BuildFrameworkPath ]; then
		echo "===== 直接复制命令 cp -r ${BuildFrameworkPath} ${FrameworkReplacePodPath}"
		rm -rf ${FrameworkReplacePodPath}
		cp -rf ${BuildFrameworkPath}/ ${FrameworkReplacePodPath}
		echo "已经存在文件${BuildFrameworkPath},跳过编译"
		continue;
else
		echo "不存在文件${BuildFrameworkPath},需要编译"
		
		echo "删除旧的缓存framework文件"
		for file in $(ls -d ${WORKSPACE}/${PROJECT_NAME}/ArchiveFrameworks/${scheme}_*.framework)
		do 
		echo "------------删除旧的framework:${file}"
		rm -rf ${file}; 
		done
fi

echo "=========== FrameworkReplacePodPath is ${FrameworkReplacePodPath}"


echo "INFOPLIST_FILE = ${INFOPLIST_FILE}"
buildNumber=$(date +%Y%m%d%H%M)
echo "buildNumber=${buildNumber}"
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion $buildNumber" "$INFOPLIST_FILE"

#开始正式打包
xcodebuild -workspace SuningEBuy.xcworkspace -scheme ${scheme} -configuration Release -derivedDataPath ${DerivedDataPath} clean build

#复制到当前目录的备份文件夹里和pod对应版本路径里
echo "ls ${ReleaseFrameworkPath}"
ls ${ReleaseFrameworkPath}

echo "===== 备份复制命令 cp -r ${ReleaseFrameworkPath} ${BuildFrameworkPath}"
rm -rf ${BuildFrameworkPath}
cp -rf ${ReleaseFrameworkPath}/ ${BuildFrameworkPath}

if [ -e ${FrameworkReplaceFoldPath} ]; then
		echo "FrameworkReplaceFoldPath文件夹已经存在"
else
		mkdir ${FrameworkReplaceFoldPath}
fi

echo "===== 替换复制命令 cp -r ${ReleaseFrameworkPath} ${FrameworkReplacePodPath}"
rm -rf ${FrameworkReplacePodPath}
cp -rf ${ReleaseFrameworkPath} ${FrameworkReplacePodPath}


if ${BuildGeneralFramework}
then
echo "===== 打包通用的framework"
xcodebuild -workspace SuningEBuy.xcworkspace -scheme ${scheme} -sdk iphonesimulator -derivedDataPath ${DerivedDataPath} clean build
lipo -create "${ReleaseFrameworkPath}/${scheme}" "${DebugSimulatorFrameworkPath}/${scheme}" -o "${BuildFrameworkPath}/${scheme}"
fi
done

#build成功通用的framework,需要做什么样的处理
if ${BuildGeneralFramework}
then 
echo "成功build framework"
fi

echo '6:修改podfile里使用代码全部为false,执行一下pod install'

#修改Podfile并使用pod install生成工程
for flag in "using_code_snsearch" "using_code_snproduct" "using_code_snpm" "using_code_snlogin" "using_code_snsl" "using_code_snlive" "using_code_snmk"  "using_code_snpingou" "using_code_snhwg" "using_code_snmember" "using_code_snchannel"
do
		echo "修改Podfile里${flag}=false"
		sed -i '' "s/${flag} = true/${flag} = false/" ${PodfilePath}
done

echo '7:再次执行第4步'

# 清空之前pod生成文件

rm -rf ${WORKSPACE}/${PROJECT_NAME}/Podfile.lock Pods SuningEBuy.xcworkspace

${JENKINS_POD} install --no-repo-update
		
echo '8:执行ipa-test.sh脚本，正式打包'
# ipa-test
cd ${WORKSPACE}/${PROJECT_NAME}/
if ${SuningEMall}; then
	echo "2:打包命令:${WORKSPACE}/${PROJECT_NAME}/ipa-test-bundleId.sh ${BUILD_PARAMETER} -u -name--${UPLOAD_NAME} -force--enterprise"
	bash ${WORKSPACE}/${PROJECT_NAME}/ipa-test-bundleId.sh ${BUILD_PARAMETER} -u -name--${UPLOAD_NAME} -force--enterprise
else
	echo "2:打包命令:${WORKSPACE}/${PROJECT_NAME}/ipa-test.sh ${BUILD_PARAMETER} -u -name--${UPLOAD_NAME} -force--enterprise"
	bash ${WORKSPACE}/${PROJECT_NAME}/ipa-test.sh ${BUILD_PARAMETER} -u -name--${UPLOAD_NAME} -force--enterprise
fi


