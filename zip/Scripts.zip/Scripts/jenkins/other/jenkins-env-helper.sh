# #!/bin/bash
# jenkins_env_helper.sh
# 作用
# jenkins上总是因为一些环境没配置好而打包报错，这儿弄个脚本统一检查下，方便些
# 1.依赖的证书是否存在
# 2.机器是否已经授权git、codesign始终允许访问keychain
# 3.pod
# 	1.2.0是否安装
# 	1.8.4是否安装
# 4.xcpretty

# 环境
SCRIPT_DIR="$(cd `dirname $0`; pwd)"
cd ${SCRIPT_DIR}

#### 1.依赖的证书是否存在
# 数据格式
# CERTIFICATE_INFO=(
#     "CERTIFICATE_NAME"  				# 名称
#     "PROVISIONING_PROFILE"  			# PROVISIONING_PROFILE
#     "PROVISIONING_PROFILE_SPECIFIER"	# CERTIFICATE_PROVISIONING_PROFILE_SPECIFIER
#     "DEVELOPMENT_TEAM"       			# DEVELOPMENT_TEAM
#     "CODE_SIGN_IDENTITY"              # CODE_SIGN_IDENTITY
#     "CODE_SIGN_IDENTITY_SPECIFIER"    # CODE_SIGN_IDENTITY_SPECIFIER
# )
#
ENTERPRISE_CERTIFICATE_C_INFO=(
	"企业证书C"
	"6ef5a844-71fe-40fb-b799-c2688cad842b"
	"SuningEnterprise"
	"5E2PGY2377"
	"011EBD34F82EE293AF72D5AFA739092C0932433A"
	"iPhone Distribution: Suning Appliance Co., Ltd."
)
TESTWA_CERTIFICATE_INFO=(
	"蛙测开发证书"
	"e531efb2-5da6-40c4-9cef-a5b508bf7c43"
	"testwa_phone"
	"J7F2VA5FRW"
	"EC35DE7318A386EDAEE3FC1821F076DA7E8AD18A"
	"iPhone Developer: paifeng cheng"
)
ALL_CERTIFICATE_INFO_ARRAY=(
	ENTERPRISE_CERTIFICATE_C_INFO
	TESTWA_CERTIFICATE_INFO
)
for CERTIFICATE_INFO in ${ALL_CERTIFICATE_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
	eval CERTIFICATE_NAME=\${${CERTIFICATE_INFO}[0]}
    eval PROVISIONING_PROFILE=\${${CERTIFICATE_INFO}[1]}
    eval PROVISIONING_PROFILE_SPECIFIER=\${${CERTIFICATE_INFO}[2]}
    eval DEVELOPMENT_TEAM=\${${CERTIFICATE_INFO}[3]}
    eval CODE_SIGN_IDENTITY=\${${CERTIFICATE_INFO}[4]}
    eval CODE_SIGN_IDENTITY_SPECIFIER=\${${CERTIFICATE_INFO}[5]}

    echo ""
    echo "check ${CERTIFICATE_NAME}..."
    RESULT_COUNT=0
    # 检查mobileprovision
    if [[ ! -e ~/Library/MobileDevice/Provisioning\ Profiles/${PROVISIONING_PROFILE}.mobileprovision ]]; then
    	echo "error: not found mobileprovision"
    else
    	RESULT_COUNT=$((${RESULT_COUNT}+1))
    fi
    # 检查证书
    #   5) F4938E011FE9D84CF8140CFB700B8654A77F215C "iPhone Distribution: Suning Appliance Co., Ltd."
	if [[ "$(security find-identity -v -p codesigning | grep "${CODE_SIGN_IDENTITY}")" = "" ]]; then
		echo "error: not found certificate"
	else
		RESULT_COUNT=$((${RESULT_COUNT}+1))
	fi
	# 结果
	if [[ ${RESULT_COUNT} -lt 2 ]]; then
		echo "fail"
	else
		echo "pass"
	fi
done

#### 2.机器是否已经授权git、codesign始终允许访问keychain
# 检查git pull
# 目的是看是否会显示弹窗授权git访问keychain
# 如果显示弹窗，输入电脑密码后选择总是允许
echo ""
echo "check git pull git.cnsuning.com"
cd ${SCRIPT_DIR}
CHECK_RESULT="0"
SN_REPO_PATH=""
for REPO_NAME in $(ls ${HOME}/.cocoapods/repos/ | grep SN)
do
	if [[ -d ${HOME}/.cocoapods/repos/${REPO_NAME}/.git ]]; then
		SN_REPO_PATH=${HOME}/.cocoapods/repos/${REPO_NAME}
		cd ${SN_REPO_PATH}
		# git pull
		echo " > git pull"
		git pull
		# /usr/bin/git pull
		if [[ -e /usr/bin/git ]]; then
			echo " > /usr/bin/git pull"
			/usr/bin/git pull
		fi
		# /usr/local/bin/git pull
		if [[ -e /usr/local/bin/git ]]; then
			echo " > /usr/local/bin/git pull"
			/usr/local/bin/git pull
		fi
		# /usr/local/git/bin/git pull
		if [[ -e /usr/local/git/bin/git ]]; then
			echo " > /usr/local/git/bin/git pull"
			/usr/local/git/bin/git pull
		fi
		CHECK_RESULT="1"
		break
	fi
done
if [[ "${SN_REPO_PATH}" = "" ]]; then
	echo "error: not found any sn git project"
fi
if [[ "${CHECK_RESULT}" = "0" ]]; then
	echo "error: fail"
else
	echo "pass"
fi

echo ""
echo "check git clone opensource.cnsuning.com"
# 检查opensource访问权限
GIT_OPENSOURCE_URL="http://opensource.cnsuning.com/suningebuy/private-project.git"
if [[ -e /usr/bin/git ]]; then
	rm -rf private-project
	echo " > /usr/bin/git clone ${GIT_OPENSOURCE_URL}"
	/usr/bin/git clone ${GIT_OPENSOURCE_URL}
fi
if [[ -e /usr/local/bin/git ]]; then
	rm -rf private-project
	echo " > /usr/local/bin/git clone ${GIT_OPENSOURCE_URL}"
	/usr/local/bin/git clone ${GIT_OPENSOURCE_URL}
fi
if [[ -e /usr/local/git/bin/git ]]; then
	rm -rf private-project
	echo " > /usr/local/git/bin/git clone ${GIT_OPENSOURCE_URL}"
	/usr/local/git/bin/git clone ${GIT_OPENSOURCE_URL}
fi
rm -rf private-project

# 检查codesign
# 目的是看是否会显示弹窗授权codesign访问keychain
# 如果显示弹窗，输入电脑密码后选择总是允许
echo ""
echo "check codesign"
cd ${SCRIPT_DIR}
if [[ "${SN_REPO_PATH}" = "" ]]; then
	echo "error: not found any sn git project"
else
	EXECUTEABLE_FILE_PATH=""
	# .framework
	if [[ "${EXECUTEABLE_FILE_PATH}" = "" ]]; then
		FRAMEWORK_PATH=$(find ${SN_REPO_PATH} -name *.framework | head -1)
		if [[ "${FRAMEWORK_PATH}" != "" ]]; then
			FRAMEWORK_NAME=$(basename ${FRAMEWORK_PATH})
			FRAMEWORK_NAME=${FRAMEWORK_NAME%.framework}
			EXECUTEABLE_FILE_PATH=${FRAMEWORK_PATH}/${FRAMEWORK_NAME}
		fi
	fi
	# .a
	if [[ "${EXECUTEABLE_FILE_PATH}" = "" ]]; then
		LIBRARY_PATH=$(find ${SN_REPO_PATH} -name *.a | head -1)
		if [[ "${FRAMEWORK_PATH}" != "" ]]; then
			EXECUTEABLE_FILE_PATH=${LIBRARY_PATH}
		fi
	fi
fi
# 检测
if [[ "${EXECUTEABLE_FILE_PATH}" = "" ]]; then
	echo "error: not found any executeable file"
else
	mkdir -p tmpSign
	cp -f ${EXECUTEABLE_FILE_PATH} tmpSign/test-sdk
	for CERTIFICATE_INFO in ${ALL_CERTIFICATE_INFO_ARRAY[@]};  # ${}里面不能有空格
	do 
		eval CERTIFICATE_NAME=\${${CERTIFICATE_INFO}[0]}
	    eval PROVISIONING_PROFILE=\${${CERTIFICATE_INFO}[1]}
	    eval PROVISIONING_PROFILE_SPECIFIER=\${${CERTIFICATE_INFO}[2]}
	    eval DEVELOPMENT_TEAM=\${${CERTIFICATE_INFO}[3]}
	    eval CODE_SIGN_IDENTITY=\${${CERTIFICATE_INFO}[4]}
	    eval CODE_SIGN_IDENTITY_SPECIFIER=\${${CERTIFICATE_INFO}[5]}

	    echo " > codesign -f -s \"${CODE_SIGN_IDENTITY}\" tmpSign/test-sdk"
	    codesign -f -s "${CODE_SIGN_IDENTITY}" tmpSign/test-sdk
	done
	rm -rf tmpSign/
	echo "pass"
fi

#### 3.pod
echo ""
echo "check pod 1.2.0"
if [[ "$(pod _1.2.0_ --version)" != "1.2.0" ]]; then
	echo "error: not found pod 1.2.0"
else
	echo "pass"
fi

echo ""
echo "check pod 1.8.4"
if [[ "$(pod _1.8.4_ --version)" != "1.8.4" ]]; then
	echo "error: not found pod 1.8.4"
else
	echo "pass"
fi

#### 4.xcpretty
echo ""
echo "check xcpretty"
if ! command -v xcpretty > /dev/null; then
	echo "error: not found xcpretty"
else
	echo "pass"
fi

