#!/bin/bash
# admin_log_check
# 检查jenkins build的日志，是否有执行报错
# 定时执行，如果有报错看是否可以发邮件提醒

set -e

# 不设置代理
http_proxy=
https_proxy=

function shouldSkip() {
	ERROR_LINE=$1
	SHOULD_SKIP=false
	# - (void)commentMultiPostSuccess:(BOOL)isSuccess dto:(nullable SNSLCommentPublishedSuccessDTO *)dto rewardMsg:(NSString *)message error:(NSString *)errorMsg;
	if [[ ${ERROR_LINE} =~ "- (" ]]; then
		SHOULD_SKIP=true
	fi
	# [self.tagListDelegate fetchTagCommentListSuccess:NO data:nil reviewType:self.reviewType commentType:self.commentType error:self.errorMsg];
	if [[ ${ERROR_LINE} =~ "];" ]]; then
		SHOULD_SKIP=true
	fi
	# [contactStore enumerateContactsWithFetchRequest:fetchRequest error:nil usingBlock:^(CNContact * _Nonnull contact, BOOL * _Nonnull stop) {
	if [[ ${ERROR_LINE} =~ ") {" ]]; then
		SHOULD_SKIP=true
	fi
	# error: 不打包, last build is in 15 min
	if [[ ${ERROR_LINE} =~ "error: 不打包" ]]; then
		SHOULD_SKIP=true
	fi
	# error: pathspec 'Dev_Br_840' did not match any file(s) known to git
	if [[ ${ERROR_LINE} =~ "error: pathspec" ]] && [[ ${ERROR_LINE} =~ "did not match any file(s) known to git" ]]; then
		SHOULD_SKIP=true
	fi
	# /Users/apple/.jenkins-slave/workspace/ebuy-sub-860/SNProjects/SNCommon/SNCommon/Componets/SNCrashProtect/SNExceptonGuardRequest.m:42:41: 'sendSynchronousRequest:returningResponse:error:' is deprecated: first deprecated in iOS 9.0 - Use [NSURLSession dataTaskWithRequest:completionHandler:] (see NSURLSession.h [-Wdeprecated-declarations]
	if [[ ${ERROR_LINE} =~ ":error:" ]] && [[ ${ERROR_LINE} =~ ".m" ]]; then
		SHOULD_SKIP=true
	fi
	# error:(NSString *)errorMsg;
	if [[ ${ERROR_LINE} =~ "error:(NS" ]]; then
		SHOULD_SKIP=true
	fi
	
	# # 打包报错
	# # clang: error: linker command failed with exit code 1 (use -v to see invocation)
	# if [[ ${ERROR_LINE} =~ "clang: error:" ]]; then
	# 	SHOULD_SKIP=true
	# fi
	# # error: archive not found at path '/Users/apple/.jenkins-slave/workspace/SNFinance-Framework-830/build/build_test_2019-12-16_22_08/SuningEBuypre.xcarchive'
	# if [[ ${ERROR_LINE} =~ "error: archive not found" ]]; then
	# 	SHOULD_SKIP=true
	# fi
	# # The following build commands failed:
	# if [[ ${ERROR_LINE} =~ "The following build commands failed:" ]]; then
	# 	SHOULD_SKIP=true
	# fi

	echo ${SHOULD_SKIP}
}

# tmp-ebuy.txt
mkdir -p /tmp/ebuy
# 失败历史log
TMP_FAIL_HISTORY_FILE_PATH="/tmp/ebuy/tmp-admin_log_check-fail-history.txt"
touch ${TMP_FAIL_HISTORY_FILE_PATH}

# ifs设置为换行符
OLD_IFS=${IFS}
IFS='
'

# 查找最近一天内有修改的log
ERROR_LOG_COUNT=0
ERROR_CHECK_COUNT=0
MAX_ERROR_CHECK_COUNT=100
for BUILD_LOG_PATH in $(find /root/.jenkins/jobs -name log -mtime -1)
do
	# admin_log_check本身包含报错，它的日志不处理
	if [[ ${BUILD_LOG_PATH} =~ "admin_log_check" ]]; then
		continue
	fi

	IS_NEW_ERROR_LOG=false

	LOG_ARRAY=()
	LOG_ARRAY=(${LOG_ARRAY[*]} "processing ${BUILD_LOG_PATH}")

	# 报错
	# 1.error:
	# 	rsync error: some files could not be transferred (code 23) at /BuildRoot/Library/Caches/com.apple.xbs/Sources/rsync/rsync-52.200.1/rsync/main.c(996) [sender=2.6.9]
	# 2.fatal:
	# 	fatal: could not read Username for 'http://git.cnsuning.com': Device not configured
	# 	remote: HTTP Basic: Access denied fatal: Authentication failed for 'http://git.cnsuning.com/snioshomepage/snioshomepage.git/'
	# 3.failed
	# 	rsync: link_stat "/Users/apple/.jenkins-slave/workspace/SuningEBuy-Framework-830/SNProjects/SNHomePage/.DS_Store" failed: No such file or directory (2)
	# 4.sed: -i may not be used with stdin
	# 5.command not found
	# 5.Cloning into  
	# 	说明:git clone代码输出日志 需要监控，防止clone多次消耗流量且耗时
	# 	Cloning into '/Users/wangbin/Desktop/苏宁易购/code2/suningebuyES/Scripts/jenkins/SuningEBuy/SNProjects/SNSL'...
	CHECK_STRING_ARRAY=(
		"error:"
		"fatal:"
		"failed:"
		"sed: -i may not be used with stdin"
		"command not found"
		"Cloning into"
	)
	for CHECK_STRING in ${CHECK_STRING_ARRAY[*]}; do
		LOG_ARRAY=(${LOG_ARRAY[*]} "  ")
		LOG_ARRAY=(${LOG_ARRAY[*]} "  检测 ${CHECK_STRING}")
	    for ERROR_LINE in $(cat ${BUILD_LOG_PATH} | grep "${CHECK_STRING}")
	    do
	    	# 检查次数+1
			ERROR_CHECK_COUNT=$((${ERROR_CHECK_COUNT}+1))
			if [[ ${ERROR_CHECK_COUNT} -gt ${MAX_ERROR_CHECK_COUNT} ]]; then
				echo "检查次数超过最大上限-${MAX_ERROR_CHECK_COUNT}，break..."
				break
			fi

			# 检查
	    	SHOULD_SKIP=$(shouldSkip ${ERROR_LINE})	
	    	# 不能skip，打印报错
	    	if [[ ! ${SHOULD_SKIP} = "true" ]]; then
	    		IS_NEW_ERROR_LOG=true
	    		LOG_ARRAY=(${LOG_ARRAY[*]} "    ${ERROR_LINE}")
	    	fi
	    done
	done

	# 失败build的url
	ERROR_JOB_NAME=$(echo ${BUILD_LOG_PATH} | cut -d "/" -f 5)
	ERROR_BUILD_NUMBER=$(echo ${BUILD_LOG_PATH} | cut -d "/" -f 7)
	ERROR_BUILD_URL="http://10.37.64.97/jenkins/job/${ERROR_JOB_NAME}/${ERROR_BUILD_NUMBER}/console"

	# 失败文件中已有这个url，则不是新的error
	if ${IS_NEW_ERROR_LOG};then
		if [[ "$(cat ${TMP_FAIL_HISTORY_FILE_PATH} | grep ${ERROR_BUILD_URL})" != "" ]]; then
			IS_NEW_ERROR_LOG=false
		fi
	fi

	# 新的error
	if ${IS_NEW_ERROR_LOG};then
		# 失败次数+1
		ERROR_LOG_COUNT=$((${ERROR_LOG_COUNT}+1))

		# 保存build url到log文件
		echo "${ERROR_BUILD_URL}" >> ${TMP_FAIL_HISTORY_FILE_PATH}

		# log时间
		LOG_TIME=$(stat ${BUILD_LOG_PATH} | grep "Modify:")
		LOG_TIME=${LOG_TIME#*Modify: }
		LOG_TIME=${LOG_TIME%.*}

		# 打印log
		LOG_ARRAY=("${LOG_TIME}  ${ERROR_BUILD_URL}" ${LOG_ARRAY[*]})
		LOG_ARRAY=("  " ${LOG_ARRAY[*]})
		for LOG_STRING in ${LOG_ARRAY[*]}; do
			echo ${LOG_STRING}
		done
	fi
done

# 设置ifs回原来值
IFS=${OLD_IFS}

# 日志检测，是否出现新的报错
echo ""
echo "检测是否出现新的报错"
echo "ERROR_LOG_COUNT:	${ERROR_LOG_COUNT}"

if [[ ${ERROR_LOG_COUNT} -eq 0 ]]; then
	echo "没有新的报错"
else 
	echo "有新的报错，发送邮件通知..."
	# 获取时间戳
	NOTIFY_TOKEN=$(date "+%Y-%m-%d %H:%M:%S")
	NOTIFY_TOKEN=$(echo -n "${NOTIFY_TOKEN}" | openssl enc -aes-128-cbc -e -a -pass pass:mail-send-key -nosalt)

	NOTIFY_URL="http://10.37.64.97/mail/send.json"
	curl \
	-F "receiver=14121612@suning.com" \
	-F "subject=${JOB_NAME}" \
	-F "content=new build error found,fix it!!!<br>http://10.37.64.97/jenkins/job/${JOB_NAME}/${BUILD_NUMBER}/console" \
	-F "token=${NOTIFY_TOKEN}" \
	${NOTIFY_URL}
fi

