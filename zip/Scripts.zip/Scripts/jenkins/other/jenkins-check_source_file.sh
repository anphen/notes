#!/bin/bash
# jenkins-sdk-framework.sh
# 代码检查脚本
# jenkins job
# 1.SuningEBuy-Local-CheckSourceFile-9524

#### 用法，同时也是jenkins build参数
#### SuningEBuy-Local-CheckSourceFile-9524
# export build=true
# # 开始
# bash /Scripts/jenkins/other/jenkins-check_source_file.sh

# 模拟jenkins参数检查
if [[ -z ${JOB_NAME} ]]; then
	echo "error: JOB_NAME not found"
	exit 1
fi

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

export LANG=zh_CN.UTF-8
PATH=${PATH}:/usr/local/bin
if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi

#### 变量
echo ""
echo "step 1:更新主工程代码..."
# WORKSPACE默认值
# PROJECT_PATH,最终打包目录
if [ -z ${WORKSPACE} ]; then
	# JOB_NAME
	cd ${SCRIPT_DIR}/../../../../
	WORKSPACE=$(pwd)/${JOB_NAME}
	mkdir -p ${WORKSPACE}
	PROJECT_PATH="${WORKSPACE}"
else
	# 兼容研发云Delete workspace when build is done
	PROJECT_PATH=${HOME}/.suning/build/${JOB_NAME}
	mkdir -p ${PROJECT_PATH}
fi
cd ${PROJECT_PATH}

PROJECT_NAME="SuningEBuy"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_VERSION="830"
# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
	# jenkins打包 SuningEBuy-840
	GIT_BRANCH_VERSION=${JOB_NAME##*-}
elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
	# 研发云打包 ebuy_840
	GIT_BRANCH_VERSION=${JOB_NAME##*_}
fi
GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

# 拉取代码
cd ${PROJECT_PATH}
if [ ! -d ${PROJECT_PATH}/.git ]; then
	${GIT} init
	${GIT} remote add origin ${GIT_URL}
	${GIT} fetch
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
if [[ "$(${GIT} status)" =~ "unmerged" ]]; then
	${GIT} reset --hard HEAD
fi
${GIT} checkout . 
# 删除Untracked files
${GIT} clean -fd
# 拉取代码
${GIT} pull
# 切换分支
${GIT} checkout ${GIT_BRANCH_NAME}
# 拉取代码
${GIT} pull

#### 打包前处理
echo ""
echo "step 2:打包前处理..."
# 清理归档文件...
echo ""
echo "1) clean..."
bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-clean-helper.sh

echo ""
echo "开始打包🚀 🚀 🚀"

#### 参数
echo ""
echo "step 3:参数..."
echo "JENKINS_TYPE:      	${JENKINS_TYPE}"
echo "WORKSPACE:      	${WORKSPACE}"
echo "PROJECT_PATH: 		${PROJECT_PATH}"
echo "JOB_NAME:         	${JOB_NAME}"
echo "GIT_URL:          	${GIT_URL}"
echo "PROJECT_NAME:     	${PROJECT_NAME}"
echo "GIT_BRANCH_NAME:  	${GIT_BRANCH_NAME}"

#### pull代码
echo ""
echo "step 4:pull code..."
# updateAllCode
cd ${PROJECT_PATH}/
echo "cmd: bash ${PROJECT_PATH}/updateAllCode.sh -revert--subproject"
bash ${PROJECT_PATH}/updateAllCode.sh -revert--subproject
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# repo-update
echo "cmd: repo-update.sh -skip--pod..."
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/repo-update.sh -checkupdate -skip--pod -revert--subproject
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### pod集成
echo ""
echo "step 5:pod集成..."
# 清空之前pod生成文件
cd ${PROJECT_PATH}/
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
for PBXPROJ_PATH in `find ${PROJECT_PATH}/SNProjects -name project.pbxproj`
do
    sed -i "" "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
done

# 修改Podfile
echo ""
echo "修改Podfile..."
PODFILE_PATH=${PROJECT_PATH}/Podfile
# 统一修改为true
sed -i "" "/^\$using_code_.*=.*/s/=.*false/= true/" ${PODFILE_PATH}
# 设置几个不需要为true的
sed -i "" "s/\$using_code_show3dsdk.*=.*/\$using_code_show3dsdk = false/" ${PODFILE_PATH}
sed -i "" "s/\$using_code_snarplatform.*=.*/\$using_code_snarplatform = false/" ${PODFILE_PATH}
sed -i "" "s/\$using_code_snarhomedesign.*=.*/\$using_code_snarhomedesign = false/" ${PODFILE_PATH}
# 打印
cat ${PODFILE_PATH} | grep "\$using_code_.*=.*true"

# repo-update
echo ""
echo "cmd: bash repo-update.sh -pod"
cd ${PROJECT_PATH}/
bash repo-update.sh -pod

#### 打包
echo ""
echo "step 6:检查代码..."
PYTHON3="python"
if [[ "$(which python3)" != "" ]]; then
    PYTHON3="python3"
fi
cd ${PROJECT_PATH}/Scripts
echo "> ${PYTHON3} -u newCheckSourceFile.py"
${PYTHON3} -u newCheckSourceFile.py

#### 生成归档文件，jenkins Copy Artifact Plugin
echo ""
echo "step 7:生成归档文件..."
# 列出build结果
echo "cmd: ls ${PROJECT_PATH}/Scripts/checkResult"
ls ${PROJECT_PATH}/Scripts/checkResult
# 拷贝checkResult文件到build-artifacts
BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
echo "cmd: zip -r ${BUILD_ARTIFACTS_PATH}/checkResult.zip checkResult >/dev/null 2>&1"
cd ${PROJECT_PATH}/Scripts
zip -r ${BUILD_ARTIFACTS_PATH}/checkResult.zip checkResult >/dev/null 2>&1
# 软连接到WORKSPACE下
ln -fs ${BUILD_ARTIFACTS_PATH} ${WORKSPACE}/
