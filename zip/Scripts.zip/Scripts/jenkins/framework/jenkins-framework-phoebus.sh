#!/bin/bash
# framework打包

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

export LANG=zh_CN.UTF-8
export PATH=/usr/local/bin:${PATH}
if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi

#### 更新主工程代码...
echo ""
echo "step 1:更新主工程代码..."
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

PROJECT_NAME="SuningEBuy"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_VERSION="830"
# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
	# jenkins打包 SuningEBuy-840
	GIT_BRANCH_VERSION=${JOB_NAME##*-}
elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
	# 研发云打包 ebuy_840
	GIT_BRANCH_VERSION=${JOB_NAME##*_}
fi
# 研发云流水线 origin/Dev_Br_850
if [[ "${GIT_BRANCH}" =~ "origin/" ]]; then
	GIT_BRANCH_VERSION=${GIT_BRANCH##*_}
fi
GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

# 拉取代码
cd ${WORKSPACE}
if [ ! -d ${WORKSPACE}/.git ]; then
	${GIT} init
	${GIT} remote add origin ${GIT_URL}
	${GIT} fetch
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
if [[ "$(git status)" =~ "unmerged" ]]; then
	${GIT} reset --hard HEAD
fi
${GIT} checkout . 
# 删除Untracked files
${GIT} clean -fd
# 切换分支
${GIT} checkout ${GIT_BRANCH_NAME}
# 拉取代码
${GIT} pull

#### 设置sdk打包参数...
export TASK_NAME="ebuy_framework_${GIT_BRANCH_VERSION}"
export USER_NAME="14121612"
export PASSWORD=""
if [[ -z ${PASSWORD} ]] && [[ -z ${RANDOM_IDENTIFIER_2020} ]]; then
	echo "error:not found PASSWORD"
	exit 1
fi
if [[ -z ${PASSWORD} ]] && [[ ! -z ${RANDOM_IDENTIFIER_2020} ]]; then
	# 如果没设置PASSWORD，则从${RANDOM_IDENTIFIER_2020}解密而来
	echo "${RANDOM_IDENTIFIER_2020}" > encrypt.txt
	openssl enc -aes-128-cbc -in encrypt.txt -d -a -out plain.txt -pass pass:123456
	PASSWORD=$(cat plain.txt;rm -f plain.txt;rm -f encrypt.txt)
fi

# 替换UPLOAD_NAME中的空格为空字符串，防止不能完整的带到研发云
UPLOAD_NAME=${UPLOAD_NAME/ /}

export BUILD_PARAMS=""
if ${using_code_sndynamicframeworks}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_sndynamicframeworks"
fi
if ${using_code_sncommon}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_sncommon"
fi
if ${using_code_snsearch}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snsearch"
fi
if ${using_code_snproduct}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snproduct"
fi
if ${using_code_snpingou}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snpingou"
fi
if ${using_code_snpm}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snpm"
fi
if ${using_code_snlogin}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snlogin"
fi
if ${using_code_snmember}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snmember"
fi
if ${using_code_snsl}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snsl"
fi
if ${using_code_snlive}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snlive"
fi
if ${using_code_snmk}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snmk"
fi
if ${using_code_snhwg}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snhwg"
fi
if ${using_code_snchannel}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snchannel"
fi
if ${using_code_snsm}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snsm"
fi
if ${using_code_snhome}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snhome"
fi
if ${using_code_snxdcc}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snxdcc"
fi
if ${using_code_snpw}; then
	export BUILD_PARAMS="${BUILD_PARAMS} using_code_snpw"
fi
if ${pre}; then
	export BUILD_PARAMS="${BUILD_PARAMS} pre"
fi
if ${xgpre}; then
	export BUILD_PARAMS="${BUILD_PARAMS} xgpre"
fi
if ${poc}; then
	export BUILD_PARAMS="${BUILD_PARAMS} poc"
fi
if ${prd}; then
	export BUILD_PARAMS="${BUILD_PARAMS} prd"
fi
if ${sit}; then
	export BUILD_PARAMS="${BUILD_PARAMS} sit"
fi
if ${SuningEMall}; then
	export BUILD_PARAMS="${BUILD_PARAMS} SuningEMall"
fi
if ${ARMV7}; then
	export BUILD_PARAMS="${BUILD_PARAMS} ARMV7"
fi
if ${ARM64}; then
	export BUILD_PARAMS="${BUILD_PARAMS} ARM64"
fi
if ${X86_64} && [[ ! -z ${X86_64} ]]; then
	export BUILD_PARAMS="${BUILD_PARAMS} X86_64"
fi
export BUILD_PARAMS="${BUILD_PARAMS} -UPLOAD_NAME--${UPLOAD_NAME}"
export BUILD_PARAMS="${BUILD_PARAMS} -SPECIAL_BRANCH--${SPECIAL_BRANCH}"
export BUILD_PARAMS="${BUILD_PARAMS} -BUILDID--${BUILD_NUMBER}"

#### 调用phoebus-web-helper.py 
echo ""
PYTHON3="python"
if [[ "$(which python3)" != "" ]]; then
    PYTHON3="python3"
fi
echo "> ${PYTHON3} -u ${PROJECT_PATH}/Scripts/phoebus/phoebus-web-helper.py "
${PYTHON3} -u ${PROJECT_PATH}/Scripts/phoebus/phoebus-web-helper.py 

