# #!/bin/bash
# clean

# 基本变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

PROJECT_PATH="$(cd ${SCRIPT_DIR}/../../; pwd)"

# git
GIT="git"

# svn
SVN="svn"

# clean git工程
# 主工程
# SNEBuy_buss_repos、SNEBuy_repos
# SNProjects下子工程
# SNPods下子工程
SUB_PROJECT_PATH_ARRAY=(${PROJECT_PATH})
SUB_PROJECT_PATH_ARRAY=(${SUB_PROJECT_PATH_ARRAY[*]} ${HOME}/.cocoapods/repos/SNEBuy_buss_repos)
SUB_PROJECT_PATH_ARRAY=(${SUB_PROJECT_PATH_ARRAY[*]} ${HOME}/.cocoapods/repos/SNEBuy_repos)
for SUB_PROJECT_NAME in $(ls ${PROJECT_PATH}/SNProjects)
do
	SUB_PROJECT_PATH=${PROJECT_PATH}/SNProjects/${SUB_PROJECT_NAME}
	if [[ -e ${SUB_PROJECT_PATH}/.git ]]; then
		SUB_PROJECT_PATH_ARRAY=(${SUB_PROJECT_PATH_ARRAY[*]} ${SUB_PROJECT_PATH})
	fi
done 
for SUB_PROJECT_NAME in $(ls ${PROJECT_PATH}/SNPods)
do
	SUB_PROJECT_PATH=${PROJECT_PATH}/SNPods/${SUB_PROJECT_NAME}
	if [[ -e ${SUB_PROJECT_PATH}/.git ]]; then
		SUB_PROJECT_PATH_ARRAY=(${SUB_PROJECT_PATH_ARRAY[*]} ${SUB_PROJECT_PATH})
	fi
done 
for SUB_PROJECT_PATH in ${SUB_PROJECT_PATH_ARRAY[*]}
do
	if [ -d ${SUB_PROJECT_PATH} ]; then
		if [[ "${SUB_PROJECT_PATH}" = "${PROJECT_PATH}" ]]; then
			echo ""
			echo "clean主工程..."
		elif [[ "$(basename ${SUB_PROJECT_PATH})" = "SNEBuy_buss_repos" ]]; then
			echo ""
			echo "clean pod repos..."
		elif [[ "$(basename ${SUB_PROJECT_PATH})" = "$(ls ${PROJECT_PATH}/SNProjects | head -1)" ]]; then
			echo ""
			echo "clean 子工程..."
		fi
		
		echo "clean ${SUB_PROJECT_PATH}..."
		cd ${SUB_PROJECT_PATH}
		# 放弃本地修改
		if [[ "$(${GIT} status)" =~ "unmerged" ]]; then
			${GIT} reset --hard HEAD
		fi
		${GIT} checkout . 
		# 删除Untracked files
		${GIT} clean -fd
		# # 切换分支
		# ${GIT} checkout ${GIT_BRANCH_NAME}
		echo "finish"
	fi
done

# clean svn工程
# SNEBuy_YFBSDK、SNEBuy_YFBWallet
for POD_REPO_PATH in "${HOME}/.cocoapods/repos/SNEBuy_YFBSDK" \
  "${HOME}/.cocoapods/repos/SNEBuy_YFBWallet"
do
	if [ -d ${POD_REPO_PATH} ]; then
		echo "clean ${POD_REPO_PATH}..."
		cd ${POD_REPO_PATH}
		${SVN} cleanup
		${SVN} revert . -R
		echo "finish"
	fi
done

echo ""
echo "clean build目录..."
# 删除工程打包build目录
BUILD_DIRECTORY="${PROJECT_PATH}/build"
if [ -e ${BUILD_DIRECTORY} ];then 
	echo "cmd: rm -rf ${BUILD_DIRECTORY}/*"
	rm -rf ${BUILD_DIRECTORY}/*
fi

# 删除${HOME}/.cocoapods/repos/SNEBuy_build_rsync目录7天未使用的文件夹
RSYNC_BUILD_DIRECTORY="${HOME}/.cocoapods/repos/SNEBuy_build_rsync"
if [ -e ${RSYNC_BUILD_DIRECTORY} ];then 
	echo ""
	echo "clean ${RSYNC_BUILD_DIRECTORY}..."
	# 删除7天未使用的文件夹
	for A_DIRECTORY in $(ls ${RSYNC_BUILD_DIRECTORY})
	do
		SAVE_MAX_DAYS="7"
		MODIFY_FILE_LIST_IN_MAX_DAYS=$(find ${RSYNC_BUILD_DIRECTORY}/${A_DIRECTORY} -mtime -${SAVE_MAX_DAYS})
	    if [[ ${MODIFY_FILE_LIST_IN_MAX_DAYS} = "" ]]; then
			echo "BUILD ${A_DIRECTORY} ${SAVE_MAX_DAYS}天内没修改，删除..."
			echo "cmd: rm -rf ${RSYNC_BUILD_DIRECTORY}/${A_DIRECTORY}"
			rm -rf ${RSYNC_BUILD_DIRECTORY}/${A_DIRECTORY}
	    fi
	done
fi

# 删除${HOME}/Library/Developer/Xcode/DerivedData目录3天未使用的文件夹
XCODE_BUILD_DIRECTORY="${HOME}/Library/Developer/Xcode/DerivedData"
if [ -e ${XCODE_BUILD_DIRECTORY} ];then 
	echo ""
	echo "clean ${XCODE_BUILD_DIRECTORY}..."
	# 删除3天未使用的文件夹
	for A_DIRECTORY in $(ls ${XCODE_BUILD_DIRECTORY})
	do
		SAVE_MAX_DAYS="3"
		MODIFY_FILE_LIST_IN_MAX_DAYS=$(find ${XCODE_BUILD_DIRECTORY}/${A_DIRECTORY} -mtime -${SAVE_MAX_DAYS})
	    if [[ ${MODIFY_FILE_LIST_IN_MAX_DAYS} = "" ]]; then
			echo "BUILD ${A_DIRECTORY} ${SAVE_MAX_DAYS}天内没修改，删除..."
			echo "cmd: rm -rf ${XCODE_BUILD_DIRECTORY}/${A_DIRECTORY}"
			rm -rf ${XCODE_BUILD_DIRECTORY}/${A_DIRECTORY}
	    fi
	done
fi

echo ""
echo "clean 归档文件..."
BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
mkdir -p ${BUILD_ARTIFACTS_PATH}
echo "cmd: rm -rf ${BUILD_ARTIFACTS_PATH}/*"
rm -rf ${BUILD_ARTIFACTS_PATH}/*

# 如果有${HOME}/.jenkins-slave/workspace文件夹，就清理
# 研发云打包不需要清理
for JENKINS_WORKSPACE_DIRECTORY in "${HOME}/.jenkins-slave/workspace" \
  "${HOME}/jenkins/prd/workspace" \
  "${HOME}/.suning/build"
do
	if [[ -d ${JENKINS_WORKSPACE_DIRECTORY} ]]; then
		echo ""
		echo "clean ${JENKINS_WORKSPACE_DIRECTORY}..."
		# 删除.jenkins-slave下3天没使用的workspace
		for A_DIRECTORY in $(ls ${JENKINS_WORKSPACE_DIRECTORY})
		do
			SAVE_MAX_DAYS="3"
			MODIFY_FILE_LIST_IN_MAX_DAYS=$(find ${JENKINS_WORKSPACE_DIRECTORY}/${A_DIRECTORY} -mtime -${SAVE_MAX_DAYS})
		    if [[ ${MODIFY_FILE_LIST_IN_MAX_DAYS} = "" ]]; then
				echo "JOB ${A_DIRECTORY} ${SAVE_MAX_DAYS}天内没修改，删除..."
				echo "cmd: rm -rf ${JENKINS_WORKSPACE_DIRECTORY}/${A_DIRECTORY}"
				rm -rf ${JENKINS_WORKSPACE_DIRECTORY}/${A_DIRECTORY}
		    fi
		done
	fi

	echo ""
	echo "cmd: rm -rvf ${JENKINS_WORKSPACE_DIRECTORY}/ebuy-sub-*"
	rm -rvf ${JENKINS_WORKSPACE_DIRECTORY}/ebuy-sub-*
done

echo ""
echo "clean 重复的多余描述文件..."
# 清理重复的多余描述文件，解决以下错误提示
# 2020-07-16 22:11:06.769 xcodebuild[34894:8456709]  DVTProvisioningProfileManager: Failed to load profile "/Users/ios-ci-1/Library/MobileDevice/Provisioning Profiles/46d17afb-a4d5-47bf-bb67-aaed189c58aa.mobileprovision20200716111345" (Error Domain=DVTProvisioningProfileSourceErrorDomain Code=0 "No provisioning profile provider found for profile "/Users/ios-ci-1/Library/MobileDevice/Provisioning Profiles/46d17afb-a4d5-47bf-bb67-aaed189c58aa.mobileprovision20200716111345"." UserInfo={NSLocalizedDescription=No provisioning profile provider found for profile "/Users/ios-ci-1/Library/MobileDevice/Provisioning Profiles/46d17afb-a4d5-47bf-bb67-aaed189c58aa.mobileprovision20200716111345".})
echo "cmd: rm -rvf ${HOME}/Library/MobileDevice/Provisioning\ Profiles/*mobileprovision20*"
rm -rvf ${HOME}/Library/MobileDevice/Provisioning\ Profiles/*mobileprovision20*

echo ""
echo "硬盘剩余空间检测..."
LEFT_SPACE=$(df -lh | grep /dev/disk1s | head -1 | awk -F ' ' '{print $4}')
echo "剩余空间大小:${LEFT_SPACE}"
LEFT_SPACE=${LEFT_SPACE//Gi/}
# 最少剩余10G空间
LEFT_SPACE_MIN=10
if [[ $(echo "${LEFT_SPACE} <= ${LEFT_SPACE_MIN}" | bc) = "1" ]]; then
	# 考虑清除
	# 1.${RSYNC_BUILD_DIRECTORY}
	# 2.${XCODE_BUILD_DIRECTORY}
	# 3.${HOME}/.suning/build
	for JENKINS_WORKSPACE_DIRECTORY in "${RSYNC_BUILD_DIRECTORY}" \
	  "${XCODE_BUILD_DIRECTORY}" \
	  "${HOME}/.suning/build"
	do
		DIRECTORY_SPACE="$(du -sh ${JENKINS_WORKSPACE_DIRECTORY} | awk -F ' ' '{print $1}')"
		# 如果文件夹大小超过1G，则清理
		if [[ ${DIRECTORY_SPACE} =~ "G" ]]; then
			echo ""
			echo "释放$(du -sh ${JENKINS_WORKSPACE_DIRECTORY})"
			echo "cmd: rm -rf ${JENKINS_WORKSPACE_DIRECTORY}/*"
			rm -rf ${JENKINS_WORKSPACE_DIRECTORY}/*
		fi
	done
	LEFT_SPACE=$(df -lh | grep /dev/disk1s | head -1 | awk -F ' ' '{print $4}')
	echo "剩余空间大小:${LEFT_SPACE}"
fi

