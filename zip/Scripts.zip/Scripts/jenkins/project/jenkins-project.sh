#!/bin/bash
# jenkins-project.sh
# 全代码打包、framework打包脚本
# 这个是全代码打包、framework打包最终执行脚本，其他只是外衣，设置参数环境什么的
# jenkins job
# 1.SuningEBuy-910
# 2.SuningEBuy-Framework-910
# 3.SuningEBuy-X86_64-910

#### 用法，同时也是jenkins build参数
#### SuningEBuy-910
# export JOB_NAME="SuningEBuy-910"
# export CHECK_LAST_BUILD_TIME=true # 检查上次build时间，勾选则15分钟内只打一次包
# export pre=true
# export xgpre=true
# export poc=false
# export prd=true
# export sit=true
# export SuningEMall=true # 选中-官方定位分享包，不选中-官方测试包
# export DEBUG=false # 选中-debug模式测试包,不选中-正常Release模式测试包
# export ARMV7=true # 打armv7架构测试包，兼容iPhone4s、5设备
# export ARM64=true # 打arm64架构测试包，目前大部分iPhone都是arm64架构
# export X86_64=false # 打X86_64架构测试包，模拟器使用
# export UPLOAD_NAME="" # 可不配置,描述会按照SuningEMall的选择来
# # SNLive=Ft_Br_910,SNLive_Framework=Ft_Br_910 子工程可以单独指定使用哪个分支打包
# export SPECIAL_BRANCH="" 
# # 开始打包
# bash jenkins-project.sh

#### SuningEBuy-Framework-910
# export JOB_NAME="SuningEBuy-Framework-830"
# export using_code_sndynamicframeworks=true # 基础SDK动态库
# export using_code_sncommon=true # 基础公共库
# export using_code_snsearch=false # 搜索
# export using_code_snproduct=false # 四级页
# export using_code_snpingou=false # 拼购
# export using_code_snpm=false # SNPM
# export using_code_snlogin=false # 登录
# export using_code_snmember=false # 会员
# export using_code_snsl=false # 交易
# export using_code_snlive=false # 直播
# export using_code_snmk=false # SNMK
# export using_code_snhwg=false # 海外购
# export using_code_snchannel=false # 频道
# export using_code_snsm=false # SNSM
# export using_code_snhome=false # 	首页
# export using_code_snxdcc=false #  菜场
# export using_code_snpw=false #  玩法
# export pre=true
# export xgpre=true
# export poc=false
# export prd=true
# export sit=true
# export SuningEMall=true # 选中-官方定位分享包，不选中-官方测试包
# export ARMV7=true # 打armv7架构测试包，兼容iPhone4s、5设备
# export ARM64=true # 打arm64架构测试包，目前大部分iPhone都是arm64架构
# export UPLOAD_NAME="" # 可不配置,描述会按照SuningEMall的选择来
# # SNLive=Ft_Br_910,SNLive_Framework=Ft_Br_910 子工程可以单独指定使用哪个分支打包
# export SPECIAL_BRANCH="" 
# # 开始打包
# bash jenkins-project.sh

#### SuningEBuy-Local-X86_64-910
# export JOB_NAME="SuningEBuy-Local-X86_64-910"
# export prd=true
# export SuningEMall=true # 选中-官方定位分享包，不选中-官方测试包
# export X86_64=true # 打X86_64架构测试包，模拟器使用
# # 开始打包
# bash jenkins-project.sh

# 模拟jenkins参数检查
if [[ -z ${JOB_NAME} ]]; then
	echo "error: JOB_NAME not found"
	exit 1
fi

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi
export LANG=zh_CN.UTF-8
export PATH=/usr/local/bin:${PATH}

# 兼容研发云打包环境，优先使用/Applications/Xcode12.3.app打包
# 研发云同时装有多个xcode版本，默认的可能不是Xcode12.3
if [[ -e /Applications/Xcode12.3.app ]]; then
    export PATH=/Applications/Xcode12.3.app/Contents/Developer/usr/bin:$PATH
fi
# 检查Xcode版本号
RESULT_STRING=$(xcodebuild -version | head -1)
echo ""
echo "using xcode: ${RESULT_STRING}"
if [[ "${RESULT_STRING}" != "Xcode 12.3" ]]; then
    echo "error: 请使用指定的Xcode版本进行打包"
    exit 1
fi

#### 变量
echo ""
echo "step 1:更新主工程代码..."
# WORKSPACE默认值
# PROJECT_PATH,最终打包目录
if [ -z ${WORKSPACE} ]; then
	# JOB_NAME
	cd ${SCRIPT_DIR}/../../../../
	WORKSPACE=$(pwd)/${JOB_NAME}
	mkdir -p ${WORKSPACE}
	PROJECT_PATH="${WORKSPACE}"
else
	# 兼容研发云Delete workspace when build is done
	PROJECT_PATH=${HOME}/.suning/build/${JOB_NAME}
	mkdir -p ${PROJECT_PATH}
fi
cd ${PROJECT_PATH}

PROJECT_NAME="SuningEBuy"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_VERSION="830"
# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
	# jenkins打包 SuningEBuy-840
	GIT_BRANCH_VERSION=${JOB_NAME##*-}
elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
	# 研发云打包 ebuy_840
	GIT_BRANCH_VERSION=${JOB_NAME##*_}
fi
# 研发云流水线 origin/Dev_Br_850
if [[ "${GIT_BRANCH}" =~ "origin/" ]]; then
	GIT_BRANCH_VERSION=${GIT_BRANCH##*_}
fi
GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

# 拉取代码
cd ${PROJECT_PATH}
if [ ! -d ${PROJECT_PATH}/.git ]; then
	${GIT} init
	${GIT} remote add origin ${GIT_URL}
	${GIT} fetch
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
if [[ "$(${GIT} status)" =~ "unmerged" ]]; then
	${GIT} reset --hard HEAD
fi
${GIT} checkout . 
# 删除Untracked files
${GIT} clean -fd
# 拉取代码
${GIT} pull
# 切换分支
${GIT} checkout ${GIT_BRANCH_NAME}
# 拉取代码
${GIT} pull

# 可以使用我们jenkins控制研发云打包，不用流水线功能了，不兼容了
# # 兼容研发云流水线打包场景，每次都会生成新的job-name
# # 将子工程放到 ~/.jenkins-slave/workspace/ebuy-sub 下
# echo ""
# echo "兼容研发云流水线场景，使用~/.jenkins-slave/workspace/ebuy-sub下子工程..."
# SUB_PROJECT_PATH_ARRAY=(
# 	"SNPods/CloudyTrace_SDK"
# 	"SNPods/MSFS_Framework"
# 	"SNPods/PPTVSDK"
# 	"SNPods/SAStatistic_SDK"
# 	"SNPods/SNChannel_Framework"
# 	"SNPods/SNCommon_Framework"
# 	"SNPods/SNDynamicFrameworks_Framework"
# 	"SNPods/SNHomePage_Framework"
# 	"SNPods/SNHWG_Framework"
# 	"SNPods/SNIRChatRoomSDK"
# 	"SNPods/SNLive_Framework"
# 	"SNPods/SNLogin_Framework"
# 	"SNPods/SNMember_Framework"
# 	"SNPods/SNMINIPSDK"
# 	"SNPods/SNMK_Framework"
# 	"SNPods/SNMPayDependency"
# 	"SNPods/SNMPaySDK"
# 	"SNPods/SNPG_Framework"
# 	"SNPods/SNPM_Framework"
# 	"SNPods/SNSHSearch_Framework"
# 	"SNPods/SNSHProductDetail_Framework"
# 	"SNPods/SNSL_Framework"
# 	"SNPods/SNSM_Framework"
# 	"SNPods/SNYXChat_Framework"
# 	"SNPods/YFBWalletLibs"
# 	"SNPods/YFBWalletSDKDependency"
# 	"SNProjects/SNChannel"
# 	"SNProjects/SNCommon"
# 	"SNProjects/SNDynamicFrameworks"
# 	"SNProjects/SNHomePage"
# 	"SNProjects/SNHWG"
# 	"SNProjects/SNLive"
# 	"SNProjects/SNMBLoginRegister"
# 	"SNProjects/SNMBMember"
# 	"SNProjects/SNMK"
# 	"SNProjects/SNPM"
# 	"SNProjects/SNPMPinGou"
# 	"SNProjects/SNPMPinGouDynamic"
# 	"SNProjects/SNSHProductDetail"
# 	"SNProjects/SNSHSearch"
# 	"SNProjects/SNSL"
# 	"SNProjects/SNSM"
# )
# JOB_EBUY_SUB_PATH=$(dirname ${WORKSPACE})/ebuy-sub-${GIT_BRANCH_VERSION}
# for SUB_PROJECT_PATH in ${SUB_PROJECT_PATH_ARRAY[*]}; do
# 	# 删除之前的软连接
# 	if [[ -L ${PROJECT_PATH}/${SUB_PROJECT_PATH} ]]; then
# 		rm -f ${PROJECT_PATH}/${SUB_PROJECT_PATH}
# 	fi
# 	# 创建新的软连接
# 	if [[ -d ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ]]; then
# 		rm -f ${PROJECT_PATH}/${SUB_PROJECT_PATH}
# 		echo "ln -fs ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ${PROJECT_PATH}/${SUB_PROJECT_PATH}"
# 		ln -fs ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ${PROJECT_PATH}/${SUB_PROJECT_PATH}
# 	fi
# done

#### 打包前处理
echo ""
echo "step 2:打包前处理..."
# 清理归档文件...
echo ""
echo "1)clean..."
bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-clean-helper.sh

# 打包间隔检查
echo ""
echo "2) 打包间隔检查..."
BUILD_IDENTIFIER="${JOB_NAME}"
BUILD_DURATION="0"
if [[ "${CHECK_LAST_BUILD_TIME}" = "true" ]];then
	BUILD_DURATION="15"
fi
BUILD_CHECK_URL="http://10.37.64.97/ipa/build.json?identifier=${BUILD_IDENTIFIER}&duration=${BUILD_DURATION}"
BUILD_CHECK_RESULT=$(curl -m 10 -s ${BUILD_CHECK_URL})
echo "check url: ${BUILD_CHECK_URL}"
echo "check result: ${BUILD_CHECK_RESULT}"
if [[ ! ${BUILD_CHECK_RESULT} =~ "\"code\":\"0\"" ]]; then
	BUILD_CHECK_RESULT_MSG=$(echo ${BUILD_CHECK_RESULT} | cut -d "\"" -f 4)
	echo "error: 不打包, ${BUILD_CHECK_RESULT_MSG}"
	echo ""
	echo "如果想强制打包，打包的时候，不要勾选CHECK_LAST_BUILD_TIME即可😢 😢 😢"
	echo ""
	exit 1
else
	echo ""
	echo "开始打包🚀 🚀 🚀"
fi

#### 参数
# 默认值
# 1.using_code_xxx默认是true
# 2.其他默认false或者空
echo ""
echo "step 3:参数..."
# INDEX
POD_NAME_STRING_INDEX=0
POD_DESC_STRING_INDEX=1
POD_USING_CODE_INDEX=2
POD_USING_CODE_VALUE_INDEX=3
POD_VERSION_INFO_INDEX=4
POD_PATH_INDEX=5
# 数据格式
POD_INFO_ARRAY=(
	POD_NAME_STRING 				# pod名，SNSHSearch/searchlib
	POD_DESC_STRING 				# pod描述，搜索
	POD_USING_CODE 					# using_code_snsearch
	POD_USING_CODE_VALUE 			# 默认为空，后面根据变量设置为true或者false
	POD_VERSION_INFO 				# 使用framework集成时，framework的编译时间、库git日志等信息
	POD_PATH 						# 工程原来指定的pod目录
)
SNDYNAMICFRAMEWORKS_POD_INFO_ARRAY=(
    "SNDynamicFrameworks"
    "基础SDK动态库"
    "using_code_sndynamicframeworks"
    ""
)
SNSDKS_POD_INFO_ARRAY=(
    "SNSDKs"
    "基础SDK动态库"
    "using_code_sndynamicframeworks"
    ""
)
SNLAZYLOADFRAMEWORKS_POD_INFO_ARRAY=(
    "SNLazyLoadFrameworks"
    "延迟加载动态库"
    "using_code_sndynamicframeworks"
    ""
)
SNCOMMON_POD_INFO_ARRAY=(
    "SNCommon"
    "基础公共库"
    "using_code_sncommon"
    ""
)
SNSHSEARCH_POD_INFO_ARRAY=(
    "SNSHSearch"
    "搜索"
    "using_code_snsearch"
    ""
)
SNPRODUCT_POD_INFO_ARRAY=(
    "SNSHProductDetail"
    "四级页"
    "using_code_snproduct"
    ""
)
SNPINGOU_POD_INFO_ARRAY=(
    "SNPMPinGou"
    "拼购"
    "using_code_snpingou"
    ""
)
SNPM_POD_INFO_ARRAY=(
    "SNPM"
    "SNPM"
    "using_code_snpm"
    ""
)
SNLOGIN_POD_INFO_ARRAY=(
    "SNMBLoginRegister"
    "登录"
    "using_code_snlogin"
    ""
)
SNMEMBER_POD_INFO_ARRAY=(
    "SNMBMember"
    "会员"
    "using_code_snmember"
    ""
)
SNSL_POD_INFO_ARRAY=(
    "SNSL"
    "交易"
    "using_code_snsl"
    ""
)
SNLIVE_POD_INFO_ARRAY=(
    "SNLive"
    "直播"
    "using_code_snlive"
    ""
)
SNMK_POD_INFO_ARRAY=(
    "SNMK"
    "SNMK"
    "using_code_snmk"
    ""
)
SNHWG_POD_INFO_ARRAY=(
    "SNHWG"
    "海外购"
    "using_code_snhwg"
    ""
)
SNCHANNEL_POD_INFO_ARRAY=(
    "SNChannel"
    "频道"
    "using_code_snchannel"
    ""
)
SNSM_POD_INFO_ARRAY=(
    "SNSM"
    "SNSM"
    "using_code_snsm"
    ""
)
SNHOME_POD_INFO_ARRAY=(
    "SNHomePage"
    "首页"
    "using_code_snhome"
    ""
)
SNXDCCPAGE_POD_INFO_ARRAY=(
    "SNXDCCPage"
    "菜场"
    "using_code_snxdcc"
    ""
)
SNPW_POD_INFO_ARRAY=(
    "SNPW"
    "玩法"
    "using_code_snpw"
    ""
)
ALL_POD_INFO_ARRAY=(
	SNDYNAMICFRAMEWORKS_POD_INFO_ARRAY
	SNSDKS_POD_INFO_ARRAY
	SNLAZYLOADFRAMEWORKS_POD_INFO_ARRAY
	SNCOMMON_POD_INFO_ARRAY
	SNSHSEARCH_POD_INFO_ARRAY
	SNPRODUCT_POD_INFO_ARRAY
	SNPINGOU_POD_INFO_ARRAY
	SNPM_POD_INFO_ARRAY
	SNLOGIN_POD_INFO_ARRAY
	SNMEMBER_POD_INFO_ARRAY
	SNSL_POD_INFO_ARRAY
	SNLIVE_POD_INFO_ARRAY
	SNMK_POD_INFO_ARRAY
	SNHWG_POD_INFO_ARRAY
	SNCHANNEL_POD_INFO_ARRAY
	SNSM_POD_INFO_ARRAY
	SNHOME_POD_INFO_ARRAY
    SNXDCCPAGE_POD_INFO_ARRAY
    SNPW_POD_INFO_ARRAY
)

# rsync
RSYNC_JOB_PATH="${HOME}/.cocoapods/repos/SNEBuy_build_rsync/SuningEBuy-Framework-${GIT_BRANCH_VERSION}"
mkdir -p ${RSYNC_JOB_PATH}

# versions.txt
# 格式：SNHomePage | 6d5da8808 Fri Nov 8 19:36:46 2019 +0800 | build:2019年11月 9日 星期六 14时39分23秒 CST
RSYNC_VERSIONS_TXT_PATH="${RSYNC_JOB_PATH}/versions.txt"

# tmp-ebuy.txt
TMP_FILE_PATH="/tmp/tmp-ebuy.txt"
rm -f ${TMP_FILE_PATH}
touch ${TMP_FILE_PATH}

# 参数检查
BUILD_PARAMETER=""
if [[ "${pre}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -pre"
fi
if [[ "${xgpre}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -xgpre"
fi
if [[ "${poc}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -poc"
fi
if [[ "${prd}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -prd"
fi
if [[ "${sit}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -sit"
fi
# 去除左右空格
BUILD_PARAMETER=$(echo ${BUILD_PARAMETER})
if [ "${BUILD_PARAMETER}" = "" ]; then
	echo "请选择打包环境"
	exit 0
fi

# BUILD_ALL_CODE，全代码打包
BUILD_USING_ALL_CODE=true

# 临时变量，打包描述
TMP_BUILD_DESC_STRING=""
for POD_INFO_ARRAY in ${ALL_POD_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
    eval POD_NAME_STRING=\${${POD_INFO_ARRAY}[${POD_NAME_STRING_INDEX}]}
	eval POD_DESC_STRING=\${${POD_INFO_ARRAY}[${POD_DESC_STRING_INDEX}]}
    eval POD_USING_CODE=\${${POD_INFO_ARRAY}[${POD_USING_CODE_INDEX}]}
    eval POD_USING_CODE_VALUE=\${${POD_INFO_ARRAY}[${POD_USING_CODE_VALUE_INDEX}]}
    eval POD_VERSION_INFO=\${${POD_INFO_ARRAY}[${POD_VERSION_INFO_INDEX}]}
    eval POD_PATH=\${${POD_INFO_ARRAY}[${POD_PATH_INDEX}]}

    # POD_USING_CODE_VALUE,计算using_code_snhome=true
	eval POD_USING_CODE_VALUE=\${${POD_USING_CODE}}
	# 如果没有配置using_code_snhome，则using_code_snhome=true
	if [[ -z ${POD_USING_CODE_VALUE} ]]; then
		POD_USING_CODE_VALUE=true
	fi
	# 如果rsync目录下没有该库的framework目录，则using_code_snhome=true
	# 没framework，只好用代码集成了
	if [[ ! -e ${RSYNC_JOB_PATH}/${POD_NAME_STRING}/${POD_NAME_STRING}.framework ]]; then
    	# 之前没有打过该framework,使用代码编译
    	POD_USING_CODE_VALUE=true
    # else
    # 	# 没必要做，默认三个架构都有，检查实现起来还比较麻烦：判断已有的framework是否包含要打的架构
    fi    
    eval ${POD_INFO_ARRAY}[${POD_USING_CODE_VALUE_INDEX}]=${POD_USING_CODE_VALUE}

    # POD_VERSION_INFO
    if [[ -z ${POD_VERSION_INFO} ]]; then
		POD_VERSION_INFO="POD_VERSION_INFO_${POD_NAME_STRING}"
		eval ${POD_INFO_ARRAY}[${POD_VERSION_INFO_INDEX}]=${POD_VERSION_INFO}
		# 默认三个架构的版本信息为空
		eval ${POD_VERSION_INFO}[0]=""
		eval ${POD_VERSION_INFO}[1]=""
		eval ${POD_VERSION_INFO}[2]=""
	fi

    # 如果有一个库不是代码编译，则就不是全代码打包
    if ! ${POD_USING_CODE_VALUE}; then
    	BUILD_USING_ALL_CODE=false
    fi

    # using_code_snhome: true
    # SNSDKs、SNLazyLoadFrameworks不设置打包描述，使用SNDynamicFrameworks的
    if [[ "${POD_NAME_STRING}" != "SNSDKs" ]] \
    	&& [[ "${POD_NAME_STRING}" != "SNLazyLoadFrameworks" ]]; then
    	echo "    ${POD_USING_CODE}:      				${POD_USING_CODE_VALUE}" >> ${TMP_FILE_PATH}

    	# 默认描述
    	if [[ "${POD_USING_CODE_VALUE}" = "true" ]]; then
    		if [[ "${TMP_BUILD_DESC_STRING}" = "" ]]; then
	    		TMP_BUILD_DESC_STRING="${POD_DESC_STRING}"
	    	else
	    		TMP_BUILD_DESC_STRING="${TMP_BUILD_DESC_STRING}、${POD_DESC_STRING}"
	    	fi
    	fi
    fi
done

# UPLOAD_NAME
if [[ "${BUILD_USING_ALL_CODE}" = "true" ]]; then
	if [ "${UPLOAD_NAME}" = "" ]; then
		if [[ "${SuningEMall}" = "true" ]]; then
			UPLOAD_NAME="官方定位分享包"
		else
			UPLOAD_NAME="官方测试包"
		fi
	fi
else
	# UPLOAD_NAME，默认值
	if [ "${UPLOAD_NAME}" = "" ]; then
		if [[ "${TMP_BUILD_DESC_STRING}" = "" ]]; then
			UPLOAD_NAME="主工程测试包"
		else
			UPLOAD_NAME="${TMP_BUILD_DESC_STRING}测试包"
		fi
	fi
	UPLOAD_NAME="framework打包-${UPLOAD_NAME}"
fi

# 默认打armv7和arm64包
if [[ "${ARMV7}" != "true" ]] && [[ "${ARM64}" != "true" ]] && [[ "${X86_64}" != "true" ]]; then
	ARMV7=true
	ARM64=true
fi
# 如果设置了armv或者arm64架构，则不打x86_64架构的包，arm优先
if [[ "${ARMV7}" = "true" ]] || [[ "${ARM64}" = "true" ]]; then
	X86_64=false
fi
# 模拟器架构打debug包，谁会要release的模拟器包
if [[ "${X86_64}" = "true" ]]; then
	DEBUG=true
fi
# 如果没有配置DEBUG，则DEBUG=false
if [[ -z ${DEBUG} ]]; then
	DEBUG=false
fi

BUILD_ARCHS=""
if [[ "${ARMV7}" = "true" ]];then
	BUILD_ARCHS="${BUILD_ARCHS} armv7"
fi
if [[ "${ARM64}" = "true" ]];then
	BUILD_ARCHS="${BUILD_ARCHS} arm64"
fi
if [[ "${X86_64}" = "true" ]];then
	BUILD_ARCHS="${BUILD_ARCHS} x86_64"
fi
# 去除左右空格
BUILD_ARCHS=$(echo ${BUILD_ARCHS})

# USE_SNFINANCE_CODE
USE_SNFINANCE_CODE=false
if [ "${SNMPaySDK_PATH}" != "" ] \
	|| [ "${SNMPayDependency_PATH}" != "" ] \
	|| [ "${YFBWalletLibs_PATH}" != "" ] \
	|| [ "${YFBWalletSDKDependency_PATH}" != "" ]; then
	USE_SNFINANCE_CODE=true
fi

# 是否要将打好的framework push到服务器
SHOULD_PUSH_FRAMEWORKS=true
# arm打包
if [[ "${ARMV7}" = "true" ]] || [[ "${ARM64}" = "true" ]]; then
	# debug模式不处理framework
	if [[ "${DEBUG}" = "true" ]]; then
		SHOULD_PUSH_FRAMEWORKS=false
	fi
	# 使用金融代码，不处理framework
	if [ "${USE_SNFINANCE_CODE}" = "true" ]; then
		SHOULD_PUSH_FRAMEWORKS=false
	fi
fi

if [[ -z ${JENKINS_TYPE} ]]; then
	JENKINS_TYPE="jenkins"
fi

echo "JENKINS_TYPE:      					${JENKINS_TYPE}"
echo "WORKSPACE:      					${WORKSPACE}"
echo "PROJECT_PATH: 						${PROJECT_PATH}"
echo "JOB_NAME:         					${JOB_NAME}"
echo "GIT_URL:          					${GIT_URL}"
echo "PROJECT_NAME:     					${PROJECT_NAME}"
echo "GIT_BRANCH_NAME:  					${GIT_BRANCH_NAME}"
echo "RSYNC_JOB_PATH:         				${RSYNC_JOB_PATH}"

echo ""
echo "buld参数"
echo "BUILD_PARAMETER:          				${BUILD_PARAMETER}"
echo "UPLOAD_NAME:      					${UPLOAD_NAME}"
echo "BUILD_ARCHS:      					${BUILD_ARCHS}"
echo "SuningEMall:      					${SuningEMall}"
echo "DEBUG:      						${DEBUG}"
echo "全代码打包:      						${BUILD_USING_ALL_CODE}"
cat ${TMP_FILE_PATH}
echo "SNMPaySDK_PATH:      					${SNMPaySDK_PATH}"
echo "SNMPayDependency_PATH:      				${SNMPayDependency_PATH}"
echo "YFBWalletLibs_PATH:      				${YFBWalletLibs_PATH}"
echo "YFBWalletSDKDependency_PATH:      			${YFBWalletSDKDependency_PATH}"
echo "USE_SNFINANCE_CODE:      				${USE_SNFINANCE_CODE}"
echo "SHOULD_PUSH_FRAMEWORKS:  				${SHOULD_PUSH_FRAMEWORKS}"

#### pull代码
echo ""
echo "step 4:pull code..."
# updateAllCode
cd ${PROJECT_PATH}/
echo "cmd: bash ${PROJECT_PATH}/updateAllCode.sh -revert--subproject"
bash ${PROJECT_PATH}/updateAllCode.sh -revert--subproject
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# 处理SPECIAL_BRANCH中主分支，确保打包用的脚本用的是指定分支的
if [[ ! -z ${SPECIAL_BRANCH} ]]; then
    echo ""
    echo "处理SPECIAL_BRANCH，寻找指定的主工程分支..."
    BRANCH_INFO_ARRAY=(${SPECIAL_BRANCH//,/ })
    for BRANCH_INFO in ${BRANCH_INFO_ARRAY[*]}
    do
        PROJECT_NAME=${BRANCH_INFO%=*}
        BRANCH_NAME=${BRANCH_INFO#*=}

        # 切换主分支
        if [[ "${PROJECT_NAME}" = "SuningEBuy" ]]; then
            echo "BRANCH_INFO:${BRANCH_INFO}"
            echo "PROJECT_NAME:${PROJECT_NAME}"
            echo "BRANCH_NAME:${BRANCH_NAME}"
            
            cd ${PROJECT_PATH}
            # 放弃本地修改
            ${GIT} checkout .
            # 切换分支
            ${GIT} checkout ${BRANCH_NAME}
			# 命令执行失败,异常退出
			if [[ ! $? -eq 0 ]]; then
			    exit 1
			fi
            # 拉取代码
            ${GIT} pull
            # 跳出
            break
        fi
    done
fi

# repo-update更新代码
cd ${PROJECT_PATH}/
if [ "${USE_SNFINANCE_CODE}" = "true" ]; then
	echo ""
	echo "cmd: bash ${PROJECT_PATH}/repo-update.sh -paysdk -skip--pod -check--branch -revert--subproject"
	bash ${PROJECT_PATH}/repo-update.sh -paysdk -skip--pod -check--branch -revert--subproject
else
	echo ""
	echo "cmd: bash ${PROJECT_PATH}/repo-update.sh -skip--pod -check--branch -revert--subproject"
	bash ${PROJECT_PATH}/repo-update.sh -skip--pod -check--branch -revert--subproject
fi
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# 可以使用我们jenkins控制研发云打包，不用流水线功能了，不兼容了
# # 兼容研发云流水线打包场景，每次都会生成新的job-name
# # 将子工程放到 ~/.jenkins-slave/workspace/ebuy-sub 下
# echo ""
# echo "兼容研发云流水线场景，移动子工程到~/.jenkins-slave/workspace/ebuy-sub..."
# for SUB_PROJECT_PATH in ${SUB_PROJECT_PATH_ARRAY[*]}; do
# 	if [[ ! -L ${PROJECT_PATH}/${SUB_PROJECT_PATH} ]]; then
# 		echo "    移动子工程${SUB_PROJECT_PATH}..."
# 		mkdir -p $(dirname ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH})
# 		rm -rf ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH}
# 		mv ${PROJECT_PATH}/${SUB_PROJECT_PATH} ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} 
# 		echo "ln -fs ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ${PROJECT_PATH}/${SUB_PROJECT_PATH}"
# 		ln -fs ${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH} ${PROJECT_PATH}/${SUB_PROJECT_PATH}
# 	fi
# done
# echo "done"

# # 检查SNPods、SNProjects下不是软链接的文件夹，报错并提示，需要放入SUB_PROJECT_PATH_ARRAY
# echo ""
# echo "检查SNPods、SNProjects下不是软链接的文件夹..."
# for SNPODS_PATH_NAME in "SNPods" "SNProjects"; do 
# 	for SUB_PROJECT_NAME in $(ls ${PROJECT_PATH}/${SNPODS_PATH_NAME}); do
# 		# 忽略SNSDKs_Framework、SNLazyLoadFrameworks_Framework，是放到主工程的
# 		if [[ ${SUB_PROJECT_NAME} = "SNSDKs_Framework" ]] \
# 			|| [[ ${SUB_PROJECT_NAME} = "SNLazyLoadFrameworks_Framework" ]]; then
# 			continue
# 		fi
# 		if [[ ! -L ${PROJECT_PATH}/${SNPODS_PATH_NAME}/${SUB_PROJECT_NAME} ]] \
# 			&& [[ -d ${PROJECT_PATH}/${SNPODS_PATH_NAME}/${SUB_PROJECT_NAME} ]]; then
# 			echo "wb error: ${SNPODS_PATH_NAME}/${SUB_PROJECT_NAME} 需要放入 SUB_PROJECT_PATH_ARRAY"
# 		fi
# 	done
# done

# 处理SPECIAL_BRANCH
if [[ ! -z ${SPECIAL_BRANCH} ]]; then
	echo ""
	echo "处理SPECIAL_BRANCH..."
	BRANCH_INFO_ARRAY=(${SPECIAL_BRANCH//,/ })  
	for BRANCH_INFO in ${BRANCH_INFO_ARRAY[*]}
	do
		echo ""
		echo "BRANCH_INFO:${BRANCH_INFO}"
		PROJECT_NAME=${BRANCH_INFO%=*}
		BRANCH_NAME=${BRANCH_INFO#*=}
		echo "PROJECT_NAME:${PROJECT_NAME}"
		echo "BRANCH_NAME:${BRANCH_NAME}"
        # 切换主分支
        if [[ "${PROJECT_NAME}" = "SuningEBuy" ]]; then
            cd ${PROJECT_PATH}
        fi
        # 切换SNEBuy_buss_repos、SNEBuy_repos分支
        if [[ "${PROJECT_NAME}" = "SNEBuy_buss_repos" ]] \
        	|| [[ "${PROJECT_NAME}" = "SNEBuy_repos" ]]; then
            cd "${HOME}/.cocoapods/repos/${PROJECT_NAME}"
        fi
		# 如果存在
		if [[ -e ${PROJECT_PATH}/SNProjects/${PROJECT_NAME} ]]; then
			cd ${PROJECT_PATH}/SNProjects/${PROJECT_NAME}
		fi
		if [[ -e ${PROJECT_PATH}/SNPods/${PROJECT_NAME} ]]; then
			cd ${PROJECT_PATH}/SNPods/${PROJECT_NAME}
		fi
		CURRENT_DIRECTORY=$(pwd)
		CURRENT_DIRECTORY=$(basename ${CURRENT_DIRECTORY})
		# 兼容主工程目录ebuy_9520 -> SuningEBuy
		if [[ ${CURRENT_DIRECTORY} =~ "ebuy_" ]]; then
			CURRENT_DIRECTORY="SuningEBuy"
		fi
		if [[ "${CURRENT_DIRECTORY}" = ${PROJECT_NAME} ]]; then
			# 放弃本地修改
			${GIT} checkout . 
			# 切换分支
			${GIT} checkout ${BRANCH_NAME}
			# 命令执行失败,异常退出
			if [[ ! $? -eq 0 ]]; then
			    exit 1
			fi
			# 拉取代码
			${GIT} pull
		fi
	done
fi

# 检查git忽略文件
echo ""
echo "检查git忽略文件..."
cd ${PROJECT_PATH}
RESULT_STRING=$(${GIT} status)
if [[ ! "${RESULT_STRING}" =~ "working tree clean" ]]; then
	echo ${RESULT_STRING}
	echo "wb error: new .gitignore item found"
fi

# rsync pull
echo ""
echo "更新rsync目录..."
echo "cmd: bash ${PROJECT_PATH}/Scripts/rsync-helper.sh pull ${RSYNC_JOB_PATH}/ | tail -n 3"
bash ${PROJECT_PATH}/Scripts/rsync-helper.sh pull ${RSYNC_JOB_PATH}/ | tail -n 3
# versions.txt
if [[ ! -f ${RSYNC_VERSIONS_TXT_PATH} ]]; then
	mkdir -p $(dirname ${RSYNC_VERSIONS_TXT_PATH})
	touch ${RSYNC_VERSIONS_TXT_PATH}
fi

#### pod集成
echo ""
echo "step 5:pod集成..."
# 清空之前pod生成文件
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
# find命令-L参数查找目录下软链接文件夹
for PBXPROJ_PATH in `find -L ${PROJECT_PATH}/SNProjects -name project.pbxproj`
do
    sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
done

# 修改Podfile
echo "修改Podfile..."
PODFILE_PATH=${PROJECT_PATH}/Podfile
for POD_INFO_ARRAY in ${ALL_POD_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
    eval POD_NAME_STRING=\${${POD_INFO_ARRAY}[${POD_NAME_STRING_INDEX}]}
	eval POD_DESC_STRING=\${${POD_INFO_ARRAY}[${POD_DESC_STRING_INDEX}]}
    eval POD_USING_CODE=\${${POD_INFO_ARRAY}[${POD_USING_CODE_INDEX}]}
    eval POD_USING_CODE_VALUE=\${${POD_INFO_ARRAY}[${POD_USING_CODE_VALUE_INDEX}]}
    eval POD_VERSION_INFO=\${${POD_INFO_ARRAY}[${POD_VERSION_INFO_INDEX}]}
    eval POD_PATH=\${${POD_INFO_ARRAY}[${POD_PATH_INDEX}]}

    echo ""
    echo "${POD_NAME_STRING}:"

    # POD_PATH,从Podfile获取并赋值
	# /Users/wangbin/.cocoapods/repos/SNEBuy_buss_repos/BussLibs/SNHomePage/8.1.8
	POD_PATH=$(cat ${PODFILE_PATH} | grep -v '#' | grep "${POD_NAME_STRING}_SPEC_PATH" | head -1)
	POD_PATH=${POD_PATH#*=}
	# 替换空格为空字符串
	POD_PATH=${POD_PATH// /}
	# 替换+为空字符串
	POD_PATH=${POD_PATH//+/}
	# 替换'为空字符串
	POD_PATH=${POD_PATH//\'/}
	# 替换POD_BUSS_SPEC_PATH为${HOME}/.cocoapods/repos/SNEBuy_buss_repos
	POD_PATH=${POD_PATH//\$POD_BUSS_SPEC_PATH/${HOME}\/.cocoapods\/repos\/SNEBuy_buss_repos\/}
	POD_PATH=${POD_PATH//SNPods/${PROJECT_PATH}\/SNPods}
	eval ${POD_INFO_ARRAY}[${POD_PATH_INDEX}]="\${POD_PATH}"

	# POD_VERSION_INFO，编译的framework信息从versions.txt读取
	for ARCH in "armv7" "arm64" "x86_64"; do
		ARCH_INDEX=0
		if [[ "${ARCH}" = "arm64" ]]; then
			ARCH_INDEX=1
		elif [[ "${ARCH}" = "x86_64" ]]; then
			ARCH_INDEX=2
		fi
		POD_VERSION_IDENTIFIER="${POD_NAME_STRING}-${ARCH} |"
		RSYNC_POD_VERSION_INFO_STRING=$(cat ${RSYNC_VERSIONS_TXT_PATH} | grep "${POD_VERSION_IDENTIFIER}")
		eval ${POD_VERSION_INFO}[\${ARCH_INDEX}]=\${RSYNC_POD_VERSION_INFO_STRING}
	done

    if [[ "${POD_USING_CODE_VALUE}" = "true" ]]; then
    	# 修改Podfile，using_code_snhome = true
		sed -i '' "s/${POD_USING_CODE} =.*/${POD_USING_CODE} = true/" ${PODFILE_PATH}
		cat ${PODFILE_PATH} | grep "${POD_USING_CODE} ="
	else
		# 修改Podfile，using_code_snhome = false
		sed -i '' "s/${POD_USING_CODE} =.*/${POD_USING_CODE} = false/" ${PODFILE_PATH}
		cat ${PODFILE_PATH} | grep "${POD_USING_CODE} ="

		# framework信息
		echo ""
		echo "framework信息..."
		for ARCH in "armv7" "arm64" "x86_64"; do
			# 当前没打这个架构的包，continue
			if [[ ! "${BUILD_ARCHS}" =~ "${ARCH}" ]]; then
				continue
			fi
			ARCH_INDEX=0
			if [[ "${ARCH}" = "arm64" ]]; then
				ARCH_INDEX=1
			elif [[ "${ARCH}" = "x86_64" ]]; then
				ARCH_INDEX=2
			fi
			eval RSYNC_POD_VERSION_INFO_STRING=\${${POD_VERSION_INFO}[${ARCH_INDEX}]}
			# 打印编译用的framework信息
			echo "    ${ARCH}"
			echo "        framework build time:			$(echo ${RSYNC_POD_VERSION_INFO_STRING} | cut -d "|" -f 3)"
			echo "        framework build git log:		$(echo ${RSYNC_POD_VERSION_INFO_STRING} | cut -d "|" -f 2)"
		done

		# 替换podspce文件
		echo ""
		echo "替换podspec..."
		if [[ ! "${POD_PATH}" =~ "${RSYNC_JOB_PATH}" ]]; then
			echo "    cmd: cp -f ${POD_PATH}/*.podspec ${RSYNC_JOB_PATH}/${POD_NAME_STRING}"
			cp -f ${POD_PATH}/*.podspec ${RSYNC_JOB_PATH}/${POD_NAME_STRING}
		fi

		# resources，cocoapods不支持软连接，这儿只有先替换整个目录
		echo ""
		echo "替换Resources文件夹..."
		if [[ ! "${POD_PATH}" =~ "${RSYNC_JOB_PATH}" ]]; then
			echo "    cmd: rsync -avz --delete \
			    --exclude .DS_Store \
			    ${POD_PATH}/Resources/ \
			    ${RSYNC_JOB_PATH}/${POD_NAME_STRING}/Resources/ \
			    | tail -n 3"
			rsync -avz --delete \
			    --exclude .DS_Store \
			    ${POD_PATH}/Resources/ \
			    ${RSYNC_JOB_PATH}/${POD_NAME_STRING}/Resources/ \
			    | tail -n 3
		fi

		# 修改Podfile
		# "        pod 'SNSL/productlib', :path => '${HOME}/.cocoapods/repos/SNEBuy_build_rsync/xxx/SNSL'"
		POD_INFO_STRING="path => '${RSYNC_JOB_PATH}/${POD_NAME_STRING}'"
		POD_INFO_STRING=${POD_INFO_STRING//\//\\\/}
		POD_INFO_STRING=${POD_INFO_STRING//\./\\\.}
		sed -i '' "s/\\(${POD_NAME_STRING}\/.*\\)path.*/\1${POD_INFO_STRING}/" ${PODFILE_PATH}

		# 打印Podfile
		echo ""
		echo "Podfile:"
		cat ${PODFILE_PATH} | grep "pod.*${POD_NAME_STRING}/"
	fi
done

if [ "${SNMPaySDK_PATH}" != "" ]; then
	echo ""
	echo "libSNMPaySDK"
	SNMPaySDK_PATH="\$POD_SPEC_PATH_YFBSDK + \'${SNMPaySDK_PATH}\'"
	SNMPaySDK_PATH=${SNMPaySDK_PATH//\//\\\/}
	SNMPaySDK_PATH=${SNMPaySDK_PATH//\./\\\.}
	# echo "libSNMPaySDK:${SNMPaySDK_PATH}"
	sed -i '' "s/\'SNPods\/SNMPaySDK\'/${SNMPaySDK_PATH}/" ${PODFILE_PATH}
	cat ${PODFILE_PATH} | grep "pod 'libSNMPaySDK"
fi

if [ "${SNMPayDependency_PATH}" != "" ]; then
	echo ""
	echo "SNMPayDependency"
	SNMPayDependency_PATH="\$POD_SPEC_PATH_YFBSDK + \'${SNMPayDependency_PATH}\'"
	SNMPayDependency_PATH=${SNMPayDependency_PATH//\//\\\/}
	SNMPayDependency_PATH=${SNMPayDependency_PATH//\./\\\.}
	# echo "SNMPayDependency:${SNMPayDependency_PATH}"
	sed -i '' "s/\'SNPods\/SNMPayDependency\'/${SNMPayDependency_PATH}/" ${PODFILE_PATH}
	cat ${PODFILE_PATH} | grep "pod 'SNMPayDependency"
fi

if [ "${YFBWalletLibs_PATH}" != "" ]; then
	echo ""
	echo "YFBWalletSDK"
	YFBWalletLibs_PATH="\$POD_SPEC_PATH_YFBWallet + \'${YFBWalletLibs_PATH}\'"
	YFBWalletLibs_PATH=${YFBWalletLibs_PATH//\//\\\/}
	YFBWalletLibs_PATH=${YFBWalletLibs_PATH//\./\\\.}
	# echo "YFBWalletLibs:${YFBWalletLibs_PATH}"
	sed -i '' "s/\'SNPods\/YFBWalletLibs\'/${YFBWalletLibs_PATH}/" ${PODFILE_PATH}
	cat ${PODFILE_PATH} | grep "pod 'YFBWalletLibs"
fi

if [ "${YFBWalletSDKDependency_PATH}" != "" ]; then
	echo ""
	echo "YFBWalletSDKDependency"
	YFBWalletSDKDependency_PATH="\$POD_SPEC_PATH_YFBWallet + \'${YFBWalletSDKDependency_PATH}\'"
	YFBWalletSDKDependency_PATH=${YFBWalletSDKDependency_PATH//\//\\\/}
	YFBWalletSDKDependency_PATH=${YFBWalletSDKDependency_PATH//\./\\\.}
	# echo "YFBWalletSDKDependency_PATH:${YFBWalletSDKDependency_PATH}"
	sed -i '' "s/\'SNPods\/YFBWalletSDKDependency\'/${YFBWalletSDKDependency_PATH}/" ${PODFILE_PATH}
	cat ${PODFILE_PATH} | grep "pod 'YFBWalletSDKDependency"
fi

# # 兼容cocoapods 1.6.2版本
# # 1.6.2版本Framework的路径如果是软链接，则其中的资源不会集成到工程
# # 这儿修改Podfile，指向实体路径
# echo ""
# echo "兼容cocoapods 1.6.2版本..."
# for SUB_PROJECT_PATH in ${SUB_PROJECT_PATH_ARRAY[*]}; do
# 	echo ""
# 	echo "${SUB_PROJECT_PATH}"
# 	if [[ -L ${PROJECT_PATH}/${SUB_PROJECT_PATH} ]]; then
# 		# SUB_PROJECT_PATH2 "SNProjects/SNSL"
# 		SUB_PROJECT_PATH2=${SUB_PROJECT_PATH//\//\\\/}
# 		SUB_PROJECT_PATH2=${SUB_PROJECT_PATH2//\./\\\.}
# 		# SUBJOB_SUB_PROJECT_PATH "/Users/xxx/.jenkins-slave/workspace/ebuy-sub-895/SNProjects/SNSL"
# 		SUBJOB_SUB_PROJECT_PATH2="${JOB_EBUY_SUB_PATH}/${SUB_PROJECT_PATH}"
# 		SUBJOB_SUB_PROJECT_PATH2=${SUBJOB_SUB_PROJECT_PATH2//\//\\\/}
# 		SUBJOB_SUB_PROJECT_PATH2=${SUBJOB_SUB_PROJECT_PATH2//\./\\\.}
# 		# 替换
# 		sed -i '' "s/${SUB_PROJECT_PATH2}\'/${SUBJOB_SUB_PROJECT_PATH2}\'/" ${PODFILE_PATH}
# 		cat ${PODFILE_PATH} | grep "${SUB_PROJECT_PATH}\'"
# 		# 替换
# 		sed -i '' "s/${SUB_PROJECT_PATH2}\//${SUBJOB_SUB_PROJECT_PATH2}\//" ${PODFILE_PATH}
# 		cat ${PODFILE_PATH} | grep "${SUB_PROJECT_PATH}\/"
# 	fi
# done

# repo-update
echo ""
echo "cmd: bash ${PROJECT_PATH}/repo-update.sh -pod"
cd ${PROJECT_PATH}
bash ${PROJECT_PATH}/repo-update.sh -pod

# 改为实体路径集成代码,不用兼容了
# # 兼容cocoapods 1.6.2版本
# # Pods-SNCommon.debug.xcconfig的path
# # 1.2.0版本 ../../../SuningEBuy-895/Pods/Target Support Files/Pods-SNCommon/Pods-SNCommon.debug.xcconfig
# # 	最终找到的路径是SuningEBuy-895/Pods下,可以找到Pods-SNCommon.debug.xcconfig
# # 1.6.2版本 ../../Pods/Target Support Files/Pods-SNCommon/Pods-SNCommon.debug.xcconfig
# # 	最终找到的路径是在ebuy-sub-895/Pods下，这儿找不到Pods-SNCommon.debug.xcconfig
# # 所以这儿兼容下，将SuningEBuy-895/Pods软链接到ebuy-sub-895/Pods
# ln -fs ${PROJECT_PATH}/Pods ${JOB_EBUY_SUB_PATH}

#### 打包
echo ""
echo "step 6:打包..."
echo "打印Podfile..."
cat ${PODFILE_PATH}

# 处理SPECIAL_BRANCH
if [[ ! -z ${SPECIAL_BRANCH} ]]; then
	echo ""
	echo "处理SPECIAL_BRANCH，检查切换操作是否完成..."
	BRANCH_INFO_ARRAY=(${SPECIAL_BRANCH//,/ })  
	for BRANCH_INFO in ${BRANCH_INFO_ARRAY[*]}
	do
		echo ""
		echo "BRANCH_INFO:${BRANCH_INFO}"
		PROJECT_NAME=${BRANCH_INFO%=*}
		BRANCH_NAME=${BRANCH_INFO#*=}
		echo "PROJECT_NAME:${PROJECT_NAME}"
		echo "BRANCH_NAME:${BRANCH_NAME}"
        # 切换主分支
        if [[ "${PROJECT_NAME}" = "SuningEBuy" ]]; then
            cd ${PROJECT_PATH}
        fi
        # 切换SNEBuy_buss_repos、SNEBuy_repos分支
        if [[ "${PROJECT_NAME}" = "SNEBuy_buss_repos" ]] \
        	|| [[ "${PROJECT_NAME}" = "SNEBuy_repos" ]]; then
            cd "${HOME}/.cocoapods/repos/${PROJECT_NAME}"
        fi
		# 如果存在
		if [[ -e ${PROJECT_PATH}/SNProjects/${PROJECT_NAME} ]]; then
			cd ${PROJECT_PATH}/SNProjects/${PROJECT_NAME}
		fi
		if [[ -e ${PROJECT_PATH}/SNPods/${PROJECT_NAME} ]]; then
			cd ${PROJECT_PATH}/SNPods/${PROJECT_NAME}
		fi
		CURRENT_DIRECTORY=$(pwd)
		CURRENT_DIRECTORY=$(basename ${CURRENT_DIRECTORY})
		# 兼容主工程目录ebuy_9520 -> SuningEBuy
		if [[ ${CURRENT_DIRECTORY} =~ "ebuy_" ]]; then
			CURRENT_DIRECTORY="SuningEBuy"
		fi
		if [[ "${CURRENT_DIRECTORY}" = ${PROJECT_NAME} ]]; then
			if [[ -z "$(${GIT} status | grep ${BRANCH_NAME})" ]]; then
				echo "error: 没有找到该分支,请检查"
				exit 1
			else
				${GIT} status | head -2
			fi
		else
			echo "error: 没有找到该库,请检查"
			exit 1
		fi
	done
fi

# BUILD_PARAMETER
BUILD_PARAMETER="${BUILD_PARAMETER} -u -name--${UPLOAD_NAME} -force--enterprise -skip--clean -xcpretty"
# jenkins描述
BUILD_PARAMETER="${BUILD_PARAMETER} -jenkinsDesc--#${BUILD_NUMBER}"
if [[ "${JENKINS_TYPE}" = "jenkins" ]]; then
	# http://10.37.64.97/jenkins/job/SuningEBuy-Framework-850/107/
	JENKINS_URL="http://10.37.64.97/jenkins/job/${JOB_NAME}/${BUILD_NUMBER}/"
elif [[ "${JENKINS_TYPE}" = "phoebus" ]]; then
	# http://10.37.64.97/ftp-ios/Dev_Br_842/suningebuy__researchCloud_pipeline_1578897649221_1/
	JENKINS_URL="http://10.37.64.97/ftp-ios/${GIT_BRANCH_NAME}/${JOB_NAME}_${BUILD_NUMBER}/"
fi
BUILD_PARAMETER="${BUILD_PARAMETER} -jenkinsUrl--${JENKINS_URL}"
# debug
if [[ "${DEBUG}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -debug"
fi
# armv7
if [[ "${ARMV7}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--armv7"
fi
# arm64
if [[ "${ARM64}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--arm64"
fi
# x86_64
if [[ "${X86_64}" = "true" ]]; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--x86_64"
fi

if [[ "${SuningEMall}" = "true" ]]; then
	echo ""
	echo "6-2:打包命令:${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}"
	echo "building..."
	bash ${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}
else
	echo ""	
	echo "6-2:打包命令:${PROJECT_PATH}/ipa-test.sh ${BUILD_PARAMETER}"
	echo "building..."
	bash ${PROJECT_PATH}/ipa-test.sh ${BUILD_PARAMETER}
fi
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

# CURRENT_BUILD_DIRECTORY
CURRENT_BUILD_DIRECTORY=$(ls -rt ${PROJECT_PATH}/build | tail -1)
CURRENT_BUILD_DIRECTORY="${PROJECT_PATH}/build/${CURRENT_BUILD_DIRECTORY}"
cd ${CURRENT_BUILD_DIRECTORY}

#### 替换rsync文件夹中的framework
echo ""
echo "step 7:保存frameworks..."
# rsync pull
echo "1) rsync pull..."
echo "cmd: bash ${PROJECT_PATH}/Scripts/rsync-helper.sh pull ${RSYNC_JOB_PATH}/ | tail -n 3"
bash ${PROJECT_PATH}/Scripts/rsync-helper.sh pull ${RSYNC_JOB_PATH}/ | tail -n 3

echo ""
echo "2) 替换frameworks..."
DERIVEDDATA_BUILD_DIRECTORY=$(grep " OBJROOT" "${CURRENT_BUILD_DIRECTORY}/build_setting.txt")
DERIVEDDATA_BUILD_DIRECTORY=$(echo ${DERIVEDDATA_BUILD_DIRECTORY} | cut  -d  "="  -f  2)
DERIVEDDATA_BUILD_DIRECTORY=$(echo ${DERIVEDDATA_BUILD_DIRECTORY} | grep -o "[^ ]\+\( \+[^ ]\+\)*")
DERIVEDDATA_BUILD_DIRECTORY=$(dirname ${DERIVEDDATA_BUILD_DIRECTORY})
if [[ "${X86_64}" != "true" ]]; then
	# arm架构打的framework路径
	DERIVEDDATA_BUILD_DIRECTORY=${DERIVEDDATA_BUILD_DIRECTORY}/Intermediates.noindex/ArchiveIntermediates
	DERIVEDDATA_BUILD_DIRECTORY=${DERIVEDDATA_BUILD_DIRECTORY}/SuningEBuy/IntermediateBuildFilesPath/UninstalledProducts/iphoneos
else
	# x86_64架构打的framework在Products/Release-iphonesimulator下
	DERIVEDDATA_BUILD_DIRECTORY="${DERIVEDDATA_BUILD_DIRECTORY}/Products/Release-iphonesimulator"
fi
if [[ "${DEBUG}" = "true" ]]; then
	DERIVEDDATA_BUILD_DIRECTORY="${DERIVEDDATA_BUILD_DIRECTORY//Release-iphonesimulator/Debug-iphonesimulator}"
fi
for POD_INFO_ARRAY in ${ALL_POD_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
    eval POD_NAME_STRING=\${${POD_INFO_ARRAY}[${POD_NAME_STRING_INDEX}]}
	eval POD_DESC_STRING=\${${POD_INFO_ARRAY}[${POD_DESC_STRING_INDEX}]}
    eval POD_USING_CODE=\${${POD_INFO_ARRAY}[${POD_USING_CODE_INDEX}]}
    eval POD_USING_CODE_VALUE=\${${POD_INFO_ARRAY}[${POD_USING_CODE_VALUE_INDEX}]}
    eval POD_VERSION_INFO=\${${POD_INFO_ARRAY}[${POD_VERSION_INFO_INDEX}]}
    eval POD_PATH=\${${POD_INFO_ARRAY}[${POD_PATH_INDEX}]}

    echo ""
    echo "${POD_NAME_STRING}:"
    echo "    ${POD_USING_CODE}: 			${POD_USING_CODE_VALUE}"

    if [[ "${POD_USING_CODE_VALUE}" = "true" ]]; then
    	# 是否可以用这次打包的framework替换rsync上的
    	# 因为打包的时候，可能rsync数据有更新，这儿再次判断下版本
    	CAN_PUSH_POD=false

	    # pod库标识符，加上" |",防止snpm和snpmpingou混淆问题
	    # POD_VERSION_INFO，编译的framework信息从versions.txt读取
		for ARCH in "armv7" "arm64" "x86_64"; do
			ARCH_INDEX=0
			if [[ "${ARCH}" = "arm64" ]]; then
				ARCH_INDEX=1
			elif [[ "${ARCH}" = "x86_64" ]]; then
				ARCH_INDEX=2
			fi
			eval RSYNC_POD_VERSION_INFO_STRING=\${${POD_VERSION_INFO}[${ARCH_INDEX}]}
		    if [[ ${RSYNC_POD_VERSION_INFO_STRING} = "" ]]; then
		    	# 之前没有version信息，可以替换
		    	CAN_PUSH_POD=true
		    else
		    	# version.txt中当前库的git日志，在本地工程git日志中有，说明至少是相同的版本，可以替换
		    	RSYNC_POD_VERSION_INFO_GIT_COMMIT=$(echo ${RSYNC_POD_VERSION_INFO_STRING} | cut -d "|" -f 2)
		    	# 去除首尾空格
		    	RSYNC_POD_VERSION_INFO_GIT_COMMIT=$(eval echo "${RSYNC_POD_VERSION_INFO_GIT_COMMIT}")
		    	if [[ "${POD_NAME_STRING}" = "SNSDKs" ]] \
		    		|| [[ "${POD_NAME_STRING}" = "SNLazyLoadFrameworks" ]]; then
		    		# SNSDKs、SNLazyLoadFrameworks库在SNDynamicFrameworks工程中
		    		cd ${PROJECT_PATH}/SNProjects/SNDynamicFrameworks
		    	else
		    		cd ${PROJECT_PATH}/SNProjects/${POD_NAME_STRING}
		    	fi
		    	# 解决出现过一次commit id为7位造成framework不push的bug
		    	# 	SNMBMember-armv7 | 7f08e4d Wed Jun 3 10:17:57 2020 +0800 | build:2020年 6月 8日 星期一 06时11分49秒 CST
		    	# 这儿是7f08e4d，正确的应该为7f08e4d5
		    	# 	7f08e4d5 Wed Jun 3 10:17:57 2020 +0800
		    	RSYNC_POD_VERSION_INFO_GIT_COMMIT2=$(echo ${RSYNC_POD_VERSION_INFO_GIT_COMMIT} | cut -d " " -f 1)
			    if [[ "$(${GIT} log --pretty=format:"%h %cd" | grep "${RSYNC_POD_VERSION_INFO_GIT_COMMIT2}")" != "" ]]; then
			    	CAN_PUSH_POD=true
			    fi
		    fi
		done

	    # 不允许处理framework，则不push
	    if [[ "${SHOULD_PUSH_FRAMEWORKS}" = "false" ]]; then
	    	CAN_PUSH_POD=false
	    fi

	    echo "    CAN_PUSH_POD: 			${CAN_PUSH_POD}"

	    if [[ "${CAN_PUSH_POD}" = "true" ]]; then
	   		# 修改versions.txt
		    echo "versions.txt..."
	   		for ARCH in "armv7" "arm64" "x86_64"; do
	   			ARCH_INDEX=0
				if [[ "${ARCH}" = "arm64" ]]; then
					ARCH_INDEX=1
				elif [[ "${ARCH}" = "x86_64" ]]; then
					ARCH_INDEX=2
				fi
				# 读取versions.txt最新数据
				POD_VERSION_IDENTIFIER="${POD_NAME_STRING}-${ARCH} |"
				RSYNC_POD_VERSION_INFO_STRING=$(cat ${RSYNC_VERSIONS_TXT_PATH} | grep "${POD_VERSION_IDENTIFIER}")
				# 删除之前的记录
		    	sed -i '' "/${POD_VERSION_IDENTIFIER}/d" ${RSYNC_VERSIONS_TXT_PATH}
			    # 添加新记录
				if [[ "${BUILD_ARCHS}" =~ "${ARCH}" ]]; then
	   				# 编译了该架构，用最新的git log
					if [[ ${POD_NAME_STRING} = "SNSDKs" ]] \
						|| [[ ${POD_NAME_STRING} = "SNLazyLoadFrameworks" ]]; then
				    	# SNSDKs、SNLazyLoadFrameworks到SNDynamicFrameworks目录获取git log
				    	cd ${PROJECT_PATH}/SNProjects/SNDynamicFrameworks
				    else
				    	cd ${PROJECT_PATH}/SNProjects/${POD_NAME_STRING}
				    fi
				    POD_LATEST_COMMIT_INFO=$(${GIT} log --pretty=format:"%h %cd" | head -1)
				    RSYNC_POD_VERSION_INFO_STRING="${POD_NAME_STRING}-${ARCH} | ${POD_LATEST_COMMIT_INFO} | build:$(date)"
				fi
				# git信息不为空，写入version.txt文件
				if [[ "${RSYNC_POD_VERSION_INFO_STRING}" != "" ]]; then
					echo "    cmd: echo ${RSYNC_POD_VERSION_INFO_STRING} >> ${RSYNC_VERSIONS_TXT_PATH}"
					echo ${RSYNC_POD_VERSION_INFO_STRING} >> ${RSYNC_VERSIONS_TXT_PATH}
				fi
	   		done

		    # framework
		    echo ""
		    echo "替换framework..."
		    # 清空之前的内容
	    	POD_RSYNC_LOCAL_PATH="${RSYNC_JOB_PATH}/${POD_NAME_STRING}"
	    	mkdir -p ${POD_RSYNC_LOCAL_PATH}
	    	# 替换framework
		    DERIVEDDATA_FRAMEWORK_DIRECTORY="${DERIVEDDATA_BUILD_DIRECTORY}/${POD_NAME_STRING}.framework"
		    RSYNC_FRAMEWORK_DIRECTORY="${POD_RSYNC_LOCAL_PATH}/${POD_NAME_STRING}.framework"
	    	echo "    cmd: \rsync -avz --delete \
	    	    --exclude ${POD_NAME_STRING} \
	    	    --exclude .DS_Store \
	    	    ${DERIVEDDATA_FRAMEWORK_DIRECTORY}/ \
	    	    ${RSYNC_FRAMEWORK_DIRECTORY}/ \
	    	    | tail -n 3"
	    	rsync -avz --delete \
	    	    --exclude ${POD_NAME_STRING} \
	    	    --exclude .DS_Store \
	    	    ${DERIVEDDATA_FRAMEWORK_DIRECTORY}/ \
	    	    ${RSYNC_FRAMEWORK_DIRECTORY}/ \
	    	    | tail -n 3
	    	# 替换可执行文件
	    	if [[ ! -e ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING} ]]; then
	    		# rsync不存在可执行文件，直接拷贝
	    		echo "    cmd: cp -f ${DERIVEDDATA_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING} ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}"
	    		cp -f ${DERIVEDDATA_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING} ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}
	    	else
	    		# 打出来的framework包含的架构
	    		DERIVEDDATA_FRAMEWORK_ARCHS=$(lipo -archs ${DERIVEDDATA_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING})
	    		# 去除两边空格
	    		DERIVEDDATA_FRAMEWORK_ARCHS=$(echo ${DERIVEDDATA_FRAMEWORK_ARCHS})
	    		for FRAMEWORK_ARCH in "armv7" "arm64" "x86_64"
	    		do
	    			if [[ ! "${DERIVEDDATA_FRAMEWORK_ARCHS}" =~ "${FRAMEWORK_ARCH}" ]]; then
	    				# 打出来的framework没有该架构，continue
	    				continue
	    			fi
	    			# 导出单架构 thin file
	    			echo ""
	    			echo "    ${FRAMEWORK_ARCH}:"
	    			DERIVEDDATA_FRAMEWORK_ARCH_PATH="${DERIVEDDATA_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}"
	    			if [[ "${DERIVEDDATA_FRAMEWORK_ARCHS}" != "${FRAMEWORK_ARCH}" ]]; then
	    				# 打出来的framework有多个架构
	    				DERIVEDDATA_FRAMEWORK_ARCH_PATH="${DERIVEDDATA_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}-${FRAMEWORK_ARCH}"
	    				echo "    cmd: lipo ${DERIVEDDATA_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING} \
	    					-thin ${FRAMEWORK_ARCH} \
	    					-output ${DERIVEDDATA_FRAMEWORK_ARCH_PATH}"
	    				lipo ${DERIVEDDATA_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING} \
	    					-thin ${FRAMEWORK_ARCH} \
	    					-output ${DERIVEDDATA_FRAMEWORK_ARCH_PATH}
	    			fi
	    			# 合入rsync中的framework
	    			# rsync中的framework包含的架构
		    		RSYNC_FRAMEWORK_ARCHS=$(lipo -archs ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING})
		    		# 去除两边空格
		    		RSYNC_FRAMEWORK_ARCHS=$(echo ${RSYNC_FRAMEWORK_ARCHS})
	    			if [[ "${RSYNC_FRAMEWORK_ARCHS}" = "${FRAMEWORK_ARCH}" ]]; then
	    				# rsync中的framework是单架构，且和打出来的framework相同，直接拷贝
	    				echo "    cmd: cp -f ${DERIVEDDATA_FRAMEWORK_ARCH_PATH} ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}"
	    				cp -f ${DERIVEDDATA_FRAMEWORK_ARCH_PATH} ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}
	    			elif [[ "${RSYNC_FRAMEWORK_ARCHS}" =~ "${FRAMEWORK_ARCH}" ]]; then
	    				# rsync中的framework已有该架构
	    				echo "    cmd: lipo ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING} \
	    					-replace ${FRAMEWORK_ARCH} ${DERIVEDDATA_FRAMEWORK_ARCH_PATH} \
	    					-output ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}"
	    				lipo ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING} \
	    					-replace ${FRAMEWORK_ARCH} ${DERIVEDDATA_FRAMEWORK_ARCH_PATH} \
	    					-output ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}
	    			else
	    				# rsync中的framework没有该架构
	    				echo "    cmd: lipo ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING} \
	    					-create ${DERIVEDDATA_FRAMEWORK_ARCH_PATH} \
	    					-output ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}"
	    				lipo ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING} \
	    					-create ${DERIVEDDATA_FRAMEWORK_ARCH_PATH} \
	    					-output ${RSYNC_FRAMEWORK_DIRECTORY}/${POD_NAME_STRING}
	    			fi
	    			# 删除单架构 thin file
	    			rm -f ${DERIVEDDATA_FRAMEWORK_ARCH_PATH}-*
	    		done
	    	fi

	    	# 替换podspce文件
	    	echo ""
			echo "替换podspec..."
			if [[ ! "${POD_PATH}" =~ "${RSYNC_JOB_PATH}" ]]; then
				echo "    cmd: cp -f ${POD_PATH}/*.podspec ${RSYNC_JOB_PATH}/${POD_NAME_STRING}"
				cp -f ${POD_PATH}/*.podspec ${RSYNC_JOB_PATH}/${POD_NAME_STRING}
			fi

			# resources，cocoapods不支持软连接，这儿只有先替换整个目录
			echo ""
			echo "替换Resources文件夹..."
			if [[ ! "${POD_PATH}" =~ "${RSYNC_JOB_PATH}" ]]; then
				echo "    cmd: rsync -avz --delete \
				    --exclude .DS_Store \
				    ${POD_PATH}/Resources/ \
				    ${RSYNC_JOB_PATH}/${POD_NAME_STRING}/Resources/ \
				    | tail -n 3"
				rsync -avz --delete \
				    --exclude .DS_Store \
				    ${POD_PATH}/Resources/ \
				    ${RSYNC_JOB_PATH}/${POD_NAME_STRING}/Resources/ \
				    | tail -n 3
			fi

	    	if [[ ${POD_NAME_STRING} = "SNDynamicFrameworks" ]]; then
	    		echo ""
	    		echo "替换SNDynamicFrameworks Headers..."
	    		echo "    cmd: bash ${PROJECT_PATH}/Scripts/jenkins/project/sndynamic-headers-helper.sh ${RSYNC_JOB_PATH}/"
	    		bash ${PROJECT_PATH}/Scripts/jenkins/project/sndynamic-headers-helper.sh ${RSYNC_JOB_PATH}/
	    	fi
	    fi
	else
		echo "    CAN_PUSH_POD: 			false"
    fi
done

echo ""
echo "3) rsync push..."
echo "cmd: bash ${PROJECT_PATH}/Scripts/rsync-helper.sh push ${RSYNC_JOB_PATH}/ | tail -n 3"
bash ${PROJECT_PATH}/Scripts/rsync-helper.sh push ${RSYNC_JOB_PATH}/ | tail -n 3

#### clean
echo ""
echo "4) clean..."
cd ${PROJECT_PATH}
PROJECT_WORKSPACE="SuningEBuy.xcworkspace"
PROJECT_SCHEME="SuningEBuy"
XCODE_CLEAN="xcodebuild -workspace ${PROJECT_WORKSPACE} -scheme ${PROJECT_SCHEME} -configuration Release clean"
${XCODE_CLEAN}

#### 生成归档文件，jenkins Copy Artifact Plugin
echo ""
echo "step 8:生成归档文件..."
# 列出build结果
echo "cmd: ls ${CURRENT_BUILD_DIRECTORY}"
ls ${CURRENT_BUILD_DIRECTORY}
# 拷贝dsynm文件到build-artifacts
BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
for XCARCHIVE_FILE_PATH in $(find ${CURRENT_BUILD_DIRECTORY} -name *.xcarchive -maxdepth 1)
do
	cd ${XCARCHIVE_FILE_PATH}/dSYMs
	for DSYM_FILE_NAME in $(ls)
	do
		if [[ ${DSYM_FILE_NAME} =~ ".dSYM" ]]; then
			echo ""
			echo "cmd: zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1"
			zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1
		fi
	done
done
# debug模式ipa没dsym文件，这儿占个位，不然会提示任务错误
if [[ "${DEBUG}" = "true" ]]; then
	echo "cmd: touch ${BUILD_ARTIFACTS_PATH}/debug-ipa-no-dsym.zip"
	touch ${BUILD_ARTIFACTS_PATH}/debug-ipa-no-dsym.zip
fi
# x86_64架构ipa没dsym文件，这儿占个位，不然会提示任务错误
if [[ "${X86_64}" = "true" ]]; then
	echo "cmd: touch ${BUILD_ARTIFACTS_PATH}/x86_64-ipa-no-dsym.zip"
	touch ${BUILD_ARTIFACTS_PATH}/x86_64-ipa-no-dsym.zip
fi
# build-artifact/README.md
if [[ "${JENKINS_TYPE}" = "phoebus" ]]; then
	# http://10.37.87.240/job/ebuy_9040/54/
	JENKINS_URL="http://10.37.87.240/job/${JOB_NAME}/${BUILD_NUMBER}/"
	# 创建README.md
	echo "# 研发云打包" >> ${BUILD_ARTIFACTS_PATH}/README.md
	echo "" >> ${BUILD_ARTIFACTS_PATH}/README.md
	echo "[${JENKINS_URL}](${JENKINS_URL})" >> ${BUILD_ARTIFACTS_PATH}/README.md
fi
# 兼容研发云Delete workspace when build is done
if [[ -d ${WORKSPACE}/build-artifacts ]] && [[ ! -L ${WORKSPACE}/build-artifacts ]]; then
    rm -rf ${WORKSPACE}/build-artifacts
fi
ln -fs ${BUILD_ARTIFACTS_PATH} ${WORKSPACE}/

#### 打印编译信息
echo ""
echo "step 9:打印编译的各framework信息..."
for POD_INFO_ARRAY in ${ALL_POD_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
    eval POD_NAME_STRING=\${${POD_INFO_ARRAY}[${POD_NAME_STRING_INDEX}]}
	eval POD_DESC_STRING=\${${POD_INFO_ARRAY}[${POD_DESC_STRING_INDEX}]}
    eval POD_USING_CODE=\${${POD_INFO_ARRAY}[${POD_USING_CODE_INDEX}]}
    eval POD_USING_CODE_VALUE=\${${POD_INFO_ARRAY}[${POD_USING_CODE_VALUE_INDEX}]}
    eval POD_VERSION_INFO=\${${POD_INFO_ARRAY}[${POD_VERSION_INFO_INDEX}]}
    eval POD_PATH=\${${POD_INFO_ARRAY}[${POD_PATH_INDEX}]}

    echo ""
    echo "${POD_NAME_STRING}:"
    if [[ "${POD_USING_CODE_VALUE}" = "true" ]]; then
    	echo "    使用代码打包"
    else
    	echo "    使用framework打包"
    	for ARCH in "armv7" "arm64" "x86_64"; do
    		# 当前没打这个架构的包，continue
    		if [[ ! "${BUILD_ARCHS}" =~ "${ARCH}" ]]; then
    			continue
    		fi
			ARCH_INDEX=0
			if [[ "${ARCH}" = "arm64" ]]; then
				ARCH_INDEX=1
			elif [[ "${ARCH}" = "x86_64" ]]; then
				ARCH_INDEX=2
			fi
			eval RSYNC_POD_VERSION_INFO_STRING=\${${POD_VERSION_INFO}[${ARCH_INDEX}]}
			echo "    ${ARCH}"
			echo "        framework build time:			$(echo ${RSYNC_POD_VERSION_INFO_STRING} | cut -d "|" -f 3)"
    		echo "        framework build git log:		$(echo ${RSYNC_POD_VERSION_INFO_STRING} | cut -d "|" -f 2)"
		done
    fi
done
echo ""

