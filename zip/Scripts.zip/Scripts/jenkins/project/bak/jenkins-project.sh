#!/bin/bash
# jenkins设置中执行脚本

# set -e

# # 模拟参数
# SNMPaySDK_PATH="libSNMPaySDK/branches/2.9.7.1"
# SNMPayDependency_PATH="SNMPayDependency/tags/3.6.0.3"
# YFBWalletLibs_PATH="YFBWalletSDK/branches/3.0.0.718"
# YFBWalletSDKDependency_PATH="YFBWalletSDKDependency/branches/2.2.0.718"

#### 系统环境
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

export LANG=zh_CN.UTF-8
PATH=${PATH}:/usr/local/bin
if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi

#### 变量
echo ""
echo "step 1:更新主工程代码..."
# 默认值
if [[ ! ${WORKSPACE} ]]; then
	WORKSPACE=${SCRIPT_DIR}/SuningEBuy
	mkdir -p ${WORKSPACE}
fi
cd ${WORKSPACE}

PROJECT_PATH="${WORKSPACE}"

PROJECT_NAME="SuningEBuy"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

GIT_BRANCH_VERSION="830"
# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
	# jenkins打包 SuningEBuy-840
	GIT_BRANCH_VERSION=${JOB_NAME##*-}
elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
	# 研发云打包 ebuy_840
	GIT_BRANCH_VERSION=${JOB_NAME##*_}
fi
# 研发云流水线 origin/Dev_Br_850
if [[ "${GIT_BRANCH}" =~ "origin/" ]]; then
	GIT_BRANCH_VERSION=${GIT_BRANCH##*_}
fi
GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

# 拉取代码
cd ${WORKSPACE}
if [ ! -d ${WORKSPACE}/.git ]; then
	${GIT} init
	${GIT} remote add origin ${GIT_URL}
	${GIT} fetch
	${GIT} checkout ${GIT_BRANCH_NAME}
fi
# 放弃本地修改
if [[ "$(${GIT} status)" =~ "unmerged" ]]; then
	${GIT} reset --hard HEAD
fi
${GIT} checkout . 
# 删除Untracked files
${GIT} clean -fd
# 切换分支
${GIT} checkout ${GIT_BRANCH_NAME}
# 拉取代码
${GIT} pull

#### 打包前处理
echo ""
echo "step 2:打包前处理..."
# 清理归档文件...
echo "1) clean..."
bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-clean-helper.sh

# 打包间隔检查
echo ""
echo "2) 打包间隔检查..."
BUILD_IDENTIFIER="${JOB_NAME}"
BUILD_DURATION="0"
if [[ "${CHECK_LAST_BUILD_TIME}" = "true" ]];then
	BUILD_DURATION="15"
fi
BUILD_CHECK_URL="http://10.37.64.97/ipa/build.json?identifier=${BUILD_IDENTIFIER}&duration=${BUILD_DURATION}"
BUILD_CHECK_RESULT=$(curl -m 10 -s ${BUILD_CHECK_URL})
echo "check url: ${BUILD_CHECK_URL}"
echo "check result: ${BUILD_CHECK_RESULT}"
if [[ ! ${BUILD_CHECK_RESULT} =~ "\"code\":\"0\"" ]]; then
	BUILD_CHECK_RESULT_MSG=$(echo ${BUILD_CHECK_RESULT} | cut -d "\"" -f 4)
	echo "error: 不打包, ${BUILD_CHECK_RESULT_MSG}"
	echo ""
	echo "如果想强制打包，打包的时候，不要勾选CHECK_LAST_BUILD_TIME即可😢 😢 😢"
	echo ""
	exit 1
else
	echo ""
	echo "开始打包🚀 🚀 🚀"
fi

#### 输入参数检查
echo ""
echo "step 3:参数..."
BUILD_PARAMETER=""
if ${pre}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -pre"
fi
if ${xgpre}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -xgpre"
fi
if ${poc}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -poc"
fi
if ${prd}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -prd"
fi
if ${sit}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -sit"
fi
if [ "${BUILD_PARAMETER}" = "" ]; then
	echo "请选择打包环境"
	exit 0
fi

if [ "${UPLOAD_NAME}" = "" ]; then
	if ${SuningEMall}; then
		UPLOAD_NAME="官方定位分享包"
	else
		UPLOAD_NAME="官方测试包"
	fi
fi
if [[ "${SERVER_TYPE}" =~ "server-" ]]; then
	BUILD_IDENTIFIER=${SERVER_TYPE#*server-}
	UPLOAD_NAME="${BUILD_IDENTIFIER}号打包机-${UPLOAD_NAME}"
fi

echo ""
echo "JENKINS_TYPE:      					${JENKINS_TYPE}"
echo "WORKSPACE:      					${WORKSPACE}"
echo "JOB_NAME:         					${JOB_NAME}"
echo "GIT_URL:          					${GIT_URL}"
echo "PROJECT_NAME:     					${PROJECT_NAME}"
echo "GIT_BRANCH_NAME:  					${GIT_BRANCH_NAME}"

echo ""
echo "buld参数"
echo "BUILD_PARAMETER:          				${BUILD_PARAMETER}"
echo "UPLOAD_NAME:      					${UPLOAD_NAME}"

#### pull代码
echo ""
echo "step 4:pull code..."
# updateAllCode
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/updateAllCode.sh -checkupdate
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### pod集成
echo ''
echo 'step 5:pod集成...'
# 清空之前pod生成文件
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
for PBXPROJ_PATH in `find ${PROJECT_PATH}/SNProjects -name project.pbxproj`
do
    sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
done

# 修改Podfile
echo "修改Podfile..."
PODFILE_PATH=${PROJECT_PATH}/Podfile
sed -i '' "s/using_code_sncommon = false/using_code_sncommon = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_sncommon ="

sed -i '' "s/using_code_snsearch = false/using_code_snsearch = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snsearch ="

sed -i '' "s/using_code_snproduct = false/using_code_snproduct = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snproduct ="

sed -i '' "s/using_code_snpingou = false/using_code_snpingou = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snpingou ="

sed -i '' "s/using_code_snpm = false/using_code_snpm = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snpm ="

sed -i '' "s/using_code_snlogin = false/using_code_snlogin = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snlogin ="

sed -i '' "s/using_code_snmember = false/using_code_snmember = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snmember ="

sed -i '' "s/using_code_snsl = false/using_code_snsl = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snsl ="

sed -i '' "s/using_code_snlive = false/using_code_snlive = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snlive ="

sed -i '' "s/using_code_snmk = false/using_code_snmk = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snmk ="

sed -i '' "s/using_code_snmptm = false/using_code_snmptm = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snmptm ="

sed -i '' "s/using_code_snhwg = false/using_code_snhwg = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snhwg ="

sed -i '' "s/using_code_snchannel = false/using_code_snchannel = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snchannel ="

sed -i '' "s/using_code_snsm = false/using_code_snsm = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snsm ="

sed -i '' "s/using_code_snhome = false/using_code_snhome = true/" ${PODFILE_PATH}
cat ${PODFILE_PATH} | grep "using_code_snhome ="

if [ "${SNMPaySDK_PATH}" != "" ]; then
	SNMPaySDK_PATH="POD_SPEC_PATH_YFBSDK + \'${SNMPaySDK_PATH}"
	SNMPaySDK_PATH=${SNMPaySDK_PATH//\//\\\/}
	SNMPaySDK_PATH=${SNMPaySDK_PATH//\./\\\.}
	# echo "libSNMPaySDK:${SNMPaySDK_PATH}"
	sed -i '' "s/POD_BUSS_SPEC_PATH + \'BussLibs\/SNEBuy_YFBSDK_Ebuy\/libSNMPaySDK\/.*'/${SNMPaySDK_PATH}'/" ${PODFILE_PATH}
	echo ""
	echo "libSNMPaySDK"
	cat ${PODFILE_PATH} | grep "pod 'libSNMPaySDK"
fi

if [ "${SNMPayDependency_PATH}" != "" ]; then
	SNMPayDependency_PATH="POD_SPEC_PATH_YFBSDK + \'${SNMPayDependency_PATH}"
	SNMPayDependency_PATH=${SNMPayDependency_PATH//\//\\\/}
	SNMPayDependency_PATH=${SNMPayDependency_PATH//\./\\\.}
	# echo "SNMPayDependency:${SNMPayDependency_PATH}"
	sed -i '' "s/POD_BUSS_SPEC_PATH + \'BussLibs\/SNEBuy_YFBSDK_Ebuy\/SNMPayDependency\/.*'/${SNMPayDependency_PATH}'/" ${PODFILE_PATH}
	echo ""
	echo "SNMPayDependency"
	cat ${PODFILE_PATH} | grep "pod 'SNMPayDependency"
fi

if [ "${YFBWalletLibs_PATH}" != "" ]; then
	YFBWalletLibs_PATH="POD_SPEC_PATH_YFBWallet + \'${YFBWalletLibs_PATH}"
	YFBWalletLibs_PATH=${YFBWalletLibs_PATH//\//\\\/}
	YFBWalletLibs_PATH=${YFBWalletLibs_PATH//\./\\\.}
	# echo "YFBWalletLibs:${YFBWalletLibs_PATH}"
	sed -i '' "s/POD_BUSS_SPEC_PATH + \'BussLibs\/SNEBuy_YFBWallet\/YFBWalletSDK\/.*'/${YFBWalletLibs_PATH}'/" ${PODFILE_PATH}
	echo ""
	echo "YFBWalletSDK"
	cat ${PODFILE_PATH} | grep "pod 'YFBWalletSDK"
fi

if [ "${YFBWalletSDKDependency_PATH}" != "" ]; then
	YFBWalletSDKDependency_PATH="POD_SPEC_PATH_YFBWallet + \'${YFBWalletSDKDependency_PATH}"
	YFBWalletSDKDependency_PATH=${YFBWalletSDKDependency_PATH//\//\\\/}
	YFBWalletSDKDependency_PATH=${YFBWalletSDKDependency_PATH//\./\\\.}
	# echo "YFBWalletSDKDependency_PATH:${YFBWalletSDKDependency_PATH}"
	sed -i '' "s/POD_BUSS_SPEC_PATH + \'BussLibs\/SNEBuy_YFBWallet\/YFBWalletSDKDependency\/.*'/${YFBWalletSDKDependency_PATH}'/" ${PODFILE_PATH}
	echo ""
	echo "YFBWalletSDKDependency"
	cat ${PODFILE_PATH} | grep "pod 'YFBWalletSDKDependency"
fi

# repo-update
cd ${PROJECT_PATH}/
if [ "${SNMPaySDK_PATH}" != "" ]; then
	bash ${PROJECT_PATH}/repo-update.sh -paysdk -checkupdate
else
	bash ${PROJECT_PATH}/repo-update.sh -checkupdate
fi
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### 打包
echo ''
echo 'step 6:打包...'
echo "6-1:打印Podfile"
cat ${PODFILE_PATH}

# BUILD_PARAMETER
BUILD_PARAMETER="${BUILD_PARAMETER} -u -name--${UPLOAD_NAME} -force--enterprise -xcpretty"
# debug
if ${DEBUG}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -debug"
fi
# armv7
if ${ARMV7}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--armv7"
fi
# arm64
if ${ARM64}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--arm64"
fi
# x86_64
if ${X86_64}; then
	BUILD_PARAMETER="${BUILD_PARAMETER} -arch--x86_64"
fi

# ipa-test
cd ${PROJECT_PATH}/
if ${SuningEMall}; then
	echo "6-2:打包命令:${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}"
	echo ''
	echo "building..."
	bash ${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}
else
	echo "6-2:打包命令:${PROJECT_PATH}/ipa-test.sh ${BUILD_PARAMETER}"
	echo ''	
	echo "building..."
	bash ${PROJECT_PATH}/ipa-test.sh ${BUILD_PARAMETER}
fi

# CURRENT_BUILD_DIRECTORY
CURRENT_BUILD_DIRECTORY=$(ls -rt ${PROJECT_PATH}/build | tail -1)
CURRENT_BUILD_DIRECTORY="${PROJECT_PATH}/build/${CURRENT_BUILD_DIRECTORY}"
cd ${CURRENT_BUILD_DIRECTORY}

#### 生成归档文件，jenkins Copy Artifact Plugin
echo ''
echo ''
echo 'step 7:生成归档文件...'
# 列出build结果
echo "cmd: ls ${CURRENT_BUILD_DIRECTORY}"
ls ${CURRENT_BUILD_DIRECTORY}
# 拷贝dsynm文件到build-artifacts
BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
for XCARCHIVE_FILE_PATH in $(find ${CURRENT_BUILD_DIRECTORY} -name *.xcarchive -maxdepth 1); do
	cd ${XCARCHIVE_FILE_PATH}/dSYMs
	for DSYM_FILE_NAME in $(ls)
	do
		if [[ ${DSYM_FILE_NAME} =~ ".dSYM" ]]; then
			echo ""
			echo "cmd: zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1"
			zip -r ${BUILD_ARTIFACTS_PATH}/${DSYM_FILE_NAME}.zip ${DSYM_FILE_NAME} >/dev/null 2>&1
		fi
	done
done
# debug模式ipa没dsym文件，这儿占个位，不然会提示任务错误
if ${DEBUG}; then
	touch ${BUILD_ARTIFACTS_PATH}/debug-ipa-no-dsym.zip
fi
# x86_64架构ipa没dsym文件，这儿占个位，不然会提示任务错误
if ${X86_64}; then
	touch ${BUILD_ARTIFACTS_PATH}/x86_64-ipa-no-dsym.zip
fi

