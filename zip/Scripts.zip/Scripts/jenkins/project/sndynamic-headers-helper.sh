# #!/bin/bash
# sndynamic-headers-helper.sh

# 功能:处理两个库的头文件，将他们
# 将SNDynamicFrameworks和SNSDKs工程的头文件放到rsync目录下，供framework打包使用
# 用法
# ./sndynamic-headers-helper.sh ${HOME}/.cocoapods/repos/SNEBuy_build_rsync/SuningEBuyES-Framework-120

# 两种头文件类型
# 1. pod/xxx。h
# 		这个导入方式有<pod/xxx.h>和"xx.h"两种
# 2. pod/framework/xxx.h
# 		导入方式只有<framework/xxx.h>一种

# Pods/Target\ Support\ Files/Pods-SNDynamicFrameworks/Pods-SNDynamicFrameworks.release.xcconfig 
# OTHER_LDFLAGS 
# HEADER_SEARCH_PATHS

# 环境
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

PROJECT_PATH=$(cd ${SCRIPT_DIR}/../../../; pwd)
cd ${PROJECT_PATH}

if [[ ! -d ${PROJECT_PATH}/Pods ]]; then
	echo "工程无Pods文件夹，无法拷贝Headers..."
    exit 1
fi

RSYNC_JOB_PATH=$1

RSYNC_LOCAL_ROOT_PATH="${HOME}/.cocoapods/repos/SNEBuy_build_rsync"
if [[ ! "${RSYNC_JOB_PATH}" =~ "${RSYNC_LOCAL_ROOT_PATH}" ]]; then
    echo "只处理${HOME}/.cocoapods/repos/SNEBuy_build_rsync目录文件"
    exit 1
fi

echo "1.拷贝SNDynamicFrameworks依赖的所有pod库头文件..."
# 方案
# 将SNDynamicFrameworks依赖的所有pod库头文件拷贝到SNDynamicFrameworks.framework/Headers/xxx/下

# PROJECT_POD_NAME_ARRAY SNDynamicFrameworks包含的pod列表
PROJECT_POD_NAME_ARRAY=()
for PROJECT_NAME_STRING in "SNDynamicFrameworks" "SNSDKs"
do
	PROJECT_XCCONFIG_PATH="${PROJECT_PATH}/Pods/Target Support Files/Pods-${PROJECT_NAME_STRING}/Pods-${PROJECT_NAME_STRING}.release.xcconfig"
	if [[ ! -f ${PROJECT_XCCONFIG_PATH} ]]; then
		echo "cocoapods生成的工程xcconfig文件找不到..."
    	exit 1
	fi

	# 解析xcconfig文件OTHER_LDFLAGS对应的字符串
	PROJECT_OTHER_LDFLAGS=$(cat "${PROJECT_XCCONFIG_PATH}" | grep "OTHER_LDFLAGS")
	# 替换所有的" -l"为" -framework "
	PROJECT_OTHER_LDFLAGS=${PROJECT_OTHER_LDFLAGS//" -l"/" -framework "}
	# 以" -framework "分割成数组
	PROJECT_OTHER_LDFLAGS_ARRAY=(${PROJECT_OTHER_LDFLAGS//" -framework "/ })
	# 遍历，找出所有的pod
	for PROJECT_POD_NAME in ${PROJECT_OTHER_LDFLAGS_ARRAY[@]}
	do
		if [[ ${PROJECT_POD_NAME} =~ "\"" ]]; then
			# 替换单引号为空
			PROJECT_POD_NAME=${PROJECT_POD_NAME//\"/}
			# echo ""
			# echo "包含pod: ${PROJECT_POD_NAME}"
			PROJECT_POD_NAME_ARRAY=(${PROJECT_POD_NAME_ARRAY[@]} ${PROJECT_POD_NAME})
		fi
	done

	# 解析xcconfig文件LIBRARY_SEARCH_PATHS对应的字符串
	PROJECT_LIBRARY_SEARCH_PATHS=$(cat "${PROJECT_XCCONFIG_PATH}" | grep "LIBRARY_SEARCH_PATHS")
	# 以空格" "分割成数组
	PROJECT_LIBRARY_SEARCH_PATHS_ARRAY=(${PROJECT_LIBRARY_SEARCH_PATHS//" "/ })
	# 遍历，找出所有的pod
	for PROJECT_POD_NAME in ${PROJECT_LIBRARY_SEARCH_PATHS_ARRAY[@]}
	do
		if [[ ${PROJECT_POD_NAME} =~ "\"" ]]; then
			# 替换单引号为空
			PROJECT_POD_NAME=${PROJECT_POD_NAME//\"/}
			PROJECT_POD_NAME=${PROJECT_POD_NAME##*/}
			# echo ""
			# echo "包含pod: ${PROJECT_POD_NAME}"
			PROJECT_POD_NAME_ARRAY=(${PROJECT_POD_NAME_ARRAY[@]} ${PROJECT_POD_NAME})
		fi
	done
done

# 先清除之前的头文件
# 头文件全部放在SNDynamicFrameworks库中，方便一些
SNDYNAMIC_FRAMEWORK_HEADERS_DIRECTORY="${RSYNC_JOB_PATH}/SNDynamicFrameworks/SNDynamicFrameworks.framework/Headers"
mkdir -p ${SNDYNAMIC_FRAMEWORK_HEADERS_DIRECTORY}
rm -rf ${SNDYNAMIC_FRAMEWORK_HEADERS_DIRECTORY}/*

# 开始拷贝
for PROJECT_POD_NAME in ${PROJECT_POD_NAME_ARRAY[@]}
do
	# echo ""
	# echo "包含pod: ${PROJECT_POD_NAME}"
	# cocoapods生成的库名称可能带-，例如SNFoundation-682f520b，这儿兼容下
	TMP_PROJECT_POD_NAME="${PROJECT_POD_NAME}-"
	while [[ "${TMP_PROJECT_POD_NAME}" =~ "-" ]]; do
		TMP_PROJECT_POD_NAME=${TMP_PROJECT_POD_NAME%-*}
		# echo "    TMP_PROJECT_POD_NAME:			${TMP_PROJECT_POD_NAME}"
		# cocoapods生成的库名会去除库前面的lib,例如libSNMPaySDK变为SNMPaySDK，这儿多搜索个,兼容下
		# 最高搜索3级目录中的文件夹
		for PROJECT_POD_HEADER_DIRECTORY in \
			$(find ${PROJECT_PATH}/Pods/Headers -type d -maxdepth 3 -name ${TMP_PROJECT_POD_NAME} -o -name lib${TMP_PROJECT_POD_NAME}); 
		do
			# # cocoapods会移除pod库名称前面的lib，兼容
			# TMP_PROJECT_POD_NAME=${TMP_PROJECT_POD_NAME//lib/}
			# echo "    PROJECT_POD_HEADER_DIRECTORY:		${PROJECT_POD_HEADER_DIRECTORY}"
			mkdir -p ${SNDYNAMIC_FRAMEWORK_HEADERS_DIRECTORY}/${TMP_PROJECT_POD_NAME}
			# echo "cmd: cp -rf ${PROJECT_POD_HEADER_DIRECTORY}/* ${SNDYNAMIC_FRAMEWORK_HEADERS_DIRECTORY}/${TMP_PROJECT_POD_NAME}/"
			cp -rf ${PROJECT_POD_HEADER_DIRECTORY}/* ${SNDYNAMIC_FRAMEWORK_HEADERS_DIRECTORY}/${TMP_PROJECT_POD_NAME}/
		done
	done
done

# 兼容cocoapods1.8.4
# 如果工程使用的是cocoapods1.8.4版本，则需要额外修改SNDynamicFrameworks_Framework.podspec
# PROJECT_USE_POD18
# pod18不会在Headers下生成framework头文件夹
# 这儿用SAStatistic_SDK这个framework来判断，易购app应该都会接入
PROJECT_USE_POD18=false
if [[ ! -e ${PROJECT_PATH}/Pods/Headers/Public/SAStatistic_SDK ]]; then
	PROJECT_USE_POD18=true
fi
if [[ "${PROJECT_USE_POD18}" = "true" ]]; then
	echo "2.兼容cocoapods1.8.4..."
	
	# 1.兼容framework的pod库
	echo "2-1.兼容framework的pod库"
	# 1-1:先回退之前的修改
	PODSPEC_PATH=${RSYNC_JOB_PATH}/SNDynamicFrameworks/SNDynamicFrameworks_Framework.podspec
	sed -i '' "/pod18/d" ${PODSPEC_PATH}
	# 1-2:读取所有FRAMEWORK_SEARCH_PATHS
	PROJECT_XCCONFIG_PATH="${PROJECT_PATH}/Pods/Target Support Files/Pods-SNDynamicFrameworks/Pods-SNDynamicFrameworks.release.xcconfig"
	FRAMEWORK_SEARCH_PATHS=$(cat "${PROJECT_XCCONFIG_PATH}" | grep "FRAMEWORK_SEARCH_PATHS =")
	for FRAMEWORK_SEARCH_PATH in ${FRAMEWORK_SEARCH_PATHS[*]}; do
		# echo "FRAMEWORK_SEARCH_PATH: ${FRAMEWORK_SEARCH_PATH}"
		if [[ "${FRAMEWORK_SEARCH_PATH}" = "FRAMEWORK_SEARCH_PATHS" ]]; then
			continue
		fi
		if [[ "${FRAMEWORK_SEARCH_PATH}" = "=" ]]; then
			continue
		fi
		if [[ "${FRAMEWORK_SEARCH_PATH}" = "\$(inherited)" ]]; then
			continue
		fi
		# "${PODS_ROOT}/../../../../../../.cocoapods/repos/SNEBuy_repos/AlipaySDK/15.7.5/AlipaySDK"
		# 替换为${HOME}/.cocoapods/repos/SNEBuy_repos/AlipaySDK/15.7.5/AlipaySD
		if [[ "${FRAMEWORK_SEARCH_PATH}" =~ "/.cocoapods/repos/" ]]; then
			FRAMEWORK_SEARCH_PATH=${FRAMEWORK_SEARCH_PATH#*/.cocoapods/repos/}
			FRAMEWORK_SEARCH_PATH="\"\${HOME}/.cocoapods/repos/${FRAMEWORK_SEARCH_PATH}"
		fi
		if [[ ! ${ALL_FRAMEWORK_SEARCH_PATHS} =~ "${FRAMEWORK_SEARCH_PATH}" ]]; then
			# echo "found framework path: ${FRAMEWORK_SEARCH_PATH}"
			ALL_FRAMEWORK_SEARCH_PATHS="${ALL_FRAMEWORK_SEARCH_PATHS} ${FRAMEWORK_SEARCH_PATH}"
		fi
	done
	# 1-3:修改podspec
	# 找到最后一行行号
	LINE_END_NUMBER=$(grep -n "end" ${PODSPEC_PATH} | tail -1)
	LINE_END_NUMBER=${LINE_END_NUMBER%:*}
	LINE_END_NUMBER=$((${LINE_END_NUMBER}-1))
	# s.xcconfig = { "FRAMEWORK_SEARCH_PATHS" => pod18_framework_search_paths }
	sed -i '' "${LINE_END_NUMBER}a\\
	\ \ s.xcconfig = { \"FRAMEWORK_SEARCH_PATHS\" => pod18_framework_search_paths }\\
	" ${PODSPEC_PATH}
	# pod18_framework_search_paths += " \"${HOME}/.cocoapods/repos/SNEBuy_repos/SNSDeviceIdentifier/1.6.5/SNSDeviceIdentifier\""
	for FRAMEWORK_SEARCH_PATH in ${ALL_FRAMEWORK_SEARCH_PATHS[*]}
	do
		FRAMEWORK_SEARCH_PATH2=${FRAMEWORK_SEARCH_PATH#\"}
		FRAMEWORK_SEARCH_PATH2=${FRAMEWORK_SEARCH_PATH2%\"}
		# 替换$为\$
		FRAMEWORK_SEARCH_PATH2=${FRAMEWORK_SEARCH_PATH2//\$/\\\$}
		# echo ${FRAMEWORK_SEARCH_PATH2}

		sed -i '' "${LINE_END_NUMBER}a\\
		\ \ pod18_framework_search_paths += \" \\\\\"${FRAMEWORK_SEARCH_PATH2}\\\\\"\"\\
		" ${PODSPEC_PATH}
	done
	# pod18_framework_search_paths = ""
	sed -i '' "${LINE_END_NUMBER}a\\
	\ \ pod18_framework_search_paths = \"\"\\
	" ${PODSPEC_PATH}
	sed -i '' "${LINE_END_NUMBER}a\\
	\ \ # pod18:framework打包兼容cocoapods1.8.4\\
	" ${PODSPEC_PATH}

	# 2.兼容代码的pod库
	echo "2-2.兼容代码的pod库"
	echo "由cocoapods-helper.sh脚本在post_install时兼容,这里不做操作"
fi

