#!/bin/bash
# jenkins设置中执行脚本

# set -e

# #### 模拟参数
# GIT_BRANCH_NAME="Dev_Br_818"
# PROJECT_VERSION="8.1.8"
# PROJECT_BUILD_VERSION="8.1.8.1"

# # #### 模拟参数2
# WORKSPACE="/Users/wangbin/.jenkins-slave/workspace/SuningEBuy-Appstore"
# PROJECT_NAME="SuningEBuy"
# PROJECT_PATH="${WORKSPACE}/${PROJECT_NAME}"
# PROJECT_PBXPROJ_PATH="${PROJECT_PATH}/SuningEBuy.xcodeproj/project.pbxproj"
# set +H

#### 环境变量
echo ''
echo 'step 1:环境变量...'
export LANG=zh_CN.UTF-8
PATH=${PATH}:/usr/local/bin
if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi

# 基本变量
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

# WORKSPACE默认值
if [ ! ${WORKSPACE} ]; then
	WORKSPACE=${SCRIPT_DIR}
fi
cd ${WORKSPACE}

PROJECT_NAME="SuningEBuy"

PROJECT_PATH="${WORKSPACE}/${PROJECT_NAME}"

# git
GIT="git"

GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

# svn
SVN="svn"

echo "JOB_NAME:         		${JOB_NAME}"
echo "GIT_URL:          		${GIT_URL}"
echo "PROJECT_NAME:     		${PROJECT_NAME}"

#### 输入参数检查
echo ''
echo 'step 2:参数检查...'
if [ "${GIT_BRANCH_NAME}" = "" ]; then
	echo "不能为空：				GIT_BRANCH_NAME"
	exit 0
fi
if [ "${PROJECT_VERSION}" = "" ]; then
	echo "不能为空：				PROJECT_VERSION"
	exit 0
fi
if [ "${PROJECT_BUILD_VERSION}" = "" ]; then
	echo "不能为空：				PROJECT_BUILD_VERSION"
	exit 0
fi

echo "GIT_BRANCH_NAME: 			${GIT_BRANCH_NAME}"
echo "PROJECT_VERSION:  		${PROJECT_VERSION}"
echo "PROJECT_BUILD_VERSION:  	${PROJECT_BUILD_VERSION}"

#### clean
echo ''
echo 'step 3:clean...'
echo "3-1:主工程${PROJECT_NAME}"
if [ -d ${PROJECT_PATH} ]; then
	echo "clean ${PROJECT_PATH}..."
	cd ${PROJECT_PATH}
	# 放弃本地修改
	${GIT} checkout . 
	# 删除Untracked files
	${GIT} clean -fd
	# 切换分支
	${GIT} checkout ${GIT_BRANCH_NAME}
	echo "finish"
fi

echo "3-2:pod repos"
# SNEBuy_buss_repos、SNEBuy_repos
for POD_REPO_PATH in "${HOME}/.cocoapods/repos/SNEBuy_buss_repos" \
  "${HOME}/.cocoapods/repos/SNEBuy_repos"
do
	if [ -d ${POD_REPO_PATH} ]; then
		echo "clean ${POD_REPO_PATH}..."
		cd ${POD_REPO_PATH}
		# 放弃本地修改
		${GIT} checkout . 
		# 删除Untracked files
		${GIT} clean -fd
		# 切换分支
		if [[ ${POD_REPO_PATH} =~ "SNEBuy_buss_repos" ]]; then
			${GIT} checkout Dev_Br_buss_repos
		elif [[ ${POD_REPO_PATH} =~ "SNEBuy_repos" ]]; then
			${GIT} checkout Dev_Br_repos
		fi
		echo "finish"
	fi
done

# SNEBuy_YFBSDK、SNEBuy_YFBWallet
for POD_REPO_PATH in "${HOME}/.cocoapods/repos/SNEBuy_YFBSDK" \
  "${HOME}/.cocoapods/repos/SNEBuy_YFBWallet"
do
	if [ -d ${POD_REPO_PATH} ]; then
		echo "clean ${POD_REPO_PATH}..."
		cd ${POD_REPO_PATH}
		${SVN} cleanup
		${SVN} revert . -R
		echo "finish"
	fi
done

echo "3-3:子工程"
for SUB_PROJECT_PATH in "${PROJECT_PATH}/SNProjects/SNChannel" \
  "${PROJECT_PATH}/SNProjects/SNDynamicFrameworks" \
  "${PROJECT_PATH}/SNProjects/SNHomePage" \
  "${PROJECT_PATH}/SNProjects/SNHWG" \
  "${PROJECT_PATH}/SNProjects/SNLive" \
  "${PROJECT_PATH}/SNProjects/SNMBLoginRegister" \
  "${PROJECT_PATH}/SNProjects/SNMBMember" \
  "${PROJECT_PATH}/SNProjects/SNMK" \
  "${PROJECT_PATH}/SNProjects/SNMPTM" \
  "${PROJECT_PATH}/SNProjects/SNPM" \
  "${PROJECT_PATH}/SNProjects/SNPMPinGou" \
  "${PROJECT_PATH}/SNProjects/SNPMPinGouDynamic" \
  "${PROJECT_PATH}/SNProjects/SNSHProductDetail" \
  "${PROJECT_PATH}/SNProjects/SNSHSearch" \
  "${PROJECT_PATH}/SNProjects/SNSL" \
  "${PROJECT_PATH}/SNProjects/SNSM"
do
	if [ -d ${SUB_PROJECT_PATH} ]; then
		echo "clean ${SUB_PROJECT_PATH}..."
		cd ${SUB_PROJECT_PATH}
		# 放弃本地修改
		${GIT} checkout . 
		# 删除Untracked files
		${GIT} clean -fd
		# 切换分支
		${GIT} checkout ${GIT_BRANCH_NAME}
		echo "finish"
	fi
done

echo "3-4:build目录"
# 删除工程打包build目录1天前文件夹
BUILD_DIRECTORY="${PROJECT_PATH}/build"
if [ -e ${BUILD_DIRECTORY} ];then 
	echo "cmd: rm -rf ${BUILD_DIRECTORY}/*"
	rm -rf ${BUILD_DIRECTORY}/*
fi

echo "3-5:.jenkins-slave/workspace"
# 删除.jenkins-slave下7天没使用的workspace
JENKINS_WORKSPACE_DIRECTORY="${HOME}/.jenkins-slave/workspace"
for JOB_WORKSPACE_NAME in $(ls ${JENKINS_WORKSPACE_DIRECTORY}); do
	JOB_SAVE_MAX_DAYS="7"
	JOB_MODIFY_FILE_LIST_IN_MAX_DAYS=$(find ${JENKINS_WORKSPACE_DIRECTORY}/${JOB_WORKSPACE_NAME} -mtime -${JOB_SAVE_MAX_DAYS})
    if [[ ${JOB_MODIFY_FILE_LIST_IN_MAX_DAYS} = "" ]]; then
		echo "JOB ${JOB_WORKSPACE_NAME} ${JOB_SAVE_MAX_DAYS}天内没修改，删除..."
		echo "cmd: rm -rf ${JENKINS_WORKSPACE_DIRECTORY}/${JOB_WORKSPACE_NAME}"
		rm -rf ${JENKINS_WORKSPACE_DIRECTORY}/${JOB_WORKSPACE_NAME}
    fi
done

#### pull代码
echo ''
cd ${WORKSPACE}
echo 'step 4:pull code...'
if [ -d ${PROJECT_NAME} ]; then
	cd ${PROJECT_NAME}
	${GIT} pull
	${GIT} checkout ${GIT_BRANCH_NAME}
else
	${GIT} clone ${GIT_URL} ${PROJECT_NAME}
	cd ${PROJECT_NAME}
	${GIT} checkout ${GIT_BRANCH_NAME}
fi

# updateAllCode
cd ${PROJECT_PATH}/
bash ${PROJECT_PATH}/updateAllCode.sh
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### pod集成
echo ''
echo 'step 5:pod集成...'
# 清空之前pod生成文件
rm -f ${PROJECT_PATH}/Podfile.lock
rm -rf ${PROJECT_PATH}/Pods
rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
# # 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
# for PBXPROJ_PATH in `find ${PROJECT_PATH}/SNProjects -name project.pbxproj`
# do
#     sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
# done

# 修改Podfile
PodfilePath=${PROJECT_PATH}/Podfile
sed -i '' "s/using_code_snsearch = false/using_code_snsearch = true/" ${PodfilePath}
sed -i '' "s/using_code_snproduct = false/using_code_snproduct = true/" ${PodfilePath}
sed -i '' "s/using_code_snpingou = false/using_code_snpingou = true/" ${PodfilePath}
sed -i '' "s/using_code_snpm = false/using_code_snpm = true/" ${PodfilePath}
sed -i '' "s/using_code_snlogin = false/using_code_snlogin = true/" ${PodfilePath}
sed -i '' "s/using_code_snmember = false/using_code_snmember = true/" ${PodfilePath}
sed -i '' "s/using_code_snsl = false/using_code_snsl = true/" ${PodfilePath}
sed -i '' "s/using_code_snlive = false/using_code_snlive = true/" ${PodfilePath}
sed -i '' "s/using_code_snmk = false/using_code_snmk = true/" ${PodfilePath}
sed -i '' "s/using_code_snmptm = false/using_code_snmptm = true/" ${PodfilePath}
sed -i '' "s/using_code_snhwg = false/using_code_snhwg = true/" ${PodfilePath}
sed -i '' "s/using_code_snchannel = false/using_code_snchannel = true/" ${PodfilePath}
sed -i '' "s/using_code_snsm = false/using_code_snsm = true/" ${PodfilePath}
sed -i '' "s/using_code_snhome = false/using_code_snhome = true/" ${PodfilePath}

# repo-update
cd ${PROJECT_PATH}/
if [ "${SNMPaySDK_PATH}" != "" ]; then
	bash ${PROJECT_PATH}/repo-update.sh -paysdk
else
	bash ${PROJECT_PATH}/repo-update.sh
fi
# 命令执行失败,异常退出
if [[ ! $? -eq 0 ]]; then
    exit 1
fi

#### appstore打包配置
echo ''
echo 'step 6:appstore打包配置...'
#### bundle identifier
# SuningEBuy
PROJECT_BUNDLE_ID="SuningEMall"
PROJECT_INFOPLIST_PATH="${PROJECT_PATH}/SuningEBuy/Info.plist"
/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${PROJECT_BUNDLE_ID}" ${PROJECT_INFOPLIST_PATH}

# TodayWidget
TODAY_WIDGET_INFOPLIST_PATH="${PROJECT_PATH}/TodayWidget/Info.plist"
/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${PROJECT_BUNDLE_ID}.TodayWidget" ${TODAY_WIDGET_INFOPLIST_PATH}

# PushService
PUSH_SERVICE_INFOPLIST_PATH="${PROJECT_PATH}/PushService/Info.plist"
/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${PROJECT_BUNDLE_ID}.PushService" ${PUSH_SERVICE_INFOPLIST_PATH}

#### 版本号
# SuningEBuy
/usr/libexec/PlistBuddy -c "set CFBundleShortVersionString ${PROJECT_VERSION}" ${PROJECT_INFOPLIST_PATH}
/usr/libexec/PlistBuddy -c "set CFBundleVersion ${PROJECT_BUILD_VERSION}" ${PROJECT_INFOPLIST_PATH}

# TodayWidget
/usr/libexec/PlistBuddy -c "set CFBundleShortVersionString ${PROJECT_VERSION}" ${TODAY_WIDGET_INFOPLIST_PATH}
/usr/libexec/PlistBuddy -c "set CFBundleVersion ${PROJECT_BUILD_VERSION}" ${TODAY_WIDGET_INFOPLIST_PATH}

# PushService
/usr/libexec/PlistBuddy -c "set CFBundleShortVersionString ${PROJECT_VERSION}" ${PUSH_SERVICE_INFOPLIST_PATH}
/usr/libexec/PlistBuddy -c "set CFBundleVersion ${PROJECT_BUILD_VERSION}" ${PUSH_SERVICE_INFOPLIST_PATH}

#### 修改证书 
# DEVELOPMENT_TEAM
PROJECT_PBXPROJ_PATH="${PROJECT_PATH}/SuningEBuy.xcodeproj/project.pbxproj"
PROJECT_DEVELOPMENT_TEAM="76M3JYH4P2"
sed -i '' "s/DEVELOPMENT_TEAM =.*;/DEVELOPMENT_TEAM = ${PROJECT_DEVELOPMENT_TEAM};/" ${PROJECT_PBXPROJ_PATH}

# 修改project证书
PROJECT_PROVISIONING_PROFILE_SPECIFIER="SuningEMallDistribution"
PROJECT_CODE_SIGN_IDENTITY="iPhone Distribution: Suning Commerce Group Co.,Ltd. (76M3JYH4P2)"
# CODE_SIGN_IDENTITY
set +H
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/1" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/2" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/1" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/2" ${PROJECT_PBXPROJ_PATH}

# 修改第一个target也就是SuningEBuy证书
# PROVISIONING_PROFILE_SPECIFIER
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${PROJECT_PROVISIONING_PROFILE_SPECIFIER};/1" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${PROJECT_PROVISIONING_PROFILE_SPECIFIER};/2" ${PROJECT_PBXPROJ_PATH}
# CODE_SIGN_IDENTITY
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/3" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/4" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/3" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/4" ${PROJECT_PBXPROJ_PATH}

# 修改第2个target也就是TodayWidget证书
# PROVISIONING_PROFILE_SPECIFIER
TODAY_WIDGET_PROVISIONING_PROFILE_SPECIFIER="SuningEMallTodayWidgetDistribution"
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${TODAY_WIDGET_PROVISIONING_PROFILE_SPECIFIER};/3" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${TODAY_WIDGET_PROVISIONING_PROFILE_SPECIFIER};/4" ${PROJECT_PBXPROJ_PATH}
# CODE_SIGN_IDENTITY
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/5" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/6" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/5" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/6" ${PROJECT_PBXPROJ_PATH}

# 修改第3个target也就是PushService证书
# PROVISIONING_PROFILE_SPECIFIER
PUSH_SERVICE_PROVISIONING_PROFILE_SPECIFIER="SuningEMallPushServiceDistrbution"
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${PUSH_SERVICE_PROVISIONING_PROFILE_SPECIFIER};/5" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/PROVISIONING_PROFILE_SPECIFIER =[^;]*;/PROVISIONING_PROFILE_SPECIFIER = ${PUSH_SERVICE_PROVISIONING_PROFILE_SPECIFIER};/6" ${PROJECT_PBXPROJ_PATH}
# CODE_SIGN_IDENTITY
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/7" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/CODE_SIGN_IDENTITY =[^;]*;/CODE_SIGN_IDENTITY = \"${PROJECT_CODE_SIGN_IDENTITY}\";/8" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/7" ${PROJECT_PBXPROJ_PATH}
sed -i '' "1h;1!H;\$!d;\$g;\$s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*\]\" =[^;]*;/\"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"${PROJECT_CODE_SIGN_IDENTITY}\";/8" ${PROJECT_PBXPROJ_PATH}

#### Capabilities
# App Groups
PROJECT_ENTITLEMENTS_PATH="${PROJECT_PATH}/SuningEBuy/SuningEBuy.entitlements"
# 开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.ApplicationGroups.iOS = {[^}]*};/com.apple.ApplicationGroups.iOS = {enabled = 1;};/1" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy.entitlements
PLIST_KEY="com.apple.security.application-groups"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string 'group.SuningEMall'" ${PROJECT_ENTITLEMENTS_PATH}

# Apple Pay
# 开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.ApplePay = {[^}]*};/com.apple.ApplePay = {enabled = 1;};/1" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy.entitlements
PLIST_KEY="com.apple.developer.in-app-payments"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string 'merchant.SuningEMall'" ${PROJECT_ENTITLEMENTS_PATH}

# Associated Domains
# 开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.SafariKeychain = {[^}]*};/com.apple.SafariKeychain = {enabled = 1;};/1" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy.entitlements
PLIST_KEY="com.apple.developer.associated-domains"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string 'applinks:m.suning.com'" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string 'applinks:*.m.suning.com'" ${PROJECT_ENTITLEMENTS_PATH}

# Background Modes
# 开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.BackgroundModes = {[^}]*};/com.apple.BackgroundModes = {enabled = 1;};/1" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy/Info.plist
PLIST_KEY="UIBackgroundModes"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${PROJECT_INFOPLIST_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${PROJECT_INFOPLIST_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string 'remote-notification'" ${PROJECT_INFOPLIST_PATH}

# Keychain Sharing
# 开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.Keychain = {[^}]*};/com.apple.Keychain = {enabled = 1;};/1" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy/Info.plist
PLIST_KEY="keychain-access-groups"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string '\$(AppIdentifierPrefix)SuningEMall'" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string '\$(AppIdentifierPrefix)com.suning.SuningEfubao'" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string '\$(AppIdentifierPrefix)com.suning.xiaodian'" ${PROJECT_ENTITLEMENTS_PATH}

# Push Notifications
# 开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.Push = {[^}]*};/com.apple.Push = {enabled = 1;};/1" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy/Info.plist
PLIST_KEY="aps-environment"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${PROJECT_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} string development" ${PROJECT_ENTITLEMENTS_PATH}

#### TodayWidget Capabilities 
# App Groups
TODAY_WIDGET_ENTITLEMENTS_PATH="${PROJECT_PATH}/TodayWidget/TodayWidget.entitlements"
# 开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.ApplicationGroups.iOS = {[^}]*};/com.apple.ApplicationGroups.iOS = {enabled = 1;};/2" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy.entitlements
PLIST_KEY="com.apple.security.application-groups"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${TODAY_WIDGET_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${TODAY_WIDGET_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string 'group.SuningEMall'" ${TODAY_WIDGET_ENTITLEMENTS_PATH}

# Keychain Sharing
# 开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.Keychain = {[^}]*};/com.apple.Keychain = {enabled = 1;};/2" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy/Info.plist
PLIST_KEY="keychain-access-groups"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${TODAY_WIDGET_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${TODAY_WIDGET_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string '\$(AppIdentifierPrefix)SuningEMall.TodayWidget'" ${TODAY_WIDGET_ENTITLEMENTS_PATH}

#### PushService Capabilities 
# Keychain Sharing
PUSH_SERVICE_ENTITLEMENTS_PATH="${PROJECT_PATH}/PushService/PushService.entitlements"
# 开启
sed -i '' "1h;1!H;\$!d;\$g;\$s/com.apple.Keychain = {[^}]*};/com.apple.Keychain = {enabled = 1;};/3" ${PROJECT_PBXPROJ_PATH}
# SuningEBuy/Info.plist
PLIST_KEY="keychain-access-groups"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${PUSH_SERVICE_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} array" ${PUSH_SERVICE_ENTITLEMENTS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}: string '\$(AppIdentifierPrefix)SuningEMall.PushService'" ${PUSH_SERVICE_ENTITLEMENTS_PATH}

#### 修改环境
URL_TYPE_PLIST_PATH="${PROJECT_PATH}/SuningEBuy/AppConfig/SNUrlDomainManagerUrlType.plist"
PROJECT_CONFIG_PATH="${PROJECT_PATH}/SuningEBuy/AppConfig/SuningEBuyConfig.h"
/usr/libexec/PlistBuddy -c "set URLConfig 0" ${URL_TYPE_PLIST_PATH}
sed -i '' "s/.*#define kPreTest.*/\/\/#define kPreTest        1/" ${PROJECT_CONFIG_PATH}
sed -i '' "s/.*#define kSitTest.*/\/\/#define kSitTest        1/" ${PROJECT_CONFIG_PATH}
sed -i '' "s/.*#define kReleaseH.*/\/\/#define kReleaseH        1/" ${PROJECT_CONFIG_PATH}
sed -i '' "s/.*#define kAllowInvalidHttps.*/#define kAllowInvalidHttps   0/" ${PROJECT_CONFIG_PATH}
sed -i '' "s/.*#define kIsOfficial.*/#define kIsOfficial     1/" ${PROJECT_CONFIG_PATH}

#### DC.plist
DC_PLIST_PATH="${PROJECT_PATH}/SuningEBuy/DC.plist"
/usr/libexec/PlistBuddy -c "set itemIndex 0" ${DC_PLIST_PATH}

#### 中文名称
PROJECT_INFO_PLIST_STRING_PATH="${PROJECT_PATH}/SuningEBuy/zh-Hans.lproj/InfoPlist.strings"
sed -i '' -e "4s/^.*$/CFBundleDisplayName = \"苏宁易购\";/" ${PROJECT_INFO_PLIST_STRING_PATH}

#### exportOptions.plist
PROJECT_EXPORT_OPTIONS_PATH="${PROJECT_PATH}/exportOptions.plist"
# method
/usr/libexec/PlistBuddy -c "set method app-store" ${PROJECT_EXPORT_OPTIONS_PATH}
# 先删除之前的key值
PLIST_KEY="provisioningProfiles"
/usr/libexec/PlistBuddy -c "Delete :${PLIST_KEY}" ${PROJECT_EXPORT_OPTIONS_PATH}
# # 先添加key值
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY} dict" ${PROJECT_EXPORT_OPTIONS_PATH}
# # 添加value值
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}:'${PROJECT_BUNDLE_ID}' string ${PROJECT_PROVISIONING_PROFILE_SPECIFIER}" ${PROJECT_EXPORT_OPTIONS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}:'${PROJECT_BUNDLE_ID}.TodayWidget' string ${TODAY_WIDGET_PROVISIONING_PROFILE_SPECIFIER}" ${PROJECT_EXPORT_OPTIONS_PATH}
/usr/libexec/PlistBuddy -c "Add :${PLIST_KEY}:'${PROJECT_BUNDLE_ID}.PushService' string ${PUSH_SERVICE_PROVISIONING_PROFILE_SPECIFIER}" ${PROJECT_EXPORT_OPTIONS_PATH}
# compileBitcode
/usr/libexec/PlistBuddy -c "set compileBitcode NO" ${PROJECT_EXPORT_OPTIONS_PATH}
# uploadSymbols
/usr/libexec/PlistBuddy -c "set uploadSymbols NO" ${PROJECT_EXPORT_OPTIONS_PATH}

#### 打包
echo ''
echo 'step 7:打包...'
PROJECT_WORKSPACE="SuningEBuy.xcworkspace"
PROJECT_SCHEME="SuningEBuy"
XCODE_BUILD="xcodebuild -workspace ${PROJECT_WORKSPACE} -scheme ${PROJECT_SCHEME} -configuration Release"
XCODE_CLEAN="xcodebuild -workspace ${PROJECT_WORKSPACE} -scheme ${PROJECT_SCHEME} -configuration Release clean"
XCODE_ARCHIVE="xcodebuild archive -workspace ${PROJECT_WORKSPACE} -scheme ${PROJECT_SCHEME} -configuration Release"
XCODE_EXPORT="xcodebuild -exportArchive -exportOptionsPlist ./exportOptions.plist"

# clean
echo "clean..."
${XCODE_CLEAN}

# archive
echo ""
echo "archive..."
BUILD_RESULT_PATH="${PROJECT_PATH}/build/appstore_${PROJECT_BUILD_VERSION}_$(date +%Y-%m-%d_%H_%M)"
ARCHIVE_PATH="${BUILD_RESULT_PATH}/SuningEBuy.xcarchive"
mkdir -p $(dirname ${ARCHIVE_PATH})
if command -v xcpretty > /dev/null; then
	${XCODE_ARCHIVE} -archivePath ${ARCHIVE_PATH} | xcpretty
else
	${XCODE_ARCHIVE} -archivePath ${ARCHIVE_PATH}
fi

# export
echo ""
echo "export..."
IPA_PATH="${BUILD_RESULT_PATH}/SuningEBuy.ipa"
${XCODE_EXPORT} -archivePath ${ARCHIVE_PATH} -exportPath ${IPA_PATH}

# clean
echo ""
echo "clean..."
${XCODE_CLEAN}

#### appstore发布配置检查
echo ''
echo 'step 8:appstore发布配置检查...'
cd ${PROJECT_PATH}/Scripts/AppstoreCheck
python checkSettings.py

#### 生成归档文件，jenkins Copy Artifact Plugin
echo ''
echo 'step 9:生成归档文件...'
BUILD_ARTIFACTS_PATH="${WORKSPACE}/build-artifacts"
mkdir -p ${BUILD_ARTIFACTS_PATH}
rm -rf ${BUILD_ARTIFACTS_PATH}/*
# 拷贝文件
cd ${BUILD_RESULT_PATH}/
for XCARCHIVE_FILE_NAME in $(ls)
do
	if [[ ${XCARCHIVE_FILE_NAME} =~ ".xcarchive" ]] \
		|| [[ ${XCARCHIVE_FILE_NAME} =~ ".ipa" ]]; then
		echo ""
		echo "cmd: zip -r ${BUILD_ARTIFACTS_PATH}/${XCARCHIVE_FILE_NAME}.zip ${XCARCHIVE_FILE_NAME} >/dev/null 2>&1"
		zip -r ${BUILD_ARTIFACTS_PATH}/${XCARCHIVE_FILE_NAME}.zip ${XCARCHIVE_FILE_NAME} >/dev/null 2>&1
	fi
done

