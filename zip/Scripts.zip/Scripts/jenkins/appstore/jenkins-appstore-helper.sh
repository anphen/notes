# #!/bin/bash
# jenkins-appstore-helper.sh

# 使用
# export GIT_BRANCH_NAME="Dev_Br_910"
# export APPSTORE_BRANCH_NAME="Ft_Br_Appstore_910"
# bash Scripts/jenkins/appstore/jenkins-appstore-helper.sh

# 使用参数检查
if [[ -z ${GIT_BRANCH_NAME} ]]; then
	echo "error: GIT_BRANCH_NAME not found"
	exit 1
fi
if [[ -z ${APPSTORE_BRANCH_NAME} ]]; then
	echo "error: APPSTORE_BRANCH_NAME not found"
	exit 1
fi

# 基本变量
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"
PROJECT_PATH="$(cd ${SCRIPT_DIR}/../../../;pwd)"
cd ${PROJECT_PATH}
echo "PROJECT_PATH:  ${PROJECT_PATH}"

GIT="git"

if [[ -z ${GIT_BRANCH_NAME} ]]; then
	GIT_BRANCH_NAME="Dev_Br_904"
    APPSTORE_BRANCH_NAME="Ft_Br_Appstore_904"
fi
# 主工程
SNMAIN_PROJECT_INFO_ARRAY=(
    "SNMain"
    "http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"
    "${GIT_BRANCH_NAME}"
    "${PROJECT_PATH}"
    "${APPSTORE_BRANCH_NAME}"
)
# ALL_CHECK_PROJECT_INFO_ARRAY
ALL_CHECK_PROJECT_INFO_ARRAY=(
    SNMAIN_PROJECT_INFO_ARRAY
)

ERROR_COUNT=0
PROJECT_ERROR_COUNT=0
FILE_ERROR_COUNT=0
LINE_ERROR_COUNT=0
PODFILE_ERROR_COUNT=0

OLD_IFS=${IFS}
IFS='
'

#### 方法
#### 通用
function print_LINE_KNOWN_CHANGED_ARRAY() {
	# LINE_KNOWN_CHANGED_ARRAY=(
	# 	"-\$using_code_snsearch = false"
	# )
	echo "LINE_KNOWN_CHANGED_ARRAY=("
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		if [[ "${CHANGED_LINE}" =~ "_VERSION =" ]]; then
			# 版本号有时候一致，比对则没有区别，有时候不一致能比对出区别，统一就不处理了
			# 版本号经常修改，只要修改版本号合并代码就报冲突，需要手动处理
			# 修改1个或者2个版本号的时候，区分版本号就比较麻烦
			# 而且发布的时候版本号也好测试，这儿就不比较版本号了
			continue
		fi

		# 注意点
		# 1.$要改为\$
		# 2."要改为\"
		# 1.$要改为\$
		CHANGED_LINE=${CHANGED_LINE//\$/\\\$}
		# 2.替换"为\"
		CHANGED_LINE=${CHANGED_LINE//\"/\\\"}
		echo "	\"${CHANGED_LINE}\""
	done
	echo ")"
}

#### 检查工程
#### f_check_project
# 有修改的工程
# 1.SNCommon
function f_check_project_SNCommon() {
	GIT_PATH=$1
	# echo "function:f_check_project_SNCommon"
	# echo "GIT_PATH:${GIT_PATH}"

	# 检查修改
	# 检查需要的文件修改操作
	# SNCommon修改了SuningEBuyConfig.h文件
	cd ${GIT_PATH}
	if [[ "$(${GIT} status | grep "modified" | grep "SNCommon/AppConfig/SuningEBuyConfig.h")" = "" ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: SuningEBuyConfig.h没修改"
	fi
	# 检查不需要的文件修改操作
	for MODIFIED_FILE in $(${GIT} status | grep "modified")
	do
		if [[ "${MODIFIED_FILE}" =~ "SuningEBuyConfig.h" ]]; then
			continue
		fi
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 不需要的文件修改操作 ${MODIFIED_FILE}"
	done
	# 检查不需要的文件新增操作
	for NEW_FILE in $(${GIT} status | grep "new file")
	do
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 不需要的文件新增操作 ${NEW_FILE}"
	done
	# 检查不需要的文件删除操作
	for DELETED_FILE in $(${GIT} status | grep "deleted")
	do
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 不需要的文件删除操作 ${DELETED_FILE}"
	done
}

#### 检查工程下文件
#### f_check_files_SNMain
# SNMain下有修改的文件
# 1.Podfile/
# 2.PushService.entitlements
# 3.SuningEBuy.xcodeproj
# 4.SuningEBuy.entitlements
# 5.TodayWidget.entitlements
# 6.exportOptions.plist

# Podfile
function f_check_files_SNMain_Podfile() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-\$using_code_snsearch = false"
		"-\$using_code_snproduct = false"
		"-\$using_code_snpingou = false"
		"-\$using_code_snpm = false"
		"-\$using_code_snlogin = false"
		"-\$using_code_snmember = false"
		"-\$using_code_snsl = false"
		"-\$using_code_snlive = false"
		"-\$using_code_snmk = false"
		"-#\$using_code_snmptm = false"
		"-\$using_code_snhwg = false"
		"-\$using_code_snchannel = false"
		"-\$using_code_snsm = false"
		"-\$using_code_snhome = false"
		"-\$using_code_snxdcc = false"
		"-\$using_code_snpw = false"
		"+\$using_code_snsearch = true"
		"+\$using_code_snproduct = true"
		"+\$using_code_snpingou = true"
		"+\$using_code_snpm = true"
		"+\$using_code_snlogin = true"
		"+\$using_code_snmember = true"
		"+\$using_code_snsl = true"
		"+\$using_code_snlive = true"
		"+\$using_code_snmk = true"
		"+#\$using_code_snmptm = true"
		"+\$using_code_snhwg = true"
		"+\$using_code_snchannel = true"
		"+\$using_code_snsm = true"
		"+\$using_code_snhome = true"
		"+\$using_code_snxdcc = true"
		"+\$using_code_snpw = true"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# PushService/PushService.entitlements
function f_check_files_SNMain_PushService_entitlements() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
        "+    <key>com.apple.security.application-groups</key>"
        "+    <array>"
        "+        <string>group.SuningEMall</string>"
        "+    </array>"
    )

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SuningEBuy.xcodeproj/project.pbxproj
function f_check_files_SNMain_SuningEBuy_xcodeproj() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-                CODE_SIGN_IDENTITY = \"iPhone Developer\";"
		"-                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Developer\";"
		"+                CODE_SIGN_IDENTITY = \"iPhone Distribution\";"
		"+                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Distribution\";"
		"-                PROVISIONING_PROFILE_SPECIFIER = DevProfile;"
		"+                PROVISIONING_PROFILE_SPECIFIER = SuningEMallDistribution;"
		"-                DEVELOPMENT_TEAM = 5E2PGY2377;"
		"+                DEVELOPMENT_TEAM = 76M3JYH4P2;"
		"-                PROVISIONING_PROFILE_SPECIFIER = SuningEnterprise;"
		"+                PROVISIONING_PROFILE_SPECIFIER = SuningEMallDistribution;"
		"-                CODE_SIGN_IDENTITY = \"iPhone Developer\";"
		"-                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Developer\";"
		"+                CODE_SIGN_IDENTITY = \"iPhone Distribution\";"
		"+                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Distribution\";"
		"-                PROVISIONING_PROFILE_SPECIFIER = DevProfile;"
		"+                PROVISIONING_PROFILE_SPECIFIER = SuningEMallTodayWidgetDistribution;"
		"-                DEVELOPMENT_TEAM = 5E2PGY2377;"
		"+                DEVELOPMENT_TEAM = 76M3JYH4P2;"
		"-                PROVISIONING_PROFILE_SPECIFIER = SuningEnterprise;"
		"+                PROVISIONING_PROFILE_SPECIFIER = SuningEMallTodayWidgetDistribution;"
		"-                CODE_SIGN_IDENTITY = \"iPhone Developer\";"
		"-                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Developer\";"
		"+                CODE_SIGN_IDENTITY = \"iPhone Distribution\";"
		"+                \"CODE_SIGN_IDENTITY[sdk=iphoneos*]\" = \"iPhone Distribution\";"
		"-                PROVISIONING_PROFILE_SPECIFIER = DevProfile;"
		"+                PROVISIONING_PROFILE_SPECIFIER = SuningEMallPushServiceDistrbution;"
		"-                DEVELOPMENT_TEAM = 5E2PGY2377;"
		"+                DEVELOPMENT_TEAM = 76M3JYH4P2;"
		"-                PROVISIONING_PROFILE_SPECIFIER = SuningEnterprise;"
		"+                PROVISIONING_PROFILE_SPECIFIER = SuningEMallPushServiceDistrbution;"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}"
		CHANGED_LINE_RESULT=0
		if [[ "${CHANGED_LINE}" =~ "_VERSION =" ]]; then
			# 版本号有时候一致，比对则没有区别，有时候不一致能比对出区别，统一就不处理了
			# 版本号经常修改，只要修改版本号合并代码就报冲突，需要手动处理
			# 修改1个或者2个版本号的时候，区分版本号就比较麻烦
			# 而且发布的时候版本号也好测试，这儿就不比较版本号了
			continue

			# # appstore分支会修改自己的版本号，所以版本号修改不比对版本号变化
			# # 操作是将KNOWN_LINE中的版本号替换为CHANGED_LINE中的版本号

			# # CHANGED_LINE
			# # 替换空格为空字符串
			# CHANGED_LINE=${CHANGED_LINE// /}
			# # CHANGED_LINE_VERSION
			# CHANGED_LINE_VERSION=${CHANGED_LINE#*=}
			# CHANGED_LINE_VERSION=${CHANGED_LINE_VERSION%;*}

			# # KNOWN_LINE
			# KNOWN_LINE=${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}
			# KNOWN_LINE=${KNOWN_LINE%=*}
			# KNOWN_LINE="${KNOWN_LINE} = ${CHANGED_LINE_VERSION};"
			# # 替换空格为空字符串
			# KNOWN_LINE=${KNOWN_LINE// /}

			# if [[ "${CHANGED_LINE}" = "${KNOWN_LINE}" ]]; then
			# 	CHANGED_LINE_RESULT=1
			# fi
		elif [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			CHANGED_LINE_RESULT=1
		fi
		if [[ ${CHANGED_LINE_RESULT} -eq 1 ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# SuningEBuy/SuningEBuy.entitlements
function f_check_files_SNMain_SuningEBuy_entitlements() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
        "+    <key>aps-environment</key>"
        "+    <string>development</string>"
        "+    <key>com.apple.developer.applesignin</key>"
        "+    <array>"
        "+        <string>Default</string>"
        "+    </array>"
        "+    <key>com.apple.developer.associated-domains</key>"
        "+    <array>"
        "+        <string>applinks:m.suning.com</string>"
        "+        <string>applinks:*.m.suning.com</string>"
        "+    </array>"
        "+    <key>com.apple.developer.in-app-payments</key>"
        "+    <array>"
        "+        <string>merchant.SuningEMall</string>"
        "+    </array>"
        "+    <key>com.apple.developer.networking.wifi-info</key>"
        "+    <true/>"
        "+    <key>com.apple.security.application-groups</key>"
        "+    <array>"
        "+        <string>group.SuningEMall</string>"
        "+    </array>"
    )

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# TodayWidget/TodayWidget.entitlements
function f_check_files_SNMain_TodayWidget_entitlements() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
        "+    <key>com.apple.security.application-groups</key>"
        "+    <array>"
        "+        <string>group.SuningEMall</string>"
        "+    </array>"
    )

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

# exportOptions.plist
function f_check_files_SNMain_exportOptions_plist() {
	CHANGED_LINE_ARRAY=$1

	# LINE_KNOWN_CHANGED_ARRAY
	LINE_KNOWN_CHANGED_ARRAY=(
		"-    <string>enterprise</string>"
		"+    <string>app-store</string>"
		"-        <string>ebad1e74-19d9-49a3-b47c-6fa46b6d3efa</string>"
		"+        <string>SuningEMallDistribution</string>"
		"-        <string>ebad1e74-19d9-49a3-b47c-6fa46b6d3efa</string>"
		"+        <string>SuningEMallPushServiceDistrbution</string>"
		"-        <string>ebad1e74-19d9-49a3-b47c-6fa46b6d3efa</string>"
		"+        <string>SuningEMallTodayWidgetDistribution</string>"
		"-    <string>011EBD34F82EE293AF72D5AFA739092C0932433A</string>"
		"+    <string>iPhone Distribution</string>"
	)

	CHANGED_LINE_INDEX=0
	for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
	do
		# echo "CHANGED_LINE:${CHANGED_LINE}"
		if [[ "${CHANGED_LINE}" = "${LINE_KNOWN_CHANGED_ARRAY[${CHANGED_LINE_INDEX}]}" ]]; then
			echo "check line:  ${CHANGED_LINE}  pass"
		else
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			LINE_ERROR_COUNT=$((${LINE_ERROR_COUNT}+1))
			# 打印错误
			echo "check line:  ${CHANGED_LINE}  fail"
			echo "error ${ERROR_COUNT}: 文件修改不符合预期"
		fi

		# CHANGED_LINE_INDEX+1
		CHANGED_LINE_INDEX=$((${CHANGED_LINE_INDEX}+1))
	done
	# 所有预期的修改都要有
	if [[ ! ${CHANGED_LINE_INDEX} -eq ${#LINE_KNOWN_CHANGED_ARRAY[*]} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}: 文件修改行数不符合预期"
		echo "          现有修改数:${CHANGED_LINE_INDEX}"
		echo "          预期修改数:${#LINE_KNOWN_CHANGED_ARRAY[*]}"
	fi
}

function f_check_files_SNMain() {
	SUB_PROJECT_GIT_BRANCH_NAME=$1
	SUB_PROJECT_SNWAPM_BRANCH_NAME=$2
	# echo "function:f_check_files_SNMain"
	# echo "SUB_PROJECT_GIT_BRANCH_NAME:${SUB_PROJECT_GIT_BRANCH_NAME}"
	# echo "SUB_PROJECT_SNWAPM_BRANCH_NAME:${SUB_PROJECT_SNWAPM_BRANCH_NAME}"

	FILE_ERROR_COUNT=0
	for CHANGED_FILE in $(${GIT} diff origin/${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_APPSTORE_BRANCH_NAME} --name-only)
	do
		echo ""
		# check file:   Podfile
		echo "#### check file:  ${CHANGED_FILE}..."
		KNOWN_CHANGED_FILE=""
		if [[ "${CHANGED_FILE}" =~ "Podfile" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "PushService/PushService.entitlements" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SuningEBuy.xcodeproj/project.pbxproj" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "SuningEBuy/SuningEBuy.entitlements" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "TodayWidget/TodayWidget.entitlements" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		if [[ "${CHANGED_FILE}" =~ "exportOptions.plist" ]]; then
			KNOWN_CHANGED_FILE="${CHANGED_FILE}"
		fi
		# 其他文件修改
		if [[ "${KNOWN_CHANGED_FILE}" = "" ]]; then
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			FILE_ERROR_COUNT=$((${FILE_ERROR_COUNT}+1))
			# 打印错误
			echo "error ${ERROR_COUNT}: 不需要的文件修改操作 ${KNOWN_CHANGED_FILE}"
		else
			CHANGED_LINE_ARRAY=$(${GIT} diff origin/${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_APPSTORE_BRANCH_NAME} ${KNOWN_CHANGED_FILE})
			CHANGED_LINE_ARRAY2=()
			for CHANGED_LINE in ${CHANGED_LINE_ARRAY[*]}
			do
				# --- a/Podfile
				if [[ "${CHANGED_LINE}" =~ "--- a" ]]; then
					continue
				fi
				# +++ b/Podfile
				if [[ "${CHANGED_LINE}" =~ "+++ b" ]]; then
					continue
				fi
				LINE_FIRST_CHARACTER=${CHANGED_LINE:0:1}
				if [[ "${LINE_FIRST_CHARACTER}" != "-" && "${LINE_FIRST_CHARACTER}" != "+" ]]; then
					continue
				fi
				# 终端上输出tab，拷贝到sublime是tab，拷贝到xcode里是4个空格
				# 这儿统一将tab替换为4个空格，兼容sublime和xcode
				CHANGED_LINE=${CHANGED_LINE//	/    }
				CHANGED_LINE_ARRAY2=(${CHANGED_LINE_ARRAY2[*]} "${CHANGED_LINE}")
			done
			CHANGED_LINE_ARRAY="${CHANGED_LINE_ARRAY2[*]}"
			
			LINE_ERROR_COUNT=0
			if [[ "${CHANGED_FILE}" = "Podfile" ]]; then
				f_check_files_SNMain_Podfile "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${CHANGED_FILE}" = "PushService/PushService.entitlements" ]]; then
				f_check_files_SNMain_PushService_entitlements "${CHANGED_LINE_ARRAY[*]}"	
			fi
			if [[ "${CHANGED_FILE}" = "SuningEBuy.xcodeproj/project.pbxproj" ]]; then
				f_check_files_SNMain_SuningEBuy_xcodeproj  "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${CHANGED_FILE}" = "SuningEBuy/SuningEBuy.entitlements" ]]; then
				f_check_files_SNMain_SuningEBuy_entitlements  "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${CHANGED_FILE}" = "TodayWidget/TodayWidget.entitlements" ]]; then
				f_check_files_SNMain_TodayWidget_entitlements  "${CHANGED_LINE_ARRAY[*]}"
			fi
			if [[ "${CHANGED_FILE}" = "exportOptions.plist" ]]; then
				f_check_files_SNMain_exportOptions_plist  "${CHANGED_LINE_ARRAY[*]}"
			fi
			# 打印单个project结果
			if [[ ${LINE_ERROR_COUNT} -eq 0 ]]; then
				echo "total: pass"
			else
				echo "total: fail"
				echo "changed:"
				print_LINE_KNOWN_CHANGED_ARRAY "${CHANGED_LINE_ARRAY[*]}"
			fi
		fi
	done
}

# git库检查
echo ""
echo "检查项1:检查工程修改..."
cd ${PROJECT_PATH}
CHECK_GIT_ARRAY=(${PROJECT_PATH})
CHECK_GIT_ARRAY=(${CHECK_GIT_ARRAY[*]} ${HOME}/.cocoapods/repos/SNEBuy_buss_repos)
CHECK_GIT_ARRAY=(${CHECK_GIT_ARRAY[*]} ${HOME}/.cocoapods/repos/SNEBuy_repos)
for GIT_PROJECT_NAME in $(ls ${PROJECT_PATH}/SNProjects)
do
	GIT_PATH=${PROJECT_PATH}/SNProjects/${GIT_PROJECT_NAME}
	if [[ -e ${GIT_PATH}/.git ]]; then
		CHECK_GIT_ARRAY=(${CHECK_GIT_ARRAY[*]} ${GIT_PATH})
	fi
done 
for GIT_PROJECT_NAME in $(ls ${PROJECT_PATH}/SNPods)
do
	GIT_PATH=${PROJECT_PATH}/SNPods/${GIT_PROJECT_NAME}
	if [[ -e ${GIT_PATH}/.git ]]; then
		CHECK_GIT_ARRAY=(${CHECK_GIT_ARRAY[*]} ${GIT_PATH})
	fi
done 
for GIT_PATH in ${CHECK_GIT_ARRAY[*]}
do
	echo ""
	echo "check project $(basename ${GIT_PATH})..."
	cd ${GIT_PATH}
	PROJECT_ERROR_COUNT=0
	if [[ "$(basename ${GIT_PATH})" = "SNCommon" ]]; then
		# SNCommon单独检查
		f_check_project_SNCommon ${GIT_PATH}
	else
		# 除了SNCommon外其他库，应该没修改
		if [[ ! "$(${GIT} status)" =~ " working tree clean" ]]; then
			# 失败次数+1
			ERROR_COUNT=$((${ERROR_COUNT}+1))
			PROJECT_ERROR_COUNT=$((${PROJECT_ERROR_COUNT}+1))
			# 打印错误
			echo "error ${ERROR_COUNT}: $(basename ${GIT_PATH})不该有修改"
			echo "错误详情"
			${GIT} status
		fi
	fi

	# 打印单个project结果
	if [[ ${PROJECT_ERROR_COUNT} -eq 0 ]]; then
	    echo "pass"
	else
		echo "fail"
	fi
done

echo ""
echo "检查项2:检查工程下文件修改..."
cd ${PROJECT_PATH}
for SUB_PROJECT_INFO_ARRAY in ${ALL_CHECK_PROJECT_INFO_ARRAY[@]};  # ${}里面不能有空格
do 
	eval SUB_PROJECT_NAME=\${${SUB_PROJECT_INFO_ARRAY}[0]}
	eval SUB_PROJECT_GIT_URL=\${${SUB_PROJECT_INFO_ARRAY}[1]}
	eval SUB_PROJECT_GIT_BRANCH_NAME=\${${SUB_PROJECT_INFO_ARRAY}[2]}
	eval SUB_PROJECT_PATH=\${${SUB_PROJECT_INFO_ARRAY}[3]}
	eval SUB_PROJECT_APPSTORE_BRANCH_NAME=\${${SUB_PROJECT_INFO_ARRAY}[4]}

	echo ""
	echo "check project ${SUB_PROJECT_NAME}下文件修改..."
	cd ${SUB_PROJECT_PATH}
	if [[ "${SUB_PROJECT_NAME}" = "SNMain" ]]; then
		f_check_files_SNMain ${SUB_PROJECT_GIT_BRANCH_NAME} ${SUB_PROJECT_SNWAPM_BRANCH_NAME}
	fi
done

echo ""
echo "检查项3:检查Podfile..."
PODFILE_PATH=${PROJECT_PATH}/Podfile
for PODFILE_USING_CODE_FALSE in $(cat ${PODFILE_PATH} | grep using_code_.*=.*false); do
	if [[ ! "${PODFILE_USING_CODE_FALSE}" =~ "using_code_show3dsdk" ]] \
		&& [[ ! "${PODFILE_USING_CODE_FALSE}" =~ "using_code_snarplatform" ]] \
		&& [[ ! "${PODFILE_USING_CODE_FALSE}" =~ "using_code_snarhomedesign" ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		PODFILE_ERROR_COUNT=$((${PODFILE_ERROR_COUNT}+1))
		# 打印错误
		echo "error ${ERROR_COUNT}:未知的using_code_xxx = false ---- ${PODFILE_USING_CODE_FALSE} "
	fi
done
# 打印单个project结果
if [[ ${PODFILE_ERROR_COUNT} -eq 0 ]]; then
    echo "pass"
else
	echo "fail"
fi

echo ""
echo "检查项4:检查证书..."
PROVISIONING_PROFILE_PATH="acdeb9a3-a2ef-49ff-9433-1d8ea06a399b.mobileprovision"
cd ${HOME}/Library/MobileDevice/Provisioning\ Profiles
if [[ -e ${PROVISIONING_PROFILE_PATH} ]]; then
	PROVISIONING_EXPIRE_DATE=$(security cms -D -i "${PROVISIONING_PROFILE_PATH}" | grep -A 1 "<key>ExpirationDate</key>" | tail -1)
	PROVISIONING_EXPIRE_DATE=${PROVISIONING_EXPIRE_DATE/<date>/}
	PROVISIONING_EXPIRE_DATE=${PROVISIONING_EXPIRE_DATE/<\/date>/}
	PROVISIONING_EXPIRE_DATE=${PROVISIONING_EXPIRE_DATE/	/}
	PROVISIONING_EXPIRE_DATE=${PROVISIONING_EXPIRE_DATE:0:10}
	echo "PROVISIONING_EXPIRE_DATE:${PROVISIONING_EXPIRE_DATE}"

	# 当前时间
	CURRENT_DATE=$(date -v +0d +%Y-%m-%d)
	echo "CURRENT_DATE:${CURRENT_DATE}"

	# 比较
	CURRENT_TIMESTAMP=$(date -j -f "%Y-%m-%d %H:%M:%S" "${CURRENT_DATE} 00:00:00" +%s)
	PROVISIONING_TIMESTAMP=$(date -j -f "%Y-%m-%d %H:%M:%S" "${PROVISIONING_EXPIRE_DATE} 00:00:00" +%s)
	if [[ ${CURRENT_TIMESTAMP} -ge ${PROVISIONING_TIMESTAMP} ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		echo "fail:证书已过期"
	elif [[ ${CURRENT_TIMESTAMP} -ge $((${PROVISIONING_TIMESTAMP}-7*24*60*60)) ]]; then
		# 失败次数+1
		ERROR_COUNT=$((${ERROR_COUNT}+1))
		echo "fail:证书将在7天内过期"
	else
		echo "pass"
	fi
else
	# 失败次数+1
	ERROR_COUNT=$((${ERROR_COUNT}+1))
	echo "error ${ERROR_COUNT}:没有找到该描述文件"
fi

echo ""
if [[ ${ERROR_COUNT} -gt 0 ]]; then
	echo "检查出不符合预期的修改:${ERROR_COUNT}处"
	echo "最终检查结果:  不通过"
	exit 1
else
	echo "最终检查结果:  pass"
fi

# 设回IFS
IFS=${OLD_IFS}

