#!/bin/bash
# jenkins-ioptimi.sh
# ioptimi打包脚本
# 这个是ioptimi打包最终执行脚本，其他只是外衣，设置参数环境什么的
# jenkins job
# 1.SuningEBuy-ioptimi-920

#### 用法，同时也是jenkins build参数
#### SuningEBuy-ioptimi-920
# export JOB_NAME=SuningEBuy-ioptimi-9511
# export build=true # 打包，耗时30分钟左右
# export analyze=true # 使用ioptimi分析，耗时5分钟
# export SPECIAL_BRANCH="" # PPTVSDK=Ft_Br_14121612_329
# # 开始打包
# bash Scripts/jenkins/ioptimi/jenkins-ioptimi.sh

# 模拟jenkins参数检查
if [[ -z ${JOB_NAME} ]]; then
	echo "error: JOB_NAME not found"
	exit 1
fi

#### 系统环境
# set -e
SCRIPT_DIR="$(cd `dirname $0`; pwd)"

if [ -f /etc/bash_profile ];then 
	source /etc/bash_profile
fi
if [ -f /etc/bashrc ];then 
	source /etc/bashrc
fi
if [ -f ~/.bash_profile ];then 
	source ~/.bash_profile
fi
if [ -f ~/.bashrc ];then 
	source ~/.bashrc
fi
export LANG=zh_CN.UTF-8
export PATH=/usr/local/bin:${PATH}

# 兼容研发云打包环境，优先使用/Applications/Xcode12.3.app打包
# 研发云同时装有多个xcode版本，默认的可能不是Xcode12.3
if [[ -e /Applications/Xcode12.3.app ]]; then
    export PATH=/Applications/Xcode12.3.app/Contents/Developer/usr/bin:$PATH
fi
# 检查Xcode版本号
RESULT_STRING=$(xcodebuild -version | head -1)
echo ""
echo "using xcode: ${RESULT_STRING}"
if [[ "${RESULT_STRING}" != "Xcode 12.3" ]]; then
    echo "error: 请使用指定的Xcode版本进行打包"
    exit 1
fi

function pull_code {
	# 如果存在SuningEBuy.xcworkspace，则表示build和analyze一起执行的
	# 不用再更新代码
	if [[ -e ${PROJECT_PATH}/SuningEBuy.xcworkspace ]]; then
		return
	fi

	# updateAllCode
	cd ${PROJECT_PATH}/
	echo "cmd: bash ${PROJECT_PATH}/updateAllCode.sh -checkupdate -revert--subproject"
	bash ${PROJECT_PATH}/updateAllCode.sh -checkupdate -revert--subproject
	# 命令执行失败,异常退出
	if [[ ! $? -eq 0 ]]; then
	    exit 1
	fi

	# 处理SPECIAL_BRANCH中主分支，确保打包用的脚本用的是指定分支的
	if [[ ! -z ${SPECIAL_BRANCH} ]]; then
	    echo ""
	    echo "处理SPECIAL_BRANCH，寻找指定的主工程分支..."
	    BRANCH_INFO_ARRAY=(${SPECIAL_BRANCH//,/ })
	    for BRANCH_INFO in ${BRANCH_INFO_ARRAY[*]}
	    do
	        PROJECT_NAME=${BRANCH_INFO%=*}
	        BRANCH_NAME=${BRANCH_INFO#*=}

	        # 切换主分支
	        if [[ "${PROJECT_NAME}" = "SuningEBuy" ]]; then
	            echo "BRANCH_INFO:${BRANCH_INFO}"
	            echo "PROJECT_NAME:${PROJECT_NAME}"
	            echo "BRANCH_NAME:${BRANCH_NAME}"
	            
	            cd ${PROJECT_PATH}
	            # 放弃本地修改
	            ${GIT} checkout .
	            # 切换分支
	            ${GIT} checkout ${BRANCH_NAME}
				# 命令执行失败,异常退出
				if [[ ! $? -eq 0 ]]; then
				    exit 1
				fi
	            # 拉取代码
	            ${GIT} pull
	            # 跳出
	            break
	        fi
	    done
	fi

	# repo-update更新代码
	cd ${PROJECT_PATH}/
	echo ""
	echo "cmd: bash ${PROJECT_PATH}/repo-update.sh -checkupdate -revert--subproject -skip--pod"
	bash ${PROJECT_PATH}/repo-update.sh -checkupdate -revert--subproject -skip--pod

	# 处理SPECIAL_BRANCH
	if [[ ! -z ${SPECIAL_BRANCH} ]]; then
		echo ""
		echo "处理SPECIAL_BRANCH..."
		BRANCH_INFO_ARRAY=(${SPECIAL_BRANCH//,/ })  
		for BRANCH_INFO in ${BRANCH_INFO_ARRAY[*]}
		do
			echo ""
			echo "BRANCH_INFO:${BRANCH_INFO}"
			PROJECT_NAME=${BRANCH_INFO%=*}
			BRANCH_NAME=${BRANCH_INFO#*=}
			echo "PROJECT_NAME:${PROJECT_NAME}"
			echo "BRANCH_NAME:${BRANCH_NAME}"
	        # 切换主分支
	        if [[ "${PROJECT_NAME}" = "SuningEBuy" ]]; then
	            cd ${PROJECT_PATH}
	        fi
	        # 切换SNEBuy_buss_repos、SNEBuy_repos分支
	        if [[ "${PROJECT_NAME}" = "SNEBuy_buss_repos" ]] \
	        	|| [[ "${PROJECT_NAME}" = "SNEBuy_repos" ]]; then
	            cd "${HOME}/.cocoapods/repos/${PROJECT_NAME}"
	        fi
			# 如果存在
			if [[ -e ${PROJECT_PATH}/SNProjects/${PROJECT_NAME} ]]; then
				cd ${PROJECT_PATH}/SNProjects/${PROJECT_NAME}
			fi
			if [[ -e ${PROJECT_PATH}/SNPods/${PROJECT_NAME} ]]; then
				cd ${PROJECT_PATH}/SNPods/${PROJECT_NAME}
			fi
			CURRENT_DIRECTORY=$(pwd)
			CURRENT_DIRECTORY=$(basename ${CURRENT_DIRECTORY})
			# 兼容主工程目录ebuy_9520 -> SuningEBuy
			if [[ ${CURRENT_DIRECTORY} =~ "ebuy_" ]]; then
				CURRENT_DIRECTORY="SuningEBuy"
			fi
			if [[ "${CURRENT_DIRECTORY}" = ${PROJECT_NAME} ]]; then
				# 放弃本地修改
				${GIT} checkout . 
				# 切换分支
				${GIT} checkout ${BRANCH_NAME}
				# 命令执行失败,异常退出
				if [[ ! $? -eq 0 ]]; then
				    exit 1
				fi
				# 拉取代码
				${GIT} pull
			fi
		done
	fi
}

function pod_install {
	# 如果存在SuningEBuy.xcworkspace，则表示build和analyze一起执行的
	# 不用再pod install
	if [[ -e ${PROJECT_PATH}/SuningEBuy.xcworkspace ]]; then
		return
	fi

	# 清空之前pod生成文件
	cd ${PROJECT_PATH}/
	rm -f ${PROJECT_PATH}/Podfile.lock
	rm -rf ${PROJECT_PATH}/Pods
	rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
	# 重置子工程之前的xcconfig设置，Pods-xxx.debug.xcconfig、Pods-xxx.release.xcconfig
	for PBXPROJ_PATH in $(find ${PROJECT_PATH}/SNProjects -name project.pbxproj)
	do
	    sed -i '' "s/.*Pods-.*xcconfig.*//" ${PBXPROJ_PATH}
	done

	# 修改Podfile
	echo ""
	echo "修改Podfile..."
	PODFILE_PATH=${PROJECT_PATH}/Podfile
	# 统一修改为true
	sed -i '' "/^\$using_code_.*=.*/s/=.*false/= true/" ${PODFILE_PATH}
	# 设置几个不需要为true的
	sed -i '' "s/\$using_code_show3dsdk.*=.*/\$using_code_show3dsdk = false/" ${PODFILE_PATH}
	sed -i '' "s/\$using_code_snarplatform.*=.*/\$using_code_snarplatform = false/" ${PODFILE_PATH}
	sed -i '' "s/\$using_code_snarhomedesign.*=.*/\$using_code_snarhomedesign = false/" ${PODFILE_PATH}
	# 打印
	cat ${PODFILE_PATH} | grep "\$using_code_.*=.*true"

	# repo-update
	cd ${PROJECT_PATH}/
	bash ${PROJECT_PATH}/repo-update.sh -pod
	# 命令执行失败,异常退出
	if [[ ! $? -eq 0 ]]; then
	    exit 1
	fi
}

function jenkins_build {
	echo ""
	echo "jenkins_build"
	#### 变量
	echo ""
	echo "step 1:更新主工程代码..."
	# WORKSPACE默认值
	# PROJECT_PATH,最终打包目录
	if [ -z ${WORKSPACE} ]; then
	    # JOB_NAME
	    cd ${SCRIPT_DIR}/../../../../
	    WORKSPACE=$(pwd)/${JOB_NAME}
	    mkdir -p ${WORKSPACE}
	    PROJECT_PATH="${WORKSPACE}"
	else
	    # 兼容研发云Delete workspace when build is done
	    PROJECT_PATH=${HOME}/.suning/build/${JOB_NAME}
	    mkdir -p ${PROJECT_PATH}
	fi
	cd ${PROJECT_PATH}

	PROJECT_NAME="SuningEBuy"

	# git
	GIT="git"

	GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

	GIT_BRANCH_VERSION="830"
	# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
	if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
		# jenkins打包 SuningEBuy-840
		GIT_BRANCH_VERSION=${JOB_NAME##*-}
	elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
		# 研发云打包 ebuy_840
		GIT_BRANCH_VERSION=${JOB_NAME##*_}
	fi
	# 研发云流水线 origin/Dev_Br_850
	if [[ "${GIT_BRANCH}" =~ "origin/" ]]; then
		GIT_BRANCH_VERSION=${GIT_BRANCH##*_}
	fi
	GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

	# 拉取代码
	cd ${PROJECT_PATH}
	if [ ! -d ${PROJECT_PATH}/.git ]; then
		${GIT} init
		${GIT} remote add origin ${GIT_URL}
		${GIT} fetch
		${GIT} checkout ${GIT_BRANCH_NAME}
	fi
	# 放弃本地修改
	${GIT} checkout . 
	# 删除Untracked files
	${GIT} clean -fd
	# 切换分支
	${GIT} checkout ${GIT_BRANCH_NAME}
	# 拉取代码
	${GIT} pull

	#### 打包前处理
	echo ""
	echo "step 2:打包前处理..."
	# 清理归档文件...
	echo "1) clean..."
	bash ${PROJECT_PATH}/Scripts/jenkins/jenkins-clean-helper.sh

	# 打包间隔检查
	echo ""
	echo "2) 打包间隔检查..."
	BUILD_IDENTIFIER="${JOB_NAME}"
	BUILD_DURATION="0"
	if [[ "${CHECK_LAST_BUILD_TIME}" = "true" ]];then
		BUILD_DURATION="15"
	fi
	BUILD_CHECK_URL="http://10.37.64.97/ipa/build.json?identifier=${BUILD_IDENTIFIER}&duration=${BUILD_DURATION}"
	BUILD_CHECK_RESULT=$(curl -m 10 -s ${BUILD_CHECK_URL})
	echo "check url: ${BUILD_CHECK_URL}"
	echo "check result: ${BUILD_CHECK_RESULT}"
	if [[ ! ${BUILD_CHECK_RESULT} =~ "\"code\":\"0\"" ]]; then
		BUILD_CHECK_RESULT_MSG=$(echo ${BUILD_CHECK_RESULT} | cut -d "\"" -f 4)
		echo "error: 不打包, ${BUILD_CHECK_RESULT_MSG}"
		echo ""
		echo "如果想强制打包，打包的时候，不要勾选CHECK_LAST_BUILD_TIME即可😢 😢 😢"
		echo ""
		exit 1
	else
		echo ""
		echo "开始打包🚀 🚀 🚀"
	fi

	#### 输入参数检查
	echo ""
	echo "step 3:参数..."
	BUILD_PARAMETER="-prd"

	UPLOAD_NAME="官方定位分享包"

	echo ""
	echo "JENKINS_TYPE:      					${JENKINS_TYPE}"
	echo "WORKSPACE:      					${WORKSPACE}"
	echo "PROJECT_PATH: 						${PROJECT_PATH}"
	echo "JOB_NAME:         					${JOB_NAME}"
	echo "GIT_URL:          					${GIT_URL}"
	echo "PROJECT_NAME:     					${PROJECT_NAME}"
	echo "GIT_BRANCH_NAME:  					${GIT_BRANCH_NAME}"

	echo ""
	echo "buld参数"
	echo "BUILD_PARAMETER:          				${BUILD_PARAMETER}"
	echo "UPLOAD_NAME:      					${UPLOAD_NAME}"

	#### pull代码
	echo ""
	echo "step 4:pull code..."
	# build时重新拉取最新代码，analyze不用
	rm -rf ${PROJECT_PATH}/SuningEBuy.xcworkspace
	pull_code

	#### pod集成
	echo ''
	echo 'step 5:pod集成...'
	pod_install

	#### 修改打包配置
	echo ''
	echo 'step 6:修改打包配置...'
	# VALID_ARCHS = arm64
	echo "6-1:修改工程配置VALID_ARCHS = arm64..."
	PBXPROJ_PATH_ARRAY=("${PROJECT_PATH}/SuningEBuy.xcodeproj/project.pbxproj")
	# 不增加这个操作，方便本地打包时数据和jenkins打包一致
	# for PBXPROJ_PATH in $(find ${PROJECT_PATH}/SNProjects -name project.pbxproj)
	# do
	# 	PBXPROJ_PATH_ARRAY=(${PBXPROJ_PATH_ARRAY[@]} "${PBXPROJ_PATH}")
	# done
	for PBXPROJ_PATH in ${PBXPROJ_PATH_ARRAY[*]}
	do
		echo "${PBXPROJ_PATH}..."
		sed -i '' "s/TARGETED_DEVICE_FAMILY = \"1,2\";/TARGETED_DEVICE_FAMILY = \"1,2\";VALID_ARCHS = \"arm64\";/" ${PBXPROJ_PATH}
		sed -i '' "s/TARGETED_DEVICE_FAMILY = 1;/TARGETED_DEVICE_FAMILY = 1;VALID_ARCHS = \"arm64\";/" ${PBXPROJ_PATH}
		sed -i '' "s/VALID_ARCHS = \".*\";/VALID_ARCHS = \"arm64\";/" ${PBXPROJ_PATH}
		RESULT_STRING=$(cat ${PBXPROJ_PATH} | grep "VALID_ARCHS = \"arm64\"")
		echo ${RESULT_STRING}
		if [[ ${RESULT_STRING} == "" ]]; then
			echo "error: 设置VALID_ARCHS = arm64失败"
			exit 1
		fi
	done

	#### 打包
	echo ''
	echo 'step 7:打包...'
	echo "7-1:打印Podfile"
	cat ${PODFILE_PATH}

	# 处理SPECIAL_BRANCH
	if [[ ! -z ${SPECIAL_BRANCH} ]]; then
		echo ""
		echo "处理SPECIAL_BRANCH，检查切换操作是否完成..."
		BRANCH_INFO_ARRAY=(${SPECIAL_BRANCH//,/ })  
		for BRANCH_INFO in ${BRANCH_INFO_ARRAY[*]}
		do
			echo ""
			echo "BRANCH_INFO:${BRANCH_INFO}"
			PROJECT_NAME=${BRANCH_INFO%=*}
			BRANCH_NAME=${BRANCH_INFO#*=}
			echo "PROJECT_NAME:${PROJECT_NAME}"
			echo "BRANCH_NAME:${BRANCH_NAME}"
	        # 切换主分支
	        if [[ "${PROJECT_NAME}" = "SuningEBuy" ]]; then
	            cd ${PROJECT_PATH}
	        fi
	        # 切换SNEBuy_buss_repos、SNEBuy_repos分支
	        if [[ "${PROJECT_NAME}" = "SNEBuy_buss_repos" ]] \
	        	|| [[ "${PROJECT_NAME}" = "SNEBuy_repos" ]]; then
	            cd "${HOME}/.cocoapods/repos/${PROJECT_NAME}"
	        fi
			# 如果存在
			if [[ -e ${PROJECT_PATH}/SNProjects/${PROJECT_NAME} ]]; then
				cd ${PROJECT_PATH}/SNProjects/${PROJECT_NAME}
			fi
			if [[ -e ${PROJECT_PATH}/SNPods/${PROJECT_NAME} ]]; then
				cd ${PROJECT_PATH}/SNPods/${PROJECT_NAME}
			fi
			CURRENT_DIRECTORY=$(pwd)
			CURRENT_DIRECTORY=$(basename ${CURRENT_DIRECTORY})
			# 兼容主工程目录ebuy_9520 -> SuningEBuy
			if [[ ${CURRENT_DIRECTORY} =~ "ebuy_" ]]; then
				CURRENT_DIRECTORY="SuningEBuy"
			fi
			if [[ "${CURRENT_DIRECTORY}" = ${PROJECT_NAME} ]]; then
				if [[ -z "$(${GIT} status | grep ${BRANCH_NAME})" ]]; then
					echo "error: 没有找到该分支,请检查"
					exit 1
				else
					${GIT} status | head -2
				fi
			else
				echo "error: 没有找到该库,请检查"
				exit 1
			fi
		done
	fi

	# 创建LinkMap文件夹
	mkdir -p ${PROJECT_PATH}/LinkMap
	rm -rf ${PROJECT_PATH}/LinkMap/*

	# BUILD_PARAMETER
	BUILD_PARAMETER="${BUILD_PARAMETER} -force--enterprise -xcpretty"

	# ipa-test
	cd ${PROJECT_PATH}/
	echo ""
	echo "7-2:打包命令:${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}"
	echo "building..."
	bash ${PROJECT_PATH}/ipa-test-bundleId.sh ${BUILD_PARAMETER}
	# 命令执行失败,异常退出
	if [[ ! $? -eq 0 ]]; then
	    exit 1
	fi

	# CURRENT_BUILD_DIRECTORY
	CURRENT_BUILD_DIRECTORY=$(ls -rt ${PROJECT_PATH}/build | tail -1)
	CURRENT_BUILD_DIRECTORY="${PROJECT_PATH}/build/${CURRENT_BUILD_DIRECTORY}"
	cd ${CURRENT_BUILD_DIRECTORY}

	#### 生成归档文件，jenkins Copy Artifact Plugin
	echo ''
	echo ''
	echo 'step 8:生成归档文件...'
	# 列出build结果
	echo "cmd: ls ${CURRENT_BUILD_DIRECTORY}"
	ls ${CURRENT_BUILD_DIRECTORY}
	# 移动ipa
	BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
	mv ${CURRENT_BUILD_DIRECTORY}/SuningEMall/SuningEBuy.ipa \
		${BUILD_ARTIFACTS_PATH}/SuningEBuy-${GIT_BRANCH_VERSION}.ipa
	# 移动linkmap文件
	cd ${PROJECT_PATH}
	zip -r ${BUILD_ARTIFACTS_PATH}/LinkMap-${GIT_BRANCH_VERSION}.zip LinkMap >/dev/null 2>&1
	# 兼容研发云Delete workspace when build is done
	if [[ -d ${WORKSPACE}/build-artifacts ]] && [[ ! -L ${WORKSPACE}/build-artifacts ]]; then
		rm -rf ${WORKSPACE}/build-artifacts
	fi
	ln -fs ${BUILD_ARTIFACTS_PATH} ${WORKSPACE}/
}

function jenkins_analyze {
	echo ""
	echo "jenkins_analyze"
	#### 变量
	echo ""
	echo "step 1:更新主工程代码..."
	# WORKSPACE默认值
	# PROJECT_PATH,最终打包目录
	if [ -z ${WORKSPACE} ]; then
	    # JOB_NAME
	    cd ${SCRIPT_DIR}/../../../../
	    WORKSPACE=$(pwd)/${JOB_NAME}
	    mkdir -p ${WORKSPACE}
	    PROJECT_PATH="${WORKSPACE}"
	else
	    # 兼容研发云Delete workspace when build is done
	    PROJECT_PATH=${HOME}/.suning/build/${JOB_NAME}
	    mkdir -p ${PROJECT_PATH}
	fi
	cd ${PROJECT_PATH}

	PROJECT_NAME="SuningEBuy"

	# git
	GIT="git"

	GIT_URL="http://git.cnsuning.com/suningebuy/SuningEBuyIphone.git"

	GIT_BRANCH_VERSION="875"
	# 根据JOB_NAME修改branch，取最后一个"-"后面的数字
	if [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "-" ]];then
		# jenkins打包 SuningEBuy-840
		GIT_BRANCH_VERSION=${JOB_NAME##*-}
	elif [[ ${JOB_NAME} ]] && [[ ${JOB_NAME} =~ "_" ]]; then
		# 研发云打包 ebuy_840
		GIT_BRANCH_VERSION=${JOB_NAME##*_}
	fi
	# 研发云流水线 origin/Dev_Br_850
	if [[ "${GIT_BRANCH}" =~ "origin/" ]]; then
		GIT_BRANCH_VERSION=${GIT_BRANCH##*_}
	fi
	GIT_BRANCH_NAME="Dev_Br_${GIT_BRANCH_VERSION}"

	# 拉取代码
	cd ${PROJECT_PATH}
	if [ ! -d ${PROJECT_PATH}/.git ]; then
		${GIT} init
		${GIT} remote add origin ${GIT_URL}
		${GIT} fetch
		${GIT} checkout ${GIT_BRANCH_NAME}
	fi
	# 放弃本地修改
	${GIT} checkout . 
	# 切换分支
	${GIT} checkout ${GIT_BRANCH_NAME}
	# 拉取代码
	${GIT} pull

	#### pull代码
	echo ""
	echo "step 2:pull code..."
	pull_code

	#### pod集成
	echo ''
	echo 'step 3:pod集成...'
	pod_install

	echo ""
	echo "step 4:build-artifacts..."
	# build-artifacts
	BUILD_ARTIFACTS_PATH="${PROJECT_PATH}/build-artifacts"
	mkdir -p ${BUILD_ARTIFACTS_PATH}

	# 兼容研发云Delete workspace when build is done
	if [[ -d ${WORKSPACE}/build-artifacts ]] && [[ ! -L ${WORKSPACE}/build-artifacts ]]; then
		rm -rf ${WORKSPACE}/build-artifacts
	fi
	ln -fs ${BUILD_ARTIFACTS_PATH} ${WORKSPACE}/
	
	# 下载最新build数据
	if [[ ! -f ${BUILD_ARTIFACTS_PATH}/SuningEBuy-${GIT_BRANCH_VERSION}.ipa ]]; then
		cd ${BUILD_ARTIFACTS_PATH}
		rm -rf ${BUILD_ARTIFACTS_PATH}/*

		# BUILD_NAME
		BUILD_NUMBER_MAX=0
		for RESULT_STRING in $(curl -s http://10.37.64.97/ftp-ios/${GIT_BRANCH_NAME}/ | grep ebuy_ioptimi); do
			# 不包含ebuy_ioptimi，不处理
			if [[ ! "${RESULT_STRING}" =~ "ebuy_ioptimi" ]]; then
				continue
			fi
			BUILD_NAME=${RESULT_STRING#*>}
			BUILD_NAME=${BUILD_NAME%%/*}
			BUILD_NUMBER=${BUILD_NAME##*_}
			if [[ ${BUILD_NUMBER} -gt ${BUILD_NUMBER_MAX} ]]; then
				BUILD_NUMBER_MAX=${BUILD_NUMBER}
			fi
		done
		BUILD_NAME=ebuy_ioptimi_${GIT_BRANCH_VERSION}_${BUILD_NUMBER_MAX}

		echo "下载SuningEBuy-${GIT_BRANCH_VERSION}.ipa"
		echo "http://10.37.64.97/ftp-ios/${GIT_BRANCH_NAME}/${BUILD_NAME}/SuningEBuy-${GIT_BRANCH_VERSION}.ipa"
		curl http://10.37.64.97/ftp-ios/${GIT_BRANCH_NAME}/${BUILD_NAME}/SuningEBuy-${GIT_BRANCH_VERSION}.ipa \
			-o SuningEBuy-${GIT_BRANCH_VERSION}.ipa
		
		echo ""
		echo "下载LinkMap-${GIT_BRANCH_VERSION}.zip"
		echo "http://10.37.64.97/ftp-ios/${GIT_BRANCH_NAME}/${BUILD_NAME}/LinkMap-${GIT_BRANCH_VERSION}.zip"
		curl http://10.37.64.97/ftp-ios/${GIT_BRANCH_NAME}/${BUILD_NAME}/LinkMap-${GIT_BRANCH_VERSION}.zip \
			-o LinkMap-${GIT_BRANCH_VERSION}.zip
	fi

	CMD_ERROR=false
	if [[ ! -f ${BUILD_ARTIFACTS_PATH}/SuningEBuy-${GIT_BRANCH_VERSION}.ipa ]]; then
		CMD_ERROR=true
		echo ""
		echo "error: ipa not found"
	fi
	if [[ ! -f ${BUILD_ARTIFACTS_PATH}/LinkMap-${GIT_BRANCH_VERSION}.zip ]]; then
		CMD_ERROR=true
		echo ""
		echo "error: linkmap not found"
	fi
	if ${CMD_ERROR}; then
		echo ""
		exit 1
	fi

	echo ""
	echo "step 5:ioptimi..."
	echo "5-1 检查ioptimi版本..."
	# 这儿pip3是xcode的，因为export PATH=/Applications/Xcode12.3.app/Contents/Developer/usr/bin:$PATH
	CURRENT_VERSION=$(pip3 show ioptimi | grep "Version: ")
	# 兼容/usr/local/bin/pip3
	if [[ "${CURRENT_VERSION}" = "" ]] && [[ -f /usr/local/bin/pip3 ]]; then
		CURRENT_VERSION=$(/usr/local/bin/pip3 show ioptimi | grep "Version: ")
	fi
	CURRENT_VERSION=${CURRENT_VERSION##Version: }
	echo "CURRENT_VERSION:	${CURRENT_VERSION}"

	LATEST_VERSION=$(curl -s http://10.37.64.97/simple/ioptimi/ | grep ioptimi- | tail -1)
	LATEST_VERSION=${LATEST_VERSION##*>ioptimi-}
	LATEST_VERSION=${LATEST_VERSION%\.tar\.gz*}
	echo "LATEST_VERSION:		${LATEST_VERSION}"

	if [[ "${CURRENT_VERSION}" != "${LATEST_VERSION}" ]]; then
		echo "ioptimi need update"
		echo "安装请参考wiki http://wiki.cnsuning.com/pages/viewpage.action?pageId=33643107"
		exit 1
	fi

	mkdir -p ${PROJECT_PATH}/Scripts/ioptimi/data
	cd ${PROJECT_PATH}/Scripts/ioptimi/data
	ln -fs ${PROJECT_PATH}/Scripts/ioptimi/ioptimi.conf ioptimi.conf
	ln -fs ${PROJECT_PATH}/Scripts/ioptimi/module.txt module.txt

	# cmd: ioptimi version 8.7.5
	echo ""
	PROJECT_VERSION=${GIT_BRANCH_VERSION:0:1}.${GIT_BRANCH_VERSION:1:1}.${GIT_BRANCH_VERSION:2}
	echo "5-2 cmd: ioptimi version ${PROJECT_VERSION}"
	ioptimi version ${PROJECT_VERSION}

	# 资源 project文件夹
	echo ""
	echo "5-3 project文件夹..."
	mkdir -p ${PROJECT_VERSION}/project
	# ipa
	ln -fs ${BUILD_ARTIFACTS_PATH}/SuningEBuy-${GIT_BRANCH_VERSION}.ipa ${PROJECT_VERSION}/project
	# linkmap
	unzip ${BUILD_ARTIFACTS_PATH}/LinkMap-${GIT_BRANCH_VERSION}.zip -d ${PROJECT_VERSION}/project
	mv ${PROJECT_VERSION}/project/LinkMap/*-arm64.txt ${PROJECT_VERSION}/project
	rm -rf ${PROJECT_VERSION}/project/LinkMap
	# 工程
	ln -fs ${PROJECT_PATH} ${PROJECT_VERSION}/project

	# cmd: ioptimi resources
	echo ""
	echo "5-4 cmd: ioptimi resources analyze"
	rm -rf ${BUILD_ARTIFACTS_PATH}/resources-result-waring.txt
	ioptimi resources analyze

	# cmd: ioptimi linkmap
	echo ""
	echo "5-5 cmd: ioptimi linkmap analyze"
	rm -rf ${BUILD_ARTIFACTS_PATH}/linkmap-result-waring.txt
	ioptimi linkmap analyze

	CMD_ERROR=false
	if [[ -f ${PROJECT_VERSION}/z_resources/z_result-waring.txt ]]; then
		CMD_ERROR=true
		echo ""
		echo "error: ioptimi resources analyze"
		cp ${PROJECT_VERSION}/z_resources/z_result-waring.txt ${BUILD_ARTIFACTS_PATH}/resources-result-waring.txt
	fi
	if [[ -f ${PROJECT_VERSION}/z_linkmap/z_result-waring.txt ]]; then
		CMD_ERROR=true
		echo ""
		echo "error: ioptimi linkmap analyze"
		cp ${PROJECT_VERSION}/z_linkmap/z_result-waring.txt ${BUILD_ARTIFACTS_PATH}/linkmap-result-waring.txt
	fi
	if ${CMD_ERROR}; then
		# exit 1研发云不会上传文件到ftp，这儿改为exit 0
		echo ""
		exit 0
	fi

	# upload
	echo ""
	echo "5-6 cmd: ioptimi resources upload"
	export IOPTIMI_INTERACTION=0
	ioptimi resources upload

	echo ""
	echo "5-7 cmd: ioptimi linkmap upload"
	ioptimi linkmap upload

	echo ""
}

if ${build};then
	jenkins_build
fi

if ${analyze};then
	jenkins_analyze
fi
