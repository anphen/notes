#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, sys, time

# svn信息，替换其中的xxx为自己的工号和密码
svnName = 'xxx'
svnPassword = 'xxx'

logStartDate=''
logEndDate=''
# log起始时间，不设置拉取所有改动log
# logStartDate='2017-12-03'
# logEndDate='2017-12-03'

cwd = os.getcwd()

svnArray = [];

svnInfo = {
    'svnUrl': 'http://a.svncode.cnsuning.com/svn/2012_Terminal_code/Ebuy/iphone/branches/suningebuy_V5.8.0',
    'project': 'project-mainProject'
};
svnArray.append(svnInfo);

# svnInfo = {
#     'svnUrl': 'http://d.svncode.cnsuning.com/svn/snlogin/branches/snlogin_V1.0.0/5.7.0',
#     'project': 'project-snlogin'
# };
# svnArray.append(svnInfo);
#
# svnInfo = {
#     'svnUrl': 'http://d.svncode.cnsuning.com/svn/ipdetail/branches/ipdetail_V1.0.0/SNSHProductDetail_V5.7.0',
#     'project': 'project-snproduct'
# };
# svnArray.append(svnInfo);
#
# svnInfo = {
#     'svnUrl': 'http://d.svncode.cnsuning.com/svn/ivirtual/branches/ivirtual_V1.0.0/5.7.0',
#     'project': 'project-snsl'
# };
# svnArray.append(svnInfo);
#
# svnInfo = {
#     'svnUrl': 'http://d.svncode.cnsuning.com/svn/ijigu/branches/ijigu_V1.0.0/SNLive/5.7.0',
#     'project': 'project-snlive'
# };
# svnArray.append(svnInfo);
#
# svnInfo = {
#     'svnUrl': 'http://d.svncode.cnsuning.com/svn/snhibuy/branches/snhibuy_V2.0.0/src/5.7.0',
#     'project': 'project-snhibuy'
# };
# svnArray.append(svnInfo);
#
# svnInfo = {
#     'svnUrl': 'http://e.svncode.cnsuning.com/svn/snpmpg/branches/snpmpg_V1.1.0',
#     'project': 'project-snpingou'
# };
# svnArray.append(svnInfo);

def getTimeStamp(dateTimeString, format):
    #转换成时间数组
    timeArray = time.strptime(dateTimeString, format)
    #转换成时间戳
    timestamp = time.mktime(timeArray)
    return long(timestamp)

for svnInfo in svnArray:
    print svnInfo["project"]
    print svnInfo["svnUrl"]

    project = svnInfo["project"]
    svnUrl = svnInfo["svnUrl"]

    array = svnUrl.split('/')
    svnProject = array[len(array) - 1]
    print(svnProject)

    projectDirectory = cwd + '/' + project
    print projectDirectory

    resultDirectory = cwd + '/' + project + '-changed'
    if not os.path.exists(resultDirectory):
        print 'mkdir ' + resultDirectory
        os.mkdir(resultDirectory)

    # 更新svn
    print 'check out svn'
    if os.path.exists(projectDirectory):
        os.chdir(projectDirectory)
        commond = 'svn up --username=' + svnName + ' --password=' + svnPassword
        print commond
        os.system(commond)
    else:
        commond = 'svn co ' + svnUrl + ' ' + projectDirectory + ' --username=' + svnName + ' --password=' + svnPassword
        print commond
        os.system(commond)

    os.chdir(projectDirectory)

    # 获取日志
    print 'get log'
    commond = 'svn log -v --username=' + svnName + ' --password=' + svnPassword
    print commond
    process = os.popen(commond)
    output = process.read()
    # print output
    process.close()

    userDict = {}
    version = ''
    originalVersion = ''
    logDate = ''

    array = output.split('------------------------------------------------------------------------')
    logStartDateStamp = 0
    if logStartDate != '':
        logStartDateStamp = getTimeStamp(logStartDate, '%Y-%m-%d')
    logEndDateStamp = 0
    if logEndDate != '':
        logEndDateStamp = getTimeStamp(logEndDate, '%Y-%m-%d')
    logDateStamp = 0
    print ("logStartDateStamp:%f"%(logStartDateStamp))
    print ("logEndDateStamp:%f" %(logEndDateStamp))

    for log in array:
        user = ''
        fileArray = []

        lineArray = log.split('\n')
        for line in lineArray:
            # r181826 | 14121612 | 2017-11-06 17:53:40 +0800 (一, 06 11 2017) | 1 line
            infoArray = line.split('|')
            if len(infoArray) == 4:
                # print line
                infoArray = line.split('|')
                user = infoArray[1]
                user = user.replace(' ', '')
                # print 'user:'+user
                if userDict.has_key(user):
                    fileArray = userDict[user]
                else:
                    userDict[user] = fileArray

                # 提交版本
                version = infoArray[0]
                version.replace(' ', '')

                # 提交日期
                logDate = infoArray[2]
                if len(logDate) > 11:
                    logDate = logDate[1:11]
                    logDateStamp = getTimeStamp(logDate, '%Y-%m-%d')
                else:
                    logDateStamp = 0
            elif '/' in line and svnProject in line:
                # logDate
                if logDateStamp == 0:
                    print 'skip with date:'+logDate
                    continue;
                if logStartDateStamp!=0 and logDateStamp<logStartDateStamp:
                    print 'skip with date:'+logDate+'  reason:start Date:'+logStartDate
                    continue
                if logEndDateStamp!=0 and logDateStamp>logEndDateStamp:
                    print 'skip with date:'+logDate+'  reason:end Date:'+logEndDate
                    continue

                # 修改的文件
                tmpArray = line.split('/')
                if svnProject in tmpArray:
                    index = tmpArray.index(svnProject)
                    if index > 0:
                        del tmpArray[0:index+1]
                        changeFile = '/'.join(tmpArray)
                        if ' (from ' in changeFile:
                            index = changeFile.index(' (from ')
                            changeFile = changeFile[0:index]
                            # print 'changeFile:' + changeFile
                        # print 'changeFile:'+changeFile
                        if changeFile not in fileArray:
                            # print 'changeFile:'+changeFile
                            fileArray.append(changeFile)

                        # 最初的提交版本
                        originalVersion = version

    # 处理最新版本数据
    print 'cp newest files'
    items = userDict.items()
    for user, fileArray in items:
        print 'user:' + user
        userDirectory = resultDirectory + '/' + user
        if not os.path.exists(userDirectory):
            print 'mkdir ' + userDirectory
            os.mkdir(userDirectory)

        for changeFile in fileArray:
            print 'changeFile:' + changeFile
            tmpArray = changeFile.split('/')

            fileName = tmpArray[len(tmpArray) - 1]
            if '.' in fileName:
                index = fileName.index('.')
                fileName = fileName[0:index]
            targetDirectory = userDirectory + '/' + fileName
            if not os.path.exists(targetDirectory):
                os.mkdir(targetDirectory)

            targetFile = targetDirectory + '/' + tmpArray[len(tmpArray) - 1]
            sourceFile = cwd + '/' + project + '/' + changeFile
            print 'targetFile:' + targetFile
            print 'sourceFile:' + sourceFile
            if os.path.exists(sourceFile) and not os.path.isdir(sourceFile) and not os.path.exists(targetFile):
                open(targetFile, "wb").write(open(sourceFile, "rb").read())

    os.chdir(projectDirectory)
    print 'originalVersion:' + originalVersion
    commond = 'svn up -r ' + originalVersion + ' --username=' + svnName + ' --password=' + svnPassword
    print commond
    os.system(commond)

    # 处理最初版本数据
    print 'cp oldest files'
    for user, fileArray in items:
        print 'user:' + user
        userDirectory = resultDirectory + '/' + user
        if not os.path.exists(userDirectory):
            print 'mkdir ' + userDirectory
            os.mkdir(userDirectory)

        for changeFile in fileArray:
            print 'changeFile:' + changeFile
            tmpArray = changeFile.split('/')

            fileName = tmpArray[len(tmpArray) - 1]
            if '.' in fileName:
                index = fileName.index('.')
                fileName = fileName[0:index]
            targetDirectory = userDirectory + '/' + fileName
            if not os.path.exists(targetDirectory):
                os.mkdir(targetDirectory)

            targetFile = targetDirectory + '/old_' + tmpArray[len(tmpArray) - 1]
            sourceFile = cwd + '/' + project + '/' + changeFile
            print 'targetFile:' + targetFile
            print 'sourceFile:' + sourceFile
            if os.path.exists(sourceFile) and not os.path.isdir(sourceFile) and not os.path.exists(targetFile):
                open(targetFile, "wb").write(open(sourceFile, "rb").read())

